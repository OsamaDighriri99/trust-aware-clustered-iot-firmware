/*============================================================================
 * OSCORE Real Cryptographic Primitives
 * Replaces placeholder XOR implementations with real AES-CCM-16-64-128 and HKDF-SHA256
 *
 * Paper 6 Eq. 13-14: AES-CCM with IND-CCA2 + SUF-CMA
 * Paper 6 Eq. 1-2: HKDF-Expand per RFC 5869 / RFC 8613
 *
 * This file provides inline helper functions used by all 3 node types.
 * Include order: after OSCORE defines, before oscore_protect_message
 *============================================================================*/

#ifndef OSCORE_CRYPTO_REAL_H
#define OSCORE_CRYPTO_REAL_H

/*----------------------------------------------------------------------------
 * VERIFICATION STATUS — known-answer tests (KATs)
 *   The primitives below were validated against standard published vectors:
 *     - AES-128 block    : FIPS-197 Appendix C.1     PASS
 *     - SHA-256          : NIST "abc" vector          PASS
 *     - HMAC-SHA256      : RFC 4231 Test Case 1       PASS
 *     - HKDF-Expand      : RFC 5869 Test Case 1       PASS
 *   => AES-CCM-16-64-128 and HKDF-SHA256 in this codebase are built on
 *      standards-correct primitives, not placeholders.
 *
 * ARCHITECTURE (intentional — keeps this header a self-contained PRIMITIVES
 * library): the full AEAD (aes_ccm_encrypt/decrypt = CTR + CBC-MAC) and the
 * full HKDF (extract+expand, hkdf_sha256) are assembled ON TOP of these
 * primitives inside each node's .c file. They are deliberately NOT duplicated
 * here: those .c definitions are unguarded `static` functions, so defining
 * them here too would cause redefinition errors. This header owns the
 * primitives; the .c files own the AEAD assembly.
 *
 * DOCUMENTED INPUT BOUNDS (sufficient for OSCORE's small inputs):
 *     - sha256_hash       : message up to 240 bytes (buf[256], see cap)
 *     - hmac_sha256       : message truncated at 128 bytes
 *     - hkdf_expand_sha256: info up to 62 bytes, output up to 32 bytes (1 block)
 *--------------------------------------------------------------------------*/

/* FIX #4: IMPORTANT INCLUSION NOTE
 * oscore_crypto.h uses static const for large tables (aes_sbox = 256 B,
 * sha256_k = 256 B). If this header is included in more than one .c file
 * each translation unit gets its own copy, wasting ~512+ bytes of ROM.
 * In the current merged architecture (client.c, cluster.c, edge.c are
 * compiled separately), this is unavoidable without a separate .c file.
 * Each node runs one binary, so duplication does not occur at link time.
 * If you ever link multiple node types into one binary, move the tables
 * to a oscore_crypto.c and expose only declarations here. */

/*--------------------------------------------------------------------------
 * AES-128 S-Box (used by both AES-CCM and SHA-256)
 *------------------------------------------------------------------------*/
static const uint8_t aes_sbox[256] = {
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
};

static const uint8_t aes_rcon[11] = {
    0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36
};

/*--------------------------------------------------------------------------
 * AES-128 Key Expansion: expands 16-byte key to 176-byte round keys
 *------------------------------------------------------------------------*/
static void aes128_expand_key(const uint8_t *key, uint8_t *rk) {
    uint16_t i, j;
    memcpy(rk, key, 16);
    for (i = 1; i <= 10; i++) {
        uint8_t temp[4];
        memcpy(temp, &rk[(i-1)*16 + 12], 4);
        uint8_t t = temp[0];
        temp[0] = aes_sbox[temp[1]] ^ aes_rcon[i];
        temp[1] = aes_sbox[temp[2]];
        temp[2] = aes_sbox[temp[3]];
        temp[3] = aes_sbox[t];
        for (j = 0; j < 16; j++) {
            rk[i*16 + j] = rk[(i-1)*16 + j] ^ ((j < 4) ? temp[j] : rk[i*16 + j - 4]);
        }
    }
}

/*--------------------------------------------------------------------------
 * AES-128 Encrypt Block: encrypts 16 bytes in-place using expanded round keys
 *------------------------------------------------------------------------*/
#define AES_XTIME(x) (((x)<<1) ^ ((((x)>>7)&1)*0x1b))

static void aes128_encrypt_block(uint8_t *blk, const uint8_t *rk) {
    uint8_t i, t;
    /* Initial AddRoundKey */
    for (i = 0; i < 16; i++) blk[i] ^= rk[i];
    
    for (uint8_t round = 1; round <= 10; round++) {
        /* SubBytes */
        for (i = 0; i < 16; i++) blk[i] = aes_sbox[blk[i]];
        /* ShiftRows */
        t=blk[1]; blk[1]=blk[5]; blk[5]=blk[9]; blk[9]=blk[13]; blk[13]=t;
        t=blk[2]; blk[2]=blk[10]; blk[10]=t; t=blk[6]; blk[6]=blk[14]; blk[14]=t;
        t=blk[15]; blk[15]=blk[11]; blk[11]=blk[7]; blk[7]=blk[3]; blk[3]=t;
        /* MixColumns (skip on last round) */
        /* FIX #3: Layout note: AES state stored column-major here:
         * blk[c*4 + r] = state[column c][row r]. This is consistent
         * with ShiftRows above which shifts within rows across columns.
         * Do NOT change to row-major (blk[r*4+c]) — that would break
         * compatibility with the ShiftRows step above. */
        if (round < 10) {
            for (uint8_t c = 0; c < 4; c++) {
                uint8_t *col = &blk[c*4];
                uint8_t a0=col[0], a1=col[1], a2=col[2], a3=col[3];
                uint8_t x = a0^a1^a2^a3;
                col[0] ^= AES_XTIME(a0^a1) ^ x;
                col[1] ^= AES_XTIME(a1^a2) ^ x;
                col[2] ^= AES_XTIME(a2^a3) ^ x;
                col[3] ^= AES_XTIME(a3^a0) ^ x;
            }
        }
        /* AddRoundKey */
        for (i = 0; i < 16; i++) blk[i] ^= rk[round*16 + i];
    }
}

/*--------------------------------------------------------------------------
 * SHA-256 Implementation (for HKDF-SHA256)
 *------------------------------------------------------------------------*/
static const uint32_t sha256_k[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};

#define SHA_ROTR(x,n)  (((x)>>(n))|((x)<<(32-(n))))
#define SHA_CH(x,y,z)  (((x)&(y))^((~(x))&(z)))
#define SHA_MAJ(x,y,z) (((x)&(y))^((x)&(z))^((y)&(z)))
#define SHA_EP0(x)  (SHA_ROTR(x,2)^SHA_ROTR(x,13)^SHA_ROTR(x,22))
#define SHA_EP1(x)  (SHA_ROTR(x,6)^SHA_ROTR(x,11)^SHA_ROTR(x,25))
#define SHA_SIG0(x) (SHA_ROTR(x,7)^SHA_ROTR(x,18)^((x)>>3))
#define SHA_SIG1(x) (SHA_ROTR(x,17)^SHA_ROTR(x,19)^((x)>>10))

/* SHA-256 hash: msg up to 240 bytes (safely capped), outputs 32-byte digest */
static void sha256_hash(const uint8_t *msg, uint16_t msg_len, uint8_t *digest) {
    uint32_t h[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                     0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    
    /* FIX #1: Buffer sizing relationship documented:
     * buf[256] holds padded SHA-256 blocks. With 256 bytes, the maximum
     * padded_len = ((240+9+63)/64)*64 = 256, which exactly fits buf[256].
     * Safety cap at 240 ensures padded_len never exceeds 256 bytes.
     * DO NOT raise the cap above 240 without also enlarging buf. */
    uint8_t buf[256]; /* supports up to 240-byte messages (see cap below) */
    memset(buf, 0, sizeof(buf));
    if (msg_len > 240) msg_len = 240; /* safety cap: padded_len max = 256 = sizeof(buf) */
    memcpy(buf, msg, msg_len);
    buf[msg_len] = 0x80;
    uint16_t padded_len = ((msg_len + 9 + 63) / 64) * 64;
    uint64_t bit_len = (uint64_t)msg_len * 8;
    buf[padded_len - 1] = (uint8_t)(bit_len);
    buf[padded_len - 2] = (uint8_t)(bit_len >> 8);
    buf[padded_len - 3] = (uint8_t)(bit_len >> 16);
    buf[padded_len - 4] = (uint8_t)(bit_len >> 24);
    buf[padded_len - 5] = (uint8_t)(bit_len >> 32);
    buf[padded_len - 6] = (uint8_t)(bit_len >> 40);
    buf[padded_len - 7] = (uint8_t)(bit_len >> 48);
    buf[padded_len - 8] = (uint8_t)(bit_len >> 56);
    
    for (uint16_t blk = 0; blk < padded_len; blk += 64) {
        uint32_t w[64];
        for (uint8_t i = 0; i < 16; i++) {
            w[i] = ((uint32_t)buf[blk+i*4]<<24) | ((uint32_t)buf[blk+i*4+1]<<16) |
                   ((uint32_t)buf[blk+i*4+2]<<8) | (uint32_t)buf[blk+i*4+3];
        }
        for (uint8_t i = 16; i < 64; i++) {
            w[i] = SHA_SIG1(w[i-2]) + w[i-7] + SHA_SIG0(w[i-15]) + w[i-16];
        }
        uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hv=h[7];
        for (uint8_t i = 0; i < 64; i++) {
            uint32_t t1 = hv + SHA_EP1(e) + SHA_CH(e,f,g) + sha256_k[i] + w[i];
            uint32_t t2 = SHA_EP0(a) + SHA_MAJ(a,b,c);
            hv=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
        }
        h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=hv;
    }
    
    for (uint8_t i = 0; i < 8; i++) {
        digest[i*4]   = (uint8_t)(h[i]>>24);
        digest[i*4+1] = (uint8_t)(h[i]>>16);
        digest[i*4+2] = (uint8_t)(h[i]>>8);
        digest[i*4+3] = (uint8_t)(h[i]);
    }
}

/* HMAC-SHA256: key up to 64 bytes, msg up to 128 bytes, outputs 32 bytes */
static void hmac_sha256(const uint8_t *key, uint8_t key_len,
                        const uint8_t *msg, uint16_t msg_len,
                        uint8_t *mac) {
    uint8_t k_pad[64];
    memset(k_pad, 0, 64);
    if (key_len <= 64) {
        memcpy(k_pad, key, key_len);
    } else {
        sha256_hash(key, key_len, k_pad); /* hash key if > 64 bytes */
    }
    
    /* FIX #2: Message truncation limit documented. hmac_sha256 silently
     * discards msg bytes > 128. For HKDF-SHA256 (RFC 5869) usage in this
     * codebase, OSCORE key derivation inputs are always <= 64 bytes, so
     * this limit is never hit in practice. If you need longer HMAC inputs,
     * enlarge inner[] and raise the copy_len cap accordingly. */
    /* Inner hash: SHA256((K XOR ipad) || msg) */
    uint8_t inner[192]; /* 64 (k_pad xor ipad) + up to 128 bytes of message */
    for (uint8_t i = 0; i < 64; i++) inner[i] = k_pad[i] ^ 0x36;
    uint16_t copy_len = (msg_len > 128) ? 128 : msg_len; /* 128-byte limit: see FIX #2 */
    memcpy(&inner[64], msg, copy_len);
    
    uint8_t inner_hash[32];
    sha256_hash(inner, 64 + copy_len, inner_hash);
    
    /* Outer hash: SHA256((K XOR opad) || inner_hash) */
    uint8_t outer[96]; /* 64 + 32 */
    for (uint8_t i = 0; i < 64; i++) outer[i] = k_pad[i] ^ 0x5c;
    memcpy(&outer[64], inner_hash, 32);
    
    sha256_hash(outer, 96, mac);
}

/*--------------------------------------------------------------------------
 * HKDF-Expand (RFC 5869, Section 2.3) — used in OSCORE key derivation
 * FIX context: Ensures derived keys for OSCORE counters are cryptographically
 * independent (supports FIX #05 tx_protected/rx_verified separation).
 * Input:  prk (pseudorandom key, 32 bytes), info, info_len
 * Output: okm (output key material, okm_len bytes, max 32)
 *------------------------------------------------------------------------*/
static void hkdf_expand_sha256(const uint8_t *prk,
                                const uint8_t *info, uint8_t info_len,
                                uint8_t *okm, uint8_t okm_len) {
    if (okm_len == 0 || okm_len > 32) return;
    /* T(1) = HMAC-SHA256(PRK, "" || info || 0x01) */
    uint8_t msg[64];
    uint8_t msg_len = 0;
    if (info && info_len > 0 && info_len <= 62) {
        memcpy(msg, info, info_len);
        msg_len = info_len;
    }
    msg[msg_len++] = 0x01;
    uint8_t t[32];
    hmac_sha256(prk, 32, msg, msg_len, t);
    memcpy(okm, t, okm_len);
}

/*--------------------------------------------------------------------------
 * AES-128-CTR stream cipher — used by secure_encrypt/secure_decrypt
 * (AES counter mode: no padding, length-preserving, deterministic)
 *
 * FIX: Wrapped in #ifndef AES_128_CTR_CRYPT_DEFINED so that source files
 * which supply their own local definition (e.g. edge.c) are not broken by
 * a conflicting duplicate. Define AES_128_CTR_CRYPT_DEFINED before
 * including oscore_crypto.h to suppress this copy entirely.
 *------------------------------------------------------------------------*/
#ifndef AES_128_CTR_CRYPT_DEFINED
#define AES_128_CTR_CRYPT_DEFINED
static int aes_128_ctr_crypt(const uint8_t *key, const uint8_t *iv,
                              const void *in, void *out, uint16_t len) {
    if (!key || !iv || !in || !out || len == 0) return -1;

    uint8_t rk[176];
    aes128_expand_key(key, rk);

    uint8_t counter[16];
    memcpy(counter, iv, 16);   /* IV is the initial counter block */

    const uint8_t *src = (const uint8_t *)in;
    uint8_t       *dst = (uint8_t *)out;

    uint16_t offset = 0;
    while (offset < len) {
        /* Encrypt counter block to get keystream */
        uint8_t ks[16];
        memcpy(ks, counter, 16);
        aes128_encrypt_block(ks, rk);

        /* XOR keystream with plaintext/ciphertext */
        uint16_t blk_len = (len - offset > 16) ? 16 : (len - offset);
        for (uint16_t i = 0; i < blk_len; i++) {
            dst[offset + i] = src[offset + i] ^ ks[i];
        }
        offset += blk_len;

        /* Increment counter (big-endian, last 4 bytes) */
        for (int8_t b = 15; b >= 12; b--) {
            if (++counter[b] != 0) break;
        }
    }
    return 0;
}
#endif /* AES_128_CTR_CRYPT_DEFINED */

/*--------------------------------------------------------------------------
 * FIX #05 / RegB: OSCORE COUNTER VALIDATION HELPERS
 * Root cause (edge.c): verified > protected because:
 *   (a) oscore_messages_verified++ fired on EVERY received plain-text message
 *       in udp_rx_callback, not just authenticated OSCORE messages (RegB-2).
 *   (b) oscore_messages_protected was double-counted — enhanced_send_protocol_message
 *       incremented edge_state.security_metrics.oscore_messages_protected on top
 *       of the increment already inside oscore_udp_sendto (RegB-3).
 *       RegB-3 fix: removed the redundant increment from enhanced_send so only
 *       oscore_udp_sendto increments the counter.
 *   (c) edge_state.total_messages was incremented twice per passthrough (RegB-1).
 * All three root causes were fixed at the call sites in edge.c.
 *
 * FIX New-5 (session 13): After RegB-3, oscore_udp_sendto incremented the
 * INTERNAL context counter (global_oscore_ctx.mqtt_context.messages_protected)
 * but NOT the HIGH-LEVEL edge_state.security_metrics.oscore_messages_protected
 * counter that the OSCORE maintenance log reads from.  This caused protected_tx
 * to freeze at 46 after the first batch.
 * Fix: oscore_udp_sendto now increments BOTH counters on every successful
 * protection — this is NOT double-counting because they are two different
 * variables serving different purposes (low-level context stats vs high-level
 * security metrics).  enhanced_send still does NOT increment either counter.
 *
 * Counter semantics post all fixes:
 *   tx_protected  = messages THIS node sent with OSCORE protection
 *   rx_verified   = messages THIS node received and successfully authenticated
 * A return of 0 from oscore_counters_sane() should trigger a LOG_WARN.
 *--------------------------------------------------------------------------*/

/**
 * Validate OSCORE counter separation.
 * Returns 1 if the counters are semantically consistent (neither is
 * obviously contaminated by the other's events), 0 if suspicious.
 * A return of 0 should trigger a LOG_WARN in the caller.
 *
 * @param tx_protected  Count of outgoing OSCORE-protected messages
 * @param rx_verified   Count of incoming OSCORE-verified messages
 * @param total_msgs    Total messages processed (both directions)
 */
static inline int oscore_counters_sane(uint32_t tx_protected,
                                       uint32_t rx_verified,
                                       uint32_t total_msgs) {
    /* Neither counter should exceed total activity */
    if (tx_protected > total_msgs) return 0;
    if (rx_verified  > total_msgs) return 0;
    /* Sum should not exceed total (they are independent channels) */
    if (tx_protected + rx_verified > total_msgs * 2) return 0;
    return 1;
}

/*--------------------------------------------------------------------------
 * FIX #06/#16: OSCORE SECURITY REPORT COUNTER MERGER
 * Issue: Encrypted Messages = 0 and Key Rotations = 0 in all 170
 *        Adaptive-Client reports because the Security Status Report read
 *        from local counters (never incremented) instead of OSCORE subsystem.
 * Fix:  Security reports must add the OSCORE subsystem counters to local ones.
 *       These inline helpers compute the merged totals.
 *--------------------------------------------------------------------------*/

/**
 * Compute the merged "Encrypted Messages" total for the Security Status Report.
 * = AES-layer encrypted count (legacy) + OSCORE TX protected count (modern).
 *
 * @param aes_encrypted        Local AES-only encrypted_messages counter
 * @param oscore_tx_protected  OSCORE subsystem oscore_messages_protected counter
 */
static inline uint32_t security_report_encrypted_total(uint32_t aes_encrypted,
                                                        uint32_t oscore_tx_protected) {
    return aes_encrypted + oscore_tx_protected;
}

/**
 * Compute the merged "Key Rotations" total for the Security Status Report.
 * = local key_rotations + OSCORE subsystem key rotation count.
 *
 * @param local_rotations   Local security_metrics.key_rotations counter
 * @param oscore_rotations  OSCORE subsystem oscore_key_rotations counter
 */
static inline uint32_t security_report_key_rotations_total(uint32_t local_rotations,
                                                            uint32_t oscore_rotations) {
    return local_rotations + oscore_rotations;
}

/* Version note: v3.4 (session 13) — FIX New-5 comment above (line ~294) updated.
 * oscore_udp_sendto now correctly increments BOTH the internal context counter
 * (global_oscore_ctx.mqtt_context.messages_protected) AND the high-level
 * edge_state.security_metrics.oscore_messages_protected on every successful
 * protection.  These are two different variables; incrementing both is NOT
 * double-counting.  The RegB-3 fix removed the extra increment from
 * enhanced_send_protocol_message (which was the true double-count source). */

#endif /* OSCORE_CRYPTO_REAL_H */
