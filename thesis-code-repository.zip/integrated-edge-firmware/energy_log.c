/* ENERGY_LOG.C -- see energy_log.h */
#include "contiki.h"
#include "sys/energest.h"
#include "sys/node-id.h"
#include <stdio.h>
#include "energy_log.h"

#ifndef RAISEF_NRG_LOG
#define RAISEF_NRG_LOG 1
#endif
#ifndef RAISEF_NRG_PERIOD
#define RAISEF_NRG_PERIOD (60 * CLOCK_SECOND)
#endif

#if RAISEF_NRG_LOG
PROCESS(energy_log_process, "RAISEF energy log");

PROCESS_THREAD(energy_log_process, ev, data)
{
    static struct etimer et;
    PROCESS_BEGIN();
    etimer_set(&et, RAISEF_NRG_PERIOD);
    while (1) {
        PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));
        etimer_reset(&et);
        energest_flush();
        printf("DLNRG,node=%u,cpu=%llu,lpm=%llu,tx=%llu,rx=%llu,sec=%lu\n",
               (unsigned)node_id,
               (unsigned long long)energest_type_time(ENERGEST_TYPE_CPU),
               (unsigned long long)energest_type_time(ENERGEST_TYPE_LPM),
               (unsigned long long)energest_type_time(ENERGEST_TYPE_TRANSMIT),
               (unsigned long long)energest_type_time(ENERGEST_TYPE_LISTEN),
               (unsigned long)ENERGEST_SECOND);
    }
    PROCESS_END();
}
#endif

void energy_log_start(void)
{
#if RAISEF_NRG_LOG
    static uint8_t started = 0;
    if (!started) {
        started = 1;
        process_start(&energy_log_process, NULL);
    }
#endif
}
