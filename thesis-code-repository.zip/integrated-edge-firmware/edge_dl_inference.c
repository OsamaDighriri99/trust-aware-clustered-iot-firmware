/*******************************************************************************
 * EDGE_DL_INFERENCE.C -- CNN-LSTM trust forecaster forward pass (float32).
 *
 * Mirrors python/reference_model.py exactly:
 *   Conv1D(valid)+ReLU -> Conv1D(valid)+ReLU -> LSTM(last h) -> concat scalars
 *   -> Dense+ReLU -> Dense+sigmoid.
 *   LSTM gate order [i,f,c,o], recurrent activation sigmoid, cell tanh.
 * Verified numerically against the NumPy reference (test_dl_main.c).
 ******************************************************************************/
#include <math.h>
#include <stdint.h>
#include "edge_dl_inference.h"
#include "dl_model_weights.h"

static float dl_relu(float x)    { return x > 0.0f ? x : 0.0f; }
static float dl_sigmoid(float x) { return 1.0f / (1.0f + expf(-x)); }

/* Conv1D valid: in[Lin][Cin], w[K][Cin][F], b[F] -> out[Lin-K+1][F] (+ReLU) */
static void dl_conv1d(const float *in, int Lin, int Cin,
                      const float *w, const float *b, int K, int F,
                      float *out)
{
    int Lout = Lin - K + 1;
    for (int t = 0; t < Lout; t++) {
        for (int f = 0; f < F; f++) {
            float acc = b[f];
            for (int k = 0; k < K; k++) {
                for (int c = 0; c < Cin; c++) {
                    float xv = in[(t + k) * Cin + c];
                    float wv = w[(k * Cin + c) * F + f];   /* [K,Cin,F] */
                    acc += xv * wv;
                }
            }
            out[t * F + f] = dl_relu(acc);
        }
    }
}

/* LSTM last hidden state. x[T][Cin], Wk[Cin][4U], Uk[U][4U], bk[4U] */
static void dl_lstm_last(const float *x, int T, int Cin,
                         const float *Wk, const float *Uk, const float *bk,
                         int units, float *h_out)
{
    float h[DL_U] = {0}, c[DL_U] = {0}, z[4 * DL_U];
    for (int t = 0; t < T; t++) {
        for (int j = 0; j < 4 * units; j++) {
            float acc = bk[j];
            for (int a = 0; a < Cin;   a++) acc += x[t * Cin + a] * Wk[a * (4 * units) + j];
            for (int a = 0; a < units; a++) acc += h[a]           * Uk[a * (4 * units) + j];
            z[j] = acc;
        }
        for (int u = 0; u < units; u++) {
            float i = dl_sigmoid(z[u]);
            float f = dl_sigmoid(z[units + u]);
            float g = tanhf(z[2 * units + u]);
            float o = dl_sigmoid(z[3 * units + u]);
            c[u] = f * c[u] + i * g;
            h[u] = o * tanhf(c[u]);
        }
    }
    for (int u = 0; u < units; u++) h_out[u] = h[u];
}

float dl_forward(const float *seq, const float *scalars)
{
    float c1[DL_L1 * DL_F1];
    float c2[DL_L2 * DL_F2];
    float hlast[DL_U];
    float cat[DL_U + DL_NS];
    float d1[DL_H];

    dl_conv1d(seq, DL_W, DL_CIN, DLW_c1w, DLW_c1b, DL_K1, DL_F1, c1);
    dl_conv1d(c1,  DL_L1, DL_F1, DLW_c2w, DLW_c2b, DL_K2, DL_F2, c2);
    dl_lstm_last(c2, DL_L2, DL_F2, DLW_lw, DLW_lu, DLW_lb, DL_U, hlast);

    for (int u = 0; u < DL_U; u++)  cat[u] = hlast[u];
    for (int s = 0; s < DL_NS; s++) cat[DL_U + s] = scalars[s];

    for (int j = 0; j < DL_H; j++) {              /* Dense1 + ReLU */
        float acc = DLW_d1b[j];
        for (int a = 0; a < DL_U + DL_NS; a++) acc += cat[a] * DLW_d1w[a * DL_H + j];
        d1[j] = dl_relu(acc);
    }
    float acc = DLW_d2b[0];                        /* Dense2 + sigmoid */
    for (int a = 0; a < DL_H; a++) acc += d1[a] * DLW_d2w[a];
    return dl_sigmoid(acc);
}

float dl_predict_trust_window(const float *trend_window,
                              uint8_t window_index, uint8_t count,
                              float trust_ema, float trust_slope,
                              float trust_acceleration, float proactive_risk,
                              float device_trust, float cluster_trust)
{
    float seq[DL_W];
    float scalars[DL_NS];
    int i, n, pad;

    /* Use the last n = min(count, DL_W) samples oldest->newest, exactly as
     * edge.c reads its circular window: idx = (window_index - n + i) mod DL_W.
     * Left-pad any shortfall with the EMA so the model always sees DL_W steps. */
    n = (count < DL_W) ? (int)count : DL_W;
    pad = DL_W - n;
    for (i = 0; i < pad; i++) {
        seq[i] = trust_ema;
    }
    for (i = 0; i < n; i++) {
        int idx = ((int)window_index - n + i + DL_W) % DL_W;
        seq[pad + i] = trend_window[idx];
    }

    scalars[0] = trust_ema;
    scalars[1] = trust_slope;
    scalars[2] = trust_acceleration;
    scalars[3] = proactive_risk;
    scalars[4] = device_trust;
    scalars[5] = cluster_trust;
    return dl_forward(seq, scalars);
}
