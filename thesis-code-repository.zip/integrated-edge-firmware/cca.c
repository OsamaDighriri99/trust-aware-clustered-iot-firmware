/*******************************************************************************
 * CCA.C -- Cluster-Consensus Authority (SurvivEdge sec.IV-A)
 *
 * RECONSTRUCTION of the published design. Compiled INTO the cluster binary.
 *
 * Byzantine-resilient leader election so the cluster centres can re-orchestrate
 * Tier-1 authority after edge-root compromise:
 *   Phase 1  suspicion accumulation: Sigma += [D > delta_sus]; reset on a valid
 *            current-epoch policy update. Election starts at Sigma >= Sigma_alert.
 *   Phase 2  two-message election: VoteRequest -> VoteGrant. A candidate wins on
 *            reaching the BFT quorum q_BFT = ceil((N_CC+f+1)/2) = 7  (N_CC=10,f=3),
 *            safe for f < N_CC/3 Byzantine CCs (Theorem CCA-Safety).
 *   Phase 3  authority transfer: winner increments the epoch (invalidating the
 *            compromised node's material) and broadcasts AuthorityTransfer;
 *            followers hold-last-valid until the first update from c*.
 *
 * Networking (UDP send, peer addressing) is owned by cluster.c; this module
 * provides the protocol logic and message build/parse.
 *
 * VERIFICATION (published parameters & logic):
 *   - Constants match the paper: N_CC=10, q_BFT=SE_CCA_QUORUM=7,
 *     Sigma_alert=SE_CCA_SIGMA_ALERT=3. q_BFT = ceil((N_CC+f+1)/2) = 7 with
 *     f=3, and f < N_CC/3 (3 < 3.33) so Theorem CCA-Safety's bound holds.
 *   - Logic checked with worked examples (exact functions):
 *       suspicion: election triggers exactly at Sigma=3; a valid policy update
 *                  resets Sigma to 0 (stops the election).
 *       election : candidate wins precisely on the 7th vote -> LEADER, with the
 *                  epoch incremented (invalidates the compromised material).
 *
 * TWO ITEMS TO CONFIRM AGAINST YOUR PAPER (left as-is, NOT silently changed):
 *   (1) QUORUM TEST: this code uses votes >= q_BFT (7 votes elect), matching
 *       the prose "seven votes meet q_BFT=7" and standard BFT (reaching the
 *       quorum suffices). Your Alg.CCA pseudocode writes "votes > q_BFT" (8).
 *       Keep '>=' (recommended) or switch to '>' to match the pseudocode.
 *   (2) SINGLE-GRANT-PER-EPOCH: cca_handle_vote_request() is a pure (const)
 *       check and does NOT itself dedupe voters / enforce one grant per epoch,
 *       which Theorem CCA-Safety relies on. It is deferred to the caller. To
 *       make it self-contained, a per-node file-static last-granted-epoch guard
 *       can be added here (each CC is its own binary) -- ask and I'll add it.
 ******************************************************************************/

#include "compatibility.h"
#include "contiki.h"
#include "contiki-net.h"
#include "dual_edge_types.h"
#include "timer_patch.h"
#include "sys/log.h"
#include "oscore_crypto.h"
#include "survivedge.h"
#include <string.h>

#define LOG_MODULE "CCA"
#ifndef LOG_LEVEL_CCA
#define LOG_LEVEL_CCA LOG_LEVEL_INFO
#endif
#define LOG_LEVEL LOG_LEVEL_CCA

void
cca_init(cca_state_t *st, uint8_t self_id, uint16_t epoch)
{
    if(st == NULL) {
        return;
    }
    memset(st, 0, sizeof(*st));
    st->self_id   = self_id;
    st->cur_epoch = epoch;
    st->role      = SE_ROLE_FOLLOWER;
}

/* Phase 1 ------------------------------------------------------------------ */

void
cca_note_alert(cca_state_t *st)
{
    if(st == NULL) {
        return;
    }
    if(st->sigma < 255) {
        st->sigma++;
    }
    LOG_DBG("suspicion Sigma=%u/%u\n", st->sigma, (unsigned)SE_CCA_SIGMA_ALERT);
}

void
cca_note_valid_policy(cca_state_t *st)
{
    if(st == NULL) {
        return;
    }
    /* A valid signed policy update from a current-epoch authority clears
     * suspicion (paper sec.IV-A, Phase 1). */
    st->sigma = 0;
}

uint8_t
cca_should_start_election(const cca_state_t *st)
{
    if(st == NULL) {
        return 0;
    }
    return (st->sigma >= SE_CCA_SIGMA_ALERT) ? 1 : 0;
}

/* Phase 2 ------------------------------------------------------------------ */

int
cca_build_vote_request(uint8_t *buf, uint16_t buflen, const cca_state_t *st)
{
    se_vote_request_t *m;
    uint8_t digest[32];
    uint8_t evidence[3];

    if(buf == NULL || st == NULL ||
       buflen < (uint16_t)(1 + sizeof(se_vote_request_t))) {
        return 0;
    }

    /* H(Sigma_i, D_i): hash the suspicion evidence, keep 4 bytes (paper). */
    evidence[0] = st->self_id;
    evidence[1] = st->sigma;
    evidence[2] = (uint8_t)(st->cur_epoch & 0xFF);
    sha256_hash(evidence, sizeof(evidence), digest);

    buf[0] = MSG_TYPE_SE_VOTE_REQUEST;
    m = (se_vote_request_t *)(buf + 1);
    m->cc_id = st->self_id;
    m->epoch = st->cur_epoch;
    memcpy(m->evidence_digest, digest, 4);

    return (int)(1 + sizeof(se_vote_request_t));
}

/* On receiving a VoteRequest: grant iff we have also reached Sigma_alert (i.e.
 * we independently suspect the edge root). 'payload' excludes the 1-byte tag. */
int
cca_handle_vote_request(const cca_state_t *st, const uint8_t *payload,
                        uint16_t len, uint8_t *out, uint16_t outlen)
{
    const se_vote_request_t *req;
    se_vote_grant_t *grant;

    if(st == NULL || payload == NULL || out == NULL ||
       len < sizeof(se_vote_request_t) ||
       outlen < (uint16_t)(1 + sizeof(se_vote_grant_t))) {
        return 0;
    }
    req = (const se_vote_request_t *)payload;

    /* Only same-epoch requests are valid; only grant if we also suspect.
     * An honest CC issues at most one grant per epoch -- that single-grant
     * invariant is what Theorem CCA-Safety relies on. Enforcement of "one per
     * epoch" is left to the caller's per-epoch guard (see cluster.c hook). */
    if(req->epoch != st->cur_epoch) {
        return 0;
    }
    if(st->sigma < SE_CCA_SIGMA_ALERT) {
        return 0;
    }

    out[0] = MSG_TYPE_SE_VOTE_GRANT;
    grant = (se_vote_grant_t *)(out + 1);
    grant->voter_id     = st->self_id;
    grant->candidate_id = req->cc_id;
    grant->epoch        = req->epoch;

    LOG_DBG("grant -> cand=%u epoch=%u\n", req->cc_id, req->epoch);
    return (int)(1 + sizeof(se_vote_grant_t));
}

/* On receiving a VoteGrant for us: tally and check the quorum.
 * RECON-CHOICE: the paper's prose ("seven honest votes meet q_BFT=7") implies a
 *   >= test while Alg.CCA writes "votes > q_BFT". We use >= SE_CCA_QUORUM so 7
 *   honest votes suffice. If you prefer the strict ">", change to '>' and set
 *   SE_CCA_QUORUM accordingly -- VERIFY against your paper's intended threshold. */
uint8_t
cca_handle_vote_grant(cca_state_t *st, const uint8_t *payload, uint16_t len)
{
    const se_vote_grant_t *g;

    if(st == NULL || payload == NULL || len < sizeof(se_vote_grant_t)) {
        return 0;
    }
    if(st->role != SE_ROLE_CANDIDATE) {
        return 0;
    }
    g = (const se_vote_grant_t *)payload;
    if(g->candidate_id != st->self_id || g->epoch != st->cur_epoch) {
        return 0;
    }

    if(st->votes < 255) {
        st->votes++;
    }

    if(st->votes >= SE_CCA_QUORUM) {
        st->role = SE_ROLE_LEADER;
        st->cur_epoch++;            /* invalidate compromised material */
        st->hold_last_valid = 1;    /* freeze promotions until first c* update */
        LOG_INFO("ELECTED leader: id=%u votes=%u new_epoch=%u\n",
                 st->self_id, st->votes, st->cur_epoch);
        return 1;
    }
    return 0;
}

/* Phase 3 ------------------------------------------------------------------ */

int
cca_build_authority_transfer(uint8_t *buf, uint16_t buflen,
                             const cca_state_t *st,
                             const uint8_t state_digest[32])
{
    se_authority_xfer_t *m;
    uint8_t phash[32];

    if(buf == NULL || st == NULL || state_digest == NULL ||
       buflen < (uint16_t)(1 + sizeof(se_authority_xfer_t))) {
        return 0;
    }

    buf[0] = MSG_TYPE_SE_AUTHORITY_XFER;
    m = (se_authority_xfer_t *)(buf + 1);
    m->new_authority_id = st->self_id;
    m->new_epoch        = st->cur_epoch;     /* already incremented on win */
    memcpy(m->state_digest, state_digest, 32);

    /* policy_hash: first 4 bytes of SHA-256 over the adopted state digest as a
     * stand-in for "hash of the first policy batch" (paper). */
    sha256_hash(state_digest, 32, phash);
    memcpy(m->policy_hash, phash, 4);

    return (int)(1 + sizeof(se_authority_xfer_t));
}

void
cca_handle_authority_transfer(cca_state_t *st, const uint8_t *payload,
                              uint16_t len)
{
    const se_authority_xfer_t *m;

    if(st == NULL || payload == NULL || len < sizeof(se_authority_xfer_t)) {
        return;
    }
    m = (const se_authority_xfer_t *)payload;

    /* Verify epoch monotonicity e* > e_cur (paper Alg.CCA follower step). */
    if(m->new_epoch <= st->cur_epoch) {
        LOG_WARN("reject AuthorityTransfer: epoch %u <= cur %u\n",
                 m->new_epoch, st->cur_epoch);
        return;
    }

    st->cur_epoch       = m->new_epoch;
    st->sigma           = 0;
    st->role            = SE_ROLE_FOLLOWER;
    st->votes           = 0;
    st->hold_last_valid = 1;        /* hold until first update from c* arrives */

    LOG_INFO("follow new authority id=%u epoch=%u (hold-last-valid)\n",
             m->new_authority_id, m->new_epoch);
}
