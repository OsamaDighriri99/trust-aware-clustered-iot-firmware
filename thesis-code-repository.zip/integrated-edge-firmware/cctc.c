/*******************************************************************************
 * CCTC.C -- Cross-Cluster Trust Continuity (SurvivEdge sec.IV-B)
 *
 * RECONSTRUCTION of the published design. Compiled INTO the cluster (and
 * available to edge_standby) binary.
 *
 * Replicates the security state needed for uninterrupted operation BEFORE it
 * is needed, so an elected authority assumes Tier-1 duties with no
 * re-provisioning delay:
 *   - each cycle every CC broadcasts a 32-byte SHA-256 digest of its local
 *     state (F||K||P||M||e)  (Eq. digest);
 *   - a receiver adopts state only on a supermajority (> N_CC/2) of matching
 *     digests, defeating a single corrupted broadcaster (R2 consistency);
 *   - on CC* promotion the four-step recovery R1..R4 runs, ending with an
 *     epoch increment that invalidates the compromised node's keys;
 *   - nonce continuity across failover uses S_failover = max(S_mqtt,S_coap,
 *     S_group) + Delta_safe, mirroring DE-C2 in edge_standby.c.
 *
 * The networking of R1 (StateRequest/Response) is driven by cluster.c, which
 * owns the UDP connection and peer table; this module supplies the digest,
 * the consistency logic, and the S_failover construction.
 *
 * VERIFICATION (published parameters & logic):
 *   - Digest uses sha256_hash() (validated against FIPS/NIST KAT vectors).
 *   - R2 supermajority = (agree > N_CC/2), counting self: checked with worked
 *     examples -- 5 agreeing (incl. self) is NOT consistent, 6 IS; peers whose
 *     digest differs are correctly excluded.
 *   - S_failover = max(s_mqtt,s_coap,s_group) + Delta_safe. Verified
 *     max(100,250,180)+64 = 314. Delta_safe == DE_NONCE_SAFETY_MARGIN (64), so
 *     this construction EXACTLY matches edge_standby.c's DE-C2 (er2_compute_
 *     s_failover) -- the CC* and ER1<->ER2 failover paths agree.
 *
 * SELF-CONTAINED: implementation here; cctc_state_t and SE_CCTC_* come from
 * survivedge.h (the module's own header). R1 networking is intentionally NOT
 * wired into cluster.c here. tau (digest cadence) is the caller's maintenance-
 * cycle timing, not a value this module itself needs.
 ******************************************************************************/

#include "compatibility.h"
#include "contiki.h"
#include "contiki-net.h"
#include "dual_edge_types.h"
#include "timer_patch.h"
#include "sys/log.h"
#include "oscore_crypto.h"
#include "survivedge.h"
#include <string.h>

#define LOG_MODULE "CCTC"
#ifndef LOG_LEVEL_CCTC
#define LOG_LEVEL_CCTC LOG_LEVEL_INFO
#endif
#define LOG_LEVEL LOG_LEVEL_CCTC

void
cctc_init(cctc_state_t *st, uint8_t self_id, uint16_t epoch)
{
    if(st == NULL) {
        return;
    }
    memset(st, 0, sizeof(*st));
    st->self_id = self_id;
    st->epoch   = epoch;
}

/* Eq. digest: H_i(t) = SHA-256(F || K || P || M || e). The caller serialises
 * its local state into state_buf (e.g. the de_replicated_context_t records plus
 * the epoch); we just hash it. */
void
cctc_compute_digest(const uint8_t *state_buf, uint16_t len, uint8_t out[32])
{
    if(state_buf == NULL || out == NULL) {
        if(out != NULL) {
            memset(out, 0, 32);
        }
        return;
    }
    sha256_hash(state_buf, len, out);
}

int
cctc_build_digest_msg(uint8_t *buf, uint16_t buflen, cctc_state_t *st,
                      const uint8_t *state_buf, uint16_t state_len)
{
    se_cctc_digest_t *m;

    if(buf == NULL || st == NULL ||
       buflen < (uint16_t)(1 + sizeof(se_cctc_digest_t))) {
        return 0;
    }

    cctc_compute_digest(state_buf, state_len, st->local_digest);

    buf[0] = MSG_TYPE_SE_CCTC_DIGEST;
    m = (se_cctc_digest_t *)(buf + 1);
    m->cc_id = st->self_id;
    m->epoch = st->epoch;
    memcpy(m->digest, st->local_digest, 32);

    return (int)(1 + sizeof(se_cctc_digest_t));
}

/* Record a peer's digest in our table (keyed by cc_id). Returns 1 if, after
 * recording, a supermajority of peers (plus ourselves) share our digest. */
uint8_t
cctc_on_peer_digest(cctc_state_t *st, const uint8_t *payload, uint16_t len)
{
    const se_cctc_digest_t *m;
    uint8_t i, slot = 0xFF;

    if(st == NULL || payload == NULL || len < sizeof(se_cctc_digest_t)) {
        return 0;
    }
    m = (const se_cctc_digest_t *)payload;

    /* Only same-epoch digests participate in the consistency check. */
    if(m->epoch != st->epoch) {
        return 0;
    }

    /* Find an existing slot for this cc_id, or a free one. */
    for(i = 0; i < SE_CCA_N_CC; i++) {
        if(st->peers[i].valid && st->peers[i].cc_id == m->cc_id) {
            slot = i;
            break;
        }
    }
    if(slot == 0xFF) {
        for(i = 0; i < SE_CCA_N_CC; i++) {
            if(!st->peers[i].valid) {
                slot = i;
                break;
            }
        }
    }
    if(slot == 0xFF) {
        return cctc_supermajority_consistent(st);   /* table full */
    }

    st->peers[slot].cc_id = m->cc_id;
    st->peers[slot].epoch = m->epoch;
    memcpy(st->peers[slot].digest, m->digest, 32);
    st->peers[slot].valid = 1;

    return cctc_supermajority_consistent(st);
}

/* R2: do we have > N_CC/2 peers (counting ourselves) whose digest equals ours? */
uint8_t
cctc_supermajority_consistent(const cctc_state_t *st)
{
    uint8_t i, agree = 1;       /* count ourselves */

    if(st == NULL) {
        return 0;
    }
    for(i = 0; i < SE_CCA_N_CC; i++) {
        if(st->peers[i].valid &&
           memcmp(st->peers[i].digest, st->local_digest, 32) == 0) {
            agree++;
        }
    }
    /* supermajority threshold: strictly more than half of N_CC */
    return (agree > (SE_CCA_N_CC / 2)) ? 1 : 0;
}

/* Eq. S_failover: resume sequence numbering strictly above every pre-failover
 * number across MQTT, CoAP, and Group OSCORE, plus the safety margin.
 * Mirrors er2_compute_s_failover() (DE-C2) so the cluster-tier CC* path and the
 * ER1<->ER2 path agree on the construction. */
uint64_t
cctc_compute_s_failover(uint64_t s_mqtt, uint64_t s_coap, uint64_t s_group)
{
    uint64_t m = s_mqtt;
    if(s_coap  > m) { m = s_coap;  }
    if(s_group > m) { m = s_group; }
    return m + (uint64_t)SE_CCTC_DELTA_SAFE;
}
