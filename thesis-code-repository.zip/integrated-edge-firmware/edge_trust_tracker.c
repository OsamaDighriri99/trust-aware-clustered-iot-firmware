/*******************************************************************************
 * EDGE_TRUST_TRACKER.C -- see edge_trust_tracker.h for the design.
 *
 * Log records (one per evaluated cluster per edge maintenance cycle; v5: all
 * values with 7 significant digits so training inputs equal deployed inputs):
 *   DLFEAT,scope=C,node=<id>,cyc=<c>,tw=<16 ';'-sep>,ema=..,slope=..,accel=..,
 *          risk=..,dtrust=..,ctrust=..,ctrust_now=..,ntrust=..,age=<s>
 *   DLPRED,node=<id>,cyc=<c>,mode=<DL|HEUR|NONE>,pred=..,cur=..
 *   DLEVT,node=<id>,cyc=<c>,type=ACCESS,from=<s>,to=<s>,mode=..
 *   DLEVT,node=<id>,cyc=<c>,type=REKEY_REQ,reason=<FORECAST|CURRENT>,mode=..
 * The Cooja log prefix supplies the simulation timestamp for lead-time metrics.
 ******************************************************************************/
#include "contiki.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "edge_trust_tracker.h"
#include "edge_dl_inference.h"

#ifndef RAISEF_DL_ENABLED
#define RAISEF_DL_ENABLED 0
#endif
/* 1 = forecast feeds the access cap (min rule); 0 = purely reactive cap. */
#ifndef RAISEF_ETT_PREDICT_ACCESS
#define RAISEF_ETT_PREDICT_ACCESS 1
#endif
#ifndef RAISEF_DL_HORIZON
#define RAISEF_DL_HORIZON 5
#endif
/* Dwell (hysteresis): a new access state must be observed for ETT_DWELL
 * consecutive cycles before it is committed. Needed because the Paper-8
 * reference thresholds put healthy clusters at the R = 0.055 boundary
 * (median benign risk ~0.06 in host tests), which otherwise flaps. */
#ifndef ETT_DWELL
#define ETT_DWELL 3
#endif
/* No enforcement/rekey during network bootstrap (staggered CC registration
 * + startup congestion). Must be < earliest attack onset (61). */
#ifndef ETT_WARMUP_CYCLES
#define ETT_WARMUP_CYCLES 45u
#endif
/* Forecast-confirmed downgrade (experimental, default OFF): a downgrade whose
 * current trust is still >= the Restricted gate is only committed if the
 * forecast also predicts a decline (pred < comp - ETT_CONFIRM_MARGIN). Aims to
 * cut benign flapping (a precision gain) without delaying real attacks. */
#ifndef RAISEF_ETT_CONFIRM
#define RAISEF_ETT_CONFIRM 0
#endif
#ifndef ETT_CONFIRM_MARGIN
#define ETT_CONFIRM_MARGIN 0.02f
#endif
#ifndef ETT_MIN_SAMPLES
#define ETT_MIN_SAMPLES 4
#endif
#ifndef ETT_EMA_ALPHA
#define ETT_EMA_ALPHA 0.3f
#endif
#ifndef ETT_W_DEV
#define ETT_W_DEV 0.40f
#endif
#ifndef ETT_W_CLUS
#define ETT_W_CLUS 0.35f
#endif
#ifndef ETT_W_NET
#define ETT_W_NET 0.25f
#endif
#ifndef ETT_TRUST_CRITICAL
#define ETT_TRUST_CRITICAL 0.30f
#endif
/* Edge cluster-level policy thresholds. Deliberately a SEPARATE namespace from
 * the CC's per-client TRACE thresholds (ML_ACCESS_*): calibrate_thresholds.py
 * calibrates ONLY these, so the CC's per-client policy is not silently changed.
 * Defaults = Paper-8 published values (replaced after Step 4 calibration). */
#ifndef ETT_T_FULL
#define ETT_T_FULL        0.50f
#endif
#ifndef ETT_R_FULL
#define ETT_R_FULL        0.4383f
#endif
#ifndef ETT_T_RESTRICTED
#define ETT_T_RESTRICTED  0.40f
#endif
#ifndef ETT_R_RESTRICTED
#define ETT_R_RESTRICTED  0.5000f
#endif
#ifndef ETT_T_READ_ONLY
#define ETT_T_READ_ONLY   0.30f
#endif
#ifndef ETT_R_READ_ONLY
#define ETT_R_READ_ONLY   0.5698f
#endif

static ett_cluster_t s_cl[ETT_MAX_CLUSTERS];

static float clampf(float v, float lo, float hi)
{
    return v < lo ? lo : (v > hi ? hi : v);
}

static uint8_t ett_classify(float t, float r)
{
    if (t >= ETT_T_FULL       && r < ETT_R_FULL)       return 0;
    if (t >= ETT_T_RESTRICTED && r < ETT_R_RESTRICTED) return 1;
    if (t >= ETT_T_READ_ONLY  && r < ETT_R_READ_ONLY)  return 2;
    return 3;
}

static const char *ett_mode(void)
{
#if !RAISEF_ETT_PREDICT_ACCESS
    return "NONE";
#elif RAISEF_DL_ENABLED
    return "DL";
#else
    return "HEUR";
#endif
}

/* Sample i (0 = oldest) of the last min(count, W) values. */
static float win_at(const ett_cluster_t *c, int n, int i)
{
    int idx = ((int)c->idx - n + i + ETT_W) % ETT_W;
    return c->win[idx];
}

static void ett_stats(ett_cluster_t *c)
{
    int n = c->count < ETT_W ? c->count : ETT_W;
    float old_slope = c->slope;
    if (n >= 2) {
        float mx = (n - 1) * 0.5f, my = 0.0f, sxy = 0.0f, sxx = 0.0f;
        for (int i = 0; i < n; i++) my += win_at(c, n, i);
        my /= (float)n;
        for (int i = 0; i < n; i++) {
            float dx = (float)i - mx;
            sxy += dx * (win_at(c, n, i) - my);
            sxx += dx * dx;
        }
        c->slope = (sxx > 1e-9f) ? sxy / sxx : 0.0f;
    } else {
        c->slope = 0.0f;
    }
    c->accel = (n >= 3) ? (c->slope - old_slope) : 0.0f;

    /* Paper-7 Eq. 18 risk (identical formula to edge.c tarp_compute_risk_score) */
    {
        float vol = 0.0f;
        for (int i = 0; i < n; i++) {
            float d = win_at(c, n, i) - c->ema;
            vol += d * d;
        }
        vol = (n > 0) ? sqrtf(vol / (float)n) : 0.0f;
        float m = clampf((c->slope < 0 ? -c->slope : 0.0f) * 10.0f, 0.0f, 1.0f);
        float a = clampf((c->accel < 0 ? -c->accel : 0.0f) * 20.0f, 0.0f, 1.0f);
        float v = clampf(vol * 5.0f, 0.0f, 1.0f);
        c->risk = 0.30f * (1.0f - c->comp) + 0.30f * m + 0.20f * a + 0.20f * v;
    }
}

static float ett_predict(ett_cluster_t *c)
{
    if (c->count < ETT_MIN_SAMPLES) {
        return c->comp;
    }
#if RAISEF_DL_ENABLED
    return dl_predict_trust_window(c->win, c->idx, c->count, c->ema, c->slope,
                                   c->accel, c->risk, c->dev, c->clus);
#else
    {
        float k = (float)RAISEF_DL_HORIZON;
        return clampf(c->ema + c->slope * k + 0.5f * c->accel * k * k, 0.0f, 1.0f);
    }
#endif
}

/* Median of the reported QoS of all OTHER clusters that have reported. Robust
 * to one (or a minority of) degraded clusters, unlike the mean. */
static float ett_peer_median(const ett_obs_t obs[ETT_MAX_CLUSTERS], int self)
{
    float v[ETT_MAX_CLUSTERS];
    int n = 0;
    for (int j = 0; j < ETT_MAX_CLUSTERS; j++) {
        if (j != self && obs[j].registered && obs[j].has_report) {
            float x = clampf(obs[j].reported_qos, 0.0f, 1.0f);
            int i = n++;
            while (i > 0 && v[i - 1] > x) { v[i] = v[i - 1]; i--; }   /* insertion sort */
            v[i] = x;
        }
    }
    if (n == 0) return -1.0f;
    return (n & 1) ? v[n / 2] : 0.5f * (v[n / 2 - 1] + v[n / 2]);
}

void ett_init(void)
{
    memset(s_cl, 0, sizeof(s_cl));
}

const ett_cluster_t *ett_get(uint8_t slot)
{
    return (slot < ETT_MAX_CLUSTERS) ? &s_cl[slot] : NULL;
}

void ett_tick(uint32_t cycle, const ett_obs_t obs[ETT_MAX_CLUSTERS], ett_cap_cb cb)
{
    for (int k = 0; k < ETT_MAX_CLUSTERS; k++) {
        ett_cluster_t *c = &s_cl[k];
        uint8_t changed = 0;
        if (!obs[k].registered || !obs[k].has_report) {
            continue;   /* never reported: no evidence yet (N_k handles silence later) */
        }
        /* --- evidence components --- */
        c->dev = clampf(obs[k].reported_qos, 0.0f, 1.0f);
        {
            float peers = ett_peer_median(obs, k);
            c->clus = (peers < 0.0f) ? 1.0f
                    : 1.0f - clampf(ETT_PEER_GAIN * fabsf(c->dev - peers), 0.0f, 1.0f);
        }
        if (obs[k].report_age_s <= ETT_FRESH_OK_S) {
            c->net = 1.0f;
        } else if (obs[k].report_age_s >= ETT_FRESH_DEAD_S) {
            c->net = 0.0f;
        } else {
            c->net = 1.0f - (float)(obs[k].report_age_s - ETT_FRESH_OK_S) /
                            (float)(ETT_FRESH_DEAD_S - ETT_FRESH_OK_S);
        }
        c->comp = clampf(ETT_W_DEV * c->dev + ETT_W_CLUS * c->clus + ETT_W_NET * c->net,
                         0.0f, 1.0f);

        /* Flush the bootstrap transient from the trend window at the warm-up
         * boundary, so slope/acceleration/volatility -- and hence risk --
         * start clean from the stabilised value (matches the warm-up window
         * that calibrate_thresholds.py discards). */
        {
            static uint8_t ett_warmed[ETT_MAX_CLUSTERS];
            if (cycle + ETT_W >= ETT_WARMUP_CYCLES && !ett_warmed[k]) {  /* flush ETT_W cycles early: window refills before enforcement */
                c->count = 0; c->idx = 0; c->ema = c->comp;
                c->slope = 0.0f; c->accel = 0.0f;
                ett_warmed[k] = 1;
            }
        }

        /* --- exactly one window sample per cycle --- */
        c->ema = c->seen ? (ETT_EMA_ALPHA * c->comp + (1.0f - ETT_EMA_ALPHA) * c->ema)
                         : c->comp;
        c->win[c->idx] = c->comp;
        c->idx = (uint8_t)((c->idx + 1) % ETT_W);
        if (c->count < ETT_W) c->count++;
        ett_stats(c);

        /* --- training record (same field order as the global DLFEAT) --- */
        {
            int n = c->count < ETT_W ? c->count : ETT_W;
            printf("DLFEAT,scope=C,node=%u,cyc=%lu,tw=", (unsigned)obs[k].node_id,
                   (unsigned long)cycle);
            for (int i = 0; i < n; i++) {
                printf("%.7g%s", (double)win_at(c, n, i), (i < n - 1) ? ";" : "");
            }
            printf(",ema=%.7g,slope=%.7g,accel=%.7g,risk=%.7g,dtrust=%.7g,"
                   "ctrust=%.7g,ctrust_now=%.7g,ntrust=%.7g,age=%lu\n",
                   (double)c->ema, (double)c->slope, (double)c->accel, (double)c->risk,
                   (double)c->dev, (double)c->clus, (double)c->comp, (double)c->net,
                   (unsigned long)obs[k].report_age_s);
        }

        /* --- forecast and graduated access cap --- */
        c->pred = ett_predict(c);
        printf("DLPRED,node=%u,cyc=%lu,mode=%s,pred=%.7g,cur=%.7g\n",
               (unsigned)obs[k].node_id, (unsigned long)cycle, ett_mode(),
               (double)c->pred, (double)c->comp);
        {
#if RAISEF_ETT_PREDICT_ACCESS
            float t_acc = (c->pred < c->ema) ? c->pred : c->ema;  /* min rule on smoothed trust */
#else
            float t_acc = c->ema;
#endif
            uint8_t st = ett_classify(t_acc, c->risk);
#if RAISEF_ETT_CONFIRM && RAISEF_ETT_PREDICT_ACCESS
            if (c->seen && st > c->state && c->ema >= ETT_T_RESTRICTED &&
                c->count >= ETT_MIN_SAMPLES && !(c->pred < c->ema - ETT_CONFIRM_MARGIN)) {
                st = c->state;                /* not confirmed by the forecast */
            }
#endif
            static uint8_t shist[ETT_MAX_CLUSTERS][ETT_DWELL];
            static uint8_t sn[ETT_MAX_CLUSTERS];
            if (cycle < ETT_WARMUP_CYCLES) {
                c->state = 0; sn[k] = 0;
                if (cb) cb((uint8_t)k, obs[k].node_id, c->state, 0, cycle);
                c->seen = 1;
                continue;   /* bootstrap: hold FULL, no downgrade/rekey */
            }
            shist[k][sn[k] % ETT_DWELL] = st;
            if (sn[k] < 255) sn[k]++;
            if (!c->seen) {
                c->state = st;
                changed = 1;
            } else if (sn[k] >= ETT_DWELL) {
                /* Commit the state SUSTAINED over the last ETT_DWELL cycles (the
                 * least-restrictive recent classification): a single-cycle risk
                 * blip cannot force a downgrade, while a genuine monotonic decline
                 * still commits step by step. */
                uint8_t tgt = shist[k][0];
                for (int q = 1; q < ETT_DWELL; q++)
                    if (shist[k][q] < tgt) tgt = shist[k][q];
                if (tgt != c->state) {
                    printf("DLEVT,node=%u,cyc=%lu,type=ACCESS,from=%u,to=%u,mode=%s\n",
                           (unsigned)obs[k].node_id, (unsigned long)cycle,
                           (unsigned)c->state, (unsigned)tgt, ett_mode());
                    c->state = tgt;
                    changed = 1;
                }
            }
            /* Every cycle: changed -> send + log; unchanged -> refresh send, so the
             * CC-side cap (TTL RAISEF_EDGE_CAP_TTL) never silently lapses. */
            if (cb) cb((uint8_t)k, obs[k].node_id, c->state, changed, cycle);
        }
        /* Proactive rekey REQUEST (logged). Execution needs the networked TARP
         * INIT/ACK/CONFIRM handshake, which this build does not yet have. */
        {
            static uint8_t req_latched[ETT_MAX_CLUSTERS];
            uint8_t want = 0;
            const char *reason = "";
#if RAISEF_ETT_PREDICT_ACCESS
            if (c->count >= ETT_MIN_SAMPLES && c->pred < ETT_TRUST_CRITICAL) {
                want = 1; reason = "FORECAST";
            }
#endif
            if (!want && c->comp < ETT_TRUST_CRITICAL) { want = 1; reason = "CURRENT"; }
            /* No risk-only trigger: R >= 0.30*(1-T) makes R_high a disguised
             * trust threshold (~0.82), which the TARP review showed is not a
             * trend signal. Requests fire on forecast or current breach only. */
            if (want && !req_latched[k]) {
                printf("DLEVT,node=%u,cyc=%lu,type=REKEY_REQ,reason=%s,mode=%s\n",
                       (unsigned)obs[k].node_id, (unsigned long)cycle, reason, ett_mode());
            }
            req_latched[k] = want;
        }
        c->seen = 1;
    }
}
