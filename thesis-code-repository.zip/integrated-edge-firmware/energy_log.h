/*******************************************************************************
 * ENERGY_LOG.H -- measured radio-energy records for the final-stage evaluation.
 *
 * Every node (ER1, ER2, CCs, clients) prints, every RAISEF_NRG_PERIOD:
 *   DLNRG,node=<id>,cpu=<ticks>,lpm=<ticks>,tx=<ticks>,rx=<ticks>,sec=<ticks/s>
 * using Contiki-NG Energest. On the Cooja platform the TRANSMIT and LISTEN
 * states are driven by the simulated radio (cooja-radio.c), so tx/rx are
 * simulated radio airtimes. CPU/LPM on Cooja native motes do NOT model a real
 * MCU and must not be reported as energy. dl_pipeline/evaluate.py energy
 * converts tx/rx airtime to energy with the CC2420 datasheet currents.
 ******************************************************************************/
#ifndef ENERGY_LOG_H
#define ENERGY_LOG_H
void energy_log_start(void);
#endif
