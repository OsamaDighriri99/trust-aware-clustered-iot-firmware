/*******************************************************************************
 * TIMER PATCH HEADER FOR RAISEF-IoT WITH OSCORE SECURITY
 * UPDATED FOR MERGED ARCHITECTURE
 * 
 * This header provides safe timer utilities and OSCORE-specific timing
 * functions for the RAISEF-IoT framework.
 * 
 * Features:
 * - Safe timer set/reset/stop functions with NULL checks
 * - Jitter-based timer initialization for desynchronization
 * - OSCORE-specific timer utilities for maintenance, rotation, and trust
 * - Time conversion utilities (ticks, seconds, milliseconds)
 * - Key freshness and expiration calculations
 * - Overflow-safe elapsed time computation
 * - Adaptive timer adjustment based on system load
 * 
 * MERGED ARCHITECTURE NOTE:
 * All OSCORE code (oscore_security.h/.c, oscore_enhancements.h/.c,
 * raiseif_params.h, raiseif_messages.h) is now inlined directly into
 * client.c, cluster.c, and edge.c. This file remains external because
 * its static inline functions are shared across all three main files.
 * 
 * INCLUDE ORDER (FIX #INC: previous top-of-file comment had wrong order):
 *   The correct, verified order — identical in client.c, cluster.c, edge.c — is:
 *   1. #include "compatibility.h"   (platform layer — MUST be first)
 *   2. #include "contiki.h"          (Contiki-NG core — needed before timer_patch.h)
 *   3. #include "contiki-net.h"      (networking stack)
 *   4. #include "timer_patch.h"      (THIS FILE — needs clock.h from contiki.h)
 *   5. sys/log.h, net/ipv6/uip.h ... (other system headers)
 *   6. #include "oscore_crypto.h"    (crypto primitives, inside MERGED INLINE BLOCK)
 *   7. Application code
 *
 *   The OLD comment above this block incorrectly listed timer_patch.h at position 2
 *   (before contiki.h), which would cause CLOCK_SECOND-undefined errors at compile
 *   time since this file includes sys/clock.h which depends on contiki.h internals.
 * 
 * Compatible with Contiki-NG 4.8+
 * 
 * Version: 2.5 (Bug-T5: TARP double-ptr + Bug-T6: jitter overflow + Bug-T7: modulo-zero UB + Bug-T8: missing guards)
 * Date: March 2026
 * License: Research use
 ******************************************************************************/

#ifndef TIMER_PATCH_H
#define TIMER_PATCH_H

/* Issue D FIX: Include order is now VERIFIED identical across all three node files.
 * Required order in client.c, cluster.c, AND edge.c:
 *   1. #include "compatibility.h"   -- platform layer, MUST be first
 *   2. #include "contiki.h"          -- Contiki-NG core
 *   3. #include "contiki-net.h"      -- networking stack
 *   4. #include "timer_patch.h"      -- THIS FILE (needs clock.h from contiki.h)
 *   5. sys/log.h, net/ipv6/uip.h ... -- other system headers
 *   6. #define AES_128_CTR_CRYPT_DEFINED (edge.c only)
 *      #include "oscore_crypto.h"   -- crypto primitives (inlined OSCORE block)
 *   7. Application code
 * Any deviation from this order in any of the three files will cause:
 *   - CLOCK_SECOND undefined when timer constants are evaluated
 *   - compiler warnings about implicit declarations
 *   - potential duplicate type definitions
 */

#include "sys/etimer.h"
#include "sys/ctimer.h"
#include "sys/clock.h"
#include "lib/random.h"

/*==============================================================================
 * PLATFORM COMPATIBILITY DEFINITIONS
 *============================================================================*/

/* Define CLOCK_TIME_MAX if not defined by platform */
#ifndef CLOCK_TIME_MAX
#define CLOCK_TIME_MAX ((clock_time_t)-1)
#endif

/* Ensure CLOCK_SECOND is defined */
#ifndef CLOCK_SECOND
#define CLOCK_SECOND 128
#endif

/*==============================================================================
 * OSCORE TIMING CONSTANTS
 * Aligned with RAISEF-IoT and TrustCom paper specifications
 *============================================================================*/

/* VERIFICATION (timer_patch.h):
 *   - Paper-relevant timing constants are #ifndef-guarded and paper-aligned:
 *       maintenance 15s, rotation 90s, protocol-switch cooldown 60s (Paper 1
 *       Sec III-F). Because they are guarded, a value defined BEFORE this header
 *       (in a .c or project-conf.h) wins. NB: if any .c overrides the cooldown
 *       to 120s, that node will NOT match Paper 1's 60s — keep it at 60s.
 *   - Overflow-safe arithmetic (Bug-T4..T9) verified with worked examples:
 *       ticks_to_ms / ms_to_ticks are correct including values that overflow the
 *       naive formula (10,000,000 ticks -> 78,125,000 ms; 100,000,000 ms ->
 *       12,800,000 ticks); safe_elapsed_time handles clock wraparound.
 *   No paper logic beyond the timing constants — this is the timer utility layer. */

/* Core OSCORE timers (guarded - may also appear in project-conf.h) */
#ifndef OSCORE_MAINTENANCE_INTERVAL
#define OSCORE_MAINTENANCE_INTERVAL     (CLOCK_SECOND * 15)     /* FIX-C1C3: 15s (was 60s) */
#endif
#ifndef OSCORE_ROTATION_INTERVAL
#define OSCORE_ROTATION_INTERVAL        (CLOCK_SECOND * 90)     /* FIX-C1: 90s (was 1hr) */
#endif
#ifndef OSCORE_TRUST_INTERVAL
#define OSCORE_TRUST_INTERVAL           (CLOCK_SECOND * 30)     /* 30 seconds */
#endif
#ifndef OSCORE_STATS_INTERVAL
#define OSCORE_STATS_INTERVAL           (CLOCK_SECOND * 300)    /* 5 minutes */
#endif
#ifndef OSCORE_EMERGENCY_INTERVAL
#define OSCORE_EMERGENCY_INTERVAL       (CLOCK_SECOND * 5)      /* 5 seconds */
#endif
#ifndef OSCORE_CLUSTERING_INTERVAL
#define OSCORE_CLUSTERING_INTERVAL      (CLOCK_SECOND * 60)     /* 60 seconds */
#endif
#ifndef OSCORE_STATUS_REPORT_INTERVAL
#define OSCORE_STATUS_REPORT_INTERVAL   (CLOCK_SECOND * 600)    /* 10 minutes */
#endif

/* Key rotation boundaries (guarded - project-conf.h defines bare-second versions) */
#ifndef OSCORE_MIN_KEY_LIFETIME
#define OSCORE_MIN_KEY_LIFETIME         (CLOCK_SECOND * 300)    /* 5 minutes */
#endif
#ifndef OSCORE_MAX_KEY_LIFETIME
#define OSCORE_MAX_KEY_LIFETIME         (CLOCK_SECOND * 86400)  /* 24 hours */
#endif
#ifndef OSCORE_DEFAULT_KEY_LIFETIME
#define OSCORE_DEFAULT_KEY_LIFETIME     (CLOCK_SECOND * 3600)   /* 1 hour */
#endif

/* Protocol switch timing (guarded) */
#ifndef OSCORE_PROTOCOL_SWITCH_COOLDOWN
/* FIX #3: Aligned with project-conf.h PROTOCOL_SWITCH_COOLDOWN.
 * Paper 1 Sec III-F specifies 60s; 120s doubled suppression time. */
#define OSCORE_PROTOCOL_SWITCH_COOLDOWN (CLOCK_SECOND * 60)     /* FIX #3: 60s (was 120s) per Paper 1 Sec III-F */
#endif
#ifndef OSCORE_PROTOCOL_MONITOR_INTERVAL
#define OSCORE_PROTOCOL_MONITOR_INTERVAL (CLOCK_SECOND * 30)    /* 30 seconds */
#endif

/* General constraints
 * FIX Bug-T8: These were bare #defines with no #ifndef guard.  If any .c file
 * or another header defined them before including timer_patch.h, the bare
 * #define would silently redefine them, ignoring the caller's value.
 * Added #ifndef guards so the caller's definition wins if present. */
#ifndef MIN_TIMER_INTERVAL
#define MIN_TIMER_INTERVAL              1
#endif
#ifndef MAX_JITTER_PERCENT
#define MAX_JITTER_PERCENT              50
#endif
#ifndef DEFAULT_JITTER_PERCENT
#define DEFAULT_JITTER_PERCENT          10
#endif

/*==============================================================================
 * BASIC SAFE TIMER FUNCTIONS
 *============================================================================*/

/**
 * Safe etimer set function with NULL and zero interval checks
 * @param et Event timer pointer
 * @param interval Timer interval in clock ticks
 * @return 0 on success, -1 on error
 */
static inline int safe_etimer_set(struct etimer *et, clock_time_t interval) {
    if (!et) {
        return -1;
    }
    if (interval == 0) {
        interval = MIN_TIMER_INTERVAL;
    }
    etimer_set(et, interval);
    return 0;
}

/**
 * Safe etimer stop function
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int safe_etimer_stop(struct etimer *et) {
    if (!et) {
        return -1;
    }
    etimer_stop(et);
    return 0;
}

/**
 * Safe etimer reset function
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int safe_etimer_reset(struct etimer *et) {
    if (!et) {
        return -1;
    }
    etimer_reset(et);
    return 0;
}

/**
 * Safe etimer restart function with new interval
 * @param et Event timer pointer
 * @param interval New interval (0 = use existing interval)
 * @return 0 on success, -1 on error
 */
static inline int safe_etimer_restart(struct etimer *et, clock_time_t interval) {
    if (!et) {
        return -1;
    }
    if (interval > 0) {
        etimer_set(et, interval);
    } else {
        etimer_reset(et);
    }
    return 0;
}

/**
 * Safe etimer expired check
 * @param et Event timer pointer
 * @return 1 if expired, 0 if not expired or NULL
 */
static inline int safe_etimer_expired(struct etimer *et) {
    if (!et) {
        return 0;
    }
    return etimer_expired(et);
}

/**
 * Safe callback timer set function
 * @param ct Callback timer pointer
 * @param interval Timer interval
 * @param callback Callback function
 * @param ptr User data pointer
 * @return 0 on success, -1 on error
 */
static inline int safe_ctimer_set(struct ctimer *ct, 
                                  clock_time_t interval,
                                  void (*callback)(void *),
                                  void *ptr) {
    if (!ct || !callback) {
        return -1;
    }
    if (interval == 0) {
        interval = MIN_TIMER_INTERVAL;
    }
    ctimer_set(ct, interval, callback, ptr);
    return 0;
}

/**
 * Safe callback timer stop function
 * @param ct Callback timer pointer
 * @return 0 on success, -1 on error
 */
static inline int safe_ctimer_stop(struct ctimer *ct) {
    if (!ct) {
        return -1;
    }
    ctimer_stop(ct);
    return 0;
}

/*==============================================================================
 * JITTER-BASED TIMER FUNCTIONS
 * Used for desynchronizing periodic events to reduce network congestion
 *============================================================================*/

/**
 * Set timer with random jitter
 * @param et Event timer pointer
 * @param base_interval Base interval in clock ticks
 * @param jitter_percent Jitter as percentage (0-100)
 * @return 0 on success, -1 on error
 */
static inline int safe_etimer_set_with_jitter(struct etimer *et, 
                                              clock_time_t base_interval,
                                              uint8_t jitter_percent) {
    if (!et) {
        return -1;
    }
    if (base_interval == 0) {
        base_interval = MIN_TIMER_INTERVAL;
    }
    if (jitter_percent > MAX_JITTER_PERCENT) {
        jitter_percent = MAX_JITTER_PERCENT;
    }
    
    /* FIX #1 (CRITICAL): Previous unsigned subtraction:
     *   (random_rand() % (range+1)) - (range/2)
     * wraps to ~UINT32_MAX when random < range/2, producing a timer interval
     * of billions of ticks and effectively hanging the node.
     * Fix: use int32_t for the signed offset, prevent underflow explicitly.
     *
     * FIX Bug-T6: (base_interval * jitter_percent * 2) overflows uint32_t when
     * base_interval is large (threshold: ~42M ticks at jitter_percent=50).
     * In a 5-min Cooja simulation base_interval never exceeds ~38400 ticks so
     * this does not trigger in practice, but the arithmetic is now done in
     * uint64_t to be correct for all inputs. */
    int32_t signed_jitter = 0;
    if (jitter_percent > 0) {
        uint64_t jitter_range64 = ((uint64_t)base_interval * jitter_percent * 2u) / 100u;
        /* Clamp to uint32_t range so rand_val and signed_jitter arithmetic is safe */
        uint32_t jitter_range = (jitter_range64 > 0xFFFFFFFFu)
                                ? 0xFFFFFFFFu
                                : (uint32_t)jitter_range64;
        if (jitter_range > 0) {
            uint32_t rand_val = (uint32_t)(random_rand() % (jitter_range + 1));
            signed_jitter = (int32_t)rand_val - (int32_t)(jitter_range / 2);
        }
    }
    clock_time_t interval;
    if (signed_jitter < 0 && (uint32_t)(-signed_jitter) >= base_interval) {
        interval = MIN_TIMER_INTERVAL;
    } else {
        interval = (clock_time_t)((int32_t)base_interval + signed_jitter);
    }
    if (interval < MIN_TIMER_INTERVAL) {
        interval = MIN_TIMER_INTERVAL;
    }
    
    etimer_set(et, interval);
    return 0;
}

/**
 * Set timer with random offset (always positive jitter)
 * @param et Event timer pointer
 * @param base_interval Base interval in clock ticks
 * @param max_offset Maximum additional offset
 * @return 0 on success, -1 on error
 */
static inline int safe_etimer_set_with_offset(struct etimer *et,
                                              clock_time_t base_interval,
                                              clock_time_t max_offset) {
    if (!et) {
        return -1;
    }
    if (base_interval == 0) {
        base_interval = MIN_TIMER_INTERVAL;
    }
    
    clock_time_t offset = 0;
    /* FIX Bug-T7: random_rand() % (max_offset + 1) is undefined behaviour when
     * max_offset == CLOCK_TIME_MAX because max_offset+1 wraps to 0 (modulo zero).
     * Guard: only use modulo when max_offset < CLOCK_TIME_MAX; otherwise use
     * the raw random value (effectively treating max_offset as CLOCK_TIME_MAX). */
    if (max_offset > 0) {
        if (max_offset < CLOCK_TIME_MAX) {
            offset = random_rand() % (max_offset + 1);
        } else {
            offset = (clock_time_t)random_rand();
        }
    }
    /* FIX Bug-T9: base_interval + offset can silently wrap if base_interval is
     * near CLOCK_TIME_MAX (unsigned overflow is defined but produces a near-zero
     * timer, firing almost immediately).  Saturate to CLOCK_TIME_MAX instead. */
    clock_time_t interval = (offset <= CLOCK_TIME_MAX - base_interval)
                            ? (base_interval + offset)
                            : CLOCK_TIME_MAX;
    if (interval < MIN_TIMER_INTERVAL) {
        interval = MIN_TIMER_INTERVAL;
    }
    etimer_set(et, interval);
    return 0;
}

/*==============================================================================
 * TIMER QUERY FUNCTIONS
 *============================================================================*/

/**
 * Get remaining time on timer (handles expiration)
 * @param et Event timer pointer
 * @return Remaining time in clock ticks, 0 if expired or NULL
 */
static inline clock_time_t safe_etimer_remaining(struct etimer *et) {
    if (!et) {
        return 0;
    }
    if (etimer_expired(et)) {
        return 0;
    }
    
    clock_time_t expiration_time = etimer_expiration_time(et);
    clock_time_t current_time = clock_time();
    
    if (expiration_time > current_time) {
        return expiration_time - current_time;
    }
    return 0;
}

/**
 * Check if timer is pending (set but not expired)
 * @param et Event timer pointer
 * @return 1 if pending, 0 otherwise
 */
static inline int safe_etimer_pending(struct etimer *et) {
    if (!et) {
        return 0;
    }
    return !etimer_expired(et);
}

/*==============================================================================
 * TIME CONVERSION UTILITIES
 *============================================================================*/

/**
 * Calculate elapsed time (overflow-safe)
 * @param start_time Start time in clock ticks
 * @return Elapsed time in clock ticks
 */
static inline clock_time_t safe_elapsed_time(clock_time_t start_time) {
    clock_time_t current_time = clock_time();
    
    if (current_time >= start_time) {
        return current_time - start_time;
    } else {
        /* Overflow occurred */
        return (CLOCK_TIME_MAX - start_time) + current_time + 1;
    }
}

/**
 * Convert clock ticks to seconds
 * @param ticks Time in clock ticks
 * @return Time in seconds
 */
static inline uint32_t ticks_to_seconds(clock_time_t ticks) {
    return (uint32_t)(ticks / CLOCK_SECOND);
}

/**
 * Convert seconds to clock ticks
 * @param seconds Time in seconds
 * @return Time in clock ticks
 */
static inline clock_time_t seconds_to_ticks(uint32_t seconds) {
    return (clock_time_t)(seconds * CLOCK_SECOND);
}

/**
 * Convert clock ticks to milliseconds
 * @param ticks Time in clock ticks
 * @return Time in milliseconds
 * FIX Bug-T4: Previous (ticks * 1000) / CLOCK_SECOND overflows uint32_t when
 * ticks > UINT32_MAX/1000 = 4,294,967 (~33,554 s at 128 Hz).  In a 5-min
 * simulation this never triggers, but latency measurements on long-running
 * nodes would silently wrap.  Fixed: divide first, then multiply to keep the
 * intermediate value in range.  Precision loss is at most 0.78ms per call
 * which is acceptable for IoT timing purposes.
 */
static inline uint32_t ticks_to_ms(clock_time_t ticks) {
    /* Divide before multiply: avoids overflow, loses < 1ms precision */
    return (uint32_t)((ticks / CLOCK_SECOND) * 1000u +
                      (uint32_t)(((ticks % CLOCK_SECOND) * 1000u) / CLOCK_SECOND));
}

/**
 * Convert milliseconds to clock ticks
 * @param ms Time in milliseconds
 * @return Time in clock ticks
 * FIX Bug-T4: Previous (ms * CLOCK_SECOND) / 1000 overflows uint32_t when
 * ms > UINT32_MAX/128 = 33,554,431 ms (~9.3 hours).  Fixed: same divide-first
 * pattern with a sub-millisecond remainder term for accuracy.
 */
static inline clock_time_t ms_to_ticks(uint32_t ms) {
    return (clock_time_t)((ms / 1000u) * CLOCK_SECOND +
                          ((ms % 1000u) * CLOCK_SECOND) / 1000u);
}

/*==============================================================================
 * OSCORE-SPECIFIC TIMER UTILITIES
 *============================================================================*/

/**
 * Set OSCORE maintenance timer (15 seconds)
 * FIX Bug-T2: doc previously said "60 seconds" — OSCORE_MAINTENANCE_INTERVAL
 * was reduced from 60s to 15s (FIX-C1C3) so trust rotation fires during 5-min
 * simulations.  Comment updated to match the actual value.
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_maintenance(struct etimer *et) {
    if (!et) {
        return -1;
    }
    return safe_etimer_set_with_jitter(et, OSCORE_MAINTENANCE_INTERVAL, DEFAULT_JITTER_PERCENT);
}

/**
 * Set OSCORE key rotation timer (90 seconds)
 * FIX Bug-T3: doc previously said "1 hour default" -- OSCORE_ROTATION_INTERVAL
 * was reduced from 3600s to 90s (FIX-C1) so key freshness decays within 5-min
 * simulations and triggers trust-driven rotation.  Comment updated to match.
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_rotation(struct etimer *et) {
    if (!et) {
        return -1;
    }
    return safe_etimer_set_with_jitter(et, OSCORE_ROTATION_INTERVAL, DEFAULT_JITTER_PERCENT);
}

/**
 * Set trust assessment timer (30 seconds)
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_trust_assessment(struct etimer *et) {
    if (!et) {
        return -1;
    }
    return safe_etimer_set_with_jitter(et, OSCORE_TRUST_INTERVAL, DEFAULT_JITTER_PERCENT);
}

/**
 * Set OSCORE statistics logging timer (5 minutes)
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_statistics(struct etimer *et) {
    if (!et) {
        return -1;
    }
    return safe_etimer_set(et, OSCORE_STATS_INTERVAL);
}

/**
 * Set OSCORE emergency rotation timer (5 seconds)
 * For use when key compromise is detected
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_emergency_rotation(struct etimer *et) {
    if (!et) {
        return -1;
    }
    return safe_etimer_set(et, OSCORE_EMERGENCY_INTERVAL);
}

/**
 * Set clustering event timer with jitter
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_clustering(struct etimer *et) {
    if (!et) {
        return -1;
    }
    return safe_etimer_set_with_jitter(et, OSCORE_CLUSTERING_INTERVAL, DEFAULT_JITTER_PERCENT);
}

/**
 * Set protocol monitoring timer (30 seconds)
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_protocol_monitor(struct etimer *et) {
    if (!et) {
        return -1;
    }
    return safe_etimer_set_with_jitter(et, OSCORE_PROTOCOL_MONITOR_INTERVAL, DEFAULT_JITTER_PERCENT);
}

/**
 * Set status report timer (10 minutes)
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_status_report(struct etimer *et) {
    if (!et) {
        return -1;
    }
    return safe_etimer_set_with_jitter(et, OSCORE_STATUS_REPORT_INTERVAL, DEFAULT_JITTER_PERCENT);
}

/*==============================================================================
 * DYNAMIC THRESHOLD TIMER (Paper 5, Eq. 1)
 * For periodic recalibration of QoS, BIRCH, and DBSCAN thresholds
 *============================================================================*/

#ifndef OSCORE_DYNAMIC_THRESHOLD_INTERVAL
#define OSCORE_DYNAMIC_THRESHOLD_INTERVAL (CLOCK_SECOND * 60)  /* Every 60 seconds */
#endif

/**
 * Set dynamic threshold recalibration timer
 * @param et Event timer pointer
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_dynamic_threshold(struct etimer *et) {
    if (!et) {
        return -1;
    }
    return safe_etimer_set_with_jitter(et, OSCORE_DYNAMIC_THRESHOLD_INTERVAL, DEFAULT_JITTER_PERCENT);
}

/*==============================================================================
 * ADAPTIVE REPORTING TIMER (Paper 5, Eq. 5)
 * f_comm = f_base * (1 + alpha*dTheta/Theta_max + beta*dP/P_max)
 *============================================================================*/

/**
 * Calculate adaptive reporting interval based on threat and performance
 * @param base_interval Base send interval in clock ticks
 * @param threat_factor Threat level [0.0, 1.0] (higher = more urgent)
 * @param perf_delta Performance degradation [0.0, 1.0]
 * @return Adapted interval in clock ticks
 */
static inline clock_time_t oscore_adaptive_report_interval(
    clock_time_t base_interval, float threat_factor, float perf_delta) {
    
    /* Paper 5 Eq. 5 */
    /* FIX #2: Use project-conf.h ADAPTIVE_REPORT_ALPHA/BETA constants.
     * Hardcoded 0.5/0.3 silently overrode tuned project-conf.h values. */
#ifdef ADAPTIVE_REPORT_ALPHA
    float alpha = (float)ADAPTIVE_REPORT_ALPHA;
#else
    float alpha = 0.5f;
#endif
#ifdef ADAPTIVE_REPORT_BETA
    float beta = (float)ADAPTIVE_REPORT_BETA;
#else
    float beta = 0.3f;
#endif
    
    float rate_mult = 1.0f + alpha * threat_factor + beta * perf_delta;
    
    /* Clamp multiplier */
    if (rate_mult > 2.0f) rate_mult = 2.0f;
    if (rate_mult < 0.5f) rate_mult = 0.5f;
    
    /* Higher rate_mult = faster reporting = shorter interval */
    clock_time_t interval = (clock_time_t)((float)base_interval / rate_mult);
    
    if (interval < MIN_TIMER_INTERVAL) {
        interval = MIN_TIMER_INTERVAL;
    }
    return interval;
}

/*==============================================================================
 * CROSS-PROTOCOL SEQUENCE SYNC TIMING (Paper 6, Eq. 18)
 * Timer guard for sequence synchronization cooldown
 *============================================================================*/

#ifndef OSCORE_SEQ_SYNC_COOLDOWN
#define OSCORE_SEQ_SYNC_COOLDOWN (CLOCK_SECOND * 5)  /* Min time between seq syncs */
#endif

/**
 * Check if sequence synchronization cooldown has elapsed
 * @param last_sync_time Timestamp of last sequence synchronization
 * @return 1 if cooldown elapsed (sync allowed), 0 if still in cooldown
 */
static inline int oscore_seq_sync_allowed(clock_time_t last_sync_time) {
    return (safe_elapsed_time(last_sync_time) >= OSCORE_SEQ_SYNC_COOLDOWN) ? 1 : 0;
}

/*==============================================================================
 * TARP-OSCORE TIMER UTILITIES (Paper 7)
 * Timers for trust lifecycle, rekey retry, and overlap expiry
 *============================================================================*/

/* Ensure TARP constants are available (may also be defined in .c files) */
#ifndef TARP_REKEY_ACK_TIMEOUT
#define TARP_REKEY_ACK_TIMEOUT        15      /* Seconds to wait for rekey ACK */
#endif

/**
 * TARP trust lifecycle evaluation interval (Paper 7 C1)
 * Periodic check: compute composite trust, decide rekey
 */
#ifndef TARP_LIFECYCLE_CHECK_INTERVAL
#define TARP_LIFECYCLE_CHECK_INTERVAL (CLOCK_SECOND * 60)  /* 60s default */
#endif

/**
 * TARP rekey retry timer (Paper 7 C2, Eq. 7)
 */
#ifndef TARP_REKEY_RETRY_TIMER
#define TARP_REKEY_RETRY_TIMER (CLOCK_SECOND * 10)  /* 10s between retries */
#endif

/**
 * TARP overlap expiry timer (Paper 7 C2, Eq. 8)
 * How long deprecated keys remain acceptable
 */
#ifndef TARP_OVERLAP_EXPIRY_TIME
#define TARP_OVERLAP_EXPIRY_TIME (CLOCK_SECOND * 120)  /* 2 min overlap */
#endif

/**
 * TARP trend analysis interval (Paper 7 C3, Eq. 10)
 * How often trust trend is sampled
 */
#ifndef TARP_TREND_SAMPLE_INTERVAL
#define TARP_TREND_SAMPLE_INTERVAL (CLOCK_SECOND * 30)  /* 30s sampling */
#endif

/**
 * Check if TARP overlap period has expired
 * @param overlap_start When the overlap state began
 * @return 1 if overlap expired (should move to DEPRECATED), 0 if still in overlap
 */
static inline int tarp_overlap_expired(clock_time_t overlap_start) {
    return (safe_elapsed_time(overlap_start) >= TARP_OVERLAP_EXPIRY_TIME) ? 1 : 0;
}

/**
 * Check if TARP rekey ACK has timed out
 * @param rekey_initiated When the rekey was initiated
 * @return 1 if timed out (should retry or abort), 0 if still waiting
 */
static inline int tarp_rekey_ack_timed_out(clock_time_t rekey_initiated) {
    return (safe_elapsed_time(rekey_initiated) >= 
            (clock_time_t)(TARP_REKEY_ACK_TIMEOUT * CLOCK_SECOND)) ? 1 : 0;
}

/**
 * Check if trust lifecycle evaluation is due
 * @param last_evaluation Last evaluation timestamp
 * @return 1 if evaluation is due, 0 otherwise
 */
static inline int tarp_lifecycle_check_due(clock_time_t last_evaluation) {
    return (safe_elapsed_time(last_evaluation) >= TARP_LIFECYCLE_CHECK_INTERVAL) ? 1 : 0;
}

/**
 * Set TARP lifecycle check timer macro
 * FIX Bug-T1: was oscore_etimer_set_safe() which does not exist anywhere in
 * this file or the .c files.  Replaced with safe_etimer_set_with_jitter().
 * FIX Bug-T5: original broken macro used &(et) which would pass struct etimer**
 * to a function expecting struct etimer* if the caller passes a pointer.
 * Convention matches all other OSCORE_SET_* macros: caller passes struct etimer*,
 * macro forwards it directly without taking another address.
 */
#define TARP_SET_LIFECYCLE_TIMER(et) \
    safe_etimer_set_with_jitter((et), TARP_LIFECYCLE_CHECK_INTERVAL, DEFAULT_JITTER_PERCENT)

/**
 * Set TARP trend sampling timer macro
 * FIX Bug-T1: was oscore_etimer_set_safe() -> safe_etimer_set_with_jitter().
 * FIX Bug-T5: removed spurious & (double-pointer), now passes (et) directly.
 */
#define TARP_SET_TREND_TIMER(et) \
    safe_etimer_set_with_jitter((et), TARP_TREND_SAMPLE_INTERVAL, DEFAULT_JITTER_PERCENT)

/**
 * Set TARP rekey retry timer macro
 * FIX Bug-T1: was oscore_etimer_set_safe() -> safe_etimer_set().
 * FIX Bug-T5: removed spurious & (double-pointer), now passes (et) directly.
 * Retry timers are not jittered -- deterministic backoff is intentional.
 */
#define TARP_SET_REKEY_RETRY_TIMER(et) \
    safe_etimer_set((et), TARP_REKEY_RETRY_TIMER)

/*==============================================================================
 * OSCORE KEY MANAGEMENT UTILITIES
 *============================================================================*/

/**
 * Check if OSCORE key has exceeded its lifetime
 * @param key_timestamp Key creation time in clock ticks
 * @param max_lifetime Maximum lifetime in seconds
 * @return 1 if expired, 0 if valid
 */
static inline int oscore_key_is_expired(clock_time_t key_timestamp, uint32_t max_lifetime) {
    clock_time_t elapsed = safe_elapsed_time(key_timestamp);
    uint32_t elapsed_seconds = ticks_to_seconds(elapsed);
    return (elapsed_seconds >= max_lifetime) ? 1 : 0;
}

/**
 * Calculate OSCORE key freshness score (0.0 to 1.0)
 * Higher values indicate fresher keys
 * @param key_timestamp Key creation time in clock ticks
 * @param max_lifetime Maximum lifetime in seconds
 * @return Freshness score [0.0, 1.0]
 */
static inline float oscore_key_freshness(clock_time_t key_timestamp, uint32_t max_lifetime) {
    if (max_lifetime == 0) {
        return 0.0f;
    }
    
    clock_time_t elapsed = safe_elapsed_time(key_timestamp);
    uint32_t elapsed_seconds = ticks_to_seconds(elapsed);
    
    if (elapsed_seconds >= max_lifetime) {
        return 0.0f;
    }
    return 1.0f - ((float)elapsed_seconds / (float)max_lifetime);
}

/**
 * Calculate remaining key lifetime in seconds
 * @param key_timestamp Key creation time in clock ticks
 * @param max_lifetime Maximum lifetime in seconds
 * @return Remaining lifetime in seconds, 0 if expired
 */
static inline uint32_t oscore_key_remaining_lifetime(clock_time_t key_timestamp, 
                                                      uint32_t max_lifetime) {
    clock_time_t elapsed = safe_elapsed_time(key_timestamp);
    uint32_t elapsed_seconds = ticks_to_seconds(elapsed);
    
    if (elapsed_seconds >= max_lifetime) {
        return 0;
    }
    return max_lifetime - elapsed_seconds;
}

/**
 * Check if key rotation should be scheduled (within warning threshold)
 * @param key_timestamp Key creation time in clock ticks
 * @param max_lifetime Maximum lifetime in seconds
 * @param warning_threshold Warning threshold in seconds before expiry
 * @return 1 if rotation should be scheduled, 0 otherwise
 */
static inline int oscore_key_rotation_due(clock_time_t key_timestamp,
                                          uint32_t max_lifetime,
                                          uint32_t warning_threshold) {
    uint32_t remaining = oscore_key_remaining_lifetime(key_timestamp, max_lifetime);
    return (remaining <= warning_threshold) ? 1 : 0;
}

/*==============================================================================
 * SYNCHRONIZED TIMER FUNCTIONS
 * For cluster coordination and network-wide synchronization
 *============================================================================*/

/**
 * Set synchronized timer for cluster coordination
 * @param et Event timer pointer
 * @param base_interval Base interval in clock ticks
 * @param max_offset Maximum offset for desynchronization
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_synchronized(struct etimer *et, 
                                                  clock_time_t base_interval,
                                                  clock_time_t max_offset) {
    if (!et) {
        return -1;
    }
    if (base_interval == 0) {
        base_interval = MIN_TIMER_INTERVAL;
    }
    
    clock_time_t offset = 0;
    /* FIX Bug-T7: random_rand() % (max_offset + 1) is undefined behaviour when
     * max_offset == CLOCK_TIME_MAX because max_offset+1 wraps to 0 (modulo zero).
     * Guard: only use modulo when max_offset < CLOCK_TIME_MAX; otherwise use
     * the raw random value (effectively treating max_offset as CLOCK_TIME_MAX). */
    if (max_offset > 0) {
        if (max_offset < CLOCK_TIME_MAX) {
            offset = random_rand() % (max_offset + 1);
        } else {
            offset = (clock_time_t)random_rand();
        }
    }
    /* FIX Bug-T9: base_interval + offset can silently wrap if base_interval is
     * near CLOCK_TIME_MAX (unsigned overflow produces a near-zero timer value,
     * causing the timer to fire almost immediately instead of after base_interval).
     * Saturate to CLOCK_TIME_MAX to produce the longest safe interval instead. */
    clock_time_t interval = (offset <= CLOCK_TIME_MAX - base_interval)
                            ? (base_interval + offset)
                            : CLOCK_TIME_MAX;
    if (interval < MIN_TIMER_INTERVAL) {
        interval = MIN_TIMER_INTERVAL;
    }
    etimer_set(et, interval);
    return 0;
}

/**
 * Set adaptive timer - adjusts interval based on system load
 * Higher load = longer intervals to reduce system stress
 * @param et Event timer pointer
 * @param base_interval Base interval in clock ticks
 * @param load_factor System load factor [0.0, 1.0]
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_adaptive(struct etimer *et,
                                              clock_time_t base_interval,
                                              float load_factor) {
    if (!et) {
        return -1;
    }
    if (base_interval == 0) {
        base_interval = MIN_TIMER_INTERVAL;
    }
    
    /* Clamp load factor */
    if (load_factor < 0.0f) {
        load_factor = 0.0f;
    } else if (load_factor > 1.0f) {
        load_factor = 1.0f;
    }
    
    /* Increase interval by up to 50% under high load */
    float multiplier = 1.0f + (load_factor * 0.5f);
    clock_time_t interval = (clock_time_t)((float)base_interval * multiplier);
    
    if (interval < MIN_TIMER_INTERVAL) {
        interval = MIN_TIMER_INTERVAL;
    }
    
    etimer_set(et, interval);
    return 0;
}

/**
 * Set QoS-aware timer - shorter intervals for better QoS
 * @param et Event timer pointer
 * @param base_interval Base interval in clock ticks
 * @param qos_score QoS score [0.0, 1.0] (higher = better)
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_qos_aware(struct etimer *et,
                                               clock_time_t base_interval,
                                               float qos_score) {
    if (!et) {
        return -1;
    }
    if (base_interval == 0) {
        base_interval = MIN_TIMER_INTERVAL;
    }
    
    /* Clamp QoS score */
    if (qos_score < 0.0f) {
        qos_score = 0.0f;
    } else if (qos_score > 1.0f) {
        qos_score = 1.0f;
    }
    
    /* Higher QoS = shorter interval (better responsiveness) */
    /* At QoS 1.0: 50% of base, at QoS 0.0: 150% of base */
    float multiplier = 1.5f - qos_score;
    clock_time_t interval = (clock_time_t)((float)base_interval * multiplier);
    
    if (interval < MIN_TIMER_INTERVAL) {
        interval = MIN_TIMER_INTERVAL;
    }
    
    etimer_set(et, interval);
    return 0;
}

/*==============================================================================
 * TRUST-BASED TIMER FUNCTIONS
 *============================================================================*/

/**
 * Set timer based on trust level
 * Lower trust = more frequent checks
 * @param et Event timer pointer
 * @param base_interval Base interval in clock ticks
 * @param trust_level Trust level (0=NONE, 1=LOW, 2=MEDIUM, 3=HIGH)
 * @return 0 on success, -1 on error
 */
static inline int oscore_etimer_set_trust_based(struct etimer *et,
                                                 clock_time_t base_interval,
                                                 uint8_t trust_level) {
    if (!et) {
        return -1;
    }
    if (base_interval == 0) {
        base_interval = MIN_TIMER_INTERVAL;
    }
    
    float multiplier;
    switch (trust_level) {
        case 3:  /* HIGH */
            multiplier = 2.0f;   /* Longer interval, less frequent checks */
            break;
        case 2:  /* MEDIUM */
            multiplier = 1.0f;   /* Base interval */
            break;
        case 1:  /* LOW */
            multiplier = 0.5f;   /* More frequent checks */
            break;
        case 0:  /* NONE */
        default:
            multiplier = 0.25f;  /* Very frequent checks */
            break;
    }
    
    clock_time_t interval = (clock_time_t)((float)base_interval * multiplier);
    
    if (interval < MIN_TIMER_INTERVAL) {
        interval = MIN_TIMER_INTERVAL;
    }
    
    etimer_set(et, interval);
    return 0;
}

/*==============================================================================
 * CONVENIENCE MACROS
 *============================================================================*/

/* Quick timer set macros */
#define OSCORE_SET_MAINTENANCE_TIMER(et)    oscore_etimer_set_maintenance(et)
#define OSCORE_SET_ROTATION_TIMER(et)       oscore_etimer_set_rotation(et)
#define OSCORE_SET_TRUST_TIMER(et)          oscore_etimer_set_trust_assessment(et)
#define OSCORE_SET_STATS_TIMER(et)          oscore_etimer_set_statistics(et)
#define OSCORE_SET_EMERGENCY_TIMER(et)      oscore_etimer_set_emergency_rotation(et)

#define OSCORE_SET_DYN_THRESHOLD_TIMER(et) oscore_etimer_set_dynamic_threshold(et)

/* Time conversion macros */
#define SECONDS_TO_TICKS(s)                 seconds_to_ticks(s)
#define TICKS_TO_SECONDS(t)                 ticks_to_seconds(t)
#define MS_TO_TICKS(ms)                     ms_to_ticks(ms)
#define TICKS_TO_MS(t)                      ticks_to_ms(t)

/* Key management macros */
#define OSCORE_KEY_EXPIRED(ts, lifetime)    oscore_key_is_expired(ts, lifetime)
#define OSCORE_KEY_FRESHNESS(ts, lifetime)  oscore_key_freshness(ts, lifetime)
#define OSCORE_KEY_REMAINING(ts, lifetime)  oscore_key_remaining_lifetime(ts, lifetime)

/* Timer state macros */
#define TIMER_SET_SAFE(et, interval)        safe_etimer_set(et, interval)
#define TIMER_RESET_SAFE(et)                safe_etimer_reset(et)
#define TIMER_STOP_SAFE(et)                 safe_etimer_stop(et)
#define TIMER_EXPIRED_SAFE(et)              safe_etimer_expired(et)
#define TIMER_REMAINING(et)                 safe_etimer_remaining(et)

#endif /* TIMER_PATCH_H */

/*==============================================================================
 * INTEGRATION WITH MERGED OSCORE ARCHITECTURE
 * 
 * This timer patch header provides foundational timing utilities used by
 * the OSCORE code that is now inlined inside each main .c file.
 * 
 * USED BY INLINED OSCORE CODE:
 * - Predictive rotation timing (Contribution #2)
 * - Energy-aware interval adaptation (Contribution #4b)
 * - Performance metrics timestamping
 * 
 * KEY FUNCTIONS:
 * - safe_elapsed_time()               - Trust history tracking
 * - oscore_key_freshness()            - Rotation decisions
 * - oscore_etimer_set_trust_based()   - Adaptive timing
 * - ticks_to_ms()                     - Latency measurements
 * 
 * Version: 2.6 (Bug-T9: base+offset overflow saturation)
 *
 * NEW FIXES (v2.5 -> v2.6):
 *   Bug-T9: safe_etimer_set_with_offset() and oscore_etimer_set_synchronized()
 *     both computed clock_time_t interval = base_interval + offset without any
 *     overflow guard.  clock_time_t is unsigned, so if base_interval is near
 *     CLOCK_TIME_MAX and offset > 0, the addition wraps silently to a value
 *     close to zero — causing the timer to fire almost immediately instead of
 *     after base_interval.  This can cascade into rapid-fire timer events under
 *     extreme (but valid) input combinations.
 *     Fixed: added a saturation check in both functions:
 *       interval = (offset <= CLOCK_TIME_MAX - base_interval)
 *                  ? (base_interval + offset) : CLOCK_TIME_MAX;
 *     Also added MIN_TIMER_INTERVAL clamp after saturation for consistency
 *     with the rest of the safe_etimer_* family.
 *     Harmless in normal 5-min Cooja simulations (max interval ~38400 ticks),
 *     but necessary for correctness at the boundary.
 *
 * NEW FIXES (v2.4 -> v2.5):
 *   Bug-T5 (CRITICAL): The Bug-T1 fix in v2.4 replaced oscore_etimer_set_safe()
 *     correctly but kept the original &(et) in all three TARP_SET_* macros.
 *     All other macros in this file (OSCORE_SET_*, TIMER_SET_SAFE) pass the
 *     pointer (et) directly, without &.  Using &(et) when et is already a
 *     struct etimer* passes struct etimer** to a function expecting struct
 *     etimer*, which is a type error that silently passes the wrong address.
 *     Fixed: all three TARP macros now pass (et) directly, matching the
 *     established convention throughout this file.
 *   Bug-T6: jitter_range computation in safe_etimer_set_with_jitter() used
 *     (base_interval * jitter_percent * 2) in uint32_t arithmetic which
 *     overflows when base_interval > ~42M ticks at jitter_percent=50.
 *     Harmless in 5-min Cooja sims (max ~38400 ticks) but incorrect.
 *     Fixed: intermediate computed in uint64_t, then clamped to uint32_t.
 *   Bug-T7: safe_etimer_set_with_offset() and oscore_etimer_set_synchronized()
 *     both computed random_rand() % (max_offset + 1) without checking whether
 *     max_offset == CLOCK_TIME_MAX.  If it is, max_offset+1 wraps to 0 and the
 *     modulo is undefined behaviour (div-by-zero on most implementations).
 *     Fixed: added CLOCK_TIME_MAX guard in both functions; if max_offset equals
 *     CLOCK_TIME_MAX the raw random_rand() value is used instead.
 *   Bug-T8: MIN_TIMER_INTERVAL, MAX_JITTER_PERCENT, and DEFAULT_JITTER_PERCENT
 *     were bare #defines with no #ifndef guard.  Any preceding definition in
 *     a .c file or another header would be silently overwritten.
 *     Fixed: wrapped all three in #ifndef / #endif guards.
 *
 * NEW FIXES (v2.3 -> v2.4):
 *   Bug-T1 (CRITICAL): Three TARP macros (TARP_SET_LIFECYCLE_TIMER,
 *     TARP_SET_TREND_TIMER, TARP_SET_REKEY_RETRY_TIMER) called
 *     oscore_etimer_set_safe() which is defined NOWHERE in this file or
 *     any of the three .c files. Any code path reaching these macros
 *     would fail to link. Fixed: replaced with safe_etimer_set_with_jitter()
 *     (periodic timers) and safe_etimer_set() (retry timer, no jitter).
 *   Bug-T2: oscore_etimer_set_maintenance() doc said "60 seconds" but
 *     OSCORE_MAINTENANCE_INTERVAL = 15s after FIX-C1C3. Comment corrected.
 *   Bug-T3: oscore_etimer_set_rotation() doc said "1 hour default" but
 *     OSCORE_ROTATION_INTERVAL = 90s after FIX-C1. Comment corrected.
 *   Bug-T4: ticks_to_ms() and ms_to_ticks() used multiply-then-divide which
 *     overflows uint32_t for values above ~9.3 hours. Reordered to
 *     divide-first with a remainder term; precision loss < 1ms, safe for IoT.
 *
 * NEW FEATURES (v2.2 -> v2.3):
 *   FIX #INC: Corrected top-of-file INCLUDE ORDER comment which incorrectly
 *   placed timer_patch.h before contiki.h. The verified correct order in all
 *   three .c files is: compatibility.h → contiki.h → contiki-net.h →
 *   timer_patch.h → system headers → oscore_crypto.h.
 *
 * NEW FEATURES (v2.1 -> v2.2):
 *   - Dynamic threshold recalibration timer (Paper 5 Eq. 1)
 *   - Adaptive reporting interval calculator (Paper 5 Eq. 5)
 *   - Cross-protocol sequence sync cooldown (Paper 6 Eq. 18)
 *============================================================================*/

/* End of timer_patch.h */
