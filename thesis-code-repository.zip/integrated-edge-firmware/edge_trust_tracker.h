/*******************************************************************************
 * EDGE_TRUST_TRACKER.H -- Per-cluster trust trajectory tracker (edge root).
 *
 * RAISEF-IoT final stage (v5). Maintains ONE trust time-series per REGISTERED
 * cluster centre at the edge root, sampled exactly once per edge maintenance
 * cycle, and drives the forecaster (CNN-LSTM when RAISEF_DL_ENABLED=1, the
 * Paper-7 analytic predictor otherwise) and the graduated access cap.
 *
 * Per-cluster composite trust (edge-observed evidence, weights = TARP C1):
 *   T_k = 0.40*D_k + 0.35*C_k + 0.25*N_k
 *   D_k  reported behaviour   = QoS in cluster k's sequenced GLOBALMETRICS   [0,1]
 *   C_k  peer consistency     = 1 - min(1, ETT_PEER_GAIN*|D_k - median(D_others)|)
 *   N_k  responsiveness       = freshness of cluster k's last sequenced report
 *
 * v5 changes (see CHANGES.md): every registered cluster is evaluated (a silent
 * cluster now loses N_k instead of being skipped); peer reference is the MEDIAN
 * of the other clusters (one collapsed cluster no longer drags every healthy
 * cluster's C_k down); the cap callback is invoked EVERY cycle (changed flag)
 * so the edge can refresh the cap before the CC-side TTL expires; the edge
 * policy has its own threshold macros (ETT_T_*, ETT_R_*), independent of the
 * CC's per-client TRACE thresholds (ML_ACCESS_*); records are logged with 7
 * significant digits so training inputs equal deployment inputs.
 ******************************************************************************/
#ifndef EDGE_TRUST_TRACKER_H
#define EDGE_TRUST_TRACKER_H

#include <stdint.h>

#ifndef ETT_MAX_CLUSTERS
#define ETT_MAX_CLUSTERS 10
#endif
#define ETT_W 16                  /* == DL_W == TARP_TREND_WINDOW_SIZE */

#ifndef ETT_PEER_GAIN
#define ETT_PEER_GAIN 2.5f        /* deviation of 0.40 from peers -> C_k = 0 */
#endif
#ifndef ETT_FRESH_OK_S
#define ETT_FRESH_OK_S   900u
#endif
#ifndef ETT_FRESH_DEAD_S
#define ETT_FRESH_DEAD_S 2700u
#endif

/* One observation per cluster slot, assembled by edge.c each cycle. */
typedef struct {
    uint8_t  registered;      /* slot registered (evaluated even if silent) */
    uint8_t  has_report;      /* at least one sequenced report received */
    uint8_t  node_id;         /* Cooja node id of the cluster centre */
    float    reported_qos;    /* D_k source (sequenced GLOBALMETRICS only) */
    uint32_t report_age_s;    /* seconds since the last sequenced report */
} ett_obs_t;

/* Per-cluster trajectory state (mirrors the TARP ctx fields the DL consumes). */
typedef struct {
    float    win[ETT_W];
    uint8_t  idx, count;
    float    ema, slope, accel, risk;
    float    dev, clus, net, comp;
    float    pred;            /* forecast T_hat(t+H) */
    uint8_t  state;           /* current access cap 0..3 */
    uint8_t  seen;
} ett_cluster_t;

/* Invoked for every evaluated cluster EVERY cycle; changed = 1 when the cap
 * state changed this cycle (edge.c logs and sends; refresh sends otherwise). */
typedef void (*ett_cap_cb)(uint8_t slot, uint8_t node_id, uint8_t state,
                           uint8_t changed, uint32_t cycle);

void  ett_init(void);
/* Run one tracker cycle. Emits DLFEAT/DLPRED/DLEVT log lines. */
void  ett_tick(uint32_t cycle, const ett_obs_t obs[ETT_MAX_CLUSTERS], ett_cap_cb cb);
const ett_cluster_t *ett_get(uint8_t slot);

#endif /* EDGE_TRUST_TRACKER_H */
