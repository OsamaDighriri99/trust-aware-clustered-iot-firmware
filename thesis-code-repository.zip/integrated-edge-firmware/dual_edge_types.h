/*******************************************************************************
 * DUAL_EDGE_TYPES.H — Dual-Edge Architecture Packed Struct Definitions
 *
 * Paper 9: "Dual-Edge OSCORE-IoT: Resilient Primary-Backup Edge Architecture"
 *
 * WHY THIS FILE EXISTS (FIX-DE1):
 *   The original dual-edge structs were in compatibility.h, which is included
 *   as the FIRST include in every .c file — before contiki.h and therefore
 *   before uip.h defines uip_ipaddr_t. The de_replicated_cluster_t struct uses
 *   uip_ipaddr_t for the cluster IPv6 address field, causing an "unknown type"
 *   compile error.
 *
 *   Attempting to forward-declare uip_ipaddr_t in compatibility.h failed
 *   because Contiki-NG defines it as:
 *     typedef uip_ip6addr_t uip_ipaddr_t;         (uip.h:105)
 *   where uip_ip6addr_t is an ANONYMOUS union (no tag name):
 *     typedef union { uint8_t u8[16]; ... } uip_ip6addr_t;  (uip.h:~100)
 *   An anonymous union cannot be forward-declared in C.
 *
 * SOLUTION:
 *   Move all dual-edge struct definitions into THIS file, which is included
 *   AFTER contiki.h in each .c file. At that point uip.h has been parsed and
 *   uip_ipaddr_t is fully defined.
 *
 * INCLUDE ORDER (all three files: edge.c, edge_standby.c, cluster.c):
 *   1. #include "compatibility.h"      (platform layer — no uip dependency)
 *   2. #include "contiki.h"            (pulls in uip.h, project-conf.h)
 *   3. #include "contiki-net.h"
 *   4. #include "dual_edge_types.h"    (THIS FILE — needs uip_ipaddr_t from step 2)
 *   5. #include "timer_patch.h"
 *   ... rest of includes ...
 *
 * Version: 1.0 — April 2026
 ******************************************************************************/

#ifndef DUAL_EDGE_TYPES_H
#define DUAL_EDGE_TYPES_H

/* This header requires uip.h (via contiki.h) to be included first.
 * Include order is enforced by convention — see the comment at the top of this file.
 * Do NOT include dual_edge_types.h before #include "contiki.h". */

/*=============================================================================
 * FIX-DE-SELFCONTAINED: Dual-edge wire-protocol constants.
 *
 * Previously these lived ONLY in project-conf.h (canonical) plus duplicate
 * #ifndef fallbacks scattered in edge.c / edge_standby.c / cluster.c. The
 * structs below reference them in their field comments (DE_STATE_*, DE_DELTA_*,
 * DE_REPLICATE_*, MSG_TYPE_DE_*, ML_ACCESS_STATE_*, ...), yet the header itself
 * defined none of them — so this header was NOT self-contained. They are added
 * here, ALL #ifndef-guarded with the EXACT canonical values, so:
 *   - the header stands alone (no dependency on project-conf.h for the
 *     constants its own structs document), and
 *   - behaviour is unchanged: project-conf.h is included before this header, so
 *     when present its definitions win and these guarded copies are skipped.
 * Single source of truth remains project-conf.h — change values THERE; these
 * guarded copies only take effect if that block is ever absent.
 *
 * Requires CLOCK_SECOND (from contiki.h, included before this header per the
 * include-order contract above) for the *_INTERVAL / *_TIME macros.
 *===========================================================================*/

/* ---- Node identity ---- */
#ifndef DUAL_EDGE_ER1_NODE_ID
#define DUAL_EDGE_ER1_NODE_ID          1
#endif
#ifndef DUAL_EDGE_ER2_NODE_ID
#define DUAL_EDGE_ER2_NODE_ID          112   /* v5: Cooja layout */
#endif
#ifndef DUAL_EDGE_ER2_ADDR_LAST_WORD
#define DUAL_EDGE_ER2_ADDR_LAST_WORD   0x0070   /* node 112 */
#endif
#ifndef DUAL_EDGE_ER2_ADDR_LAST_BYTE
#define DUAL_EDGE_ER2_ADDR_LAST_BYTE   DUAL_EDGE_ER2_ADDR_LAST_WORD
#endif

/* ---- Replication channel ---- */
#ifndef DUAL_EDGE_REPLICATION_PORT
#define DUAL_EDGE_REPLICATION_PORT     7777
#endif
#ifndef OSCORE_ER2_SENDER_ID
#define OSCORE_ER2_SENDER_ID           0x04
#endif
#ifndef OSCORE_ER2_RECIPIENT_ID
#define OSCORE_ER2_RECIPIENT_ID        0x03
#endif

/* ---- DE-C1: Replication timing (needs CLOCK_SECOND) ---- */
#ifndef DUAL_EDGE_HEARTBEAT_INTERVAL
#define DUAL_EDGE_HEARTBEAT_INTERVAL   (5 * CLOCK_SECOND)
#endif
#ifndef DUAL_EDGE_SNAPSHOT_INTERVAL
#define DUAL_EDGE_SNAPSHOT_INTERVAL    (30 * CLOCK_SECOND)
#endif
#ifndef DUAL_EDGE_HEARTBEAT_MISS_MAX
#define DUAL_EDGE_HEARTBEAT_MISS_MAX   3
#endif
#ifndef DUAL_EDGE_ACK_TIMEOUT_MS
#define DUAL_EDGE_ACK_TIMEOUT_MS       500
#endif
#ifndef DUAL_EDGE_MAX_RETRIES
#define DUAL_EDGE_MAX_RETRIES          3
#endif

/* ---- DE-C1: Replication scope (bitfield) ---- */
#ifndef DE_REPLICATE_OSCORE_CONTEXTS
#define DE_REPLICATE_OSCORE_CONTEXTS   0x01
#endif
#ifndef DE_REPLICATE_TARP_STATE
#define DE_REPLICATE_TARP_STATE        0x02
#endif
#ifndef DE_REPLICATE_CLUSTER_REGISTRY
#define DE_REPLICATE_CLUSTER_REGISTRY  0x04
#endif
#ifndef DE_REPLICATE_ML_ACCESS_POLICY
#define DE_REPLICATE_ML_ACCESS_POLICY  0x08
#endif
#ifndef DE_REPLICATE_ALL
#define DE_REPLICATE_ALL   (DE_REPLICATE_OSCORE_CONTEXTS  | \
                            DE_REPLICATE_TARP_STATE       | \
                            DE_REPLICATE_CLUSTER_REGISTRY | \
                            DE_REPLICATE_ML_ACCESS_POLICY)
#endif
#ifndef DUAL_EDGE_REPLICATE_FLAGS
#define DUAL_EDGE_REPLICATE_FLAGS      DE_REPLICATE_ALL
#endif

/* ---- DE-C2: Failover nonce-continuity ---- */
#ifndef DE_NONCE_SAFETY_MARGIN
#define DE_NONCE_SAFETY_MARGIN         64
#endif
#ifndef DE_FAILOVER_QUIESCE_TIME
#define DE_FAILOVER_QUIESCE_TIME       (2 * CLOCK_SECOND)
#endif

/* ---- DE-C3: Dual-root RPL coordination ---- */
#ifndef DUAL_EDGE_RPL_INSTANCE_ID
#define DUAL_EDGE_RPL_INSTANCE_ID      0x1E
#endif
#ifndef DUAL_EDGE_ER1_RANK
#define DUAL_EDGE_ER1_RANK             256
#endif
#ifndef DUAL_EDGE_ER2_STANDBY_RANK
#define DUAL_EDGE_ER2_STANDBY_RANK     512
#endif
#ifndef DUAL_EDGE_ER2_PROMOTED_RANK
#define DUAL_EDGE_ER2_PROMOTED_RANK    256
#endif

/* ---- Replication message types (100-119 reserved for dual-edge) ---- */
#ifndef MSG_TYPE_DE_HEARTBEAT
#define MSG_TYPE_DE_HEARTBEAT          100
#endif
#ifndef MSG_TYPE_DE_SNAPSHOT
#define MSG_TYPE_DE_SNAPSHOT           101
#endif
#ifndef MSG_TYPE_DE_DELTA_UPDATE
#define MSG_TYPE_DE_DELTA_UPDATE       102
#endif
#ifndef MSG_TYPE_DE_SNAPSHOT_ACK
#define MSG_TYPE_DE_SNAPSHOT_ACK       103
#endif
#ifndef MSG_TYPE_DE_FAILOVER_DECLARE
#define MSG_TYPE_DE_FAILOVER_DECLARE   104
#endif
#ifndef MSG_TYPE_DE_FAILOVER_ACK
#define MSG_TYPE_DE_FAILOVER_ACK       105
#endif
#ifndef MSG_TYPE_DE_RECOVERY_NOTIFY
#define MSG_TYPE_DE_RECOVERY_NOTIFY    106
#endif
#ifndef MSG_TYPE_DE_CONTEXT_REQUEST
#define MSG_TYPE_DE_CONTEXT_REQUEST    107
#endif

/* ---- ER2 state machine (de_heartbeat_t.er1_state, er2_state) ---- */
#ifndef DE_STATE_STANDBY
#define DE_STATE_STANDBY               0
#endif
#ifndef DE_STATE_PRIMARY
#define DE_STATE_PRIMARY               1
#endif
#ifndef DE_STATE_PROMOTED
#define DE_STATE_PROMOTED              2
#endif
#ifndef DE_STATE_RECOVERING
#define DE_STATE_RECOVERING            3
#endif

/* ---- Delta sub-types (de_delta_update_t.update_type) ---- */
#ifndef DE_DELTA_SEQ_UPDATE
#define DE_DELTA_SEQ_UPDATE            0x01
#endif
#ifndef DE_DELTA_KEY_ROTATION
#define DE_DELTA_KEY_ROTATION          0x02
#endif
#ifndef DE_DELTA_TRUST_CHANGE
#define DE_DELTA_TRUST_CHANGE          0x03
#endif
#ifndef DE_DELTA_ML_ACCESS
#define DE_DELTA_ML_ACCESS             0x04
#endif
#ifndef DE_DELTA_CLUSTER_JOIN
#define DE_DELTA_CLUSTER_JOIN          0x05
#endif
#ifndef DE_DELTA_CLUSTER_LEAVE
#define DE_DELTA_CLUSTER_LEAVE         0x06
#endif

/* ---- ML-ACCESS state values (Paper 8) — de_*.ml_access_state ---- */
#ifndef ML_ACCESS_STATE_FULL
#define ML_ACCESS_STATE_FULL           0
#endif
#ifndef ML_ACCESS_STATE_RESTRICTED
#define ML_ACCESS_STATE_RESTRICTED     1
#endif
#ifndef ML_ACCESS_STATE_READ_ONLY
#define ML_ACCESS_STATE_READ_ONLY      2
#endif
#ifndef ML_ACCESS_STATE_REVOKED
#define ML_ACCESS_STATE_REVOKED        3
#endif

/* ---- DE-C4: Evaluation targets ---- */
#ifndef DE_TARGET_FAILOVER_MS
#define DE_TARGET_FAILOVER_MS          3000
#endif
#ifndef DE_TARGET_CONTEXT_RECOVERY
#define DE_TARGET_CONTEXT_RECOVERY     0.99f
#endif
#ifndef DE_TARGET_NONCE_CONTINUITY
#define DE_TARGET_NONCE_CONTINUITY     1.0f
#endif
#ifndef DE_TARGET_REPLICATION_OVERHEAD
#define DE_TARGET_REPLICATION_OVERHEAD 0.02f
#endif
#ifndef DUAL_EDGE_TARGET_REPLICATION_OVERHEAD
#define DUAL_EDGE_TARGET_REPLICATION_OVERHEAD  DE_TARGET_REPLICATION_OVERHEAD
#endif

/*=============================================================================
 * DE-C1: Heartbeat  ER1 -> ER2  (sent every DUAL_EDGE_HEARTBEAT_INTERVAL)
 *===========================================================================*/
typedef struct __attribute__((packed)) {
    uint32_t er1_uptime_s;           /* ER1 uptime seconds */
    uint32_t er1_seq_counter;        /* Monotonic ER1 message counter */
    uint64_t max_sender_seq_mqtt;    /* Highest MQTT sender seq across all contexts */
    uint64_t max_sender_seq_coap;    /* Highest CoAP sender seq across all contexts */
    uint64_t max_sender_seq_group;   /* Highest Group OSCORE sender seq */
    uint8_t  active_clusters;        /* Number of registered cluster centers */
    uint8_t  active_contexts;        /* Number of active OSCORE contexts */
    uint32_t total_rekeys;           /* Cumulative TARP rekey events */
    float    global_qos;             /* Current global QoS score */
    uint8_t  er1_state;              /* DE_STATE_PRIMARY or DE_STATE_RECOVERING */
} de_heartbeat_t;

/*=============================================================================
 * DE-C1: Snapshot header  ER1 -> ER2  (precedes serialised contexts+clusters)
 *===========================================================================*/
typedef struct __attribute__((packed)) {
    uint32_t snapshot_id;            /* Monotonically increasing snapshot number */
    uint8_t  num_contexts;           /* Count of de_replicated_context_t records */
    uint8_t  num_clusters;           /* Count of de_replicated_cluster_t records */
    uint8_t  replication_flags;      /* DE_REPLICATE_* bitfield */
    uint32_t er1_uptime_s;           /* ER1 uptime at snapshot time */
} de_snapshot_hdr_t;

/*=============================================================================
 * DE-C1: Delta update  ER1 -> ER2  (per event: rekey, seq advance, ML-ACCESS)
 *===========================================================================*/
typedef struct __attribute__((packed)) {
    uint8_t  update_type;            /* DE_DELTA_* code */
    uint8_t  sender_id;              /* OSCORE sender ID of updated context */
    uint64_t new_sender_seq;         /* Updated sender sequence number */
    uint16_t new_epoch;              /* Updated TARP epoch identifier */
    uint8_t  new_key_state;          /* Updated TARP_KEY_STATE_* value */
    float    new_trust;              /* Updated composite trust score */
    uint8_t  ml_access_state;        /* Updated ML_ACCESS_STATE_* value */
    uint8_t  new_sender_key[16];     /* Updated AES-128 sender key */
    uint8_t  new_recipient_key[16];  /* Updated AES-128 recipient key */
    uint8_t  key_changed;            /* 1=new keys present, 0=seq-only update */
} de_delta_update_t;

/*=============================================================================
 * DE-C1: Replicated OSCORE context record (subset of oscore_context_t)
 *===========================================================================*/
typedef struct __attribute__((packed)) {
    uint8_t  sender_id;              /* Sender ID (0x01=client, 0x02=CC, 0x03=ER1) */
    uint8_t  recipient_id;           /* Recipient ID */
    uint8_t  sender_key[16];         /* AES-128 sender key */
    uint8_t  recipient_key[16];      /* AES-128 recipient key */
    uint8_t  common_iv[13];          /* Common IV (HKDF-derived) */
    uint64_t sender_seq;             /* Latest sender sequence number */
    uint64_t recipient_seq;          /* Latest recipient sequence number */
    uint16_t current_epoch;          /* TARP epoch identifier */
    uint8_t  key_state;              /* TARP_KEY_STATE_* lifecycle state */
    float    composite_trust;        /* TARP composite trust score */
    float    trust_adaptive_interval;/* TARP adaptive rekey interval (seconds) */
    uint8_t  ml_access_state;        /* ML_ACCESS_STATE_* (Paper 8) */
    uint8_t  cluster_id;             /* Owning cluster (0xFF = global context) */
    uint8_t  valid;                  /* 1 = slot occupied */
} de_replicated_context_t;

/*=============================================================================
 * DE-C1: Replicated cluster registration record
 * NOTE: Uses uip_ipaddr_t — requires uip.h to be included before this header.
 *===========================================================================*/
typedef struct __attribute__((packed)) {
    uint8_t      id;                 /* Cluster identifier (0-9) */
    uint8_t      is_registered;      /* 1 = registered */
    uint8_t      is_active;          /* 1 = currently active */
    uip_ipaddr_t addr;               /* Cluster IPv6 address (16 bytes) */
    uint32_t     client_count;       /* Number of client nodes */
    float        qos_score;          /* Latest QoS score */
    float        avg_latency;        /* Average latency (ms) */
    float        avg_throughput;     /* Average throughput (normalised) */
    float        avg_energy;         /* Average energy (W) */
    uint8_t      valid;              /* 1 = slot occupied */
} de_replicated_cluster_t;

/*=============================================================================
 * DE-C2: Failover declaration  ER2 -> all CCs
 *===========================================================================*/
typedef struct __attribute__((packed)) {
    uint8_t  er2_node_id;            /* ER2 Cooja node ID */
    uint32_t failover_time_s;        /* Timestamp of failover (seconds) */
    uint64_t s_failover_mqtt;        /* S_failover for MQTT contexts */
    uint64_t s_failover_coap;        /* S_failover for CoAP contexts */
    uint64_t s_failover_group;       /* S_failover for Group OSCORE */
    uint8_t  num_recovered_contexts; /* Contexts ER2 has mirrored */
    uint8_t  num_recovered_clusters; /* Clusters ER2 has mirrored */
    uint8_t  er2_new_rank_lsb;       /* New RPL rank LSB after promotion */
} de_failover_declare_t;

/*=============================================================================
 * Array size constants
 *===========================================================================*/
#ifndef DE_MAX_REPLICATED_CONTEXTS
#define DE_MAX_REPLICATED_CONTEXTS    110  /* 10 CC * 10 clients + 10 global */
#endif
#ifndef DE_MAX_REPLICATED_CLUSTERS
#define DE_MAX_REPLICATED_CLUSTERS    10
#endif

#endif /* DUAL_EDGE_TYPES_H */
