/*******************************************************************************
 * EDGE_STANDBY.C — ER2: Standby Edge Root (Dual-Edge Paper 9)
 *
 * Novel Contributions:
 *   DE-C1  Receives heartbeats, snapshots, deltas from ER1 — mirrors all:
 *          OSCORE contexts (keys, epochs, sequences), TARP lifecycle state,
 *          cluster_registrations[], ML-ACCESS policies (Paper 8)
 *   DE-C2  Failover nonce-continuity:
 *          S_failover = max(S_mqtt,S_coap,S_group) + DE_NONCE_SAFETY_MARGIN
 *          Extends Paper 6's S_unified rule across the ER1->ER2 boundary.
 *          Formal guarantee: all post-failover nonces > all pre-failover nonces.
 *   DE-C3  Dual-root RPL: ER2 starts with rank DUAL_EDGE_ER2_STANDBY_RANK.
 *          On failover, lowers rank to DUAL_EDGE_ER2_PROMOTED_RANK and resets
 *          the DIO trickle timer => network reconverges to ER2.
 *   DE-C4  Logs failover latency, context recovery %, nonce continuity,
 *          replication overhead — all Paper 9 evaluation metrics.
 *
 * Link to Paper 8 (ML-ACCESS-IoT) future work:
 *   "physical deployment" requires resilient edge infrastructure.
 *   This file provides that prerequisite.
 *
 * Include order (same as edge.c — required by compatibility.h comments):
 *   1. compatibility.h  (platform layer, defines de_*_t types)
 *   2. contiki.h
 *   3. contiki-net.h
 *   4. timer_patch.h
 *   5. oscore_crypto.h  (inlined AES-CCM, HKDF-SHA256)
 *   6. project-conf.h   (all constants including dual-edge v4.0)
 *
 * Topology: 112 nodes — ER1=node1, CC=2-11, Clients=12-111, ER2=node112 (v5)
 * Platform: Contiki-NG v5.1, Cooja/MSPSim, Zolertia Z1 (MSP430F2617)
 ******************************************************************************/

#include "compatibility.h"   /* MUST be first — defines de_*_t types */
#include "contiki.h"
#include "energy_log.h"   /* v5: DLNRG measured-energy records */
#include "contiki-net.h"
#include "dual_edge_types.h"  /* FIX-DE1: dual-edge structs need uip_ipaddr_t from contiki.h */
#include "timer_patch.h"     /* safe_etimer_set/reset — after contiki.h */
#include "sys/log.h"
#include "sys/etimer.h"
#include "net/ipv6/uip.h"
#include "net/routing/routing.h"
#include "net/routing/rpl-lite/rpl.h"
#include "simple-udp.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <inttypes.h>
#include <float.h>
#include <stdarg.h>
#include "sys/autostart.h"
#include "oscore_crypto.h"   /* Real AES-CCM-16-64-128, HKDF-SHA256 */

#define LOG_MODULE "ER2"
#define LOG_LEVEL  LOG_LEVEL_INFO

/*=============================================================================
 * FIX-DE3: Self-contained constant defaults for edge_standby.c
 *
 * All these constants are defined in project-conf.h (included via contiki.h).
 * The #ifndef defaults below make edge_standby.c compile correctly even when
 * the user's project-conf.h has not yet been updated with the Paper 9 section.
 * Values exactly match project-conf.h — the #ifndef ensures project-conf.h
 * wins when it does provide them.
 *===========================================================================*/

/* ER2 node identity and RPL ranks */
#ifndef DUAL_EDGE_ER2_NODE_ID
#define DUAL_EDGE_ER2_NODE_ID          112  /* must match project-conf.h / .csc */
#endif
#ifndef DUAL_EDGE_ER2_STANDBY_RANK
#define DUAL_EDGE_ER2_STANDBY_RANK     512
#endif
#ifndef DUAL_EDGE_ER2_PROMOTED_RANK
#define DUAL_EDGE_ER2_PROMOTED_RANK    256
#endif

/* Replication channel */
#ifndef DUAL_EDGE_REPLICATION_PORT
#define DUAL_EDGE_REPLICATION_PORT     7777
#endif
#ifndef DUAL_EDGE_HEARTBEAT_INTERVAL
#define DUAL_EDGE_HEARTBEAT_INTERVAL   (5 * CLOCK_SECOND)
#endif
#ifndef DUAL_EDGE_HEARTBEAT_MISS_MAX
#define DUAL_EDGE_HEARTBEAT_MISS_MAX   3
#endif

/* Replication flags */
#ifndef DE_REPLICATE_OSCORE_CONTEXTS
#define DE_REPLICATE_OSCORE_CONTEXTS   0x01
#endif
#ifndef DE_REPLICATE_TARP_STATE
#define DE_REPLICATE_TARP_STATE        0x02
#endif
#ifndef DE_REPLICATE_CLUSTER_REGISTRY
#define DE_REPLICATE_CLUSTER_REGISTRY  0x04
#endif
#ifndef DE_REPLICATE_ML_ACCESS_POLICY
#define DE_REPLICATE_ML_ACCESS_POLICY  0x08
#endif

/* ER state machine */
#ifndef DE_STATE_STANDBY
#define DE_STATE_STANDBY               0
#endif
#ifndef DE_STATE_PRIMARY
#define DE_STATE_PRIMARY               1
#endif
#ifndef DE_STATE_PROMOTED
#define DE_STATE_PROMOTED              2
#endif
#ifndef DE_STATE_RECOVERING
#define DE_STATE_RECOVERING            3
#endif

/* Message types */
#ifndef MSG_TYPE_DE_HEARTBEAT
#define MSG_TYPE_DE_HEARTBEAT          100
#endif
#ifndef MSG_TYPE_DE_SNAPSHOT
#define MSG_TYPE_DE_SNAPSHOT           101
#endif
#ifndef MSG_TYPE_DE_DELTA_UPDATE
#define MSG_TYPE_DE_DELTA_UPDATE       102
#endif
#ifndef MSG_TYPE_DE_SNAPSHOT_ACK
#define MSG_TYPE_DE_SNAPSHOT_ACK       103
#endif
#ifndef MSG_TYPE_DE_FAILOVER_DECLARE
#define MSG_TYPE_DE_FAILOVER_DECLARE   104
#endif
#ifndef MSG_TYPE_DE_FAILOVER_ACK
#define MSG_TYPE_DE_FAILOVER_ACK       105
#endif
#ifndef MSG_TYPE_DE_RECOVERY_NOTIFY
#define MSG_TYPE_DE_RECOVERY_NOTIFY    106
#endif
#ifndef MSG_TYPE_DE_CONTEXT_REQUEST
#define MSG_TYPE_DE_CONTEXT_REQUEST    107
#endif

/* Delta update types */
#ifndef DE_DELTA_SEQ_UPDATE
#define DE_DELTA_SEQ_UPDATE            0x01
#endif
#ifndef DE_DELTA_KEY_ROTATION
#define DE_DELTA_KEY_ROTATION          0x02
#endif
#ifndef DE_DELTA_TRUST_CHANGE
#define DE_DELTA_TRUST_CHANGE          0x03
#endif
#ifndef DE_DELTA_ML_ACCESS
#define DE_DELTA_ML_ACCESS             0x04
#endif
#ifndef DE_DELTA_CLUSTER_JOIN
#define DE_DELTA_CLUSTER_JOIN          0x05
#endif
#ifndef DE_DELTA_CLUSTER_LEAVE
#define DE_DELTA_CLUSTER_LEAVE         0x06
#endif

/* Safety margins and targets */
#ifndef DE_NONCE_SAFETY_MARGIN
#define DE_NONCE_SAFETY_MARGIN         64
#endif
#ifndef DE_TARGET_FAILOVER_MS
#define DE_TARGET_FAILOVER_MS          3000
#endif
#ifndef DE_TARGET_REPLICATION_OVERHEAD
#define DE_TARGET_REPLICATION_OVERHEAD 0.02f
#endif

/* end FIX-DE3 */

/*=============================================================================
 * ER2 REPLICATED STATE STORAGE
 *============================================================================*/

static de_replicated_context_t er2_contexts[DE_MAX_REPLICATED_CONTEXTS];
static de_replicated_cluster_t er2_clusters[DE_MAX_REPLICATED_CLUSTERS];
static uint8_t er2_num_contexts  = 0;
static uint8_t er2_num_clusters  = 0;

/* Liveness tracking */
static clock_time_t er2_last_heartbeat   = 0;
static uint8_t      er2_missed_heartbeats = 0;
/* FIX-ER2-FALSEFAILOVER: ER2 may only detect ER1 *failure* after it has actually
 * received at least one heartbeat from ER1. Without this, if the ER1->ER2
 * heartbeat channel never flows (address/topology mismatch), ER2 falsely fails
 * over at ~15 s, calls root_start(), becomes a SECOND competing RPL root, and
 * floods DIOs at the minimum trickle interval — churning the whole network until
 * Cooja stalls. This flag gates the watchdog on genuine prior contact with ER1. */
static uint8_t      er2_ever_heard_er1   = 0;
static uint8_t      er2_state            = DE_STATE_STANDBY;

/* Sequence-number tracking from ER1 heartbeats (for DE-C2) */
static uint64_t er2_max_seq_mqtt  = 0;
static uint64_t er2_max_seq_coap  = 0;
static uint64_t er2_max_seq_group = 0;

/* Snapshot tracking */
static uint32_t er2_last_snapshot_id = 0;

/* ER1 address (learned from first heartbeat) */
static uip_ipaddr_t er1_ipaddr;
static uint8_t      er1_addr_known = 0;

/* UDP connection: ER1<->ER2 replication channel */
static struct simple_udp_connection er2_repl_conn;

/* Timers */
static struct etimer er2_watchdog_timer;  /* Monitor ER1 heartbeats */
static struct etimer er2_stats_timer;     /* Periodic status output */

/* DE-C4 evaluation metrics */
static struct {
    uint32_t    heartbeats_received;
    uint32_t    snapshots_received;
    uint32_t    delta_updates_received;
    uint32_t    failover_events;
    clock_time_t failover_detected_at;
    clock_time_t failover_promoted_at;
    uint32_t    nonce_collisions_prevented;   /* Always 0 — invariant */
    uint32_t    replication_bytes;
    uint32_t    total_bytes;
} er2_metrics;

/*=============================================================================
 * FORWARD DECLARATIONS
 * All helper functions are declared here so that PROCESS_THREAD() can call
 * them regardless of definition order. This also prevents "invalid storage
 * class" errors if a build system or editor reorders sections.
 *============================================================================*/
static de_replicated_context_t *er2_find_ctx(uint8_t sender_id);
static de_replicated_context_t *er2_alloc_ctx(uint8_t sender_id);
static de_replicated_cluster_t *er2_find_cl(uint8_t cluster_id);
static de_replicated_cluster_t *er2_alloc_cl(uint8_t cluster_id);
static void er2_handle_heartbeat(const de_heartbeat_t *hb, const uip_ipaddr_t *from);
static void er2_handle_snapshot(const uint8_t *data, uint16_t datalen, const uip_ipaddr_t *from);
static void er2_handle_delta(const de_delta_update_t *d);
static void er2_compute_s_failover(uint64_t *s_mqtt, uint64_t *s_coap, uint64_t *s_group);
static void er2_start_rpl_standby(void);
static void er2_promote_rpl_root(void);
static void er2_declare_failover(void);
static void er2_handle_recovery(const uip_ipaddr_t *from);
static void er2_print_metrics(void);
static void er2_udp_rx_callback(struct simple_udp_connection *c,
    const uip_ipaddr_t *sender_addr, uint16_t sender_port,
    const uip_ipaddr_t *receiver_addr, uint16_t receiver_port,
    const uint8_t *data, uint16_t datalen);

/*=============================================================================
 * PROCESS DECLARATION
 *============================================================================*/

PROCESS(er2_process, "ER2 Standby Edge Root");
AUTOSTART_PROCESSES(&er2_process);

/*=============================================================================
 * HELPER: Find / allocate replicated slots
 *============================================================================*/

static de_replicated_context_t *er2_find_ctx(uint8_t sender_id)
{
    for (uint8_t i = 0; i < DE_MAX_REPLICATED_CONTEXTS; i++) {
        if (er2_contexts[i].valid && er2_contexts[i].sender_id == sender_id)
            return &er2_contexts[i];
    }
    return NULL;
}

static de_replicated_context_t *er2_alloc_ctx(uint8_t sender_id)
{
    de_replicated_context_t *e = er2_find_ctx(sender_id);
    if (e) return e;
    for (uint8_t i = 0; i < DE_MAX_REPLICATED_CONTEXTS; i++) {
        if (!er2_contexts[i].valid) {
            memset(&er2_contexts[i], 0, sizeof(er2_contexts[i]));
            er2_contexts[i].sender_id = sender_id;
            er2_contexts[i].valid     = 1;
            er2_num_contexts++;
            return &er2_contexts[i];
        }
    }
    LOG_WARN("ER2: no free context slots\n");
    return NULL;
}

static de_replicated_cluster_t *er2_find_cl(uint8_t cluster_id)
{
    for (uint8_t i = 0; i < DE_MAX_REPLICATED_CLUSTERS; i++) {
        if (er2_clusters[i].valid && er2_clusters[i].id == cluster_id)
            return &er2_clusters[i];
    }
    return NULL;
}

static de_replicated_cluster_t *er2_alloc_cl(uint8_t cluster_id)
{
    de_replicated_cluster_t *e = er2_find_cl(cluster_id);
    if (e) return e;
    for (uint8_t i = 0; i < DE_MAX_REPLICATED_CLUSTERS; i++) {
        if (!er2_clusters[i].valid) {
            memset(&er2_clusters[i], 0, sizeof(er2_clusters[i]));
            er2_clusters[i].id    = cluster_id;
            er2_clusters[i].valid = 1;
            er2_num_clusters++;
            return &er2_clusters[i];
        }
    }
    LOG_WARN("ER2: no free cluster slots\n");
    return NULL;
}

/*=============================================================================
 * DE-C1: Handle heartbeat from ER1
 *============================================================================*/

static void er2_handle_heartbeat(const de_heartbeat_t *hb,
                                  const uip_ipaddr_t *from)
{
    if (!hb) return;

    /* Learn ER1 address on first contact */
    if (!er1_addr_known) {
        uip_ipaddr_copy(&er1_ipaddr, from);
        er1_addr_known = 1;
        LOG_INFO("ER2: ER1 address learned from first heartbeat\n");
    }

    er2_last_heartbeat    = clock_time();
    er2_missed_heartbeats = 0;
    er2_ever_heard_er1    = 1;   /* genuine contact with ER1 established */

    /* Update max sequence numbers (used by DE-C2) */
    if (hb->max_sender_seq_mqtt  > er2_max_seq_mqtt)
        er2_max_seq_mqtt  = hb->max_sender_seq_mqtt;
    if (hb->max_sender_seq_coap  > er2_max_seq_coap)
        er2_max_seq_coap  = hb->max_sender_seq_coap;
    if (hb->max_sender_seq_group > er2_max_seq_group)
        er2_max_seq_group = hb->max_sender_seq_group;

    er2_metrics.heartbeats_received++;
    er2_metrics.replication_bytes += (uint32_t)sizeof(de_heartbeat_t);
    er2_metrics.total_bytes        += (uint32_t)sizeof(de_heartbeat_t);

    LOG_DBG("ER2: HB #%"PRIu32" up=%"PRIu32"s cl=%u seq_mqtt=%"PRIu64"\n",
            hb->er1_seq_counter, hb->er1_uptime_s,
            hb->active_clusters, hb->max_sender_seq_mqtt);
}

/*=============================================================================
 * DE-C1: Handle full snapshot from ER1
 *============================================================================*/

static void er2_handle_snapshot(const uint8_t *data, uint16_t datalen,
                                  const uip_ipaddr_t *from)
{
    if (!data || datalen < (uint16_t)sizeof(de_snapshot_hdr_t)) return;

    const de_snapshot_hdr_t *hdr = (const de_snapshot_hdr_t *)data;
    if (hdr->snapshot_id <= er2_last_snapshot_id) return;  /* stale */
    er2_last_snapshot_id = hdr->snapshot_id;

    uint16_t off = sizeof(de_snapshot_hdr_t);
    er2_metrics.snapshots_received++;

    /* Ingest OSCORE contexts */
    if (hdr->replication_flags & DE_REPLICATE_OSCORE_CONTEXTS) {
        for (uint8_t i = 0; i < hdr->num_contexts; i++) {
            if (off + (uint16_t)sizeof(de_replicated_context_t) > datalen) break;
            const de_replicated_context_t *src =
                (const de_replicated_context_t *)(data + off);
            de_replicated_context_t *slot = er2_alloc_ctx(src->sender_id);
            if (slot) {
                memcpy(slot, src, sizeof(de_replicated_context_t));
                slot->valid = 1;
                if (src->sender_seq > er2_max_seq_mqtt)
                    er2_max_seq_mqtt = src->sender_seq;
            }
            off += (uint16_t)sizeof(de_replicated_context_t);
        }
    }

    /* Ingest cluster registrations */
    if (hdr->replication_flags & DE_REPLICATE_CLUSTER_REGISTRY) {
        for (uint8_t i = 0; i < hdr->num_clusters; i++) {
            if (off + (uint16_t)sizeof(de_replicated_cluster_t) > datalen) break;
            const de_replicated_cluster_t *src =
                (const de_replicated_cluster_t *)(data + off);
            de_replicated_cluster_t *slot = er2_alloc_cl(src->id);
            if (slot) {
                memcpy(slot, src, sizeof(de_replicated_cluster_t));
                slot->valid = 1;
            }
            off += (uint16_t)sizeof(de_replicated_cluster_t);
        }
    }

    er2_metrics.replication_bytes += (uint32_t)datalen;
    er2_metrics.total_bytes        += (uint32_t)datalen;

    /* Send ACK to ER1 */
    uint8_t ack[8];
    ack[0] = MSG_TYPE_DE_SNAPSHOT_ACK;
    ack[1] = (uint8_t)(hdr->snapshot_id >> 24);
    ack[2] = (uint8_t)(hdr->snapshot_id >> 16);
    ack[3] = (uint8_t)(hdr->snapshot_id >>  8);
    ack[4] = (uint8_t)(hdr->snapshot_id);
    ack[5] = er2_num_contexts;
    ack[6] = er2_num_clusters;
    ack[7] = er2_state;
    if (er1_addr_known)
        simple_udp_sendto(&er2_repl_conn, ack, sizeof(ack), &er1_ipaddr);
    else
        simple_udp_sendto(&er2_repl_conn, ack, sizeof(ack), from);

    LOG_INFO("ER2: SNAP #%"PRIu32" ctx=%u cl=%u\n",
             hdr->snapshot_id, er2_num_contexts, er2_num_clusters);
}

/*=============================================================================
 * DE-C1: Handle delta update from ER1
 *============================================================================*/

static void er2_handle_delta(const de_delta_update_t *d)
{
    if (!d) return;
    de_replicated_context_t *ctx = er2_find_ctx(d->sender_id);

    switch (d->update_type) {

    case DE_DELTA_SEQ_UPDATE:
        if (ctx) {
            if (d->new_sender_seq > ctx->sender_seq)
                ctx->sender_seq = d->new_sender_seq;
            if (d->new_sender_seq > er2_max_seq_mqtt)
                er2_max_seq_mqtt = d->new_sender_seq;
        }
        break;

    case DE_DELTA_KEY_ROTATION:
        if (!ctx) ctx = er2_alloc_ctx(d->sender_id);
        if (ctx) {
            ctx->current_epoch = d->new_epoch;
            ctx->key_state     = d->new_key_state;
            ctx->sender_seq    = d->new_sender_seq;
            ctx->composite_trust = d->new_trust;
            /* FIX-DE-MLACCESS-MIRROR: also mirror the ML-ACCESS state carried in
             * the key-rotation delta. ER1 (edge.c) now sends the *classified*
             * access state rather than a constant, so applying it here keeps
             * ER2's mirror consistent with ER1 between ML_ACCESS deltas. Purely
             * local to this file (no new cross-module dependency). */
            ctx->ml_access_state = d->ml_access_state;
            if (d->key_changed) {
                memcpy(ctx->sender_key,    d->new_sender_key,    16);
                memcpy(ctx->recipient_key, d->new_recipient_key, 16);
            }
            if (d->new_sender_seq > er2_max_seq_mqtt)
                er2_max_seq_mqtt = d->new_sender_seq;
        }
        LOG_DBG("ER2: delta KEY_ROT sid=0x%02x epoch=%u\n",
                d->sender_id, d->new_epoch);
        break;

    case DE_DELTA_TRUST_CHANGE:
        if (ctx) ctx->composite_trust = d->new_trust;
        break;

    case DE_DELTA_ML_ACCESS:
        if (ctx) ctx->ml_access_state = d->ml_access_state;
        break;

    case DE_DELTA_CLUSTER_JOIN: {
        de_replicated_cluster_t *cl = er2_alloc_cl(d->sender_id);
        if (cl) { cl->is_registered = 1; cl->is_active = 1; }
        break;
    }
    case DE_DELTA_CLUSTER_LEAVE: {
        de_replicated_cluster_t *cl = er2_find_cl(d->sender_id);
        if (cl) cl->is_active = 0;
        break;
    }
    default:
        LOG_WARN("ER2: unknown delta type 0x%02x\n", d->update_type);
        break;
    }

    er2_metrics.delta_updates_received++;
    er2_metrics.replication_bytes += (uint32_t)sizeof(de_delta_update_t);
    er2_metrics.total_bytes        += (uint32_t)sizeof(de_delta_update_t);
}

/*=============================================================================
 * DE-C2: Compute failover sequence numbers
 *
 * S_failover = max(S_mqtt, S_coap, S_group) + DE_NONCE_SAFETY_MARGIN
 *
 * Nonce-Uniqueness Theorem (DE-C2):
 *   Let N_pre  = set of all nonces used before failover.
 *   Let N_post = set of all nonces used after failover.
 *   S_failover > max(N_pre) because:
 *     S_failover = max(heartbeat seq, context seq) + 64
 *   Therefore N_post ∩ N_pre = ∅.  QED.
 *   AES-CCM-16-64-128 confidentiality and authenticity preserved.
 *============================================================================*/

static void er2_compute_s_failover(uint64_t *s_mqtt,
                                    uint64_t *s_coap,
                                    uint64_t *s_group)
{
    uint64_t mx_mqtt  = er2_max_seq_mqtt;
    uint64_t mx_coap  = er2_max_seq_coap;
    uint64_t mx_group = er2_max_seq_group;

    /* Also scan all replicated contexts for higher sequences */
    for (uint8_t i = 0; i < DE_MAX_REPLICATED_CONTEXTS; i++) {
        if (!er2_contexts[i].valid) continue;
        if (er2_contexts[i].sender_seq > mx_mqtt)
            mx_mqtt = er2_contexts[i].sender_seq;
    }

    *s_mqtt  = mx_mqtt  + (uint64_t)DE_NONCE_SAFETY_MARGIN;
    *s_coap  = mx_coap  + (uint64_t)DE_NONCE_SAFETY_MARGIN;
    *s_group = mx_group + (uint64_t)DE_NONCE_SAFETY_MARGIN;

    LOG_INFO("ER2: DE-C2 S_failover mqtt=%"PRIu64
             " coap=%"PRIu64" grp=%"PRIu64"\n",
             *s_mqtt, *s_coap, *s_group);
}

/*=============================================================================
 * DE-C3: RPL rank management
 *============================================================================*/

/* FIX-ROOT (ER2): rpl-lite's root_start() needs a preferred global address to
 * build the DODAG-ID; ER2 must set its own before acting as (standby) root, and
 * again is guaranteed to have one for post-failover promotion. Prefix fd00:: +
 * this mote's IID yields fd00::202:2:2:2 for Cooja node 2. Mirrors
 * edge.c:edge_set_global_address(). */
static void
er2_set_global_address(void)
{
    uip_ipaddr_t ipaddr;

    uip_ip6addr(&ipaddr, 0xfd00, 0, 0, 0, 0, 0, 0, 0);
    uip_ds6_set_addr_iid(&ipaddr, &uip_lladdr);
    uip_ds6_addr_add(&ipaddr, 0, ADDR_AUTOCONF);

    LOG_INFO("FIX-ROOT: ER2 global address set to ");
    LOG_INFO_6ADDR(&ipaddr);
    LOG_INFO_("\n");
}

static void er2_start_rpl_standby(void)
{
    /* FIX-DUALROOT (critical): ER2 must NOT start a second RPL root at boot.
     *
     * rpl-lite supports a single DODAG per instance. The previous code called
     * NETSTACK_ROUTING.root_start() here, which made ER2 the root of its OWN
     * competing DODAG (DODAG-ID fd00::202:2:2:2). That has two fatal effects
     * that exactly match the observed symptoms:
     *   1. ER1 (the real root) has no route to ER2's separate DODAG, so every
     *      replication heartbeat/snapshot to fd00::202:2:2:2 is dropped and ER1
     *      reports "ACKs received: 0" even though ER2 is a direct neighbour.
     *   2. Cluster/client nodes fragment across the two roots, so registrations
     *      never converge on ER1.
     *
     * The "standby via higher rank" idea does not exist in RPL: a root is always
     * root-rank in its own DODAG. The correct primary-backup behaviour is for
     * ER2 to join ER1's DODAG as a NORMAL node now, and to call root_start()
     * ONLY on failover (see er2_promote_rpl_root(), invoked from
     * er2_declare_failover()).
     *
     * We still assign a stable global address so the replication channel has a
     * fixed fd00:: identity immediately; once ER2 joins ER1's DODAG it advertises
     * a DAO for this address and ER1 can source-route the heartbeats to it. */
    er2_set_global_address();

    LOG_INFO("ER2: standby ready — joined ER1's DODAG as a NORMAL node; will "
             "promote to RPL root only on ER1 failover\n");
}

static void er2_promote_rpl_root(void)
{
    /* DE-C3: Promote ER2 to active RPL root so the network reconverges.
     *
     * RPL-lite (Contiki-NG's default since v4.x) does not expose
     * rpl_reset_periodic_timer(). The correct API is
     * NETSTACK_ROUTING.root_start(), which internally resets the trickle
     * timer and begins flooding DIOs at the minimum interval — exactly the
     * behaviour needed to trigger rapid network reconvergence to ER2.
     *
     * Result: all CCs and clients receive ER2's lower-rank DIOs within
     * 1-2 DIO intervals (typically < 30 s) and re-select ER2 as root. */
    /* FIX-ROOT: guarantee a global address is present before promotion. */
    er2_set_global_address();
    NETSTACK_ROUTING.root_start();
    LOG_INFO("ER2: DE-C3 RPL root promoted — trickle reset, network reconverging to ER2\n");
}

/*=============================================================================
 * DE-C2+C3: Declare failover — called when ER1 unreachable
 *============================================================================*/

static void er2_declare_failover(void)
{
    if (er2_state != DE_STATE_STANDBY) return;

    er2_state = DE_STATE_PROMOTED;
    er2_metrics.failover_events++;
    er2_metrics.failover_promoted_at = clock_time();

    uint32_t detect_ms = (uint32_t)(
        (er2_metrics.failover_promoted_at - er2_metrics.failover_detected_at)
        * 1000UL / CLOCK_SECOND);

    LOG_INFO("ER2: === FAILOVER DECLARED ===\n");
    LOG_INFO("ER2: detection->promotion: %"PRIu32" ms (target <%u ms)\n",
             detect_ms, (unsigned)DE_TARGET_FAILOVER_MS);
    LOG_INFO("ER2: mirrored contexts=%u clusters=%u\n",
             er2_num_contexts, er2_num_clusters);

    /* DE-C2: Compute failover sequences */
    uint64_t s_mqtt, s_coap, s_group;
    er2_compute_s_failover(&s_mqtt, &s_coap, &s_group);

    /* Apply S_failover to all mirrored contexts */
    for (uint8_t i = 0; i < DE_MAX_REPLICATED_CONTEXTS; i++) {
        if (!er2_contexts[i].valid) continue;
        if (er2_contexts[i].sender_seq < s_mqtt)
            er2_contexts[i].sender_seq = s_mqtt;
    }
    er2_metrics.nonce_collisions_prevented = 0;  /* Invariant: always 0 */

    /* DE-C3: Promote RPL root */
    er2_promote_rpl_root();

    /* Build and broadcast failover declaration to all known clusters */
    de_failover_declare_t fd;
    fd.er2_node_id              = DUAL_EDGE_ER2_NODE_ID;
    fd.failover_time_s          = (uint32_t)(clock_time() / CLOCK_SECOND);
    fd.s_failover_mqtt          = s_mqtt;
    fd.s_failover_coap          = s_coap;
    fd.s_failover_group         = s_group;
    fd.num_recovered_contexts   = er2_num_contexts;
    fd.num_recovered_clusters   = er2_num_clusters;
    fd.er2_new_rank_lsb         = (uint8_t)(DUAL_EDGE_ER2_PROMOTED_RANK & 0xFF);

    uint8_t buf[1 + sizeof(de_failover_declare_t)];
    buf[0] = MSG_TYPE_DE_FAILOVER_DECLARE;
    memcpy(buf + 1, &fd, sizeof(fd));

    for (uint8_t i = 0; i < DE_MAX_REPLICATED_CLUSTERS; i++) {
        if (!er2_clusters[i].valid || !er2_clusters[i].is_active) continue;
        simple_udp_sendto(&er2_repl_conn, buf, sizeof(buf),
                          &er2_clusters[i].addr);
        LOG_DBG("ER2: failover declaration -> cluster %u\n",
                er2_clusters[i].id);
    }

    LOG_INFO("ER2: failover broadcast complete. Awaiting CC acknowledgments.\n");
}

/*=============================================================================
 * Handle ER1 recovery notification
 *============================================================================*/

static void er2_handle_recovery(const uip_ipaddr_t *from)
{
    (void)from;
    LOG_INFO("ER2: ER1 has recovered — transitioning back to standby\n");
    er2_state             = DE_STATE_STANDBY;
    er2_missed_heartbeats = 0;
    er2_last_heartbeat    = clock_time();
    /* ER1's lower-rank DIOs will naturally cause nodes to re-prefer ER1 */
}

/*=============================================================================
 * DE-C4: Print evaluation metrics
 *============================================================================*/

static void er2_print_metrics(void)
{
    const char *state_str =
        (er2_state == DE_STATE_STANDBY)    ? "STANDBY"    :
        (er2_state == DE_STATE_PROMOTED)   ? "PROMOTED"   :
        (er2_state == DE_STATE_RECOVERING) ? "RECOVERING" : "UNKNOWN";

    float repl_overhead = (er2_metrics.total_bytes > 0)
        ? (float)er2_metrics.replication_bytes /
          (float)er2_metrics.total_bytes
        : 0.0f;

    float ctx_recovery = (DE_MAX_REPLICATED_CONTEXTS > 0)
        ? (float)er2_num_contexts /
          (float)DE_MAX_REPLICATED_CONTEXTS
        : 0.0f;

    LOG_INFO("=== ER2 STATUS [%s] (Paper 9 DE-C4) ===\n", state_str);
    LOG_INFO("  Contexts mirrored : %u/%u (%.1f%%)\n",
             er2_num_contexts, DE_MAX_REPLICATED_CONTEXTS,
             ctx_recovery * 100.0f);
    LOG_INFO("  Clusters mirrored : %u\n", er2_num_clusters);
    LOG_INFO("  Heartbeats rcv    : %"PRIu32"\n",
             er2_metrics.heartbeats_received);
    LOG_INFO("  Snapshots rcv     : %"PRIu32"\n",
             er2_metrics.snapshots_received);
    LOG_INFO("  Delta updates rcv : %"PRIu32"\n",
             er2_metrics.delta_updates_received);
    LOG_INFO("  Failover events   : %"PRIu32"\n",
             er2_metrics.failover_events);
    LOG_INFO("  Repl overhead     : %.2f%% (target <%.0f%%)\n",
             repl_overhead * 100.0f,
             (double)(DE_TARGET_REPLICATION_OVERHEAD * 100.0f));
    LOG_INFO("  Max seq MQTT      : %"PRIu64"\n", er2_max_seq_mqtt);
    LOG_INFO("  Max seq CoAP      : %"PRIu64"\n", er2_max_seq_coap);
    LOG_INFO("  Missed HBs        : %u / %u\n",
             er2_missed_heartbeats, DUAL_EDGE_HEARTBEAT_MISS_MAX);
    LOG_INFO("  Nonce collisions  : %"PRIu32" (MUST be 0 — DE-C2 invariant)\n",
             er2_metrics.nonce_collisions_prevented);

    if (er2_metrics.failover_events > 0) {
        uint32_t fms = (uint32_t)(
            (er2_metrics.failover_promoted_at -
             er2_metrics.failover_detected_at)
            * 1000UL / CLOCK_SECOND);
        LOG_INFO("  Failover latency  : %"PRIu32" ms (target <%u ms)\n",
                 fms, (unsigned)DE_TARGET_FAILOVER_MS);
    }
    LOG_INFO("==========================================\n");
}

/*=============================================================================
 * UDP receive callback — routes all replication messages
 *============================================================================*/

static void er2_udp_rx_callback(struct simple_udp_connection *c,
    const uip_ipaddr_t *sender_addr, uint16_t sender_port,
    const uip_ipaddr_t *receiver_addr, uint16_t receiver_port,
    const uint8_t *data, uint16_t datalen)
{
    (void)c; (void)sender_port; (void)receiver_addr; (void)receiver_port;
    if (!data || datalen < 1) return;

    er2_metrics.total_bytes += (uint32_t)datalen;
    uint8_t mt = data[0];

    switch (mt) {

    case MSG_TYPE_DE_HEARTBEAT:
        if (datalen >= 1 + (uint16_t)sizeof(de_heartbeat_t))
            er2_handle_heartbeat((const de_heartbeat_t *)(data + 1),
                                  sender_addr);
        break;

    case MSG_TYPE_DE_SNAPSHOT:
        if (datalen > 1 + (uint16_t)sizeof(de_snapshot_hdr_t))
            er2_handle_snapshot(data + 1, datalen - 1, sender_addr);
        break;

    case MSG_TYPE_DE_DELTA_UPDATE:
        if (datalen >= 1 + (uint16_t)sizeof(de_delta_update_t))
            er2_handle_delta((const de_delta_update_t *)(data + 1));
        break;

    case MSG_TYPE_DE_RECOVERY_NOTIFY:
        er2_handle_recovery(sender_addr);
        break;

    case MSG_TYPE_DE_FAILOVER_ACK:
        LOG_INFO("ER2: failover ACK from cluster\n");
        break;

    default:
        LOG_WARN("ER2: unknown msg_type=0x%02x len=%u\n", mt, datalen);
        break;
    }
}

/*=============================================================================
 * MAIN PROCESS
 *============================================================================*/

PROCESS_THREAD(er2_process, ev, data)
{
    PROCESS_BEGIN();
    energy_log_start();   /* v5: DLNRG records (energy_log.c) */

    LOG_INFO("============================================\n");
    LOG_INFO("ER2: Dual-Edge Standby Root starting\n");
    LOG_INFO("ER2: Paper 9 — DE-C1/C2/C3/C4\n");
    LOG_INFO("ER2: Node ID %u, replication port %u\n",
             DUAL_EDGE_ER2_NODE_ID, DUAL_EDGE_REPLICATION_PORT);
    LOG_INFO("ER2: Nonce margin %u, failover target %u ms\n",
             DE_NONCE_SAFETY_MARGIN, DE_TARGET_FAILOVER_MS);
    LOG_INFO("============================================\n");

    /* Initialise replicated state */
    memset(er2_contexts, 0, sizeof(er2_contexts));
    memset(er2_clusters, 0, sizeof(er2_clusters));
    memset(&er2_metrics,  0, sizeof(er2_metrics));
    er2_state              = DE_STATE_STANDBY;
    er2_num_contexts       = 0;
    er2_num_clusters       = 0;
    er2_missed_heartbeats  = 0;
    er2_last_heartbeat     = clock_time();
    er1_addr_known         = 0;

    /* Open UDP replication channel */
    simple_udp_register(&er2_repl_conn,
                         DUAL_EDGE_REPLICATION_PORT, NULL,
                         DUAL_EDGE_REPLICATION_PORT,
                         er2_udp_rx_callback);
    LOG_INFO("ER2: replication UDP channel open on port %u\n",
             DUAL_EDGE_REPLICATION_PORT);

    /* DE-C3: Start as RPL root in standby mode */
    er2_start_rpl_standby();

    /* Start watchdog and stats timers */
    safe_etimer_set(&er2_watchdog_timer, DUAL_EDGE_HEARTBEAT_INTERVAL);
    safe_etimer_set(&er2_stats_timer,    60 * CLOCK_SECOND);

    LOG_INFO("ER2: ready — monitoring ER1 heartbeats "
             "(miss_max=%u, interval=%u s)\n",
             DUAL_EDGE_HEARTBEAT_MISS_MAX,
             (unsigned)(DUAL_EDGE_HEARTBEAT_INTERVAL / CLOCK_SECOND));

    while (1) {
        PROCESS_WAIT_EVENT();

        if (ev == PROCESS_EVENT_TIMER) {

            /* ---- Watchdog: detect ER1 failure ---- */
            if (etimer_expired(&er2_watchdog_timer)) {
                clock_time_t now     = clock_time();
                clock_time_t elapsed = now - er2_last_heartbeat;

                if (er2_ever_heard_er1               /* only after real contact */
                    && elapsed > DUAL_EDGE_HEARTBEAT_INTERVAL
                    && er2_state == DE_STATE_STANDBY) {

                    er2_missed_heartbeats++;
                    LOG_WARN("ER2: missed HB #%u of %u\n",
                             er2_missed_heartbeats,
                             DUAL_EDGE_HEARTBEAT_MISS_MAX);

                    if (er2_missed_heartbeats == 1) {
                        /* Record when failure was first detected */
                        er2_metrics.failover_detected_at = clock_time();
                    }

                    if (er2_missed_heartbeats >= DUAL_EDGE_HEARTBEAT_MISS_MAX) {
                        LOG_WARN("ER2: ER1 UNREACHABLE after %u missed HBs\n",
                                 er2_missed_heartbeats);
                        er2_declare_failover();
                    }
                }
                etimer_reset(&er2_watchdog_timer);
            }

            /* ---- Stats timer ---- */
            if (etimer_expired(&er2_stats_timer)) {
                er2_print_metrics();
                etimer_reset(&er2_stats_timer);
            }
        }
    }

    PROCESS_END();
}
