/*******************************************************************************
 * AGIM.C -- Anomaly-Driven Gateway Integrity Monitor (SurvivEdge sec.IV-C)
 *
 * RECONSTRUCTION of the published design. Compiled INTO the cluster binary
 * (PROJECT_SOURCEFILES). Runs each 15 s maintenance cycle at every CC.
 *
 * Fuses three locally-computable signals to detect edge-root compromise:
 *   d_policy   -- disagreement between received vs local 4-state assignment (C2,C4)
 *   d_keying   -- observed vs expected key-rotation frequency           (C3)
 *   d_response -- edge-root response-timeout severity {0,1,2}           (timeouts)
 *   D = w_p*d_policy + w_k*d_keying + (w_r/2)*d_response   (Eq. deviation)
 * A CompromiseAlert is raised when D > delta_sus for SE_AGIM_CONFIRM_CYCLES
 * consecutive cycles (2-cycle false-positive suppression).
 *
 * VERIFICATION (published parameters & logic):
 *   - Weights match the paper: w_policy=0.40, w_keying=0.35, w_response=0.25
 *     (SE_AGIM_* in survivedge.h); they sum to 1.00 (well-formed weighting).
 *   - delta_sus=0.55, confirm_cycles=2, keying_eps=0.001, resp_timeout=500 ms.
 *   - Fusion + 2-cycle alert logic checked with worked examples:
 *       D = 0.40*dp + 0.35*dk + 0.25*(level/2)
 *       (dp=.5,dk=.2,lvl=2) -> D=0.520 < 0.55 -> no alert
 *       (dp=.8,dk=.6,lvl=2) -> D=0.780 > 0.55 -> alert on 2nd consecutive cycle
 *       one cycle with D<=delta_sus clears the run (false-positive suppression).
 *
 * SELF-CONTAINED: implementation lives here; agim_state_t and the SE_AGIM_*
 * constants come from survivedge.h (this module's own header). agim.c is NOT
 * wired into cluster.c here -- that cross-tier wiring is intentionally omitted.
 ******************************************************************************/

#include "compatibility.h"
#include "contiki.h"
#include "contiki-net.h"
#include "dual_edge_types.h"
#include "timer_patch.h"
#include "sys/log.h"
#include "oscore_crypto.h"
#include "survivedge.h"
#include <string.h>
#include <math.h>

#define LOG_MODULE "AGIM"
#ifndef LOG_LEVEL_AGIM
#define LOG_LEVEL_AGIM LOG_LEVEL_INFO
#endif
#define LOG_LEVEL LOG_LEVEL_AGIM

void
agim_init(agim_state_t *st)
{
    if(st == NULL) {
        return;
    }
    memset(st, 0, sizeof(*st));
}

/* Eq. d_policy: fraction of nodes whose received state differs from the
 * locally-assigned state. local_states[] are produced by se_ml_access_classify. */
float
agim_d_policy(const uint8_t *local_states, const uint8_t *received_states,
              uint16_t n_nodes)
{
    uint16_t i, mismatches = 0;

    if(local_states == NULL || received_states == NULL || n_nodes == 0) {
        return 0.0f;
    }
    for(i = 0; i < n_nodes; i++) {
        if(local_states[i] != received_states[i]) {
            mismatches++;
        }
    }
    return (float)mismatches / (float)n_nodes;
}

/* Eq. d_keying: |obs - exp| / (exp + epsilon). */
float
agim_d_keying(float observed_rotate_freq, float expected_rotate_freq)
{
    float num = observed_rotate_freq - expected_rotate_freq;
    if(num < 0.0f) {
        num = -num;
    }
    return num / (expected_rotate_freq + SE_AGIM_KEYING_EPSILON);
}

/* Eq. d_response: two-level severity from the response time vs tau_max.
 *   resp > tau_max      -> +1  (soft timeout)
 *   resp > 3*tau_max    -> +1  (complete non-response)  => total in {0,1,2} */
uint8_t
agim_d_response_level(uint32_t resp_ms)
{
    uint8_t level = 0;
    if(resp_ms > SE_AGIM_RESP_TIMEOUT_MS) {
        level++;
    }
    if(resp_ms > (uint32_t)(3 * SE_AGIM_RESP_TIMEOUT_MS)) {
        level++;
    }
    return level;       /* 0, 1, or 2 */
}

/* Fuse the three signals and apply the 2-consecutive-cycle confirmation rule.
 * Returns 1 only on the cycle the alert is first raised. */
uint8_t
agim_evaluate(agim_state_t *st, float d_policy, float d_keying,
              uint8_t d_response_level)
{
    float d_response_norm;
    float D;
    uint8_t fired = 0;

    if(st == NULL) {
        return 0;
    }

    /* d_response is normalised by its maximum (2). The (w_r/2) factor in the
     * paper's Eq. deviation is equivalent to applying w_r to (level/2). */
    d_response_norm = (float)d_response_level / 2.0f;

    D = SE_AGIM_W_POLICY   * d_policy
      + SE_AGIM_W_KEYING   * d_keying
      + SE_AGIM_W_RESPONSE * d_response_norm;

    st->last_d_policy   = d_policy;
    st->last_d_keying   = d_keying;
    st->last_d_response = d_response_norm;
    st->last_D          = D;

    if(D > SE_AGIM_DELTA_SUS) {
        if(st->consec_over < 255) {
            st->consec_over++;
        }
        if(st->consec_over >= SE_AGIM_CONFIRM_CYCLES && !st->alert_raised) {
            st->alert_raised = 1;
            fired = 1;
            LOG_INFO("CompromiseAlert: D=%.3f (dp=%.3f dk=%.3f dr=%.3f) "
                     "after %u cycles\n",
                     (double)D, (double)d_policy, (double)d_keying,
                     (double)d_response_norm, st->consec_over);
        }
    } else {
        /* One good cycle clears the run (false-positive suppression). */
        st->consec_over = 0;
    }

    return fired;
}
