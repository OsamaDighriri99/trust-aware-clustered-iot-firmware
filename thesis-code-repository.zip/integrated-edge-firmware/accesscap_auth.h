/*******************************************************************************
 * ACCESSCAP_AUTH.H -- integrity + freshness for the edge->CC access-cap frame.
 *
 * Frame:  ACCESSCAP:<state>,NODE=<cc node id>,CYC=<edge cycle>,TAG=<16 hex>
 * TAG  =  first 8 bytes of HMAC-SHA256(K_ctl, "ACCESSCAP|<node>|<state>|<cyc>")
 *
 * The CC accepts a frame only if (i) it comes from the edge address it is
 * registered with, (ii) NODE equals its own node id, (iii) the tag verifies and
 * (iv) CYC is strictly greater than the last accepted CYC (replay protection).
 * K_ctl is a pre-shared control key (RAISEF_CTL_KEY). Like every other key in
 * this build it is pre-provisioned, not established per device; the thesis
 * states this (see plan v5, Section 13). Requires oscore_crypto.h first.
 ******************************************************************************/
#ifndef ACCESSCAP_AUTH_H
#define ACCESSCAP_AUTH_H

#include <stdio.h>
#include <string.h>
#include <stdint.h>

#ifndef RAISEF_CTL_KEY
#define RAISEF_CTL_KEY "RAISEF-ctl-key-v5-000000000000000"
#endif
#define ACCESSCAP_TAG_BYTES 8

static inline void accesscap_tag(unsigned node, unsigned state, unsigned long cyc,
                                 char out_hex[2 * ACCESSCAP_TAG_BYTES + 1])
{
    char m[64];
    uint8_t mac[32];
    int n = snprintf(m, sizeof(m), "ACCESSCAP|%u|%u|%lu", node, state, cyc);
    hmac_sha256((const uint8_t *)RAISEF_CTL_KEY, (uint8_t)strlen(RAISEF_CTL_KEY),
                (const uint8_t *)m, (uint16_t)(n > 0 ? n : 0), mac);
    for (int i = 0; i < ACCESSCAP_TAG_BYTES; i++) {
        snprintf(out_hex + 2 * i, 3, "%02x", mac[i]);
    }
    out_hex[2 * ACCESSCAP_TAG_BYTES] = '\0';
}

/* Constant-time comparison of two hex tags of equal length. */
static inline int accesscap_tag_equal(const char *a, const char *b)
{
    uint8_t d = 0;
    for (int i = 0; i < 2 * ACCESSCAP_TAG_BYTES; i++) {
        if (a[i] == '\0' || b[i] == '\0') return 0;
        d |= (uint8_t)(a[i] ^ b[i]);
    }
    return d == 0;
}

#endif /* ACCESSCAP_AUTH_H */
