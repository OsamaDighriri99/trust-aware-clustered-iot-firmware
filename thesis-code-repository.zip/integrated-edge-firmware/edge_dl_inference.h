/*******************************************************************************
 * EDGE_DL_INFERENCE.H -- On-edge CNN-LSTM trust forecaster (DL core).
 *
 * Self-contained float32 forward pass for a compact 1-D CNN-LSTM. Drop-in
 * replacement for tarp_predict_trust(): consumes ctx->trend_window[] (the
 * 16-sample trust time-series) plus scalar features, returns the forecast
 * trust in [0,1]. Weights live in dl_model_weights.h (exported from the trained
 * Keras model by export_weights.py). No dependencies beyond <math.h>.
 * Runs at the EDGE tier only.
 ******************************************************************************/
#ifndef EDGE_DL_INFERENCE_H
#define EDGE_DL_INFERENCE_H

#include <stdint.h>

/* Architecture constants -- MUST match python/reference_model.py */
#define DL_W    16   /* window length == TARP_TREND_WINDOW_SIZE */
#define DL_CIN  1
#define DL_F1   8
#define DL_K1   3
#define DL_F2   8
#define DL_K2   3
#define DL_U    8    /* LSTM units */
#define DL_NS   6    /* scalar features */
#define DL_H    8    /* dense hidden */
#define DL_L1   (DL_W  - DL_K1 + 1)   /* 14 */
#define DL_L2   (DL_L1 - DL_K2 + 1)   /* 12 */

/* Core forward pass: seq[DL_W] trust window, scalars[DL_NS] -> forecast [0,1]. */
float dl_forward(const float *seq, const float *scalars);

/* Drop-in for tarp_predict_trust(). trend_window is the CIRCULAR buffer;
 * window_index = ctx->trend_window_index (next write slot); count =
 * ctx->trend_window_count. The last min(count,DL_W) samples are linearised in
 * chronological order (matching edge.c's own window read). Horizon is baked
 * into the trained model. */
float dl_predict_trust_window(const float *trend_window,
                              uint8_t window_index, uint8_t count,
                              float trust_ema, float trust_slope,
                              float trust_acceleration, float proactive_risk,
                              float device_trust, float cluster_trust);

#endif /* EDGE_DL_INFERENCE_H */
