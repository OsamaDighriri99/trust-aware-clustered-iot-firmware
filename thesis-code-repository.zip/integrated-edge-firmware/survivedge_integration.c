/*******************************************************************************
 * SURVIVEDGE_INTEGRATION.C -- drives AGIM + CCA + CCTC at the cluster tier.
 * See survivedge_integration.h for the design. Compiled/called only when
 * ENABLE_SURVIVEDGE != 0.
 ******************************************************************************/
#include "survivedge_integration.h"

#if ENABLE_SURVIVEDGE

#include "contiki.h"
#include "sys/log.h"
#include <string.h>

#define LOG_MODULE "SurvivEdge"
#ifndef LOG_LEVEL_SURVIVEDGE
#define LOG_LEVEL_SURVIVEDGE LOG_LEVEL_INFO
#endif
#define LOG_LEVEL LOG_LEVEL_SURVIVEDGE

/* The three state machines for THIS cluster centre. */
static agim_state_t s_agim;
static cca_state_t  s_cca;
static cctc_state_t s_cctc;
static uint8_t      s_self_id;
static uint8_t      s_ready;
static uint32_t     s_cycle_count;   /* maintenance cycles since init */

void
se_integration_init(uint8_t cc_id, uint16_t epoch)
{
    s_self_id = cc_id;
    s_cycle_count = 0;
    agim_init(&s_agim);
    cca_init(&s_cca, cc_id, epoch);
    cctc_init(&s_cctc, cc_id, epoch);
    s_ready = 1;
    LOG_INFO("init: cc_id=%u epoch=%u (AGIM+CCA+CCTC active)\n",
             cc_id, epoch);
}

uint8_t
se_integration_periodic(const se_cycle_inputs_t *in,
                        se_send_fn send, void *send_ctx)
{
    uint8_t  buf[1 + sizeof(se_cctc_digest_t)];
    uint8_t  vbuf[1 + sizeof(se_vote_request_t)];
    float    d_policy, d_keying;
    uint8_t  d_resp_level;
    uint8_t  fired = 0;
    int      n;

    if(!s_ready || in == NULL) {
        return 0;
    }

    /* Keep CCA/CCTC epoch aligned with the live cluster epoch. */
    if(in->current_epoch != 0) {
        s_cca.cur_epoch = in->current_epoch;
        s_cctc.epoch    = in->current_epoch;
    }

    /* ---- AGIM: fuse the three local signals ---------------------------- */
    d_policy = 0.0f;
    if(in->local_ml_states != NULL && in->received_ml_states != NULL &&
       in->n_ml_nodes > 0) {
        d_policy = agim_d_policy(in->local_ml_states, in->received_ml_states,
                                 in->n_ml_nodes);
    }
    d_keying     = agim_d_keying(in->observed_rotate_freq,
                                 in->expected_rotate_freq);
    d_resp_level = agim_d_response_level(in->edge_response_ms);

    fired = agim_evaluate(&s_agim, d_policy, d_keying, d_resp_level);

    /* Phase-1 suspicion: Sigma += [D > delta_sus] EVERY cycle the deviation is
     * over threshold (paper), not only on AGIM's sticky first alert -- otherwise
     * suspicion would stall at 1 and never reach Sigma_alert to start an
     * election. A valid current-epoch policy update resets it (cca_note_valid_
     * policy), which is why a healthy edge keeps suspicion at 0. */
    if(s_agim.last_D > SE_AGIM_DELTA_SUS) {
        cca_note_alert(&s_cca);
    } else {
        /* Clean cycle (deviation below suspicion threshold) = the edge root is
         * behaving as a valid current-epoch authority, so Phase-1 suspicion is
         * reset (SurvivEdge CCA Phase 1). Without this, transient anomalies would
         * accumulate Sigma toward Sigma_alert and could trigger a false election. */
        cca_note_valid_policy(&s_cca);
    }
    if(fired) {
        LOG_WARN("AGIM CompromiseAlert: D=%.3f (dp=%.3f dk=%.3f dr=%.3f) "
                 "-> CCA suspicion=%u/%u\n",
                 (double)s_agim.last_D, (double)d_policy, (double)d_keying,
                 (double)s_agim.last_d_response, s_cca.sigma,
                 (unsigned)SE_CCA_SIGMA_ALERT);
    }

    /* ---- CCTC: recompute our digest every cycle (cheap; keeps local_digest
     * fresh for a possible CCA authority transfer), but only BROADCAST every
     * SE_DIGEST_EVERY_N cycles so the radio / Cooja stay light. ------------- */
    s_cycle_count++;
    n = cctc_build_digest_msg(buf, sizeof(buf), &s_cctc,
                              in->state_buf, in->state_len);
    if(n > 0 && send != NULL && (s_cycle_count % SE_DIGEST_EVERY_N) == 0) {
        send(send_ctx, buf, (uint16_t)n);
    }

    /* Visible heartbeat of the SurvivEdge layer (throttled to the digest
     * cadence so it does not flood the Cooja log): shows AGIM deviation, CCA
     * role/suspicion and whether CCTC has reached supermajority consistency. */
    if((s_cycle_count % SE_DIGEST_EVERY_N) == 0) {
        LOG_INFO("status cc=%u role=%u sigma=%u/%u D=%.3f consistent=%u\n",
                 s_self_id, s_cca.role, s_cca.sigma,
                 (unsigned)SE_CCA_SIGMA_ALERT, (double)s_agim.last_D,
                 cctc_supermajority_consistent(&s_cctc));
    }

    /* ---- CCA: start an election if we now suspect the edge root -------- */
    if(cca_should_start_election(&s_cca) && s_cca.role == SE_ROLE_FOLLOWER) {
        s_cca.role  = SE_ROLE_CANDIDATE;
        s_cca.votes = 0;
        n = cca_build_vote_request(vbuf, sizeof(vbuf), &s_cca);
        if(n > 0 && send != NULL) {
            send(send_ctx, vbuf, (uint16_t)n);
            LOG_INFO("CCA: became CANDIDATE, VoteRequest broadcast "
                     "(epoch=%u)\n", s_cca.cur_epoch);
        }
    }

    return fired;
}

uint8_t
se_integration_handle_msg(const uint8_t *data, uint16_t datalen,
                          se_send_fn send, void *send_ctx)
{
    uint8_t        tag;
    const uint8_t *payload;
    uint16_t       plen;

    if(!s_ready || data == NULL || datalen < 1) {
        return 0;
    }
    tag = data[0];
    if(tag < SE_MSG_TAG_MIN || tag > SE_MSG_TAG_MAX) {
        return 0;                       /* not a SurvivEdge frame */
    }
    payload = data + 1;
    plen    = (uint16_t)(datalen - 1);

    switch(tag) {

    case MSG_TYPE_SE_CCTC_DIGEST: {
        uint8_t consistent = cctc_on_peer_digest(&s_cctc, payload, plen);
        if(consistent) {
            LOG_DBG("CCTC: supermajority-consistent state reached\n");
        }
        break;
    }

    case MSG_TYPE_SE_VOTE_REQUEST: {
        /* Single-grant-per-epoch guard (Theorem CCA-Safety): an honest CC issues
         * at most one VoteGrant per epoch. Without this, a CC that receives vote
         * requests from multiple candidates in the same epoch could grant several,
         * which the BFT safety bound forbids. Each CC is its own binary, so a
         * file-static last-granted-epoch is the per-node guard cca.c defers here. */
        static uint16_t se_last_granted_epoch = 0xFFFF;
        uint8_t out[1 + sizeof(se_vote_grant_t)];
        if(plen >= sizeof(se_vote_request_t)) {
            const se_vote_request_t *rq = (const se_vote_request_t *)payload;
            if(rq->epoch != se_last_granted_epoch) {
                int gn = cca_handle_vote_request(&s_cca, payload, plen,
                                                 out, sizeof(out));
                if(gn > 0 && send != NULL) {
                    se_last_granted_epoch = rq->epoch;   /* one grant this epoch */
                    send(send_ctx, out, (uint16_t)gn);   /* relayed to candidate */
                }
            }
        }
        break;
    }

    case MSG_TYPE_SE_VOTE_GRANT: {
        uint8_t won = cca_handle_vote_grant(&s_cca, payload, plen);
        if(won) {
            uint8_t xbuf[1 + sizeof(se_authority_xfer_t)];
            int xn;
            LOG_INFO("CCA: WON election (votes=%u) -- broadcasting "
                     "AuthorityTransfer (new_epoch=%u)\n",
                     s_cca.votes, s_cca.cur_epoch);
            xn = cca_build_authority_transfer(xbuf, sizeof(xbuf), &s_cca,
                                              s_cctc.local_digest);
            if(xn > 0 && send != NULL) {
                send(send_ctx, xbuf, (uint16_t)xn);
            }
        }
        break;
    }

    case MSG_TYPE_SE_AUTHORITY_XFER:
        cca_handle_authority_transfer(&s_cca, payload, plen);
        break;

    default:
        /* STATE_REQUEST/RESPONSE/COMPROMISE_ALERT: accepted as SurvivEdge
         * frames (consumed) but not yet acted on at this tier. */
        break;
    }

    return 1;   /* consumed */
}

uint8_t
se_integration_role(void)
{
    return s_ready ? s_cca.role : SE_ROLE_FOLLOWER;
}

uint8_t
se_integration_alerted(void)
{
    return s_ready ? s_agim.alert_raised : 0;
}

#endif /* ENABLE_SURVIVEDGE */
