/*******************************************************************************
#define ETT_FRESH_OK_S   900u
#define ETT_FRESH_DEAD_S 2700u
#define ETT_T_FULL        0.30f
#define ETT_T_RESTRICTED  0.18f
#define ETT_T_READ_ONLY   0.10f
#define ETT_R_FULL        0.4383f
#define ETT_R_RESTRICTED  0.5000f
#define ETT_R_READ_ONLY   0.5698f
 * PROJECT CONFIGURATION FOR OSCORE-IoT WITH ENHANCEMENTS
 * UPDATED FOR MERGED ARCHITECTURE
 * 
 * ENHANCED VERSION for complete OSCORE-IoT framework with 4 novel contributions:
 * 1. MQTT-OSCORE Implementation (RFC 8613 extension)
 * 2. Predictive Trust-Aware Key Rotation
 * 3. Key Caching Optimization
 * 4. Comprehensive Performance Suite
 * 
 * MERGED ARCHITECTURE:
 * All OSCORE code (oscore_security.h/.c, oscore_enhancements.h/.c,
 * raiseif_params.h, raiseif_messages.h) is now inlined directly into
 * the 3 main files. Only 4 support files remain external:
 *   - compatibility.h  (platform layer)
 *   - timer_patch.h    (timer utilities)
 *   - project-conf.h   (THIS FILE - Contiki-NG build config)
 *   - oscore_crypto.h  (AES-128, SHA-256, HMAC-SHA256 primitives)
 * 
 * Configuration Categories:
 * - OSCORE Feature Flags and Parameters
 * - Enhancement Feature Flags
 * - Memory and Buffer Configuration
 * - Network Stack Configuration  
 * - Protocol Configuration (MQTT-OSCORE, CoAP-OSCORE)
 * - Trust Model Configuration
 * - Performance Tuning
 * - Statistics and Debugging
 * 
 * Compatible with merged self-contained files:
 * - client.c  (~9,000 lines, sender=0x01)
 * - cluster.c (~12,000 lines, sender=0x02)
 * - edge.c    (~10,000 lines, sender=0x03)
 * 
 * Version: 3.4 (New-issues 1-7: runtime counter + threshold + cycle guard fixes)
 * Date: March 2026
 * License: Research use
 ******************************************************************************/

/* FIX (critical): the Makefile passes -DPROJECT_CONF_H=\"project-conf.h\" to
 * the compiler, so the old guard "#ifndef PROJECT_CONF_H" was ALREADY defined
 * and this entire file was silently skipped in every previous build. Contiki-NG
 * locates this file via PROJECT_CONF_PATH; the guard must use its own name. */
#ifndef RAISEF_PROJECT_CONF_H_
#define RAISEF_PROJECT_CONF_H_

/*==============================================================================
 * OSCORE FEATURE FLAGS
 * Enable/disable OSCORE features at compile time
 *============================================================================*/

#ifndef ENABLE_OSCORE
#define ENABLE_OSCORE 1
#endif /* ENABLE_OSCORE */
#ifndef ENABLE_MQTT_OSCORE
#define ENABLE_MQTT_OSCORE 1
#endif /* ENABLE_MQTT_OSCORE */
#ifndef ENABLE_COAP_OSCORE
#define ENABLE_COAP_OSCORE 1
#endif /* ENABLE_COAP_OSCORE */
#ifndef ENABLE_GROUP_OSCORE
#define ENABLE_GROUP_OSCORE 1
#endif /* ENABLE_GROUP_OSCORE */
#ifndef ENABLE_EVENT_TRIGGERED_ROTATION
#define ENABLE_EVENT_TRIGGERED_ROTATION 1
#endif /* ENABLE_EVENT_TRIGGERED_ROTATION */
#ifndef ENABLE_TRUST_AWARE_OSCORE
#define ENABLE_TRUST_AWARE_OSCORE 1
#endif /* ENABLE_TRUST_AWARE_OSCORE */
#ifndef ENABLE_DYNAMIC_PROTOCOL_SWITCH
#define ENABLE_DYNAMIC_PROTOCOL_SWITCH 1
#endif /* ENABLE_DYNAMIC_PROTOCOL_SWITCH */
#ifndef ENABLE_CLUSTER_AWARE_OSCORE
#define ENABLE_CLUSTER_AWARE_OSCORE 1
#endif /* ENABLE_CLUSTER_AWARE_OSCORE */

/*==============================================================================
 * NEW: OSCORE ENHANCEMENT FEATURE FLAGS
 * Enable the 4 novel contributions
 *============================================================================*/

/* Contribution #2: Predictive Trust-Aware Rotation */
#ifndef ENABLE_PREDICTIVE_ROTATION
#define ENABLE_PREDICTIVE_ROTATION 1
#endif /* ENABLE_PREDICTIVE_ROTATION */
#ifndef PREDICTIVE_ROTATION_HISTORY_SIZE
#define PREDICTIVE_ROTATION_HISTORY_SIZE 20         /* 20 trust samples */
#endif /* PREDICTIVE_ROTATION_HISTORY_SIZE */
#ifndef PREDICTIVE_ROTATION_LOOKAHEAD
/* Issue C: This is the project-level constant. The .c files use PREDICTION_LOOKAHEAD
 * (same value, different macro name). Both must stay at 10 and are now printed
 * in the TARP-OSCORE Session Config log block at node startup for log reviewers. */
#define PREDICTIVE_ROTATION_LOOKAHEAD 10            /* Predict 10 steps ahead */
#endif /* PREDICTIVE_ROTATION_LOOKAHEAD */
#ifndef PREDICTIVE_ROTATION_CONFIDENCE_THRESHOLD
#define PREDICTIVE_ROTATION_CONFIDENCE_THRESHOLD 0.7f
#endif /* PREDICTIVE_ROTATION_CONFIDENCE_THRESHOLD */

/* Contribution #3: Key Caching Optimization */
#ifndef ENABLE_KEY_CACHING
#define ENABLE_KEY_CACHING 1
#endif /* ENABLE_KEY_CACHING */
#ifndef KEY_CACHE_SIZE
#define KEY_CACHE_SIZE 48                           /* 48 bytes per cache entry */
#endif /* KEY_CACHE_SIZE */
#ifndef KEY_CACHE_VALIDITY_TIME
/* FIX-T6 (CRITICAL): Was 300s = exact simulation length, causing all 111 nodes
 * to expire their cached keys simultaneously at t=5min, triggering a mass
 * HKDF re-derivation storm that stalls the network.
 * In simulation mode use 600s so keys remain valid across the full run.
 * In production the original 300s default applies. */
#ifdef ENABLE_SIMULATION_MODE
/* FIX-T6b (CRITICAL): FIX-T6 moved this from 300s to 600s "to cover the full
 * run" — which relocated the mass-expiry cliff from t=5min to t=10min instead
 * of removing it (all nodes boot at t=0, so a shared validity time is a
 * synchronized network-wide event). Decouple it from run length entirely:
 * 3600s puts cache expiry beyond any current run, and if longer runs are ever
 * needed the per-node jitter in the TARP layer (FIX-SYNC-1/2) prevents the
 * re-derivation from landing on one instant. */
#define KEY_CACHE_VALIDITY_TIME 300   /* kept = value every previous run actually used (project-conf.h was skipped) */
#else
#define KEY_CACHE_VALIDITY_TIME 300                 /* 5 minutes validity (production) */
#endif
#endif /* KEY_CACHE_VALIDITY_TIME */

/* Contribution #4: Performance Optimization Suite */
#ifndef ENABLE_FAST_PATH_PROCESSING
#define ENABLE_FAST_PATH_PROCESSING 1
#endif /* ENABLE_FAST_PATH_PROCESSING */
#ifndef ENABLE_ENERGY_AWARE_SECURITY
#define ENABLE_ENERGY_AWARE_SECURITY 1
#endif /* ENABLE_ENERGY_AWARE_SECURITY */
#ifndef ENABLE_BATCH_PROCESSING
#define ENABLE_BATCH_PROCESSING 1
#endif /* ENABLE_BATCH_PROCESSING */

/* Fast-path thresholds */
#ifndef FAST_PATH_TRUST_THRESHOLD
#define FAST_PATH_TRUST_THRESHOLD 0.8f   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* FAST_PATH_TRUST_THRESHOLD */
#ifndef FAST_PATH_RECENT_ROTATION_TIME
#define FAST_PATH_RECENT_ROTATION_TIME 300   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* FAST_PATH_RECENT_ROTATION_TIME */

/* Energy-aware thresholds */
#ifndef ENERGY_HIGH_BATTERY_THRESHOLD
#define ENERGY_HIGH_BATTERY_THRESHOLD 0.5f
#endif /* ENERGY_HIGH_BATTERY_THRESHOLD */
#ifndef ENERGY_LOW_BATTERY_THRESHOLD
#define ENERGY_LOW_BATTERY_THRESHOLD 0.2f
#endif /* ENERGY_LOW_BATTERY_THRESHOLD */
#ifndef ENERGY_HIGH_ROTATION_INTERVAL
#define ENERGY_HIGH_ROTATION_INTERVAL 900           /* 15 minutes */
#endif /* ENERGY_HIGH_ROTATION_INTERVAL */
#ifndef ENERGY_MEDIUM_ROTATION_INTERVAL
#define ENERGY_MEDIUM_ROTATION_INTERVAL 1800        /* 30 minutes */
#endif /* ENERGY_MEDIUM_ROTATION_INTERVAL */
#ifndef ENERGY_LOW_ROTATION_INTERVAL
#define ENERGY_LOW_ROTATION_INTERVAL 3600           /* 60 minutes */
#endif /* ENERGY_LOW_ROTATION_INTERVAL */

/* Batch processing */
#ifndef MAX_BATCH_SIZE
#define MAX_BATCH_SIZE 20
#endif /* MAX_BATCH_SIZE */
#ifndef BATCH_TIMEOUT_MS
#define BATCH_TIMEOUT_MS 100
#endif /* BATCH_TIMEOUT_MS */

/*==============================================================================
 * OSCORE BUFFER AND CONTEXT SIZES
 * Aligned with oscore_security.h definitions
 *============================================================================*/

/* Core OSCORE sizes (must match oscore_security.h) */
#ifndef OSCORE_MAX_KEY_SIZE
#define OSCORE_MAX_KEY_SIZE 16          /* AES-128 key size */
#endif /* OSCORE_MAX_KEY_SIZE */
#ifndef OSCORE_MAX_IV_SIZE
#define OSCORE_MAX_IV_SIZE 13           /* Maximum IV size for AEAD */
#endif /* OSCORE_MAX_IV_SIZE */
#ifndef OSCORE_MAX_KID_SIZE
#define OSCORE_MAX_KID_SIZE 8           /* Key ID size */
#endif /* OSCORE_MAX_KID_SIZE */
#ifndef OSCORE_MAX_PIV_SIZE
#define OSCORE_MAX_PIV_SIZE 5           /* Partial IV size */
#endif /* OSCORE_MAX_PIV_SIZE */
#ifndef OSCORE_NONCE_SIZE
#define OSCORE_NONCE_SIZE 13            /* AEAD nonce size */
#endif /* OSCORE_NONCE_SIZE */
#ifndef OSCORE_TAG_SIZE
#define OSCORE_TAG_SIZE 8               /* Authentication tag size */
#endif /* OSCORE_TAG_SIZE */
#ifndef OSCORE_MAX_PAYLOAD
#define OSCORE_MAX_PAYLOAD 1024   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* OSCORE_MAX_PAYLOAD */

/* Extended buffer sizes */
#ifndef OSCORE_CONTEXT_SIZE
#define OSCORE_CONTEXT_SIZE 256
#endif /* OSCORE_CONTEXT_SIZE */
#ifndef OSCORE_KEY_SIZE
#define OSCORE_KEY_SIZE 32              /* For key derivation buffers */
#endif /* OSCORE_KEY_SIZE */
#ifndef OSCORE_IV_SIZE
#define OSCORE_IV_SIZE 16
#endif /* OSCORE_IV_SIZE */
#ifndef OSCORE_ID_SIZE
#define OSCORE_ID_SIZE 8
#endif /* OSCORE_ID_SIZE */
#ifndef OSCORE_AAD_SIZE
#define OSCORE_AAD_SIZE 128
#endif /* OSCORE_AAD_SIZE */
#ifndef OSCORE_PROTECTED_MSG_SIZE
#define OSCORE_PROTECTED_MSG_SIZE 1024
#endif /* OSCORE_PROTECTED_MSG_SIZE */
#ifndef OSCORE_MAX_CONTEXTS
#define OSCORE_MAX_CONTEXTS 10
#endif /* OSCORE_MAX_CONTEXTS */
#ifndef OSCORE_OPTION_NUMBER
#define OSCORE_OPTION_NUMBER 9          /* OSCORE CoAP option number */
#endif /* OSCORE_OPTION_NUMBER */

/*==============================================================================
 * OSCORE SECURITY PARAMETERS
 * RFC 8613 compliant parameters
 *============================================================================*/

#ifndef OSCORE_VERSION
#define OSCORE_VERSION 1
#endif /* OSCORE_VERSION */
#ifndef OSCORE_REPLAY_WINDOW
#define OSCORE_REPLAY_WINDOW 64

/* --- OSCORE-IoT (Paper 6) opt-in features (default OFF = canonical RAISEF-IoT) ---
 * OSCORE_MQTT_TOPIC_AAD=1 enables Paper 6 Eq. aad_mqtt: the MQTT topic travels in
 *   the clear (broker-routable) and is bound via AAD = SHA-256(topic)[0:8], giving
 *   anti-topic-substitution. Default 0 keeps the topic\0payload binding.
 * PAPER6_PROFILE=1 sets Paper 6's exact reproduction values (replay window 32,
 *   cooldown 30s, protocol utility 0.35/0.40/0.25, QoS 0.30/0.25/0.25/0.20,
 *   seq-exhaustion 2^40) WITHOUT changing the canonical RAISEF-IoT defaults. */
#ifndef OSCORE_MQTT_TOPIC_AAD
#define OSCORE_MQTT_TOPIC_AAD 0
#endif
#ifndef PAPER6_PROFILE
#define PAPER6_PROFILE 0
#endif
#if PAPER6_PROFILE
  #undef  OSCORE_REPLAY_WINDOW
  #define OSCORE_REPLAY_WINDOW 32                 /* Paper 6: RFC 8613 default */
  #undef  PROTOCOL_SWITCH_COOLDOWN
  #define PROTOCOL_SWITCH_COOLDOWN (30 * CLOCK_SECOND)  /* Paper 6: =reporting interval */
#endif
/* Sender-sequence ceiling that forces a rotation before exhaustion. Paper 6 uses
 * the 2^40-1 OSCORE limit; the sim default is low so rotation is exercised in short
 * runs. Guarded so a .c or profile can override. */
#ifndef OSCORE_SENDER_SEQ_MAX
#if PAPER6_PROFILE
#define OSCORE_SENDER_SEQ_MAX 1099511627775ULL   /* 2^40 - 1 (Paper 6) */
#else
#define OSCORE_SENDER_SEQ_MAX 100000ULL          /* sim: auto-rotate before exhaustion */
#endif
#endif
#endif /* OSCORE_REPLAY_WINDOW */
#ifndef OSCORE_KEY_ROTATION_INTERVAL
/* FIX #3: OSCORE_KEY_ROTATION_INTERVAL is in bare SECONDS (used as a counter threshold);
 * KEY_ROTATION_INTERVAL below is in CLOCK_SECOND ticks (used with clock_time()).
 * Do NOT mix them — using the wrong unit causes rotations to never fire or fire instantly. */
#define OSCORE_KEY_ROTATION_INTERVAL 600   /* seconds; = TARP T_base (prior runs: never applied) */
#endif /* OSCORE_KEY_ROTATION_INTERVAL */
#ifndef OSCORE_MIN_KEY_LIFETIME
#define OSCORE_MIN_KEY_LIFETIME 300             /* 5 minutes minimum */
#endif /* OSCORE_MIN_KEY_LIFETIME */
#ifndef OSCORE_MAX_KEY_LIFETIME
#define OSCORE_MAX_KEY_LIFETIME 86400           /* 24 hours maximum */
#endif /* OSCORE_MAX_KEY_LIFETIME */
#ifndef OSCORE_MAX_SEQUENCE_NUMBER
#define OSCORE_MAX_SEQUENCE_NUMBER 0xFFFFFF
#endif /* OSCORE_MAX_SEQUENCE_NUMBER */
#ifndef OSCORE_SEQUENCE_WARNING_THRESHOLD
#define OSCORE_SEQUENCE_WARNING_THRESHOLD 10000 /* Warn when < 10000 remaining */
#endif /* OSCORE_SEQUENCE_WARNING_THRESHOLD */

/* AEAD Algorithm IDs */
#ifndef OSCORE_AEAD_ALG_AES_CCM_16_64_128
#define OSCORE_AEAD_ALG_AES_CCM_16_64_128 10    /* AES-CCM with 128-bit key */
#endif /* OSCORE_AEAD_ALG_AES_CCM_16_64_128 */

/* Event-triggered rotation types
 * FIX #A6-conf: All six rotation trigger types used by tarp_initiate_rekey()
 * trigger switch must be defined here so project-conf.h is the single source
 * of truth.  Previously TRUST_EVENT and SECURITY_EVENT were absent, forcing
 * each .c inline block to define them locally — and those local definitions
 * assigned value 4 to TRUST_EVENT, colliding with TIME_EVENT=4 here.
 * Fix: renumber the complete set to be contiguous with no collisions:
 *   CLUSTER_EVENT  = 1  (cluster reconfiguration)
 *   PROTOCOL_EVENT = 2  (protocol switch)
 *   THREAT_EVENT   = 3  (threat detected — maps to SECURITY_EVENT below)
 *   TIME_EVENT     = 4  (periodic rotation)
 *   TRUST_EVENT    = 5  (trust level dropped)   ← NEW (was missing, locally =4)
 *   SECURITY_EVENT = 6  (security breach)        ← NEW (was missing, locally =5)
 * All three .c inline blocks guard with #ifndef so they will use these values
 * automatically once project-conf.h provides them. */
#ifndef OSCORE_KEY_ROTATION_CLUSTER_EVENT
#define OSCORE_KEY_ROTATION_CLUSTER_EVENT  1  /* Cluster reconfiguration */
#endif /* OSCORE_KEY_ROTATION_CLUSTER_EVENT */
#ifndef OSCORE_KEY_ROTATION_PROTOCOL_EVENT
#define OSCORE_KEY_ROTATION_PROTOCOL_EVENT 2  /* Protocol switch */
#endif /* OSCORE_KEY_ROTATION_PROTOCOL_EVENT */
#ifndef OSCORE_KEY_ROTATION_THREAT_EVENT
#define OSCORE_KEY_ROTATION_THREAT_EVENT   3  /* Threat detected */
#endif /* OSCORE_KEY_ROTATION_THREAT_EVENT */
#ifndef OSCORE_KEY_ROTATION_TIME_EVENT
#define OSCORE_KEY_ROTATION_TIME_EVENT     4  /* Periodic time-based rotation */
#endif /* OSCORE_KEY_ROTATION_TIME_EVENT */
#ifndef OSCORE_KEY_ROTATION_TRUST_EVENT
#define OSCORE_KEY_ROTATION_TRUST_EVENT    5  /* FIX #A6-conf: Trust level change (was missing; local defs had value 4 = collision with TIME_EVENT) */
#endif /* OSCORE_KEY_ROTATION_TRUST_EVENT */
#ifndef OSCORE_KEY_ROTATION_SECURITY_EVENT
#define OSCORE_KEY_ROTATION_SECURITY_EVENT 6  /* FIX #A6-conf: Security breach detected (was missing; local defs had value 5) */
#endif /* OSCORE_KEY_ROTATION_SECURITY_EVENT */

/*==============================================================================
 * OSCORE PERFORMANCE TUNING
 *============================================================================*/

#ifndef OSCORE_ENABLE_CACHING
#define OSCORE_ENABLE_CACHING 1
#endif /* OSCORE_ENABLE_CACHING */
#ifndef OSCORE_CACHE_SIZE
#define OSCORE_CACHE_SIZE 20
#endif /* OSCORE_CACHE_SIZE */
#ifndef OSCORE_ENABLE_COMPRESSION
#define OSCORE_ENABLE_COMPRESSION 1
#endif /* OSCORE_ENABLE_COMPRESSION */
#ifndef OSCORE_PROCESSING_TIMEOUT
#define OSCORE_PROCESSING_TIMEOUT 5000          /* ms */
#endif /* OSCORE_PROCESSING_TIMEOUT */
#ifndef OSCORE_MAX_RETRANSMIT
#define OSCORE_MAX_RETRANSMIT 4
#endif /* OSCORE_MAX_RETRANSMIT */
#ifndef OSCORE_ACK_TIMEOUT
#define OSCORE_ACK_TIMEOUT 2                    /* seconds */
#endif /* OSCORE_ACK_TIMEOUT */

/*==============================================================================
 * MEMORY AND BUFFER CONFIGURATION
 *============================================================================*/

#ifndef MAX_MSG_SIZE
#define MAX_MSG_SIZE 4096
#endif /* MAX_MSG_SIZE */
#ifndef LOG_BUFFER_SIZE
#define LOG_BUFFER_SIZE 8192
#endif /* LOG_BUFFER_SIZE */
#ifndef MEMORY_POOL_SIZE
#define MEMORY_POOL_SIZE 32768
#endif /* MEMORY_POOL_SIZE */
#ifndef SECURITY_BUFFER_SIZE
#define SECURITY_BUFFER_SIZE 1024
#endif /* SECURITY_BUFFER_SIZE */
#ifndef MAX_SESSION_CACHE
#define MAX_SESSION_CACHE 30
#endif /* MAX_SESSION_CACHE */

/*==============================================================================
 * NETWORK TOPOLOGY CONFIGURATION
 *============================================================================*/

#ifndef MAX_CLUSTERS
#define MAX_CLUSTERS 10
#endif /* MAX_CLUSTERS */
#ifndef MAX_CLIENTS
#define MAX_CLIENTS 100
#endif /* MAX_CLIENTS */
#ifndef MAX_CLIENTS_PER_CLUSTER
/* Issue B: canonical value = 10. All three node files (client/cluster/edge)
 * must match this. Any local override of 50 is a bug. */
#define MAX_CLIENTS_PER_CLUSTER 10
#endif /* MAX_CLIENTS_PER_CLUSTER */
#ifndef MAX_CLUSTER_SIZE
#define MAX_CLUSTER_SIZE 10   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* MAX_CLUSTER_SIZE */
#ifndef CLIENT_PORT
#define CLIENT_PORT 5678
#endif /* CLIENT_PORT */
#ifndef EDGE_PORT
#define EDGE_PORT 1234
#endif /* EDGE_PORT */

/*==============================================================================
 * RPL CONFIGURATION
 *============================================================================*/

#ifndef RPL_CONF_DIO_INTERVAL_MIN
#define RPL_CONF_DIO_INTERVAL_MIN 12
#endif /* RPL_CONF_DIO_INTERVAL_MIN */
#ifndef RPL_CONF_DIO_INTERVAL_DOUBLINGS
#define RPL_CONF_DIO_INTERVAL_DOUBLINGS 8
#endif /* RPL_CONF_DIO_INTERVAL_DOUBLINGS */
#ifndef RPL_CONF_DEFAULT_ROUTE_INFINITE_LIFETIME
#define RPL_CONF_DEFAULT_ROUTE_INFINITE_LIFETIME 1
#endif /* RPL_CONF_DEFAULT_ROUTE_INFINITE_LIFETIME */
/* FIX-MOP: the build uses rpl-lite (see Makefile: os/net/routing/rpl-lite),
 * which operates in NON-STORING mode; client.c is likewise written around
 * non-storing (its multicast discovery is the explicit workaround for the fact
 * that the root cannot hop-by-hop route downward to clients). Advertising a
 * STORING MOP on a non-storing implementation is inconsistent and can destabilise
 * route setup, so pin the MOP to non-storing to match the actual routing model. */
#ifndef RPL_CONF_MOP
#define RPL_CONF_MOP RPL_MOP_NON_STORING
#endif /* RPL_CONF_MOP */
#ifndef RPL_CONF_WITH_PROBING
#define RPL_CONF_WITH_PROBING 1
#endif /* RPL_CONF_WITH_PROBING */
#ifndef RPL_CONF_WITH_DAO_ACK
#define RPL_CONF_WITH_DAO_ACK 1
#endif /* RPL_CONF_WITH_DAO_ACK */
#ifndef RPL_CONF_DEFAULT_LIFETIME_UNIT
#define RPL_CONF_DEFAULT_LIFETIME_UNIT 60
#endif /* RPL_CONF_DEFAULT_LIFETIME_UNIT */
#ifndef RPL_CONF_MAX_DAG_PER_INSTANCE
#define RPL_CONF_MAX_DAG_PER_INSTANCE 1
#endif /* RPL_CONF_MAX_DAG_PER_INSTANCE */

/*==============================================================================
 * NETWORK STACK CONFIGURATION
 *============================================================================*/

#ifndef NETSTACK_CONF_RDC
#define NETSTACK_CONF_RDC nullrdc_driver
#endif /* NETSTACK_CONF_RDC */
#ifndef NETSTACK_CONF_MAC
#define NETSTACK_CONF_MAC csma_driver
#endif /* NETSTACK_CONF_MAC */
#ifndef NETSTACK_CONF_FRAMER
#define NETSTACK_CONF_FRAMER framer_802154
#endif /* NETSTACK_CONF_FRAMER */

/* Buffer sizes */
#ifndef QUEUEBUF_CONF_NUM
/* FIX-SCALE-3: was 20 — too small for the edge root / CCs absorbing bursts
 * from 100 clients in one collision domain. Cooja motes are native-compiled,
 * so RAM is not the constraint. */
#define QUEUEBUF_CONF_NUM 64
#endif /* QUEUEBUF_CONF_NUM */
#ifndef UIP_CONF_BUFFER_SIZE
#define UIP_CONF_BUFFER_SIZE 1280   /* IPv6 minimum MTU; kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* UIP_CONF_BUFFER_SIZE */
#ifndef UIP_CONF_TCP
#define UIP_CONF_TCP 0
#endif /* UIP_CONF_TCP */
#ifndef UIP_CONF_UDP
#define UIP_CONF_UDP 1
#endif /* UIP_CONF_UDP */

/* FIX-SCALE-1 (112-node topology): Contiki-NG defaults size the neighbor
 * table and the routing / source-routing tables at only 16 entries. With
 * 1 edge root + 1 standby + 10 CCs + 100 clients in a single RPL DODAG, the
 * root and the CCs must hold >= 111 entries, or downward routing silently
 * fails for most nodes and RPL churns (DAO storms / no-path) for the whole
 * run. Cooja motes are native-compiled, so RAM is not a constraint. */
#ifndef NBR_TABLE_CONF_MAX_NEIGHBORS
#define NBR_TABLE_CONF_MAX_NEIGHBORS 120
#endif /* NBR_TABLE_CONF_MAX_NEIGHBORS */
#ifndef NETSTACK_CONF_MAX_ROUTE_ENTRIES
#define NETSTACK_CONF_MAX_ROUTE_ENTRIES 130
#endif /* NETSTACK_CONF_MAX_ROUTE_ENTRIES */
#ifndef UIP_SR_CONF_LINK_NUM
#define UIP_SR_CONF_LINK_NUM 130
#endif /* UIP_SR_CONF_LINK_NUM */

/* IPv6 Configuration */
#ifndef UIP_CONF_IPV6_QUEUE_PKT
#define UIP_CONF_IPV6_QUEUE_PKT 1
#endif /* UIP_CONF_IPV6_QUEUE_PKT */
#ifndef UIP_CONF_IPV6_CHECKS
#define UIP_CONF_IPV6_CHECKS 1
#endif /* UIP_CONF_IPV6_CHECKS */
#ifndef UIP_CONF_IPV6_REASSEMBLY
#define UIP_CONF_IPV6_REASSEMBLY 0
#endif /* UIP_CONF_IPV6_REASSEMBLY */
#ifndef UIP_CONF_ND6_SEND_RA
#define UIP_CONF_ND6_SEND_RA 0
#endif /* UIP_CONF_ND6_SEND_RA */
#ifndef UIP_CONF_ND6_SEND_NA
#define UIP_CONF_ND6_SEND_NA 1
#endif /* UIP_CONF_ND6_SEND_NA */
#ifndef UIP_CONF_ND6_REACHABLE_TIME
#define UIP_CONF_ND6_REACHABLE_TIME 600000
#endif /* UIP_CONF_ND6_REACHABLE_TIME */
#ifndef UIP_CONF_ND6_RETRANS_TIMER
#define UIP_CONF_ND6_RETRANS_TIMER 10000
#endif /* UIP_CONF_ND6_RETRANS_TIMER */

/*==============================================================================
 * LOGGING CONFIGURATION
 *============================================================================*/

#ifndef LOG_CONF_LEVEL_RPL
#define LOG_CONF_LEVEL_RPL LOG_LEVEL_NONE   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* LOG_CONF_LEVEL_RPL */
#ifndef LOG_CONF_LEVEL_TCPIP
#define LOG_CONF_LEVEL_TCPIP LOG_LEVEL_NONE   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* LOG_CONF_LEVEL_TCPIP */
#ifndef LOG_CONF_LEVEL_IPV6
#define LOG_CONF_LEVEL_IPV6 LOG_LEVEL_NONE   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* LOG_CONF_LEVEL_IPV6 */
#ifndef LOG_CONF_LEVEL_6LOWPAN
#define LOG_CONF_LEVEL_6LOWPAN LOG_LEVEL_NONE   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* LOG_CONF_LEVEL_6LOWPAN */
#ifndef LOG_CONF_LEVEL_MAC
#define LOG_CONF_LEVEL_MAC LOG_LEVEL_NONE   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* LOG_CONF_LEVEL_MAC */
#ifndef LOG_CONF_LEVEL_CSMA
#define LOG_CONF_LEVEL_CSMA LOG_LEVEL_NONE
#endif /* LOG_CONF_LEVEL_CSMA */
#ifndef LOG_CONF_LEVEL_OSCORE
#define LOG_CONF_LEVEL_OSCORE LOG_LEVEL_INFO
#endif /* LOG_CONF_LEVEL_OSCORE */
#ifndef LOG_CONF_LEVEL_SECURITY
#define LOG_CONF_LEVEL_SECURITY LOG_LEVEL_INFO
#endif /* LOG_CONF_LEVEL_SECURITY */
#ifndef LOG_CONF_LEVEL_OSCORE_ENH
#define LOG_CONF_LEVEL_OSCORE_ENH LOG_LEVEL_INFO     /* NEW: Enhancement logging */
#endif /* LOG_CONF_LEVEL_OSCORE_ENH */

/*==============================================================================
 * PROTOCOL CONFIGURATION
 *============================================================================*/

#ifndef PROTOCOL_VERSION
#define PROTOCOL_VERSION 1
#endif /* PROTOCOL_VERSION */
#ifndef MESSAGE_VERSION
#define MESSAGE_VERSION 1
#endif /* MESSAGE_VERSION */

/* Protocol types */
/* PROTOCOL_TYPE_MQTT: removed -- enum in edge.c/cluster.c/client.c */
/* PROTOCOL_TYPE_COAP: removed -- enum in edge.c/cluster.c/client.c */

/* Protocol switch thresholds */
#ifndef PROTOCOL_SWITCH_COOLDOWN
#define PROTOCOL_SWITCH_COOLDOWN (120 * CLOCK_SECOND)  /* Canonical: 120s = RAISEF-IoT (Paper 5). BUGFIX: was bare 60 -> ~0.47s in ticks. */
#endif /* PROTOCOL_SWITCH_COOLDOWN */
#ifndef MIN_PROTO_SCORE_DIFF
#define MIN_PROTO_SCORE_DIFF 0.15f              /* theta_hysteresis: RAISEF-IoT (Paper 5) + Papers 2,3 all specify 0.15. (Prior "FIX #2" wrongly set 0.05, colliding with STABILITY_BONUS.) */
#endif /* MIN_PROTO_SCORE_DIFF */
/* Paper 5: Additive stability bonus (was multiplicative - Issue 16 fix) */
#ifndef STABILITY_BONUS
#define STABILITY_BONUS 0.05f                   /* U + 0.05 for current protocol */
#endif /* STABILITY_BONUS */

/*==============================================================================
 * MESSAGE TYPES
 *============================================================================*/

#ifndef MSG_TYPE_DISCOVERY
#define MSG_TYPE_DISCOVERY 1
#endif /* MSG_TYPE_DISCOVERY */
#ifndef MSG_TYPE_CLIENT_DATA
#define MSG_TYPE_CLIENT_DATA 2
#endif /* MSG_TYPE_CLIENT_DATA */
#ifndef MSG_TYPE_CLUSTER_METRICS
#define MSG_TYPE_CLUSTER_METRICS 3
#endif /* MSG_TYPE_CLUSTER_METRICS */
#ifndef MSG_TYPE_CONFIG_UPDATE
#define MSG_TYPE_CONFIG_UPDATE 4
#endif /* MSG_TYPE_CONFIG_UPDATE */
#ifndef MSG_TYPE_SECURITY_INIT
#define MSG_TYPE_SECURITY_INIT 5
#endif /* MSG_TYPE_SECURITY_INIT */
#ifndef MSG_TYPE_SECURITY_UPDATE
#define MSG_TYPE_SECURITY_UPDATE 6
#endif /* MSG_TYPE_SECURITY_UPDATE */
#ifndef MSG_TYPE_HEALTH_CHECK
#define MSG_TYPE_HEALTH_CHECK 7
#endif /* MSG_TYPE_HEALTH_CHECK */
#ifndef MSG_TYPE_SECURE_DATA
#define MSG_TYPE_SECURE_DATA 8
#endif /* MSG_TYPE_SECURE_DATA */
#ifndef MSG_TYPE_CLUSTER_SUMMARY
#define MSG_TYPE_CLUSTER_SUMMARY 9
#endif /* MSG_TYPE_CLUSTER_SUMMARY */
#ifndef MSG_TYPE_NETWORK_ALERT
#define MSG_TYPE_NETWORK_ALERT 10
#endif /* MSG_TYPE_NETWORK_ALERT */
#ifndef MSG_TYPE_ERROR
#define MSG_TYPE_ERROR 0xFF
#endif /* MSG_TYPE_ERROR */

/*==============================================================================
 * MESSAGE FLAGS (Enhanced for OSCORE)
 *============================================================================*/

#ifndef MESSAGE_FLAG_ENCRYPTED
#define MESSAGE_FLAG_ENCRYPTED    0x01
#endif /* MESSAGE_FLAG_ENCRYPTED */
#ifndef MESSAGE_FLAG_COMPRESSED
#define MESSAGE_FLAG_COMPRESSED   0x02
#endif /* MESSAGE_FLAG_COMPRESSED */
#ifndef MESSAGE_FLAG_FRAGMENTED
#define MESSAGE_FLAG_FRAGMENTED   0x04
#endif /* MESSAGE_FLAG_FRAGMENTED */
#ifndef MESSAGE_FLAG_VALIDATED
#define MESSAGE_FLAG_VALIDATED    0x08
#endif /* MESSAGE_FLAG_VALIDATED */
#ifndef MESSAGE_FLAG_URGENT
#define MESSAGE_FLAG_URGENT       0x10
#endif /* MESSAGE_FLAG_URGENT */
#ifndef MESSAGE_FLAG_REQUIRES_ACK
#define MESSAGE_FLAG_REQUIRES_ACK 0x20
#endif /* MESSAGE_FLAG_REQUIRES_ACK */
#ifndef MESSAGE_FLAG_OSCORE
#define MESSAGE_FLAG_OSCORE       0x40          /* OSCORE protected message */
#endif /* MESSAGE_FLAG_OSCORE */
#ifndef MESSAGE_FLAG_FAST_PATH
#define MESSAGE_FLAG_FAST_PATH    0x80          /* NEW: Fast-path processed */
#endif /* MESSAGE_FLAG_FAST_PATH */

/*==============================================================================
 * TIMING CONFIGURATION
 *============================================================================*/

/* Base intervals */
#ifndef UPDATE_INTERVAL
#define UPDATE_INTERVAL (30 * CLOCK_SECOND)
#endif /* UPDATE_INTERVAL */
#ifndef CLUSTERING_INTERVAL
#define CLUSTERING_INTERVAL (60 * CLOCK_SECOND)
#endif /* CLUSTERING_INTERVAL */
#ifndef RECONFIG_CHECK_INTERVAL
#define RECONFIG_CHECK_INTERVAL (120 * CLOCK_SECOND)
#endif /* RECONFIG_CHECK_INTERVAL */

/* OSCORE-specific intervals */
#ifndef OSCORE_MAINTENANCE_INTERVAL
#define OSCORE_MAINTENANCE_INTERVAL (15 * CLOCK_SECOND)  /* FIX-C1C3: 15s (was 60s) for trust rotation frequency */
#endif /* OSCORE_MAINTENANCE_INTERVAL */
#ifndef OSCORE_TRUST_ASSESSMENT_INTERVAL
#define OSCORE_TRUST_ASSESSMENT_INTERVAL (30 * CLOCK_SECOND)
#endif /* OSCORE_TRUST_ASSESSMENT_INTERVAL */
#ifndef OSCORE_STATS_LOG_INTERVAL
#define OSCORE_STATS_LOG_INTERVAL (300 * CLOCK_SECOND)
#endif /* OSCORE_STATS_LOG_INTERVAL */
#ifndef OSCORE_STATUS_REPORT_INTERVAL
#define OSCORE_STATUS_REPORT_INTERVAL 10        /* maintenance cycles */
#endif /* OSCORE_STATUS_REPORT_INTERVAL */

/* NEW: Enhancement-specific intervals */
#ifndef ENHANCEMENT_METRICS_INTERVAL
#define ENHANCEMENT_METRICS_INTERVAL (60 * CLOCK_SECOND)    /* Print every 60 sec */
#endif /* ENHANCEMENT_METRICS_INTERVAL */
#ifndef PREDICTIVE_ROTATION_CHECK_INTERVAL
#define PREDICTIVE_ROTATION_CHECK_INTERVAL (30 * CLOCK_SECOND)
#endif /* PREDICTIVE_ROTATION_CHECK_INTERVAL */
#ifndef ENERGY_STATE_UPDATE_INTERVAL
#define ENERGY_STATE_UPDATE_INTERVAL (60 * CLOCK_SECOND)
#endif /* ENERGY_STATE_UPDATE_INTERVAL */

/*==============================================================================
 * SECURITY CONFIGURATION
 *============================================================================*/

/* Security modes */
/* SECURITY_MODE_DISABLED: removed -- enum in the .c files */
/* SECURITY_MODE_BASIC: removed -- enum in the .c files */
/* SECURITY_MODE_STANDARD: removed -- enum in the .c files */
/* SECURITY_MODE_ADVANCED: removed -- enum in the .c files */
/* SECURITY_MODE_ENHANCED: removed -- enum in the .c files */

/* Security levels */
#ifndef SECURITY_LEVEL_NONE
#define SECURITY_LEVEL_NONE 0
#endif /* SECURITY_LEVEL_NONE */
#ifndef SECURITY_LEVEL_INTEGRITY
#define SECURITY_LEVEL_INTEGRITY 1
#endif /* SECURITY_LEVEL_INTEGRITY */
#ifndef SECURITY_LEVEL_ENCRYPTION
#define SECURITY_LEVEL_ENCRYPTION 2             /* AES-128 */
#endif /* SECURITY_LEVEL_ENCRYPTION */
#ifndef SECURITY_LEVEL_BOTH
#define SECURITY_LEVEL_BOTH 3
#endif /* SECURITY_LEVEL_BOTH */
#ifndef SECURITY_LEVEL_OSCORE
#define SECURITY_LEVEL_OSCORE 4                 /* OSCORE (RFC 8613) */
#endif /* SECURITY_LEVEL_OSCORE */
#ifndef SECURITY_LEVEL_GROUP_OSCORE
#define SECURITY_LEVEL_GROUP_OSCORE 5           /* Group OSCORE */
#endif /* SECURITY_LEVEL_GROUP_OSCORE */
#ifndef SECURITY_LEVEL_OSCORE_ENHANCED
#define SECURITY_LEVEL_OSCORE_ENHANCED 6        /* NEW: OSCORE + Enhancements */
#endif /* SECURITY_LEVEL_OSCORE_ENHANCED */

/* Key and IV sizes */
#ifndef SECURITY_KEY_LENGTH
#define SECURITY_KEY_LENGTH 16
#endif /* SECURITY_KEY_LENGTH */
#ifndef SECURITY_IV_LENGTH
#define SECURITY_IV_LENGTH 16
#endif /* SECURITY_IV_LENGTH */
#ifndef SECURITY_NONCE_LENGTH
#define SECURITY_NONCE_LENGTH 8
#endif /* SECURITY_NONCE_LENGTH */
#ifndef MAX_SECURITY_SESSIONS
#define MAX_SECURITY_SESSIONS 10   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* MAX_SECURITY_SESSIONS */
#ifndef SESSION_TIMEOUT
#define SESSION_TIMEOUT (CLOCK_SECOND * 60 * 15)        /* 15 minutes */
#endif /* SESSION_TIMEOUT */
#ifndef KEY_ROTATION_INTERVAL
#define KEY_ROTATION_INTERVAL (CLOCK_SECOND * 600)   /* was effectively 86400 s in all prior runs; 600 s = TARP T_base */
#endif /* KEY_ROTATION_INTERVAL */
#ifndef MIN_KEY_LIFETIME
#define MIN_KEY_LIFETIME (CLOCK_SECOND * 60 * 5)        /* 5 minutes */
#endif /* MIN_KEY_LIFETIME */

/*==============================================================================
 * MQTT-OSCORE CONFIGURATION
 *============================================================================*/

#ifndef MQTT_OSCORE_MAX_TOPICS
#define MQTT_OSCORE_MAX_TOPICS 10
#endif /* MQTT_OSCORE_MAX_TOPICS */
#ifndef MQTT_OSCORE_TOPIC_LENGTH
#define MQTT_OSCORE_TOPIC_LENGTH 64
#endif /* MQTT_OSCORE_TOPIC_LENGTH */
#ifndef MQTT_OSCORE_PAYLOAD_SIZE
#define MQTT_OSCORE_PAYLOAD_SIZE 512
#endif /* MQTT_OSCORE_PAYLOAD_SIZE */
#ifndef MQTT_OSCORE_QOS_DEFAULT
#define MQTT_OSCORE_QOS_DEFAULT 1
#endif /* MQTT_OSCORE_QOS_DEFAULT */
#ifndef MQTT_OSCORE_RETAIN_DEFAULT
#define MQTT_OSCORE_RETAIN_DEFAULT 0
#endif /* MQTT_OSCORE_RETAIN_DEFAULT */
#ifndef MQTT_MAX_PENDING_MESSAGES
#define MQTT_MAX_PENDING_MESSAGES 16
#endif /* MQTT_MAX_PENDING_MESSAGES */
#ifndef MQTT_RECONNECT_INTERVAL
#define MQTT_RECONNECT_INTERVAL (30 * CLOCK_SECOND)
#endif /* MQTT_RECONNECT_INTERVAL */
#ifndef MQTT_KEEP_ALIVE
#define MQTT_KEEP_ALIVE 60   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* MQTT_KEEP_ALIVE */
#ifndef MQTT_RETRY_COUNT
#define MQTT_RETRY_COUNT 3
#endif /* MQTT_RETRY_COUNT */
#ifndef MQTT_DEFAULT_PORT
#define MQTT_DEFAULT_PORT 1883
#endif /* MQTT_DEFAULT_PORT */

/*==============================================================================
 * COAP-OSCORE CONFIGURATION
 *============================================================================*/

#ifndef COAP_OSCORE_MAX_OPTIONS
#define COAP_OSCORE_MAX_OPTIONS 16
#endif /* COAP_OSCORE_MAX_OPTIONS */
#ifndef COAP_OSCORE_TOKEN_LENGTH
#define COAP_OSCORE_TOKEN_LENGTH 8
#endif /* COAP_OSCORE_TOKEN_LENGTH */
#ifndef COAP_OSCORE_MAX_RETRANSMIT
#define COAP_OSCORE_MAX_RETRANSMIT 4
#endif /* COAP_OSCORE_MAX_RETRANSMIT */
#ifndef COAP_OSCORE_ACK_TIMEOUT
#define COAP_OSCORE_ACK_TIMEOUT 2
#endif /* COAP_OSCORE_ACK_TIMEOUT */
#ifndef COAP_OSCORE_MAX_AGE
#define COAP_OSCORE_MAX_AGE 60
#endif /* COAP_OSCORE_MAX_AGE */
#ifndef COAP_MAX_CHUNK_SIZE
#define COAP_MAX_CHUNK_SIZE 64
#endif /* COAP_MAX_CHUNK_SIZE */
#ifndef COAP_DEFAULT_PORT
#define COAP_DEFAULT_PORT 5683
#endif /* COAP_DEFAULT_PORT */
#ifndef COAP_MAX_RESOURCE_HANDLERS
#define COAP_MAX_RESOURCE_HANDLERS 16
#endif /* COAP_MAX_RESOURCE_HANDLERS */
#ifndef COAP_MAX_OBSERVERS
#define COAP_MAX_OBSERVERS 8
#endif /* COAP_MAX_OBSERVERS */
/* COAP_OBSERVE_REFRESH_INTERVAL: removed -- Contiki-NG coap-conf.h owns it */

/*==============================================================================
 * TRUST MODEL CONFIGURATION (3-tier)
 *============================================================================*/

/* Trust thresholds */
#ifndef TRUST_HIGH_THRESHOLD
#define TRUST_HIGH_THRESHOLD 0.8f
#endif /* TRUST_HIGH_THRESHOLD */
#ifndef TRUST_MEDIUM_THRESHOLD
#define TRUST_MEDIUM_THRESHOLD 0.5f
#endif /* TRUST_MEDIUM_THRESHOLD */
#ifndef TRUST_LOW_THRESHOLD
#define TRUST_LOW_THRESHOLD 0.3f
#endif /* TRUST_LOW_THRESHOLD */
#ifndef TRUST_CRITICAL_THRESHOLD
#define TRUST_CRITICAL_THRESHOLD 0.3f           /* For reactive rotation */
#endif /* TRUST_CRITICAL_THRESHOLD */
#ifndef TRUST_VOLATILITY_THRESHOLD
#define TRUST_VOLATILITY_THRESHOLD 0.15f        /* For volatility rotation */
#endif /* TRUST_VOLATILITY_THRESHOLD */

/* Trust levels (mapped to OSCORE) */
#ifndef OSCORE_TRUST_LEVEL_HIGH
#define OSCORE_TRUST_LEVEL_HIGH 3
#endif /* OSCORE_TRUST_LEVEL_HIGH */
#ifndef OSCORE_TRUST_LEVEL_MEDIUM
#define OSCORE_TRUST_LEVEL_MEDIUM 2
#endif /* OSCORE_TRUST_LEVEL_MEDIUM */
#ifndef OSCORE_TRUST_LEVEL_LOW
#define OSCORE_TRUST_LEVEL_LOW 1
#endif /* OSCORE_TRUST_LEVEL_LOW */
#ifndef OSCORE_TRUST_LEVEL_NONE
#define OSCORE_TRUST_LEVEL_NONE 0
#endif /* OSCORE_TRUST_LEVEL_NONE */

/* Trust assessment configuration */
#ifndef TRUST_ASSESSMENT_INTERVAL
#define TRUST_ASSESSMENT_INTERVAL 30            /* seconds */
#endif /* TRUST_ASSESSMENT_INTERVAL */
/* Paper 5 Eq. 6: Trust composition weights (FIXED - was 0.33/0.33/0.34) */
#ifndef TRUST_WEIGHT_AUTH
#define TRUST_WEIGHT_AUTH 0.5f                  /* alpha: authentication success */
#endif /* TRUST_WEIGHT_AUTH */
#ifndef TRUST_WEIGHT_KEY
#define TRUST_WEIGHT_KEY 0.2f                   /* beta: key freshness */
#endif /* TRUST_WEIGHT_KEY */
#ifndef TRUST_WEIGHT_PROTOCOL
#define TRUST_WEIGHT_PROTOCOL 0.3f              /* gamma: protocol compliance */
#endif /* TRUST_WEIGHT_PROTOCOL */
/* Also define aliases used in client.c */
#ifndef TRUST_WEIGHT_FRESHNESS
#define TRUST_WEIGHT_FRESHNESS TRUST_WEIGHT_KEY
#endif
#ifndef TRUST_WEIGHT_INTEGRITY
#define TRUST_WEIGHT_INTEGRITY TRUST_WEIGHT_PROTOCOL
#endif

/*==============================================================================
 * DYNAMIC THRESHOLD MANAGEMENT (Paper 5, Eq. 1)
 * T_dyn(t+1) = clip((1-eta)*T_dyn(t) + eta*T_base*(1+sum(wi*(Fi(t)-1))), T_min, T_max)
 *============================================================================*/

#ifndef ENABLE_DYNAMIC_THRESHOLDS
#define ENABLE_DYNAMIC_THRESHOLDS 1
#endif
#ifndef DYNAMIC_THRESHOLD_ETA
#define DYNAMIC_THRESHOLD_ETA 0.1f              /* Learning rate */
#endif
#ifndef DYNAMIC_THRESHOLD_QOS_BASE
#define DYNAMIC_THRESHOLD_QOS_BASE 0.45f        /* Base QoS threshold */
#endif
#ifndef DYNAMIC_THRESHOLD_QOS_MIN
#define DYNAMIC_THRESHOLD_QOS_MIN 0.2f
#endif
#ifndef DYNAMIC_THRESHOLD_QOS_MAX
#define DYNAMIC_THRESHOLD_QOS_MAX 0.8f
#endif
#ifndef DYNAMIC_THRESHOLD_BIRCH_BASE
#define DYNAMIC_THRESHOLD_BIRCH_BASE 1.5f
#endif
#ifndef DYNAMIC_THRESHOLD_BIRCH_MIN
#define DYNAMIC_THRESHOLD_BIRCH_MIN 0.5f
#endif
#ifndef DYNAMIC_THRESHOLD_BIRCH_MAX
#define DYNAMIC_THRESHOLD_BIRCH_MAX 3.0f
#endif
#ifndef DYNAMIC_THRESHOLD_DBSCAN_BASE
#define DYNAMIC_THRESHOLD_DBSCAN_BASE 0.3f
#endif
#ifndef DYNAMIC_THRESHOLD_DBSCAN_MIN
#define DYNAMIC_THRESHOLD_DBSCAN_MIN 0.1f
#endif
#ifndef DYNAMIC_THRESHOLD_DBSCAN_MAX
#define DYNAMIC_THRESHOLD_DBSCAN_MAX 1.0f
#endif

/*==============================================================================
 * ECF EXTENDED CLUSTERING FEATURES (Paper 5, Eq. 2)
 * ECF = <Ni, LSi, SSi, Ei, Ri, Ti, Si, Qi> - 8 dimensions
 *============================================================================*/

#ifndef ECF_DIMENSIONS
#define ECF_DIMENSIONS 8                        /* 8-dimensional ECF */
#endif
#ifndef ECF_WEIGHT_LATENCY
#define ECF_WEIGHT_LATENCY 0.15f
#endif
#ifndef ECF_WEIGHT_THROUGHPUT
#define ECF_WEIGHT_THROUGHPUT 0.15f
#endif
#ifndef ECF_WEIGHT_ENERGY
#define ECF_WEIGHT_ENERGY 0.10f
#endif
#ifndef ECF_WEIGHT_QOS
#define ECF_WEIGHT_QOS 0.15f
#endif
#ifndef ECF_WEIGHT_TRUST
#define ECF_WEIGHT_TRUST 0.15f
#endif
#ifndef ECF_WEIGHT_RELIABILITY
#define ECF_WEIGHT_RELIABILITY 0.10f
#endif
#ifndef ECF_WEIGHT_SECURITY
#define ECF_WEIGHT_SECURITY 0.10f
#endif
#ifndef ECF_WEIGHT_STABILITY
#define ECF_WEIGHT_STABILITY 0.10f
#endif

/*==============================================================================
 * TRUST-AWARE CLUSTERING (Paper 5, Eq. 8-10)
 *============================================================================*/

/* Trust penalty weight in secure distance metric (Eq. 8) */
#ifndef TRUST_DISTANCE_WEIGHT
#define TRUST_DISTANCE_WEIGHT 0.3f   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif
/* Minimum trust for DBSCAN expansion (Eq. 9-10: TrustCompatible) */
#ifndef TRUST_COMPATIBLE_MIN
#define TRUST_COMPATIBLE_MIN 0.3f
#endif

/*==============================================================================
 * SECURITY-COMPATIBLE GATE (Paper 5, Eq. 13)
 *============================================================================*/

#ifndef SECURITY_COMPATIBLE_THREAT_MAX
#define SECURITY_COMPATIBLE_THREAT_MAX 3         /* Max threat level for switching */
#endif
#ifndef SECURITY_COMPATIBLE_TRUST_MIN
#define SECURITY_COMPATIBLE_TRUST_MIN 0.3f       /* Min trust for switching */
#endif

/*==============================================================================
 * ADAPTIVE REPORTING (Paper 5, Eq. 5)
 * f_comm = f_base * (1 + alpha*dTheta/Theta_max + beta*dP/P_max)
 *============================================================================*/

#ifndef ADAPTIVE_REPORT_ALPHA
#define ADAPTIVE_REPORT_ALPHA 0.5f              /* Threat sensitivity */
#endif
#ifndef ADAPTIVE_REPORT_BETA
#define ADAPTIVE_REPORT_BETA 0.3f               /* Performance sensitivity */
#endif
#ifndef ADAPTIVE_REPORT_MAX_MULT
#define ADAPTIVE_REPORT_MAX_MULT 2.0f           /* Max rate multiplier */
#endif
#ifndef ADAPTIVE_REPORT_MIN_MULT
#define ADAPTIVE_REPORT_MIN_MULT 0.5f           /* Min rate multiplier */
#endif

/*==============================================================================
 * OSCORE HYBRID PROTECTION (Paper 6: 100% Coverage)
 *============================================================================*/

#ifndef ENABLE_HYBRID_PROTECTION
#define ENABLE_HYBRID_PROTECTION 1
#endif
/* Max OSCORE protection failures before key rotation trigger */
#ifndef OSCORE_MAX_PROTECT_FAILURES
#define OSCORE_MAX_PROTECT_FAILURES 10
#endif

/*==============================================================================
 * PROTOCOL UTILITY WEIGHTS (Paper 6, Eq. 3/7 - Unified)
 *============================================================================*/

#ifndef PROTO_WEIGHT_LATENCY
/* Issue A note: PROTO_WEIGHT_LATENCY (0.30) is the protocol-selector weight used
 * in Paper 6 Eq. 7 utility scoring. WEIGHT_LATENCY in the .c files (0.4) is the
 * node-local QoS normalisation weight. These are different computations — do not
 * conflate them. All three nodes use WEIGHT_LATENCY=0.4 for QoS (sum=1.0). */
#define PROTO_WEIGHT_LATENCY 0.30f              /* Paper 6 Eq. 7 */
#endif
#ifndef PROTO_WEIGHT_THROUGHPUT
#define PROTO_WEIGHT_THROUGHPUT 0.25f
#endif
#ifndef PROTO_WEIGHT_ENERGY
#define PROTO_WEIGHT_ENERGY 0.25f
#endif
#ifndef PROTO_WEIGHT_SECURITY
#define PROTO_WEIGHT_SECURITY 0.20f
#endif

/*==============================================================================
 * DOMAIN-SEPARATED KEY DERIVATION (Paper 6, Eq. 5)
 *============================================================================*/

#ifndef ENABLE_DOMAIN_SEPARATED_KEYS
#define ENABLE_DOMAIN_SEPARATED_KEYS 1
#endif

/*==============================================================================
 * CROSS-PROTOCOL SEQUENCE SYNC (Paper 6, Eq. 18)
 *============================================================================*/

#ifndef ENABLE_SEQUENCE_SYNC
#define ENABLE_SEQUENCE_SYNC 1
#endif

/*==============================================================================
 * TOPIC-BOUND AAD (Paper 6, Eq. 12)
 *============================================================================*/

/* FIX #1 (CRITICAL STRUCTURAL): TARP block was nested inside
 * #ifndef ENABLE_TOPIC_BOUND_AAD — when that feature was already defined
 * (e.g. in a prior include), ALL TARP constants were silently dropped.
 * The closing #endif for ENABLE_TOPIC_BOUND_AAD was also missing.
 * Corrected: TARP block is now at file scope, ENABLE_TOPIC_BOUND_AAD
 * has its own properly closed guard. */
#ifndef ENABLE_TOPIC_BOUND_AAD
#define ENABLE_TOPIC_BOUND_AAD 1
#endif /* ENABLE_TOPIC_BOUND_AAD */

#ifndef OSCORE_AAD_LENGTH
#define OSCORE_AAD_LENGTH 8                     /* 64-bit collision resistance */
#endif /* OSCORE_AAD_LENGTH */

/*------------------------------------------------------------------------------
 * TARP-OSCORE: Trust-Aware Reliability-resilient Protocol (Paper 7)
 * Trust-aware key lifecycle, loss-tolerant rekeying, proactive trend analysis
 * NOTE: These constants are now at file scope (not inside ENABLE_TOPIC_BOUND_AAD)
 *----------------------------------------------------------------------------*/

/* Feature flag */
#ifndef ENABLE_TARP_OSCORE
#define ENABLE_TARP_OSCORE 1
#endif

/* C1: Trust-aware key lifecycle (Paper 7 Eq. 1-4) */
#ifndef TARP_TRUST_WEIGHT_DEVICE
#define TARP_TRUST_WEIGHT_DEVICE      0.40f   /* w_d: device trust weight */
#endif
#ifndef TARP_TRUST_WEIGHT_CLUSTER
#define TARP_TRUST_WEIGHT_CLUSTER     0.35f   /* w_c: cluster trust weight */
#endif
#ifndef TARP_TRUST_WEIGHT_NETWORK
#define TARP_TRUST_WEIGHT_NETWORK     0.25f   /* w_n: network trust weight */
#endif
#ifndef TARP_REKEY_INTERVAL_BASE
#define TARP_REKEY_INTERVAL_BASE      600     /* T_base: 10 min default interval */
#endif
#ifndef TARP_REKEY_INTERVAL_MIN
#define TARP_REKEY_INTERVAL_MIN       30      /* T_min: fastest rekey (sec) */
#endif
#ifndef TARP_REKEY_INTERVAL_MAX
#define TARP_REKEY_INTERVAL_MAX       3600    /* T_max: slowest rekey (sec) */
#endif

/* FIX-SYNC-0: Rekey desynchronisation (anti t=T_base storm). All 112 nodes
 * boot at t=0 in Cooja with similar composite trust, so every context's
 * adaptive interval I = T_base*(T_comp/tau_s) matures at ~T_base = 600 s
 * simultaneously -> a network-wide TARP 3-way handshake storm at exactly the
 * 10-minute mark (the same failure class FIX-T6 documented at t=300 s).
 * JITTER_PCT randomises each interval evaluation by +/-20%; the per-node
 * budget caps how many networked rekeys one node may START per window, so a
 * synchronized maturity wave drains over several cycles instead of colliding
 * in a single collision domain. */
#ifndef TARP_REKEY_JITTER_PCT
#define TARP_REKEY_JITTER_PCT         20      /* +/- percent applied to I */
#endif

/* RAISEF-DL feature flags (File 3, optional-but-centralised). The Makefile
 * -D flags override these #ifndef-guarded defaults. */
#ifndef RAISEF_DL_ENABLED
#define RAISEF_DL_ENABLED 0
#endif
#ifndef RAISEF_DL_LOG
#define RAISEF_DL_LOG 0
#endif

/* ---- DL data-collection attack (Sec.4). OFF by default; enable via DLATTACK=1.
 * A single designated cluster head ramps its reported QoS down each maintenance
 * cycle after a warm-up, so its composite trust collapses and the CNN-LSTM has a
 * degradation trajectory to forecast. Pair with LOG=1 to capture DLFEAT lines. */
#ifndef RAISEF_DL_ATTACK
#define RAISEF_DL_ATTACK 0
#endif
#ifndef RAISEF_DL_ATTACK_CLUSTER_ID
/* v5 (plan v4.1 topology = the Cooja layout): node 1 = ER1, nodes 2-11 = CCs,
 * nodes 12-111 = clients, node 112 = ER2. The victim is the first cluster
 * centre, node 2. The DLGT,event=ONSET log line proves the attack ran. */
#define RAISEF_DL_ATTACK_CLUSTER_ID 2
#endif
#ifndef RAISEF_DL_ATTACK_SHAPE
#define RAISEF_DL_ATTACK_SHAPE 0           /* 0 ramp, 1 step, 2 ramp+recover, 3 oscillating */
#endif
#ifndef RAISEF_DL_ATTACK_RECOVER_AFTER
#define RAISEF_DL_ATTACK_RECOVER_AFTER 30  /* shape 2: cycles of decline before recovery */
#endif

/* ---- Final stage: per-cluster trust tracker at the edge (DL host) ----
 * RAISEF_TRUST_TRACKER     1 = edge_trust_tracker.c runs every edge maintenance
 *                          cycle (one sample per cluster per cycle), emits
 *                          DLFEAT(scope=C)/DLPRED/DLEVT, and sends ACCESSCAP.
 * RAISEF_ETT_PREDICT_ACCESS 1 = the forecast (DL or heuristic) feeds the access
 *                          cap through the min rule; 0 = purely reactive cap.
 * RAISEF_DL_HORIZON        forecast horizon in cycles; MUST equal --horizon used
 *                          by extract_features.py when training the model. */
#ifndef RAISEF_TRUST_TRACKER
#define RAISEF_TRUST_TRACKER 1
#endif
#ifndef RAISEF_ETT_PREDICT_ACCESS
#define RAISEF_ETT_PREDICT_ACCESS 1
#endif
#ifndef RAISEF_DL_HORIZON
#define RAISEF_DL_HORIZON 5
#endif
#ifndef RAISEF_DL_ATTACK_WARMUP
/* CC maintenance cycles (~20 s) before the attack may start. 60 cycles (~20 min)
 * lets RPL converge and every edge trust window fill (16 samples) first. */
#define RAISEF_DL_ATTACK_WARMUP 60
#endif
#ifndef RAISEF_DL_ATTACK_ONSET_JITTER
#define RAISEF_DL_ATTACK_ONSET_JITTER 30   /* + random 0..29 cycles, seeded by Cooja */
#endif
#ifndef RAISEF_DL_ATTACK_STEP
#define RAISEF_DL_ATTACK_STEP 0.03f        /* QoS decrement per cycle */
#endif
#ifndef RAISEF_DL_ATTACK_FLOOR
#define RAISEF_DL_ATTACK_FLOOR 0.05f       /* collapsed QoS floor */
#endif

/* ---- v5 final stage: edge cluster-level access policy (ETT_*) -------------
 * SEPARATE from the CC per-client TRACE thresholds (ML_ACCESS_*). Replace the
 * six values below with the output of dl_pipeline/calibrate_thresholds.py
 * (Step 4), then tag fs-thresholds. Defaults = Paper-8 published values. */
#ifndef ETT_T_FULL
#endif
#ifndef ETT_T_RESTRICTED
#endif
#ifndef ETT_T_READ_ONLY
#endif
#ifndef ETT_R_FULL
#endif
#ifndef ETT_R_RESTRICTED
#endif
#ifndef ETT_R_READ_ONLY
#endif
/* Edge->CC access cap: sent every edge cycle (refresh) and honoured by the CC
 * for RAISEF_EDGE_CAP_TTL; frames are HMAC-tagged with RAISEF_CTL_KEY. */
#ifndef RAISEF_EDGE_CAP_SEND
#define RAISEF_EDGE_CAP_SEND 1
#endif
#ifndef RAISEF_EDGE_CAP_TTL
#define RAISEF_EDGE_CAP_TTL (120 * CLOCK_SECOND)
#endif
#ifndef RAISEF_CTL_KEY
#define RAISEF_CTL_KEY "RAISEF-ctl-key-v5-000000000000000"
#endif
/* Graduated operations issued by clients so that all four access states have
 * an observable, measurable effect (client.c; enforcement in cluster.c). */
#ifndef RAISEF_GRADED_OPS
#define RAISEF_GRADED_OPS 1
#endif
#ifndef RAISEF_CMD_EVERY
#define RAISEF_CMD_EVERY 3       /* one command per 3 metric reports */
#endif
/* Measured-energy records (energy_log.c): Energest radio TX/LISTEN time of
 * every node, logged as DLNRG every RAISEF_NRG_PERIOD. */
#ifndef RAISEF_NRG_LOG
#define RAISEF_NRG_LOG 1
#endif
#ifndef RAISEF_NRG_PERIOD
#define RAISEF_NRG_PERIOD (60 * CLOCK_SECOND)
#endif
#ifndef RAISEF_OPS_LOG_PERIOD
#define RAISEF_OPS_LOG_PERIOD (60 * CLOCK_SECOND)
#endif
#ifndef TARP_MAX_REKEYS_PER_WINDOW
#define TARP_MAX_REKEYS_PER_WINDOW    2       /* networked rekeys / node / window */
#endif
#ifndef TARP_REKEY_WINDOW_SECONDS
#define TARP_REKEY_WINDOW_SECONDS     15      /* budget window length (sec) */
#endif

/* C2: Loss-tolerant rekeying (Paper 7 Eq. 5-9) */
#ifndef TARP_OVERLAP_WINDOW
#define TARP_OVERLAP_WINDOW           3       /* N_overlap: accepted old epochs */
#endif
#ifndef TARP_REKEY_MAX_RETRIES
#define TARP_REKEY_MAX_RETRIES        5       /* Max retransmissions */
#endif
#ifndef TARP_REKEY_ACK_TIMEOUT
#define TARP_REKEY_ACK_TIMEOUT        15      /* ACK timeout (sec) */
#endif

/* C3: Proactive trust-trend (Paper 7 Eq. 10-14) */
#ifndef TARP_TREND_WINDOW_SIZE
#define TARP_TREND_WINDOW_SIZE        16      /* W: sliding window samples */
#endif
#ifndef TARP_TREND_PREDICTION_HORIZON
#define TARP_TREND_PREDICTION_HORIZON 5       /* k: prediction steps ahead */
#endif
#ifndef TARP_TREND_EMA_ALPHA
#define TARP_TREND_EMA_ALPHA          0.3f    /* alpha: EMA smoothing */
#endif
/* FIX Bug5-conf: Rescaled from paper-nominal (0.7/0.4) to simulation-calibrated
 * values matching all three .c files.  The risk score R = slope^2 * accel^2 * (1-ema)
 * produces values in [0, ~0.1] during normal 5-min simulation runs, so the original
 * 0.7/0.4 thresholds were NEVER crossed — zero proactive rekeys fired.
 * New values (0.055 / 0.035) place the thresholds inside the observable R range.
 * All three .c inline blocks define identical rescaled values; this header now
 * matches so test harnesses and standalone builds see the same constants. */
#ifndef TARP_PROACTIVE_RISK_HIGH
#define TARP_PROACTIVE_RISK_HIGH      0.055f  /* Bug 5 FIX: rescaled from 0.7 */
#endif
#ifndef TARP_PROACTIVE_RISK_MEDIUM
#define TARP_PROACTIVE_RISK_MEDIUM    0.035f  /* Bug 5 FIX: rescaled from 0.4 */
#endif

/*==============================================================================
 * CLUSTER STATE CONFIGURATION
 *============================================================================*/

#ifndef CLUSTER_STATE_INACTIVE
#define CLUSTER_STATE_INACTIVE 0
#endif /* CLUSTER_STATE_INACTIVE */
#ifndef CLUSTER_STATE_ACTIVE
#define CLUSTER_STATE_ACTIVE 1
#endif /* CLUSTER_STATE_ACTIVE */
#ifndef CLUSTER_STATE_RECOVERING
#define CLUSTER_STATE_RECOVERING 2
#endif /* CLUSTER_STATE_RECOVERING */
#ifndef CLUSTER_RECOVERY_PERIOD
#define CLUSTER_RECOVERY_PERIOD (CLOCK_SECOND * 60)
#endif /* CLUSTER_RECOVERY_PERIOD */
#ifndef CLUSTER_TIMEOUT
#define CLUSTER_TIMEOUT (CLOCK_SECOND * 180)   /* kept = value every previous run actually used (project-conf.h was skipped) */
#endif /* CLUSTER_TIMEOUT */
#ifndef MAX_CONSECUTIVE_FAILURES
#define MAX_CONSECUTIVE_FAILURES 3
#endif /* MAX_CONSECUTIVE_FAILURES */

/* FIX #11 (reflected from edge/cluster .c fixes): Congestion level scale:
 *   0-20  = NONE     (no congestion)
 *   21-50 = LOW
 *   51-80 = MODERATE
 *   81-90 = HIGH
 *   91-100= CRITICAL
 * Values >100 are invalid. This is an integer percentage, NOT a [0,1] float. */
#ifndef GROUP_OSCORE_THRESHOLD
#define GROUP_OSCORE_THRESHOLD 10               /* Enable Group OSCORE for >10 nodes */
#endif /* GROUP_OSCORE_THRESHOLD */

/*==============================================================================
 * HEALTH MONITORING
 *============================================================================*/

#ifndef HEALTH_EXCELLENT
#define HEALTH_EXCELLENT 0.9f
#endif /* HEALTH_EXCELLENT */
#ifndef HEALTH_GOOD
#define HEALTH_GOOD 0.75f
#endif /* HEALTH_GOOD */
/* HEALTH_FAIR: per-binary value kept in the .c files (they differ by tier) */
/* HEALTH_POOR: per-binary value kept in the .c files (they differ by tier) */
#ifndef HEALTH_CRITICAL
#define HEALTH_CRITICAL 0.15f
#endif /* HEALTH_CRITICAL */
#ifndef WARNING_THRESHOLD
#define WARNING_THRESHOLD 0.7f
#endif /* WARNING_THRESHOLD */
#ifndef CRITICAL_THRESHOLD
#define CRITICAL_THRESHOLD 0.9f
#endif /* CRITICAL_THRESHOLD */
#ifndef CPU_THRESHOLD_HIGH
#define CPU_THRESHOLD_HIGH 0.8f
#endif /* CPU_THRESHOLD_HIGH */
#ifndef MEMORY_THRESHOLD_HIGH
#define MEMORY_THRESHOLD_HIGH 0.8f
#endif /* MEMORY_THRESHOLD_HIGH */
#ifndef NETWORK_THRESHOLD_HIGH
#define NETWORK_THRESHOLD_HIGH 0.75f
#endif /* NETWORK_THRESHOLD_HIGH */

/*==============================================================================
 * CONTIKI-NG OPTIMIZATION
 *============================================================================*/

#ifndef PROCESS_CONF_NO_PROCESS_NAMES
#define PROCESS_CONF_NO_PROCESS_NAMES 0
#endif /* PROCESS_CONF_NO_PROCESS_NAMES */
/* CLOCK_CONF_SECOND is platform-owned (cooja/native define it); removed. */
#ifndef ENERGEST_CONF_ON
#define ENERGEST_CONF_ON 1
#endif /* ENERGEST_CONF_ON */
#ifndef RADIO_CONF_CCA_THRESHOLD
#define RADIO_CONF_CCA_THRESHOLD -95
#endif /* RADIO_CONF_CCA_THRESHOLD */
#ifndef RADIO_CONF_TX_POWER
#define RADIO_CONF_TX_POWER 7
#endif /* RADIO_CONF_TX_POWER */

/*==============================================================================
 * PERFORMANCE TARGETS -- REMOVED (final-stage revision)
 * The former EXPECTED_* / TARGET_* constants reproduced published paper results
 * (6380 sessions, 23.5 "Mbps", 3.1 W, 99.91%, 1.96 s, ...). They were not used
 * by any computation, but an examiner reading the source would see results
 * embedded as targets. All reported values must come from logs.
 *============================================================================*/

/*==============================================================================
 * STATISTICS COLLECTION
 *============================================================================*/

#ifndef ENABLE_OSCORE_STATISTICS
#define ENABLE_OSCORE_STATISTICS 1
#endif /* ENABLE_OSCORE_STATISTICS */
#ifndef ENABLE_PROTOCOL_STATISTICS
#define ENABLE_PROTOCOL_STATISTICS 1
#endif /* ENABLE_PROTOCOL_STATISTICS */
#ifndef ENABLE_TRUST_STATISTICS
#define ENABLE_TRUST_STATISTICS 1
#endif /* ENABLE_TRUST_STATISTICS */
#ifndef ENABLE_PERFORMANCE_MONITORING
#define ENABLE_PERFORMANCE_MONITORING 1
#endif /* ENABLE_PERFORMANCE_MONITORING */
#ifndef ENABLE_ENHANCEMENT_STATISTICS
#define ENABLE_ENHANCEMENT_STATISTICS 1         /* NEW: Track enhancements */
#endif /* ENABLE_ENHANCEMENT_STATISTICS */
#ifndef STATS_LOG_INTERVAL
#define STATS_LOG_INTERVAL 100                  /* messages between logs */
#endif /* STATS_LOG_INTERVAL */
#ifndef STATS_REPORT_INTERVAL
#define STATS_REPORT_INTERVAL 3600              /* seconds */
#endif /* STATS_REPORT_INTERVAL */

/*==============================================================================
 * DEBUGGING AND TESTING
 *============================================================================*/

#ifndef DEBUG_OSCORE_KEYS
#define DEBUG_OSCORE_KEYS 0
#endif /* DEBUG_OSCORE_KEYS */
#ifndef DEBUG_OSCORE_MESSAGES
#define DEBUG_OSCORE_MESSAGES 0
#endif /* DEBUG_OSCORE_MESSAGES */
#ifndef DEBUG_OSCORE_CONTEXTS
#define DEBUG_OSCORE_CONTEXTS 1
#endif /* DEBUG_OSCORE_CONTEXTS */
#ifndef DEBUG_OSCORE_ROTATION
#define DEBUG_OSCORE_ROTATION 1
#endif /* DEBUG_OSCORE_ROTATION */
#ifndef DEBUG_OSCORE_PROTOCOL_SWITCH
#define DEBUG_OSCORE_PROTOCOL_SWITCH 1
#endif /* DEBUG_OSCORE_PROTOCOL_SWITCH */
#ifndef DEBUG_TRUST_MODEL
#define DEBUG_TRUST_MODEL 0
#endif /* DEBUG_TRUST_MODEL */
#ifndef DEBUG_ENHANCEMENTS
#define DEBUG_ENHANCEMENTS 1                    /* NEW: Debug enhancements */
#endif /* DEBUG_ENHANCEMENTS */
#ifndef DEBUG_PREDICTIVE_ROTATION
#define DEBUG_PREDICTIVE_ROTATION 0
#endif /* DEBUG_PREDICTIVE_ROTATION */
#ifndef DEBUG_KEY_CACHING
#define DEBUG_KEY_CACHING 0
#endif /* DEBUG_KEY_CACHING */
#ifndef DEBUG_FAST_PATH
#define DEBUG_FAST_PATH 0
#endif /* DEBUG_FAST_PATH */
#ifndef ENABLE_TEST_MODE
#define ENABLE_TEST_MODE 0
#endif /* ENABLE_TEST_MODE */
#ifndef ENABLE_SIMULATION_MODE
#define ENABLE_SIMULATION_MODE 1
#endif /* ENABLE_SIMULATION_MODE */

/*==============================================================================
 * CONTIKI-NG COMPATIBILITY
 *============================================================================*/

/* CONTIKI_VERSION_STRING is supplied by Contiki-NG's Makefile.include from the
 * actual checkout. Do not hard-code it; report the release tag / commit hash. */
#ifndef CONTIKI_TARGET_COOJA
#define CONTIKI_TARGET_COOJA 1
#endif /* CONTIKI_TARGET_COOJA */

#ifdef CONTIKI_TARGET_COOJA
/* PLATFORM_CONF_SUPPORTS_STACK_CHECK is platform-owned; removed. */
#ifndef PLATFORM_CONF_MAC_ADDR_NODE_ID
#define PLATFORM_CONF_MAC_ADDR_NODE_ID 1
#endif /* PLATFORM_CONF_MAC_ADDR_NODE_ID */
#endif

/* Platform features */
#ifndef PLATFORM_HAS_BATTERY
#define PLATFORM_HAS_BATTERY 1
#endif /* PLATFORM_HAS_BATTERY */
#ifndef PLATFORM_HAS_RADIO
#define PLATFORM_HAS_RADIO 1
#endif /* PLATFORM_HAS_RADIO */

/*==============================================================================
 * COMPILE-TIME VALIDATION
 *============================================================================*/

/* Validate OSCORE configuration */
#if ENABLE_OSCORE && !defined(OSCORE_MAX_KEY_SIZE)
#error "OSCORE enabled but OSCORE_MAX_KEY_SIZE not defined"
#endif

#if ENABLE_GROUP_OSCORE && !ENABLE_OSCORE
#error "Group OSCORE requires base OSCORE to be enabled"
#endif

#if ENABLE_MQTT_OSCORE && !ENABLE_OSCORE
#error "MQTT-OSCORE requires base OSCORE to be enabled"
#endif

#if ENABLE_COAP_OSCORE && !ENABLE_OSCORE
#error "CoAP-OSCORE requires base OSCORE to be enabled"
#endif

/* NEW: Validate enhancement configuration */
#if ENABLE_PREDICTIVE_ROTATION && !ENABLE_TRUST_AWARE_OSCORE
#error "Predictive rotation requires trust-aware OSCORE"
#endif

#if ENABLE_FAST_PATH_PROCESSING && !ENABLE_KEY_CACHING
#warning "Fast-path works best with key caching enabled"
#endif

/* Validate buffer sizes */
#if MAX_MSG_SIZE < OSCORE_PROTECTED_MSG_SIZE
#error "MAX_MSG_SIZE must be >= OSCORE_PROTECTED_MSG_SIZE"
#endif

/*==============================================================================
 * FEATURE SUMMARY (MERGED ARCHITECTURE)
 * 
 * This configuration enables:
 * ✅ OSCORE (RFC 8613) - Core implementation (inlined in each .c file)
 * ✅ MQTT-OSCORE - Novel contribution #1 (inlined)
 * ✅ CoAP-OSCORE - RFC 8613 standard (inlined)
 * ✅ Predictive Rotation - Novel contribution #2 (inlined)
 * ✅ Key Caching - Novel contribution #3 (inlined)
 * ✅ Performance Suite - Novel contribution #4 (inlined)
 *   - Fast-path processing (4a)
 *   - Energy-aware adaptation (4b)
 *   - Batch processing (4c)
 * ✅ Trust-aware security
 * ✅ Event-triggered rotation
 * ✅ Dynamic protocol switching
 * ✅ Group OSCORE support
 * ✅ Complete statistics tracking
 * 
 * NEW IN v3.4 (Session 13 — New-issues 1-7 from log analysis):
 * ✅ New-1: Client TARP thresholds were still 0.7/0.4 in .c inline block —
 *           client binary compiled with old values, zero client proactive rekeys.
 *           Fixed: #ifndef-guarded 0.055/0.035 added to client.c inline block
 *           (project-conf.h already had correct values from v3.3; client .c did not).
 * ✅ New-2: Cluster "Secured Messages: 0" — all cluster→edge/client messages
 *           go through the plaintext bypass in oscore_udp_sendto (GLOBALMETRICS,
 *           HEALTH_ACK, etc. match prefix filter before OSCORE encryption runs).
 *           Fixed: Security Status now reports protocol_stats.messages_sent as
 *           total TX with OSCORE-AES subset shown separately.
 * ✅ New-3: Edge "Proactive Rotations: 0" despite 12 TARP rekey decisions.
 *           tarp_initiate_rekey() never touched trust_rot_ctx.proactive_rotations
 *           (only the legacy oscore_enhanced_trust_rotation() path did).
 *           Fixed: added trust_rot_ctx.proactive_rotations++ in tarp_initiate_rekey.
 * ✅ New-4: Client TARP-C3 fired twice per maintenance cycle for ~24% of entries.
 *           trend_logged_this_cycle was reset inside tarp_proactive_rekey_decision()
 *           on every call; two callers in same 15s cycle both emitted a line.
 *           Fixed: reset moved to oscore_periodic_maintenance_enhanced() cycle start.
 * ✅ New-5: Edge protected_tx frozen at 46 — oscore_udp_sendto incremented only
 *           the low-level context counter; edge_state.security_metrics.oscore_messages_
 *           protected (read by maintenance log) was never updated after RegB-3 fix.
 *           Fixed: added edge_state.security_metrics.oscore_messages_protected++
 *           to both success paths inside oscore_udp_sendto.
 * ✅ New-6: Edge "Key Rotations (cumulative)" frozen at 3 — tarp_initiate_rekey()
 *           never incremented edge_state.security_metrics.oscore_key_rotations;
 *           only cluster-event and protocol-switch handlers did.
 *           Fixed: added oscore_key_rotations++ and key_rotations++ in tarp_initiate_rekey.
 * ✅ New-7: TARP session config block absent from logs — oscore_init_client() fires
 *           before the Cooja log capture window opens (~pre-07:11).
 *           Fixed: added one-shot static flag in maintenance timer tick to re-emit
 *           config at first 15s cycle (fully within the capture window).
 *
 * NEW IN v3.3 (Header Sync Pass — 35-issue cross-validation):
 * ✅ TARP_PROACTIVE_RISK_HIGH/MEDIUM rescaled (0.055/0.035) — Bug 5 fix
 * ✅ OSCORE_KEY_ROTATION_TRUST_EVENT = 5 added (was missing, caused local value=4 collision with TIME_EVENT)
 * ✅ OSCORE_KEY_ROTATION_SECURITY_EVENT = 6 added (was missing)
 * ✅ All six rotation event types now in one place; no .c-local overrides needed
 * ✅ TARP label strings aligned with .c definitions (see compatibility.h)
 *
 * NEW IN v3.2 (All 21 Fixes):
 * ✅ Real AES-CCM-16-64-128 encryption (not placeholder)
 * ✅ Real HKDF-SHA256 key derivation (not placeholder)
 * ✅ Domain-separated keys (MQTT vs CoAP)
 * ✅ Topic/URI-bound AAD (64-bit collision resistance)
 * ✅ Cross-protocol sequence synchronization
 * ✅ Edge OSCORE protection enabled
 * ✅ Hybrid protection (100% OSCORE coverage)
 * ✅ Dynamic threshold management (Paper 5 Eq. 1)
 * ✅ 8-dimensional ECF clustering (Paper 5 Eq. 2)
 * ✅ Trust-aware secure distance (Paper 5 Eq. 8)
 * ✅ TrustCompatible DBSCAN gate (Paper 5 Eq. 9-10)
 * ✅ SecurityCompatible switching gate (Paper 5 Eq. 13)
 * ✅ Adaptive reporting frequency (Paper 5 Eq. 5)
 * ✅ Corrected trust weights (0.5/0.2/0.3)
 * ✅ Additive stability bonus
 * ✅ Fixed last_key_rotation overwrite bug
 * 
 * External files needed: compatibility.h, timer_patch.h, project-conf.h, oscore_crypto.h
 * All other code is self-contained in client.c, cluster.c, edge.c
 *============================================================================*/


/*==============================================================================
 * DUAL-EDGE ARCHITECTURE — Paper 9 (Novel Contribution)
 *
 * Closes the SPOF identified in TARP-OSCORE (Paper 7, §Discussion):
 *   "full redundancy via a replicated Edge Root is identified as future work"
 *
 * Also links to ML-ACCESS-IoT (Paper 8) future work:
 *   "physical deployment on real Zolertia Z1 hardware"
 *   (requires resilient infrastructure before physical deployment is safe)
 *
 * Architecture  — 112 nodes total:
 *   Node 1       : edge.c         (ER1 — primary edge root)
 *   Nodes 2-11   : cluster.c      (10 cluster centers, failover-aware)
 *   Nodes 12-111 : client.c       (100 clients, completely transparent)
 *   Node 112     : edge_standby.c (ER2 — standby edge root)   [v5 = Cooja layout]
 *
 * Four contributions:
 *   DE-C1  Primary-backup state replication (OSCORE contexts+TARP+clusters)
 *   DE-C2  Failover nonce-continuity guarantee (extends Paper 6 S_unified)
 *   DE-C3  Dual-root RPL coordination (rank-based, no protocol modification)
 *   DE-C4  Resilience evaluation (failover latency, context recovery, overhead)
 *
 * Backward-compatible: ENABLE_DUAL_EDGE=0 restores single-edge behaviour.
 * Version: 4.0 — April 2026
 *==============================================================================*/

/* ---- Master enable ---- */
#ifndef ENABLE_DUAL_EDGE
#define ENABLE_DUAL_EDGE 1
#endif

/* ---- SurvivEdge (AGIM + CCA + CCTC) master enable ----
 * 1 = compile and RUN the SurvivEdge integrity/consensus layer at the cluster
 *     tier (driver in survivedge_integration.c; protocol logic in
 *     agim.c/cca.c/cctc.c, which must be added to PROJECT_SOURCEFILES).
 * 0 = fully excluded — the build reverts byte-for-byte to the previous system.
 * Defined here so edge.c (relay), cluster.c (driver) and the driver header all
 * agree on a single value. */
#ifndef ENABLE_SURVIVEDGE
#define ENABLE_SURVIVEDGE 1
#endif

/* ---- Cooja node IDs ---- */
#ifndef DUAL_EDGE_ER1_NODE_ID
#define DUAL_EDGE_ER1_NODE_ID          1   /* Primary edge root */
#endif
/* Topology (final, v5 = plan v4.1 = the Cooja .csc): node 1 = ER1,
 * nodes 2-11 = CCs, nodes 12-111 = clients, node 112 = ER2. */
#ifndef DUAL_EDGE_ER2_NODE_ID
#define DUAL_EDGE_ER2_NODE_ID 112 /* ER2 = node 112 (fd00::270:70:70:70) */
#endif

/* IPv6 last 16-bit word of ER2 link-local address (Cooja Z1 node 2) */
#ifndef DUAL_EDGE_ER2_ADDR_LAST_WORD
#define DUAL_EDGE_ER2_ADDR_LAST_WORD   0x0070   /* node 112 */
#endif
/* Alias: cluster_dual_edge code uses _LAST_BYTE, edge.c uses _LAST_WORD. Same value. */
#ifndef DUAL_EDGE_ER2_ADDR_LAST_BYTE
#define DUAL_EDGE_ER2_ADDR_LAST_BYTE   DUAL_EDGE_ER2_ADDR_LAST_WORD
#endif

/* Dedicated UDP port for ER1<->ER2 replication channel */
#ifndef DUAL_EDGE_REPLICATION_PORT
#define DUAL_EDGE_REPLICATION_PORT     7777
#endif

/* ---- DE-C1: Replication protocol timing ---- */
/* Heartbeat: ER1->ER2 liveness + latest sequence numbers (seconds) */
#ifndef DUAL_EDGE_HEARTBEAT_INTERVAL
#define DUAL_EDGE_HEARTBEAT_INTERVAL   (5 * CLOCK_SECOND)
#endif
/* Full snapshot: ER1->ER2 all contexts + cluster registry */
#ifndef DUAL_EDGE_SNAPSHOT_INTERVAL
#define DUAL_EDGE_SNAPSHOT_INTERVAL    (30 * CLOCK_SECOND)
#endif
/* Max consecutive missed heartbeats before ER2 declares failover */
#ifndef DUAL_EDGE_HEARTBEAT_MISS_MAX
#define DUAL_EDGE_HEARTBEAT_MISS_MAX   3
#endif
/* ACK timeout for replication messages (ms) — matches Paper 6 T_ack */
#ifndef DUAL_EDGE_ACK_TIMEOUT_MS
#define DUAL_EDGE_ACK_TIMEOUT_MS       500
#endif
/* Max replication retries before giving up */
#ifndef DUAL_EDGE_MAX_RETRIES
#define DUAL_EDGE_MAX_RETRIES          3
#endif

/* What is replicated (bitfield) */
#ifndef DE_REPLICATE_OSCORE_CONTEXTS
#define DE_REPLICATE_OSCORE_CONTEXTS   0x01
#endif
#ifndef DE_REPLICATE_TARP_STATE
#define DE_REPLICATE_TARP_STATE        0x02
#endif
#ifndef DE_REPLICATE_CLUSTER_REGISTRY
#define DE_REPLICATE_CLUSTER_REGISTRY  0x04
#endif
#ifndef DE_REPLICATE_ML_ACCESS_POLICY
#define DE_REPLICATE_ML_ACCESS_POLICY  0x08
#endif
#ifndef DE_REPLICATE_ALL
#define DE_REPLICATE_ALL   (DE_REPLICATE_OSCORE_CONTEXTS  | \
                            DE_REPLICATE_TARP_STATE       | \
                            DE_REPLICATE_CLUSTER_REGISTRY | \
                            DE_REPLICATE_ML_ACCESS_POLICY)
#endif
#ifndef DUAL_EDGE_REPLICATE_FLAGS
#define DUAL_EDGE_REPLICATE_FLAGS      DE_REPLICATE_ALL
#endif

/* ---- DE-C2: Failover nonce-continuity ----
 * S_failover = max(S_mqtt, S_coap, S_group) + DE_NONCE_SAFETY_MARGIN
 * Theorem: for all messages M_j sent post-failover, nonce(M_j) > nonce(M_i)
 *          for all M_i sent pre-failover, by construction of the margin.
 * DE_NONCE_SAFETY_MARGIN absorbs up to 64 messages of replication lag.      */
#ifndef DE_NONCE_SAFETY_MARGIN
#define DE_NONCE_SAFETY_MARGIN         64
#endif
/* Quiesce time after failover before ER2 issues new sessions (ticks) */
#ifndef DE_FAILOVER_QUIESCE_TIME
#define DE_FAILOVER_QUIESCE_TIME       (2 * CLOCK_SECOND)
#endif

/* ---- DE-C3: Dual-root RPL coordination ----
 * ER2 uses a higher rank while ER1 is alive (nodes prefer ER1).
 * On failover, ER2 lowers rank to ER2_PROMOTED_RANK => reconvergence.     */
#ifndef DUAL_EDGE_RPL_INSTANCE_ID
#define DUAL_EDGE_RPL_INSTANCE_ID      0x1E   /* 30 decimal */
#endif
#ifndef DUAL_EDGE_ER1_RANK
#define DUAL_EDGE_ER1_RANK             256    /* RPL_MIN_HOPRANKINC */
#endif
#ifndef DUAL_EDGE_ER2_STANDBY_RANK
#define DUAL_EDGE_ER2_STANDBY_RANK     512    /* 2x ER1 while standby */
#endif
#ifndef DUAL_EDGE_ER2_PROMOTED_RANK
#define DUAL_EDGE_ER2_PROMOTED_RANK    256    /* Equal to ER1 after promotion */
#endif

/* ---- Replication message types (extend existing MSG_TYPE_* space) ----
 * Existing max = 99 (MSG_TYPE_ERROR). Range 100-119 reserved for dual-edge. */
#ifndef MSG_TYPE_DE_HEARTBEAT
#define MSG_TYPE_DE_HEARTBEAT          100  /* ER1->ER2 liveness + seq counters */
#endif
#ifndef MSG_TYPE_DE_SNAPSHOT
#define MSG_TYPE_DE_SNAPSHOT           101  /* ER1->ER2 full state dump */
#endif
#ifndef MSG_TYPE_DE_DELTA_UPDATE
#define MSG_TYPE_DE_DELTA_UPDATE       102  /* ER1->ER2 incremental update */
#endif
#ifndef MSG_TYPE_DE_SNAPSHOT_ACK
#define MSG_TYPE_DE_SNAPSHOT_ACK       103  /* ER2->ER1 snapshot received */
#endif
#ifndef MSG_TYPE_DE_FAILOVER_DECLARE
#define MSG_TYPE_DE_FAILOVER_DECLARE   104  /* ER2->CCs failover announcement */
#endif
#ifndef MSG_TYPE_DE_FAILOVER_ACK
#define MSG_TYPE_DE_FAILOVER_ACK       105  /* CC->ER2 failover acknowledged */
#endif
#ifndef MSG_TYPE_DE_RECOVERY_NOTIFY
#define MSG_TYPE_DE_RECOVERY_NOTIFY    106  /* ER1->ER2 ER1 is back */
#endif
#ifndef MSG_TYPE_DE_CONTEXT_REQUEST
#define MSG_TYPE_DE_CONTEXT_REQUEST    107  /* ER2->ER1 request missing context */
#endif

/* ---- ER2 OSCORE sender/recipient IDs (replication channel only) ---- */
/* ER2 uses 0x04 on the ER1<->ER2 channel; 0x03 is ER1's sender ID      */
#ifndef OSCORE_ER2_SENDER_ID
#define OSCORE_ER2_SENDER_ID           0x04
#endif
#ifndef OSCORE_ER2_RECIPIENT_ID
#define OSCORE_ER2_RECIPIENT_ID        0x03
#endif

/* ---- ER2 state machine ---- */
#ifndef DE_STATE_STANDBY
#define DE_STATE_STANDBY               0  /* Receiving replication, not root */
#endif
#ifndef DE_STATE_PRIMARY
#define DE_STATE_PRIMARY               1  /* ER1: active root */
#endif
#ifndef DE_STATE_PROMOTED
#define DE_STATE_PROMOTED              2  /* ER2: acting as root after failover */
#endif
#ifndef DE_STATE_RECOVERING
#define DE_STATE_RECOVERING            3  /* ER1: returning after failure */
#endif

/* ---- Delta update sub-types ---- */
#ifndef DE_DELTA_SEQ_UPDATE
#define DE_DELTA_SEQ_UPDATE            0x01  /* Sequence number advanced */
#endif
#ifndef DE_DELTA_KEY_ROTATION
#define DE_DELTA_KEY_ROTATION          0x02  /* TARP key rotation */
#endif
#ifndef DE_DELTA_TRUST_CHANGE
#define DE_DELTA_TRUST_CHANGE          0x03  /* Composite trust changed */
#endif
#ifndef DE_DELTA_ML_ACCESS
#define DE_DELTA_ML_ACCESS             0x04  /* ML-ACCESS state changed */
#endif
#ifndef DE_DELTA_CLUSTER_JOIN
#define DE_DELTA_CLUSTER_JOIN          0x05  /* New cluster registered */
#endif
#ifndef DE_DELTA_CLUSTER_LEAVE
#define DE_DELTA_CLUSTER_LEAVE         0x06  /* Cluster deregistered */
#endif

/* ---- ML-ACCESS state values (Paper 8) — replicated by DE_REPLICATE_ML_ACCESS_POLICY */
/* TRACE (Paper 8) online application-level access-control enforcement. When 1
 * (default), the CC accepts/rejects each client operation per its 4-state
 * authorization. v5 operation classes (client.c RAISEF_GRADED_OPS):
 *   telemetry (Metrics:/Health:)  Full, Restricted, Read-Only
 *   low-impact command (CmdL:)    Full, Restricted
 *   high-impact command (CmdH:)   Full
 *   Revoked rejects everything.
 * v5: moved OUT of the ML_ACCESS_STATE_FULL guard (it was silently skipped if
 * any earlier header defined that state constant). Keys are never touched. */
#ifndef TRACE_ONLINE_ENFORCEMENT
#define TRACE_ONLINE_ENFORCEMENT 1
#endif
#ifndef ML_ACCESS_STATE_FULL
#define ML_ACCESS_STATE_FULL           0
#endif
#ifndef ML_ACCESS_STATE_RESTRICTED
#define ML_ACCESS_STATE_RESTRICTED     1
#endif
#ifndef ML_ACCESS_STATE_READ_ONLY
#define ML_ACCESS_STATE_READ_ONLY      2
#endif
#ifndef ML_ACCESS_STATE_REVOKED
#define ML_ACCESS_STATE_REVOKED        3
#endif

/*===========================================================================
 * FIX-PC-SELFCONTAINED: ML-ACCESS Eq.1 thresholds + SurvivEdge (AGIM/CCA/CCTC)
 * constants. These previously lived ONLY in survivedge.h. They are added here
 * (the central config / single source of truth), all #ifndef-guarded with the
 * EXACT survivedge.h values, so behaviour is unchanged regardless of which
 * header is included first. Edit values HERE; survivedge.h's guarded copies are
 * then skipped. (DE_NONCE_SAFETY_MARGIN is defined earlier in this file, so the
 * SE_CCTC_DELTA_SAFE reference below resolves.)
 *===========================================================================*/

/* --- ML-ACCESS Eq.1 thresholds (Paper 8): S(T_comp,R) cascade --- */
#ifndef ML_ACCESS_T_FULL
#define ML_ACCESS_T_FULL               0.80f
#endif
#ifndef ML_ACCESS_R_FULL
#define ML_ACCESS_R_FULL               0.035f
#endif
#ifndef ML_ACCESS_T_RESTRICTED
#define ML_ACCESS_T_RESTRICTED         0.60f
#endif
#ifndef ML_ACCESS_R_RESTRICTED
#define ML_ACCESS_R_RESTRICTED         0.055f
#endif
#ifndef ML_ACCESS_T_READ_ONLY
#define ML_ACCESS_T_READ_ONLY          0.40f
#endif
#ifndef ML_ACCESS_R_READ_ONLY
#define ML_ACCESS_R_READ_ONLY          0.10f
#endif

/* --- AGIM (SurvivEdge §IV-C): weighted deviation; weights sum to 1.00 --- */
#ifndef SE_AGIM_W_POLICY
#define SE_AGIM_W_POLICY               0.40f
#endif
#ifndef SE_AGIM_W_KEYING
#define SE_AGIM_W_KEYING               0.35f
#endif
#ifndef SE_AGIM_W_RESPONSE
#define SE_AGIM_W_RESPONSE             0.25f
#endif
#ifndef SE_AGIM_DELTA_SUS
#define SE_AGIM_DELTA_SUS              0.55f
#endif
#ifndef SE_AGIM_POLICY_ANOM_THRESH
#define SE_AGIM_POLICY_ANOM_THRESH     0.10f
#endif
#ifndef SE_AGIM_RESP_TIMEOUT_MS
#define SE_AGIM_RESP_TIMEOUT_MS        500
#endif
#ifndef SE_AGIM_CONFIRM_CYCLES
#define SE_AGIM_CONFIRM_CYCLES         2
#endif
#ifndef SE_AGIM_KEYING_EPSILON
#define SE_AGIM_KEYING_EPSILON         0.001f
#endif
#ifndef SE_AGIM_KEYING_HISTORY
#define SE_AGIM_KEYING_HISTORY         10
#endif

/* --- CCA (SurvivEdge §IV-A): BFT election, q_BFT=ceil((N_CC+f+1)/2)=7 --- */
#ifndef SE_CCA_N_CC
#define SE_CCA_N_CC                    10
#endif
#ifndef SE_CCA_F_MAX
#define SE_CCA_F_MAX                   3
#endif
#ifndef SE_CCA_QUORUM
#define SE_CCA_QUORUM                  7
#endif
#ifndef SE_CCA_SIGMA_ALERT
#define SE_CCA_SIGMA_ALERT             3
#endif
#ifndef SE_CCA_ELECTION_TIMEOUT_MS
#define SE_CCA_ELECTION_TIMEOUT_MS     1000
#endif

/* --- CCTC (SurvivEdge §IV-B): digest 32B, recovery tau 500ms, Delta_safe --- */
#ifndef SE_CCTC_DIGEST_BYTES
#define SE_CCTC_DIGEST_BYTES           32
#endif
#ifndef SE_CCTC_RECOVERY_TAU_MS
#define SE_CCTC_RECOVERY_TAU_MS        500
#endif
#ifndef SE_CCTC_DELTA_SAFE
#define SE_CCTC_DELTA_SAFE             DE_NONCE_SAFETY_MARGIN
#endif

/* --- SurvivEdge wire message types (110-116) --- */
#ifndef MSG_TYPE_SE_VOTE_REQUEST
#define MSG_TYPE_SE_VOTE_REQUEST       110
#endif
#ifndef MSG_TYPE_SE_VOTE_GRANT
#define MSG_TYPE_SE_VOTE_GRANT         111
#endif
#ifndef MSG_TYPE_SE_AUTHORITY_XFER
#define MSG_TYPE_SE_AUTHORITY_XFER     112
#endif
#ifndef MSG_TYPE_SE_CCTC_DIGEST
#define MSG_TYPE_SE_CCTC_DIGEST        113
#endif
#ifndef MSG_TYPE_SE_STATE_REQUEST
#define MSG_TYPE_SE_STATE_REQUEST      114
#endif
#ifndef MSG_TYPE_SE_STATE_RESPONSE
#define MSG_TYPE_SE_STATE_RESPONSE     115
#endif
#ifndef MSG_TYPE_SE_COMPROMISE_ALERT
#define MSG_TYPE_SE_COMPROMISE_ALERT   116
#endif

/* ---- DE-C4: Evaluation targets ---- */
#ifndef DE_TARGET_FAILOVER_MS
#define DE_TARGET_FAILOVER_MS          3000   /* Target: <3 seconds */
#endif
#ifndef DE_TARGET_CONTEXT_RECOVERY
#define DE_TARGET_CONTEXT_RECOVERY     0.99f  /* 99% contexts recovered */
#endif
#ifndef DE_TARGET_NONCE_CONTINUITY
#define DE_TARGET_NONCE_CONTINUITY     1.0f   /* 100% nonce uniqueness */
#endif
#ifndef DE_TARGET_REPLICATION_OVERHEAD
#define DE_TARGET_REPLICATION_OVERHEAD 0.02f  /* <2% overhead */
#endif
/* Alias: er1_log_repl_stats uses the longer DUAL_EDGE_ prefix. Same value. */
#ifndef DUAL_EDGE_TARGET_REPLICATION_OVERHEAD
#define DUAL_EDGE_TARGET_REPLICATION_OVERHEAD  DE_TARGET_REPLICATION_OVERHEAD
#endif

/* ---- Compile-time validation ---- */
#if ENABLE_DUAL_EDGE && !defined(ENABLE_TARP_OSCORE)
/* TARP must be enabled when dual-edge is on — checked at runtime if needed */
#endif
#if ENABLE_DUAL_EDGE && !defined(ENABLE_OSCORE)
/* OSCORE must be enabled when dual-edge is on */
#endif

#endif /* RAISEF_PROJECT_CONF_H_ */
