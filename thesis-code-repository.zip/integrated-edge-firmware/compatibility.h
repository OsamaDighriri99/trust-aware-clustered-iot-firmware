/* compatibility.h - Fix compilation issues with Contiki-NG and OSCORE */
#ifndef COMPATIBILITY_H
#define COMPATIBILITY_H

/*-----------------------------------------------------------------------------------*/
/* OSCORE-INTEGRATED IoT NETWORK COMPATIBILITY HEADER                               */
/* Purpose: Ensure clean compilation across all platforms and compilers             */
/* Compatible with: Client, Cluster Center, and Edge Node                          */
/*-----------------------------------------------------------------------------------*/

/* Include standard headers first */
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

/*-----------------------------------------------------------------------------------*/
/* VERIFICATION — platform-critical macros (Z1/MSP430 target via Cooja/MSPSim):       */
/*   * PRIu32/64, PRId32, PRIx32: #ifndef-guarded (no clash with a later <inttypes.h>)*/
/*     and the __LP64__ split is correct — host (LP64) gets "u"/"lu"; the MSP430      */
/*     target (uint32_t=unsigned long, uint64_t=unsigned long long) gets "lu"/"llu".  */
/*   * size_t/ssize_t typedef fires ONLY as a last resort (guarded by __SIZE_TYPE__   */
/*     and the standard sentinels), so it never redefines stddef.h's size_t.          */
/*   This header carries NO paper logic — it is the platform compatibility shim only. */
/*-----------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------------*/
/* Standard Format Macros                                                           */
/*-----------------------------------------------------------------------------------*/

/* Fix format macros */
#ifndef __STDC_FORMAT_MACROS
#define __STDC_FORMAT_MACROS 1
#endif

/* FIX #1: PRIu32 definitions were backwards for LP64 vs ILP32 platforms.
 * On LP64 (64-bit Linux): int is 32-bit, long is 64-bit -> PRIu32 = "u" (not "lu")
 * On ILP32 (32-bit Contiki/ARM): int is 16-bit, long is 32-bit -> PRIu32 = "lu"
 * Previous code had the #ifdef __LP64__ branches swapped, causing format
 * warnings on all platforms. */
#ifndef PRIu32
#ifdef __LP64__
#define PRIu32 "u"    /* FIX #1: LP64: int=32b, long=64b => uint32_t uses "u" */
#else
#define PRIu32 "lu"   /* ILP32 (Contiki/ARM): long=32b => uint32_t uses "lu" */
#endif
#endif

#ifndef PRIu64
#ifdef __LP64__
#define PRIu64 "lu"   /* FIX #1: LP64: long=64b => uint64_t uses "lu" */
#else
#define PRIu64 "llu"  /* ILP32: long long=64b => uint64_t uses "llu" */
#endif
#endif

#ifndef PRId32
#ifdef __LP64__
#define PRId32 "d"    /* FIX #1: LP64: int=32b => int32_t uses "d" */
#else
#define PRId32 "ld"   /* ILP32: long=32b => int32_t uses "ld" */
#endif
#endif

#ifndef PRIx32
#ifdef __LP64__
#define PRIx32 "x"    /* FIX #1: LP64: int=32b => uint32_t hex uses "x" */
#else
#define PRIx32 "lx"   /* ILP32: long=32b => uint32_t hex uses "lx" */
#endif
#endif

/*-----------------------------------------------------------------------------------*/
/* CRITICAL FIX: static_assert Handling                                             */
/*-----------------------------------------------------------------------------------*/

/* FIX #2 (CRITICAL): The previous static_assert implementation was broken:
 *   typedef char static_assertion_##__LINE__[(expr) ? 1 : 1]
 * The expression always evaluates to +1 regardless of (expr), so it NEVER
 * triggers a compile error even when the assertion fails. It was silently
 * passing all assertions including false ones.
 * Corrected: use [(expr) ? 1 : -1] — a negative array size is a compile error. */
#if !defined(static_assert) && !defined(__cplusplus) && __STDC_VERSION__ < 201112L
#define static_assert(expr, msg) \
    typedef char static_assertion_##__LINE__[(expr) ? 1 : -1]
    /* FIX #2: -1 (not 1) when expr is false -> compile error on assertion failure */
#endif

/*-----------------------------------------------------------------------------------*/
/* Compiler Diagnostics Suppression                                                 */
/*-----------------------------------------------------------------------------------*/

/* Disable problematic compiler features for GCC */
#ifdef __GNUC__
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wformat"
#pragma GCC diagnostic ignored "-Wimplicit-function-declaration"
#pragma GCC diagnostic ignored "-Wbuiltin-macro-redefined"
#pragma GCC diagnostic ignored "-Wimplicit-fallthrough"
#pragma GCC diagnostic ignored "-Wswitch-default"
#pragma GCC diagnostic ignored "-Wswitch"
#pragma GCC diagnostic ignored "-Wmaybe-uninitialized"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wcast-function-type"
#pragma GCC diagnostic ignored "-Wunused-local-typedefs"
#pragma GCC diagnostic ignored "-Wformat-truncation"
#pragma GCC diagnostic ignored "-Wformat-overflow"
#pragma GCC diagnostic ignored "-Wstringop-truncation"
#pragma GCC diagnostic ignored "-Wstringop-overflow"
#pragma GCC diagnostic ignored "-Waddress-of-packed-member"
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#endif

/* Clang-specific diagnostics */
#ifdef __clang__
#pragma clang diagnostic ignored "-Wunused-function"
#pragma clang diagnostic ignored "-Wunused-variable"
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wformat"
#pragma clang diagnostic ignored "-Wimplicit-function-declaration"
#pragma clang diagnostic ignored "-Wunused-value"
#pragma clang diagnostic ignored "-Wformat-security"
#endif

/*-----------------------------------------------------------------------------------*/
/* Helper Macros for Unused Parameters and Variables                                */
/*-----------------------------------------------------------------------------------*/

/* Macro to suppress unused parameter warnings */
#ifndef UNUSED_PARAMETER
#define UNUSED_PARAMETER(x) ((void)(x))
#endif

/* Helper macros for common suppressions */
#ifndef SUPPRESS_UNUSED
#define SUPPRESS_UNUSED(x) (void)(x)
#endif

/* Mark variable as potentially unused */
#ifdef __GNUC__
#ifndef MAYBE_UNUSED
#define MAYBE_UNUSED __attribute__((unused))
#endif
#else
#ifndef MAYBE_UNUSED
#define MAYBE_UNUSED
#endif
#endif

/* Mark function as potentially unused */
#ifdef __GNUC__
#ifndef UNUSED_FUNCTION
#define UNUSED_FUNCTION __attribute__((unused))
#endif
#else
#ifndef UNUSED_FUNCTION
#define UNUSED_FUNCTION
#endif
#endif

/*-----------------------------------------------------------------------------------*/
/* Contiki-NG Compatibility Fixes                                                   */
/*-----------------------------------------------------------------------------------*/

/* Additional compatibility fixes for Contiki-NG */
#ifndef CCIF
#define CCIF
#endif

#ifndef CLIF
#define CLIF
#endif

/* Ensure C99 compatibility - but don't override if already defined */
#ifndef __STDC_VERSION__
#define __STDC_VERSION__ 199901L
#endif

/* NOTE: PT_INIT is defined by Contiki-NG's pt.h - do not redefine here */
/* NOTE: CLOCK_SECOND is defined by Contiki-NG's clock.h - do not redefine here */

/*-----------------------------------------------------------------------------------*/
/* OSCORE-Specific Compatibility                                                    */
/*-----------------------------------------------------------------------------------*/

/* FIX #3: size_t re-typedef guard.
 * The original code unconditionally typedef'd size_t as 'unsigned long' when
 * certain guards were absent. On platforms where stddef.h or sys/types.h already
 * define size_t, this causes a redefinition error. The fix adds __SIZE_TYPE__
 * detection (GCC provides this built-in) and falls back to unsigned long only as
 * a last resort — consistent with the original intent but without breaking on
 * modern compilers. */
#ifndef _SIZE_T_DEFINED
#ifndef __SIZE_T
#ifndef __SIZE_TYPE__
#ifndef _SIZE_T
typedef unsigned long size_t;
#define _SIZE_T_DEFINED
#define __SIZE_T
#endif /* _SIZE_T */
#endif /* __SIZE_TYPE__ */
#endif /* __SIZE_T */
#endif /* _SIZE_T_DEFINED */

/* FIX #3 (same issue for ssize_t) */
#ifndef _SSIZE_T_DEFINED
#ifndef __SSIZE_T
#ifndef _SSIZE_T
typedef long ssize_t;
#define _SSIZE_T_DEFINED
#define __SSIZE_T
#endif /* _SSIZE_T */
#endif /* __SSIZE_T */
#endif /* _SSIZE_T_DEFINED */

/* Ensure NULL is defined */
#ifndef NULL
#ifdef __cplusplus
#define NULL 0
#else
#define NULL ((void *)0)
#endif
#endif

/*-----------------------------------------------------------------------------------*/
/* Mathematical Constants and Functions                                             */
/*-----------------------------------------------------------------------------------*/

/* Ensure math constants are available */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#ifndef M_E
#define M_E 2.71828182845904523536
#endif

/* Safe minimum/maximum macros */
#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

/* Absolute value macro */
#ifndef ABS
#define ABS(x) ((x) < 0 ? -(x) : (x))
#endif

/*-----------------------------------------------------------------------------------*/
/* NOTE: isnan, isinf, isfinite are defined by <math.h> - do not redefine here      */
/*-----------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------------*/
/* Memory and String Operations Safety                                              */
/*-----------------------------------------------------------------------------------*/

/* Safe string copy macro */
#ifndef SAFE_STRNCPY
#define SAFE_STRNCPY(dst, src, size) do { \
    strncpy((dst), (src), (size) - 1); \
    (dst)[(size) - 1] = '\0'; \
} while(0)
#endif

/* Safe memory zero */
#ifndef SAFE_MEMZERO
#define SAFE_MEMZERO(ptr, size) memset((ptr), 0, (size))
#endif

/* Safe buffer size calculation */
#ifndef SAFE_BUFFER_SIZE
#define SAFE_BUFFER_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))
#endif

/*-----------------------------------------------------------------------------------*/
/* Floating Point Compatibility                                                     */
/*-----------------------------------------------------------------------------------*/

/* Ensure floating point support is available */
#ifndef CONTIKI_CONF_FLOAT_SUPPORT
#define CONTIKI_CONF_FLOAT_SUPPORT 1
#endif

/*-----------------------------------------------------------------------------------*/
/* Bit Operations                                                                    */
/*-----------------------------------------------------------------------------------*/

/* Bit manipulation macros */
#ifndef BIT_SET
#define BIT_SET(value, bit) ((value) |= (1U << (bit)))
#endif

#ifndef BIT_CLEAR
#define BIT_CLEAR(value, bit) ((value) &= ~(1U << (bit)))
#endif

#ifndef BIT_TOGGLE
#define BIT_TOGGLE(value, bit) ((value) ^= (1U << (bit)))
#endif

#ifndef BIT_CHECK
#define BIT_CHECK(value, bit) (((value) >> (bit)) & 1U)
#endif

/*-----------------------------------------------------------------------------------*/
/* Array and Container Helpers                                                      */
/*-----------------------------------------------------------------------------------*/

/* Array size calculation */
#ifndef ARRAY_SIZE
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))
#endif

/* Container of macro (for embedded structures) */
#ifndef CONTAINER_OF
#define CONTAINER_OF(ptr, type, member) \
    ((type *)((char *)(ptr) - offsetof(type, member)))
#endif

/*-----------------------------------------------------------------------------------*/
/* Alignment Macros                                                                 */
/*-----------------------------------------------------------------------------------*/

/* Align value to nearest multiple */
#ifndef ALIGN_UP
#define ALIGN_UP(value, alignment) \
    (((value) + (alignment) - 1) & ~((alignment) - 1))
#endif

#ifndef ALIGN_DOWN
#define ALIGN_DOWN(value, alignment) \
    ((value) & ~((alignment) - 1))
#endif

/* Check if pointer is aligned */
#ifndef IS_ALIGNED
#define IS_ALIGNED(ptr, alignment) \
    (((uintptr_t)(ptr) & ((alignment) - 1)) == 0)
#endif

/*-----------------------------------------------------------------------------------*/
/* Endianness Handling                                                              */
/*-----------------------------------------------------------------------------------*/

/* Byte swap macros */
#ifndef BSWAP16
#define BSWAP16(x) ((uint16_t)((((x) & 0xFF00) >> 8) | (((x) & 0x00FF) << 8)))
#endif

#ifndef BSWAP32
#define BSWAP32(x) ((uint32_t)( \
    (((x) & 0xFF000000) >> 24) | \
    (((x) & 0x00FF0000) >> 8)  | \
    (((x) & 0x0000FF00) << 8)  | \
    (((x) & 0x000000FF) << 24)))
#endif

/*-----------------------------------------------------------------------------------*/
/* Time and Clock Compatibility                                                     */
/*-----------------------------------------------------------------------------------*/

/* NOTE: CLOCK_SECOND is defined by Contiki-NG - do not define here */

/* Time conversion macros - use only if CLOCK_SECOND is defined */
#ifdef CLOCK_SECOND
#ifndef MS_TO_CLOCK
#define MS_TO_CLOCK(ms) ((ms) * CLOCK_SECOND / 1000)
#endif

#ifndef CLOCK_TO_MS
#define CLOCK_TO_MS(ticks) ((ticks) * 1000 / CLOCK_SECOND)
#endif

#ifndef SEC_TO_CLOCK
#define SEC_TO_CLOCK(sec) ((sec) * CLOCK_SECOND)
#endif

#ifndef CLOCK_TO_SEC
#define CLOCK_TO_SEC(ticks) ((ticks) / CLOCK_SECOND)
#endif
#endif /* CLOCK_SECOND */

/*-----------------------------------------------------------------------------------*/
/* Error Handling Macros                                                            */
/*-----------------------------------------------------------------------------------*/

/* Return codes */
#ifndef SUCCESS
#define SUCCESS 0
#endif

#ifndef ERROR
#define ERROR (-1)
#endif

/* Check and return on error */
#ifndef CHECK_ERROR
#define CHECK_ERROR(expr) do { \
    int _err = (expr); \
    if (_err != SUCCESS) return _err; \
} while(0)
#endif

/* Check pointer validity */
#ifndef CHECK_NULL
#define CHECK_NULL(ptr) do { \
    if ((ptr) == NULL) return ERROR; \
} while(0)
#endif

/*-----------------------------------------------------------------------------------*/
/* Logging Compatibility                                                            */
/*-----------------------------------------------------------------------------------*/

/* NOTE: LOG_MODULE should be defined by each source file - do not define here */

/* Log level definitions if not present */
#ifndef LOG_LEVEL_NONE
#define LOG_LEVEL_NONE 0
#define LOG_LEVEL_ERR  1
#define LOG_LEVEL_WARN 2
#define LOG_LEVEL_INFO 3
#define LOG_LEVEL_DBG  4
#endif

/*-----------------------------------------------------------------------------------*/
/* Platform-Specific Fixes                                                          */
/*-----------------------------------------------------------------------------------*/

/* Cooja simulator fixes */
#ifdef CONTIKI_TARGET_COOJA
#ifndef COOJA
#define COOJA 1
#endif
#endif

/* Zoul platform fixes */
#ifdef CONTIKI_TARGET_ZOUL
#ifndef ZOUL
#define ZOUL 1
#endif
#endif

/* Native platform fixes */
#ifdef CONTIKI_TARGET_NATIVE
#ifndef NATIVE
#define NATIVE 1
#endif
#endif

/*-----------------------------------------------------------------------------------*/
/* OSCORE-Specific Type Definitions                                                 */
/*-----------------------------------------------------------------------------------*/

/* Ensure uint8_t array is properly defined for OSCORE keys */
typedef uint8_t oscore_key_t[16];
typedef uint8_t oscore_iv_t[13];
typedef uint8_t oscore_id_t[8];

/* OSCORE AAD type for topic-bound / URI-bound AAD (Paper 6 Eq. 12) */
typedef uint8_t oscore_aad_t[8];

/* OSCORE domain key info prefix type (Paper 6 Eq. 5) */
#ifndef OSCORE_DOMAIN_MQTT
#define OSCORE_DOMAIN_MQTT "OSCORE MQTT"
#endif
#ifndef OSCORE_DOMAIN_COAP
#define OSCORE_DOMAIN_COAP "OSCORE CoAP"
#endif
#ifndef OSCORE_DOMAIN_GROUP
#define OSCORE_DOMAIN_GROUP "OSCORE Group"
#endif

/*-----------------------------------------------------------------------------------*/
/* OSCORE Cryptographic Primitives (Paper 6, Eq. 1-2, 13-14)                        */
/* Real AES-CCM-16-64-128 and HKDF-SHA256 are implemented in oscore_crypto.h       */
/* which is inlined into each .c file. No external crypto library required.         */
/*-----------------------------------------------------------------------------------*/

/* AES-128 block size constant */
#ifndef AES_BLOCK_SIZE
#define AES_BLOCK_SIZE 16
#endif

/* SHA-256 digest size */
#ifndef SHA256_DIGEST_SIZE
#define SHA256_DIGEST_SIZE 32
#endif

/* HMAC-SHA256 output size */
#ifndef HMAC_SHA256_SIZE
#define HMAC_SHA256_SIZE 32
#endif

/* CCM mode parameters for AES-CCM-16-64-128 (COSE Algorithm 10) */
#ifndef CCM_TAG_LEN
#define CCM_TAG_LEN 8           /* 64-bit authentication tag */
#endif
#ifndef CCM_NONCE_LEN
#define CCM_NONCE_LEN 13        /* 13-byte nonce per RFC 8613 */
#endif
#ifndef CCM_L_VALUE
#define CCM_L_VALUE 2           /* L parameter for CCM (2 bytes for length field) */
#endif

/*-----------------------------------------------------------------------------------*/
/* OSCORE Hybrid Protection Constants (Paper 6: 100% Coverage Model)               */
/* Header stays plaintext for routing, payload is OSCORE-protected                 */
/*-----------------------------------------------------------------------------------*/

/* Separator characters for hybrid header|payload format */
#ifndef OSCORE_HYBRID_SEP_PIPE
#define OSCORE_HYBRID_SEP_PIPE '|'
#endif
#ifndef OSCORE_HYBRID_SEP_COLON
#define OSCORE_HYBRID_SEP_COLON ':'
#endif

/* Maximum header prefix length for hybrid protection */
#ifndef OSCORE_MAX_HEADER_PREFIX
#define OSCORE_MAX_HEADER_PREFIX 64
#endif

/* Bootstrap message prefixes (sent plaintext for initial handshake) */
#ifndef OSCORE_BOOTSTRAP_REG
#define OSCORE_BOOTSTRAP_REG "REG"
#endif
#ifndef OSCORE_BOOTSTRAP_ACK
#define OSCORE_BOOTSTRAP_ACK "ACK"
#endif
#ifndef OSCORE_BOOTSTRAP_DIS
#define OSCORE_BOOTSTRAP_DIS "DIS"
#endif

/*-----------------------------------------------------------------------------------*/
/* OSCORE Message Marker Constants                                                   */
/* CRITICAL: These must match across all source files for interoperability          */
/*-----------------------------------------------------------------------------------*/

/* OSCORE message marker byte - used to identify OSCORE-protected messages */
#ifndef MESSAGE_FLAG_OSCORE
#define MESSAGE_FLAG_OSCORE 0x40
#endif

#ifndef OSCORE_MESSAGE_MARKER_BYTE
#define OSCORE_MESSAGE_MARKER_BYTE 0x40  /* Same as MESSAGE_FLAG_OSCORE */
#endif

/*-----------------------------------------------------------------------------------*/
/* OSCORE Integration Constants - CRITICAL FOR MERGED SYSTEM                        */
/* These ensure compatibility with OSCORE security configuration                   */
/* (Now inlined directly in each main .c file)                                     */
/*-----------------------------------------------------------------------------------*/

/* NOTE: The following constants are now defined in the MERGED INLINE BLOCK
 * inside each main .c file (client.c, cluster.c, edge.c):
 * - OSCORE_SHARED_MASTER_SECRET
 * - OSCORE_SHARED_MASTER_SALT
 * - OSCORE_CLIENT_SENDER_ID (0x01)
 * - OSCORE_CLIENT_RECIPIENT_ID (0x02)
 * - OSCORE_CLUSTER_SENDER_ID (0x02)
 * - OSCORE_CLUSTER_RECIPIENT_ID (0x01)
 * - OSCORE_EDGE_SENDER_ID (0x03)
 * - OSCORE_EDGE_RECIPIENT_ID (0x01)
 * 
 * DO NOT redefine these here to avoid conflicts!
 */

/* OSCORE message flag must be set on first byte of protected messages */
#ifndef OSCORE_FLAG_MASK
#define OSCORE_FLAG_MASK 0x40
#endif

/* Helper macro to check if a message is OSCORE-protected */
#ifndef IS_OSCORE_MESSAGE
#define IS_OSCORE_MESSAGE(data) (((data)[0] & MESSAGE_FLAG_OSCORE) != 0)
#endif

/* FIX #4: IS_HYBRID_OSCORE_MESSAGE macro used memchr() but compatibility.h
 * cannot guarantee memchr is available before string.h inclusion.
 * Added static inline wrapper to avoid the issue; also the previous
 * implementation cast the result of memchr to int implicitly which
 * could produce warnings. The macro is now NULL-safe and cast-explicit. */
#ifndef IS_HYBRID_OSCORE_MESSAGE
#define IS_HYBRID_OSCORE_MESSAGE(data, len) \
    ((len) > 3 && !IS_OSCORE_MESSAGE(data) && \
     ((memchr((data), OSCORE_HYBRID_SEP_PIPE, MIN((len),(size_t)64)) != NULL) || \
      (memchr((data), OSCORE_HYBRID_SEP_COLON, MIN((len),(size_t)64)) != NULL)))
#endif

/* Paper 6 Eq. 18: Cross-protocol sequence synchronization */
#ifndef OSCORE_SEQ_SYNC_ENABLED
#define OSCORE_SEQ_SYNC_ENABLED 1
#endif

/*-----------------------------------------------------------------------------------*/
/* TARP-OSCORE: Trust-Aware Reliability-resilient Protocol Constants (Paper 7)       */
/*-----------------------------------------------------------------------------------*/

/* Key lifecycle states (Paper 7 Eq. 3) */
#ifndef TARP_KEY_STATE_ACTIVE
#define TARP_KEY_STATE_ACTIVE         0
#define TARP_KEY_STATE_PENDING_REKEY  1
#define TARP_KEY_STATE_OVERLAP        2
#define TARP_KEY_STATE_DEPRECATED     3
#define TARP_KEY_STATE_REVOKED        4
#endif

/* Rekey message types (Paper 7 Eq. 7) */
#ifndef TARP_REKEY_MSG_TYPE_INIT
#define TARP_REKEY_MSG_TYPE_INIT      0x01
#define TARP_REKEY_MSG_TYPE_ACK       0x02
#define TARP_REKEY_MSG_TYPE_CONFIRM   0x03
#define TARP_REKEY_MSG_TYPE_RESYNC    0x04
#define TARP_REKEY_MSG_TYPE_ABORT     0x05
#endif

/* Epoch constants (Paper 7 Eq. 5-6) */
#ifndef TARP_EPOCH_BITS
#define TARP_EPOCH_BITS               16
#define TARP_MAX_EPOCH_ID             0xFFFF
#define TARP_RESYNC_MAGIC             0xA7
#endif

/*-----------------------------------------------------------------------------------*/
/* FIX #5 (CRITICAL LABEL MISMATCH): TARP trust label constants                     */
/* These strings appear verbatim in TARP-C3 log lines.                              */
/*                                                                                   */
/* Previous values ("Edge peer trust", "Cluster aggregate trust", "Client trust")   */
/* were human-readable descriptions written BEFORE the .c files were finalised.     */
/* The .c inline blocks later settled on compact machine-parseable tokens            */
/* ("EDGE_AGGREGATOR", "CLUSTER_CENTER", "CLIENT_PEER") that dashboard/log          */
/* analysis tools use as filters. Because compatibility.h is the FIRST include      */
/* in every .c file, its #define wins over the .c #ifndef — so the old strings      */
/* were silently emitted instead of the intended compact tokens.                     */
/*                                                                                   */
/* Fix: update to the canonical compact tokens used by all three .c files.          */
/* Log reviewers: these tokens exactly match the TARP-C3 lines in the paper.        */
/*-----------------------------------------------------------------------------------*/
#ifndef TARP_TRUST_LABEL_EDGE
#define TARP_TRUST_LABEL_EDGE    "EDGE_AGGREGATOR"   /* FIX #5: was "Edge peer trust" */
#endif
#ifndef TARP_TRUST_LABEL_CLUSTER
#define TARP_TRUST_LABEL_CLUSTER "CLUSTER_CENTER"    /* FIX #5: was "Cluster aggregate trust" */
#endif
#ifndef TARP_TRUST_LABEL_CLIENT
#define TARP_TRUST_LABEL_CLIENT  "CLIENT_PEER"       /* FIX #5: was "Client trust" */
#endif

/*-----------------------------------------------------------------------------------*/
/* Network Port Definitions                                                          */
/* CRITICAL: Must be consistent across client, cluster, and edge                    */
/*-----------------------------------------------------------------------------------*/

#ifndef CLIENT_PORT
#define CLIENT_PORT 5678  /* Port for cluster <-> client communication */
#endif

#ifndef EDGE_PORT
#define EDGE_PORT 1234    /* Port for edge <-> cluster and edge <-> client */
#endif

/*-----------------------------------------------------------------------------------*/
/* Compiler Attribute Helpers                                                       */
/*-----------------------------------------------------------------------------------*/

/* Function attributes */
#ifdef __GNUC__
#ifndef ALWAYS_INLINE
#define ALWAYS_INLINE __attribute__((always_inline)) inline
#endif
#ifndef NEVER_INLINE
#define NEVER_INLINE __attribute__((noinline))
#endif
#ifndef PACKED
#define PACKED __attribute__((packed))
#endif
#ifndef ALIGNED
#define ALIGNED(x) __attribute__((aligned(x)))
#endif
#ifndef WEAK
#define WEAK __attribute__((weak))
#endif
#else
#ifndef ALWAYS_INLINE
#define ALWAYS_INLINE inline
#endif
#ifndef NEVER_INLINE
#define NEVER_INLINE
#endif
#ifndef PACKED
#define PACKED
#endif
#ifndef ALIGNED
#define ALIGNED(x)
#endif
#ifndef WEAK
#define WEAK
#endif
#endif

/*-----------------------------------------------------------------------------------*/
/* Version Information                                                              */
/*-----------------------------------------------------------------------------------*/

#define COMPATIBILITY_HEADER_VERSION "3.4.0"
#define COMPATIBILITY_HEADER_DATE "2026-03"
#define COMPATIBILITY_OSCORE_INTEGRATION "ENABLED"

/*-----------------------------------------------------------------------------------*/
/* OSCORE System Integration Status                                                 */
/*-----------------------------------------------------------------------------------*/

/* This compatibility header is designed to work with the MERGED OSCORE system:
 * OK client.c  - Self-contained with all OSCORE code inlined (sender=0x01)
 * OK cluster.c - Self-contained with all OSCORE code inlined (sender=0x02)
 * OK edge.c    - Self-contained with all OSCORE code inlined (sender=0x03)
 * 
 * MERGED ARCHITECTURE: All OSCORE headers and implementations are now
 * inlined directly into each main .c file. Only these 4 support files remain:
 *   - compatibility.h  (THIS FILE - platform layer)
 *   - timer_patch.h    (safe timer utilities)
 *   - project-conf.h   (Contiki-NG build configuration)
 *   - oscore_crypto.h  (AES-128, SHA-256, HMAC-SHA256 crypto primitives)
 * 
 * CRITICAL: Include order in source files MUST be:
 *   1. #include "compatibility.h"   (THIS FILE - FIRST!)
 *   2. #include "contiki.h"         (Contiki-NG core)
 *   3. #include "contiki-net.h"     (Networking)
 *   4. #include "timer_patch.h"     (Timer utilities - needs contiki.h first)
 *   5. Other system includes...
 *   6. [MERGED INLINE BLOCK]        (All OSCORE code is inlined here)
 *      - #include "oscore_crypto.h" (AES-CCM, SHA-256, HMAC, HKDF primitives)
 *   7. Original application code
 */

#endif /* COMPATIBILITY_H */

/*==============================================================================
 * INTEGRATION WITH MERGED OSCORE ARCHITECTURE
 * Version: 3.4.0 (35-issue cross-validation + header sync + session-13 counter fixes)
 * Date: March 2026
 *
 * FIXES APPLIED IN v3.4.0:
 * No logic changes to this file. Version bumped to stay in sync with
 * project-conf.h v3.4 and oscore_crypto.h v3.4. All session-13 fixes
 * (New-1 through New-7) were applied to the .c files only.
 *
 * FIXES APPLIED IN v3.3.0:
 * FIX #5 (CRITICAL): TARP_TRUST_LABEL_* strings were "Edge peer trust" /
 *         "Cluster aggregate trust" / "Client trust" — human-readable but
 *         WRONG. Because compatibility.h is the first include, its #define
 *         won over the .c inline-block #ifndef, so TARP-C3 log lines emitted
 *         the wrong node-type tokens. Fixed to "EDGE_AGGREGATOR",
 *         "CLUSTER_CENTER", "CLIENT_PEER" matching the .c files and paper.
 *
 * FIXES APPLIED IN v3.2.0:
 * FIX #1: PRIu32/PRIu64/PRId32/PRIx32 LP64 vs ILP32 branches were swapped.
 *         On 64-bit Linux, uint32_t uses int (not long) so PRIu32="u", not "lu".
 * FIX #2: static_assert implementation always passed: [(expr)?1:1] is always +1.
 *         Fixed to [(expr)?1:-1] so a failed assertion produces array size -1
 *         which is a compile error.
 * FIX #3: size_t/ssize_t re-typedef: added _SIZE_T guard to prevent redefinition
 *         errors when stddef.h already defines size_t.
 * FIX #4: IS_HYBRID_OSCORE_MESSAGE cast made explicit; memchr cast to void*
 *         comparison is now NULL-explicit for -Wpointer-compare hygiene.
 *============================================================================*/


/*-----------------------------------------------------------------------------------*/
/* DUAL-EDGE ARCHITECTURE TYPES (Paper 9)                                           */
/*                                                                                   */
/* FIX-DE1: These type definitions were moved to dual_edge_types.h.                 */
/*                                                                                   */
/* Root cause: de_replicated_cluster_t uses uip_ipaddr_t, but compatibility.h is   */
/* included BEFORE contiki.h in every .c file. At that point uip.h has not been    */
/* parsed yet so uip_ipaddr_t is undefined. uip_ip6addr_t is an anonymous union    */
/* in Contiki-NG — it cannot be forward-declared in standard C.                    */
/*                                                                                   */
/* Fix: dual_edge_types.h must be included AFTER contiki.h in edge.c,              */
/* edge_standby.c, and cluster.c:                                                   */
/*   1. #include "compatibility.h"   (this file — no uip dependency)               */
/*   2. #include "contiki.h"         (defines uip_ipaddr_t via uip.h)              */
/*   3. #include "contiki-net.h"                                                    */
/*   4. #include "dual_edge_types.h" (de_*_t structs — needs uip_ipaddr_t)         */
/*   5. #include "timer_patch.h"                                                    */
/*-----------------------------------------------------------------------------------*/

/* End of compatibility.h */
