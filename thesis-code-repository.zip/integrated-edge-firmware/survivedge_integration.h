/*******************************************************************************
 * SURVIVEDGE_INTEGRATION.H -- Wiring layer that makes AGIM + CCA + CCTC RUN
 * inside the cluster tier (SurvivEdge sec.IV, coupled to RAISEF-IoT).
 *
 * WHY THIS FILE EXISTS
 *   agim.c / cca.c / cctc.c are self-contained protocol logic but were never
 *   driven by any tier (their own comments say the cross-tier wiring was
 *   "intentionally omitted"). This module owns the three state machines and
 *   drives them from the cluster's 15 s maintenance cycle and UDP callback,
 *   so the SurvivEdge functionality is actually executed end-to-end.
 *
 * TRANSPORT
 *   Cluster centres have no peer table (they talk to the edge, not to each
 *   other). CC<->CC control messages (CCTC digests, CCA votes / authority
 *   transfer) are therefore sent to the EDGE, which relays them to every other
 *   registered cluster. The caller supplies a send callback so this module
 *   stays independent of cluster/edge internals.
 *
 * SAFETY
 *   Everything here is compiled and called only when ENABLE_SURVIVEDGE != 0.
 *   With the flag off, none of this is referenced and the system is byte-for-
 *   byte the previously-working build.
 ******************************************************************************/
#ifndef SURVIVEDGE_INTEGRATION_H
#define SURVIVEDGE_INTEGRATION_H

#include <stdint.h>
#include "survivedge.h"

#ifndef ENABLE_SURVIVEDGE
#define ENABLE_SURVIVEDGE 1
#endif

/* Message tag range handled by this module (survivedge.h: 110..116). */
#define SE_MSG_TAG_MIN  MSG_TYPE_SE_VOTE_REQUEST      /* 110 */
#define SE_MSG_TAG_MAX  MSG_TYPE_SE_COMPROMISE_ALERT  /* 116 */

/* Broadcast the CCTC digest only every N maintenance cycles. AGIM + the CCA
 * election check still run EVERY cycle (they are local and generate no radio
 * traffic); only the digest broadcast + its edge relay are throttled, which is
 * what was slowing the Cooja simulation. At UPDATE_INTERVAL=30s, N=4 means one
 * digest every ~2 min per cluster. Tune or set to 1 to broadcast every cycle. */
#ifndef SE_DIGEST_EVERY_N
#define SE_DIGEST_EVERY_N 4
#endif

/* ---- Compile-time attack: edge-root compromise (for demonstrating AGIM/CCA) --
 * OFF by default. Enable with:  make ... CFLAGS+="-DSE_ATTACK_EDGE_COMPROMISE=1"
 * After SE_ATTACK_WARMUP_CYCLES maintenance cycles, participating clusters feed
 * anomalous edge signals into AGIM, which drives D over delta_sus, accumulates
 * CCA suspicion to Sigma_alert, and triggers a leader election + authority
 * transfer -- all visible in the logs. Normal builds are unaffected. */
#ifndef SE_ATTACK_WARMUP_CYCLES
#define SE_ATTACK_WARMUP_CYCLES 3
#endif

/* Send callback: transmit a raw, plaintext SurvivEdge frame (1-byte tag +
 * packed body). 'ctx' is opaque caller context. On a cluster this sends the
 * frame to the edge for relay; on the edge the relay uses its own sender. */
typedef void (*se_send_fn)(void *ctx, const uint8_t *buf, uint16_t len);

/* Per-cycle inputs the cluster already computes. Any pointer may be NULL and
 * any field 0 -- the driver degrades gracefully (a missing signal contributes
 * 0 deviation, never a false alert). */
typedef struct {
    uint16_t       current_epoch;         /* cluster's OSCORE/TARP epoch      */
    /* AGIM d_keying */
    float          observed_rotate_freq;  /* rotations per cycle, observed    */
    float          expected_rotate_freq;  /* configured expectation           */
    /* AGIM d_response */
    uint32_t       edge_response_ms;      /* last edge round-trip / timeout   */
    /* AGIM d_policy (optional) */
    const uint8_t *local_ml_states;       /* se_ml_access_classify() locally  */
    const uint8_t *received_ml_states;    /* states received from edge root   */
    uint16_t       n_ml_nodes;
    /* CCTC digest source (serialised local security state F||K||P||M||e) */
    const uint8_t *state_buf;
    uint16_t       state_len;
} se_cycle_inputs_t;

/* Initialise all three state machines for this cluster centre. */
void se_integration_init(uint8_t cc_id, uint16_t epoch);

/* Drive AGIM (+ feed CCA suspicion), broadcast a CCTC digest, and start a CCA
 * election when suspicion crosses the alert threshold. Call once per 15 s
 * maintenance cycle. Returns 1 if an AGIM CompromiseAlert fired this cycle. */
uint8_t se_integration_periodic(const se_cycle_inputs_t *in,
                                se_send_fn send, void *send_ctx);

/* Dispatch one received SurvivEdge frame (tag in [110..116]). Safe to call for
 * any frame; returns 1 if the frame was a SurvivEdge frame and was consumed,
 * 0 otherwise (caller then processes it normally). */
uint8_t se_integration_handle_msg(const uint8_t *data, uint16_t datalen,
                                  se_send_fn send, void *send_ctx);

/* Observability: current role (SE_ROLE_*) and whether an alert is latched. */
uint8_t se_integration_role(void);
uint8_t se_integration_alerted(void);

#endif /* SURVIVEDGE_INTEGRATION_H */
