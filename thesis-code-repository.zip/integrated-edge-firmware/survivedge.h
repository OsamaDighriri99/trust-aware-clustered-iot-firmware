/*******************************************************************************
 * SURVIVEDGE.H -- Shared definitions for the SurvivEdge survivability overlay
 *
 * Paper 5: "SurvivEdge: Edge-Root-as-Adversary Survivability for Clustered IoT
 *           via Cluster Consensus and OSCORE Continuity"
 *
 * RECONSTRUCTION NOTICE
 *   The original cca.c / cctc.c / agim.c modules that produced the published
 *   SurvivEdge results were lost. This is a faithful reconstruction of the
 *   PUBLISHED DESIGN (equations and protocol text), NOT the original code, and
 *   it will not reproduce the paper's exact numbers. Every value is traced to
 *   the paper; spots where the paper underspecifies the implementation are
 *   marked  "RECON-CHOICE:"  and should be verified before thesis submission.
 *
 * LINKAGE (FIX-LINK-1: comment corrected to match the Makefile)
 *   These three modules are compiled into ALL FOUR binaries via
 *   PROJECT_SOURCEFILES += agim.c cca.c cctc.c  (see Makefile). They are NOT
 *   standalone Cooja node binaries. IMPORTANT: they are linked but not yet
 *   CALLED. The cross-tier wiring -- cluster.c invoking agim_evaluate, cca_*,
 *   cctc_* from oscore_periodic_maintenance and udp_rx_callback -- is a
 *   pending integration step, intentionally omitted so far.
 *
 * INCLUDE ORDER (matches edge_standby.c convention)
 *   compatibility.h -> contiki.h -> contiki-net.h -> dual_edge_types.h
 *   -> timer_patch.h -> ... -> oscore_crypto.h, then this header.
 ******************************************************************************/

#ifndef SURVIVEDGE_H
#define SURVIVEDGE_H

#include <stdint.h>
#include "net/ipv6/uip.h"          /* uip_ipaddr_t (after contiki.h) */
#include "simple-udp.h"

/* The SurvivEdge constants (SE_*, MSG_TYPE_SE_*, ML_ACCESS_T_* etc.) normally
 * live in project-conf.h. They are ALSO defined here under #ifndef guards so
 * that this header -- and anything that includes it -- compiles even if the
 * project-conf.h block is missing, reordered, or only partially present. The
 * guards mean these never override values project-conf.h already defined. */

/* VERIFICATION (this header's published parameters & logic):
 *   - ML-ACCESS Eq.1 thresholds match the paper: T_FULL=0.80, R_FULL=0.035,
 *     T_RESTRICTED=0.60, R_RESTRICTED=0.055, T_READ_ONLY=0.40, R_READ_ONLY=0.10.
 *   - se_ml_access_classify() checked at the boundaries (including the
 *     high-trust + high-risk -> REVOKED risk-gating case): all match Eq.1.
 *   - SE_AGIM_* (0.40/0.35/0.25, delta_sus 0.55), SE_CCA_* (N_CC 10, q_BFT 7,
 *     Sigma_alert 3) and SE_CCTC_* (Delta_safe == DE_NONCE_SAFETY_MARGIN 64)
 *     all match the paper and are exercised by agim.c / cca.c / cctc.c.
 *   - All state/message structs match the modules' field usage.
 * SELF-CONTAINED: this header defines its own guarded copies of every constant
 * it needs; it is the modules' own header, not a cross-tier link. */

/* --- Four access states (Paper 4). Self-defined so se_ml_access_classify()
 *     and any caller always resolve them regardless of include ordering. --- */
#ifndef ML_ACCESS_STATE_FULL
#define ML_ACCESS_STATE_FULL           0
#endif
#ifndef ML_ACCESS_STATE_RESTRICTED
#define ML_ACCESS_STATE_RESTRICTED     1
#endif
#ifndef ML_ACCESS_STATE_READ_ONLY
#define ML_ACCESS_STATE_READ_ONLY      2
#endif
#ifndef ML_ACCESS_STATE_REVOKED
#define ML_ACCESS_STATE_REVOKED        3
#endif

/* --- Eq.1 thresholds (Paper 4) -- fallbacks if project-conf.h block absent. --- */
#ifndef ML_ACCESS_T_FULL
#define ML_ACCESS_T_FULL               0.80f
#endif
#ifndef ML_ACCESS_R_FULL
#define ML_ACCESS_R_FULL               0.035f
#endif
#ifndef ML_ACCESS_T_RESTRICTED
#define ML_ACCESS_T_RESTRICTED         0.60f
#endif
#ifndef ML_ACCESS_R_RESTRICTED
#define ML_ACCESS_R_RESTRICTED         0.055f
#endif
#ifndef ML_ACCESS_T_READ_ONLY
#define ML_ACCESS_T_READ_ONLY          0.40f
#endif
#ifndef ML_ACCESS_R_READ_ONLY
#define ML_ACCESS_R_READ_ONLY          0.10f
#endif

/* --- Minimal CCA fallback (sizes cctc_state_t.peers[] below). --- */
#ifndef SE_CCA_N_CC
#define SE_CCA_N_CC                    10
#endif

/* --- AGIM / CCA / CCTC constant fallbacks (mirror the project-conf.h block).
 *     #ifndef-guarded, so project-conf.h values win when present; these only
 *     fill in when a module is compiled without the project-conf.h block in
 *     reach. Values traced to the SurvivEdge paper. --- */
#ifndef SE_AGIM_W_POLICY
#define SE_AGIM_W_POLICY               0.40f
#endif
#ifndef SE_AGIM_W_KEYING
#define SE_AGIM_W_KEYING               0.35f
#endif
#ifndef SE_AGIM_W_RESPONSE
#define SE_AGIM_W_RESPONSE             0.25f
#endif
#ifndef SE_AGIM_DELTA_SUS
#define SE_AGIM_DELTA_SUS              0.55f
#endif
#ifndef SE_AGIM_POLICY_ANOM_THRESH
#define SE_AGIM_POLICY_ANOM_THRESH     0.10f
#endif
#ifndef SE_AGIM_RESP_TIMEOUT_MS
#define SE_AGIM_RESP_TIMEOUT_MS        500
#endif
#ifndef SE_AGIM_CONFIRM_CYCLES
#define SE_AGIM_CONFIRM_CYCLES         2
#endif
#ifndef SE_AGIM_KEYING_EPSILON
#define SE_AGIM_KEYING_EPSILON         0.001f
#endif
#ifndef SE_AGIM_KEYING_HISTORY
#define SE_AGIM_KEYING_HISTORY         10
#endif
#ifndef SE_CCA_F_MAX
#define SE_CCA_F_MAX                   3
#endif
#ifndef SE_CCA_QUORUM
#define SE_CCA_QUORUM                  7
#endif
#ifndef SE_CCA_SIGMA_ALERT
#define SE_CCA_SIGMA_ALERT             3
#endif
#ifndef SE_CCA_ELECTION_TIMEOUT_MS
#define SE_CCA_ELECTION_TIMEOUT_MS     1000
#endif
#ifndef SE_CCTC_DIGEST_BYTES
#define SE_CCTC_DIGEST_BYTES           32
#endif
#ifndef SE_CCTC_RECOVERY_TAU_MS
#define SE_CCTC_RECOVERY_TAU_MS        500
#endif
#ifndef DE_NONCE_SAFETY_MARGIN
#define DE_NONCE_SAFETY_MARGIN         64
#endif
#ifndef SE_CCTC_DELTA_SAFE
#define SE_CCTC_DELTA_SAFE             DE_NONCE_SAFETY_MARGIN
#endif

/* --- Cluster-tier control-plane message type fallbacks (gap above DE 100-107). --- */
#ifndef MSG_TYPE_SE_VOTE_REQUEST
#define MSG_TYPE_SE_VOTE_REQUEST       110
#endif
#ifndef MSG_TYPE_SE_VOTE_GRANT
#define MSG_TYPE_SE_VOTE_GRANT         111
#endif
#ifndef MSG_TYPE_SE_AUTHORITY_XFER
#define MSG_TYPE_SE_AUTHORITY_XFER     112
#endif
#ifndef MSG_TYPE_SE_CCTC_DIGEST
#define MSG_TYPE_SE_CCTC_DIGEST        113
#endif
#ifndef MSG_TYPE_SE_STATE_REQUEST
#define MSG_TYPE_SE_STATE_REQUEST      114
#endif
#ifndef MSG_TYPE_SE_STATE_RESPONSE
#define MSG_TYPE_SE_STATE_RESPONSE     115
#endif
#ifndef MSG_TYPE_SE_COMPROMISE_ALERT
#define MSG_TYPE_SE_COMPROMISE_ALERT   116
#endif

/*=============================================================================
 * Paper 4 (ML-ACCESS) Eq.1 state-assignment S(T_comp, R) -> {0,1,2,3}
 * Shared because AGIM's d_policy compares the edge root's policy against the
 * cluster centre's LOCAL assignment, which is exactly this function.
 * States and T/R thresholds are defined above in THIS header (guarded), so the
 * classifier is self-contained; project-conf.h, if present, supplies identical
 * values and wins (the guards above are then skipped).
 *===========================================================================*/
static inline uint8_t se_ml_access_classify(float t_comp, float risk)
{
    if (t_comp >= ML_ACCESS_T_FULL       && risk < ML_ACCESS_R_FULL)
        return ML_ACCESS_STATE_FULL;
    if (t_comp >= ML_ACCESS_T_RESTRICTED && risk < ML_ACCESS_R_RESTRICTED)
        return ML_ACCESS_STATE_RESTRICTED;
    if (t_comp >= ML_ACCESS_T_READ_ONLY  && risk < ML_ACCESS_R_READ_ONLY)
        return ML_ACCESS_STATE_READ_ONLY;
    return ML_ACCESS_STATE_REVOKED;     /* Eq.1 "otherwise" */
}

/* Back-compat alias: some call sites use the short name ml_access_classify().
 * Route them to the canonical se_ml_access_classify() above so a single
 * definition serves every caller (prevents duplicate-definition / undefined
 * -reference issues). #ifndef guard avoids clashing with any real prototype. */
#ifndef ml_access_classify
#define ml_access_classify se_ml_access_classify
#endif

/* CC roles during a CCA election (Alg. CCA). */
enum {
    SE_ROLE_FOLLOWER = 0,
    SE_ROLE_CANDIDATE = 1,
    SE_ROLE_LEADER = 2
};

/*=============================================================================
 * Wire messages -- packed, 1-byte MSG_TYPE_SE_* tag prepended by the sender,
 * exactly like the de_* dual-edge messages (MSG_TYPE_DE_* 100-107).
 *===========================================================================*/

/* MSG_TYPE_SE_VOTE_REQUEST (110): CC -> all CCs  (Eq. VoteRequest) */
typedef struct __attribute__((packed)) {
    uint8_t  cc_id;                 /* requesting candidate */
    uint16_t epoch;                 /* e_cur -- current OSCORE epoch */
    uint8_t  evidence_digest[4];    /* H(Sigma_i, D_i): 4-byte truncated SHA-256 */
} se_vote_request_t;

/* MSG_TYPE_SE_VOTE_GRANT (111): CC -> candidate (or ER2 under priority rule) */
typedef struct __attribute__((packed)) {
    uint8_t  voter_id;
    uint8_t  candidate_id;          /* whom this grant is for */
    uint16_t epoch;
} se_vote_grant_t;

/* MSG_TYPE_SE_AUTHORITY_XFER (112): elected c* -> all (Eq. AuthorityTransfer) */
typedef struct __attribute__((packed)) {
    uint8_t  new_authority_id;
    uint16_t new_epoch;             /* e_cur + 1 -- invalidates compromised material */
    uint8_t  state_digest[32];      /* adopted CCTC state digest H*(t) */
    uint8_t  policy_hash[4];        /* hash of first policy batch */
} se_authority_xfer_t;

/* MSG_TYPE_SE_CCTC_DIGEST (113): CC -> all CCs, one per 15 s cycle (Eq. digest) */
typedef struct __attribute__((packed)) {
    uint8_t  cc_id;
    uint16_t epoch;
    uint8_t  digest[32];            /* SHA-256 over (F||K||P||M||e) */
} se_cctc_digest_t;

/* MSG_TYPE_SE_STATE_REQUEST (114): promoted CC* -> peers (CCTC R1) */
typedef struct __attribute__((packed)) {
    uint8_t  requester_id;
    uint16_t epoch;
} se_state_request_t;

/* MSG_TYPE_SE_STATE_RESPONSE (115) header: peer -> CC* (CCTC R1).
 * Followed by num_contexts * de_replicated_context_t records (reusing the
 * existing dual-edge record type). */
typedef struct __attribute__((packed)) {
    uint8_t  responder_id;
    uint16_t epoch;
    uint8_t  num_contexts;
    uint8_t  digest[32];            /* H_j(t) for the consistency check (R2) */
} se_state_response_hdr_t;

/*=============================================================================
 * AGIM -- Anomaly-Driven Gateway Integrity Monitor (paper sec.IV-C)
 *===========================================================================*/
typedef struct {
    float    last_d_policy;
    float    last_d_keying;
    float    last_d_response;       /* normalised: d_response_level / 2 */
    float    last_D;                /* fused composite deviation */
    uint8_t  consec_over;           /* consecutive cycles with D > delta_sus */
    uint8_t  alert_raised;          /* sticky: a CompromiseAlert has fired */
} agim_state_t;

void  agim_init(agim_state_t *st);

/* Compute the three raw signals from data the cluster already has. */
float agim_d_policy(const uint8_t *local_states,      /* se_ml_access_classify() */
                    const uint8_t *received_states,   /* states from the edge root */
                    uint16_t n_nodes);                /* Eq. d_policy */
float agim_d_keying(float observed_rotate_freq,
                    float expected_rotate_freq);      /* Eq. d_keying */
uint8_t agim_d_response_level(uint32_t resp_ms);      /* Eq. d_response -> {0,1,2} */

/* Fuse + apply the 2-consecutive-cycle rule. Returns 1 the cycle an alert
 * is first raised, else 0. */
uint8_t agim_evaluate(agim_state_t *st,
                      float d_policy, float d_keying, uint8_t d_response_level);

/*=============================================================================
 * CCA -- Cluster-Consensus Authority (paper sec.IV-A)
 *===========================================================================*/
typedef struct {
    uint8_t  sigma;                 /* suspicion counter Sigma_i */
    uint8_t  role;                  /* SE_ROLE_* */
    uint16_t cur_epoch;
    uint8_t  votes;                 /* tally while CANDIDATE */
    uint8_t  hold_last_valid;       /* 1 = freeze promotions during transfer */
    uint8_t  self_id;               /* this CC's id */
} cca_state_t;

void    cca_init(cca_state_t *st, uint8_t self_id, uint16_t epoch);

/* Phase 1: AGIM alert (or per-cycle D>delta_sus) advances suspicion; a valid
 * signed policy update from a current-epoch authority resets it. */
void    cca_note_alert(cca_state_t *st);
void    cca_note_valid_policy(cca_state_t *st);
uint8_t cca_should_start_election(const cca_state_t *st);   /* Sigma >= Sigma_alert */

/* Phase 2: build a VoteRequest (returns bytes written incl. 1-byte msg tag). */
int     cca_build_vote_request(uint8_t *buf, uint16_t buflen,
                               const cca_state_t *st);
/* On receiving a VoteRequest: if we also suspect, produce a VoteGrant to send
 * back. Returns bytes written, or 0 if no grant. */
int     cca_handle_vote_request(const cca_state_t *st, const uint8_t *payload,
                                uint16_t len, uint8_t *out, uint16_t outlen);
/* On receiving a VoteGrant addressed to us: tally; returns 1 if we just crossed
 * the BFT quorum and became LEADER this call. */
uint8_t cca_handle_vote_grant(cca_state_t *st, const uint8_t *payload, uint16_t len);
/* Build the AuthorityTransfer broadcast after winning. */
int     cca_build_authority_transfer(uint8_t *buf, uint16_t buflen,
                                     const cca_state_t *st,
                                     const uint8_t state_digest[32]);
/* On receiving AuthorityTransfer: verify epoch monotonicity, reset, follow. */
void    cca_handle_authority_transfer(cca_state_t *st, const uint8_t *payload,
                                      uint16_t len);

/*=============================================================================
 * CCTC -- Cross-Cluster Trust Continuity (paper sec.IV-B)
 *===========================================================================*/
typedef struct {
    uint8_t  cc_id;
    uint16_t epoch;
    uint8_t  digest[32];
    uint8_t  valid;
} cctc_peer_digest_t;

typedef struct {
    uint8_t            self_id;
    uint16_t           epoch;
    uint8_t            local_digest[32];
    cctc_peer_digest_t peers[SE_CCA_N_CC];   /* one slot per CC */
    uint8_t            n_peers;
} cctc_state_t;

void cctc_init(cctc_state_t *st, uint8_t self_id, uint16_t epoch);

/* Compute SHA-256 digest over the serialised local state buffer (F||K||P||M||e). */
void cctc_compute_digest(const uint8_t *state_buf, uint16_t len, uint8_t out[32]);

/* Build the per-cycle digest broadcast (Eq. digest). */
int  cctc_build_digest_msg(uint8_t *buf, uint16_t buflen, cctc_state_t *st,
                           const uint8_t *state_buf, uint16_t state_len);

/* Record a peer digest; returns 1 if a supermajority (> N_CC/2) now agree
 * with our local digest (R2 consistency condition). */
uint8_t cctc_on_peer_digest(cctc_state_t *st, const uint8_t *payload, uint16_t len);
uint8_t cctc_supermajority_consistent(const cctc_state_t *st);

/* Nonce continuity across failover (Eq. S_failover) -- mirrors the DE-C2
 * construction already in edge_standby.c, extended to the cluster tier. */
uint64_t cctc_compute_s_failover(uint64_t s_mqtt, uint64_t s_coap,
                                 uint64_t s_group);

#endif /* SURVIVEDGE_H */
