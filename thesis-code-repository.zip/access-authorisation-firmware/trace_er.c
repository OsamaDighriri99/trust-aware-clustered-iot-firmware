/*
 * TRACE unified build -- edge root (node 1, primary, RPL root) and standby edge root (node 112). Verifies protected
 * descriptor batches from the cluster centres (epoch, AEAD, replay, binding to the sending CC), evaluates the
 * configured model on each full-window descriptor and returns one protected assignment batch per descriptor batch
 * (echoed batch number, lease of 4 cycles). Models: 0 explicit reference policy on the descriptor; 1 Random Forest
 * reproducing the current reference state; 2 Random Forest predicting the most restrictive reference state over the
 * next H cycles; 3 degradation detector (TRACE default after stage A): Restricted when at least k of the trees vote
 * for degradation, otherwise no restriction.
 * Failures: OUT -- the primary ER's authorization service is unavailable from 2 h to 4 h while the node keeps routing;
 * NF -- the primary ER node fails at 2 h (it falls silent and the run script moves it out of radio range). The CCs fail
 * over by themselves (3 unanswered cycles). The primary sends a protected heartbeat to the standby every 15 s; after
 * 45 s without one the standby probes node 1 with ICMPv6 echo requests for 10 s, and if node 1 does not answer it also
 * takes over the RPL root role under the same DODAG identifier (virtual-root takeover) and repeats the global repair
 * once a minute for ten minutes. With sb=0 the standby does not serve (F0).
 * Protected-path tests (sec=1): from 2100 s on, the primary injects one crafted assignment batch every 45 s, ten kinds
 * in rotation over the CCs (valid, modified, replayed, stale, wrong key, misbound, delayed, privilege-raising, expired
 * epoch, wrong type); each is logged (SEC_TX) and the CC logs its receive decision (ASG, mdl = 100 + test id).
 */
#include "trace_common.h"
#include "net/routing/routing.h"
#include "net/routing/rpl-classic/rpl.h"
#include "net/routing/rpl-classic/rpl-private.h"
#include "net/ipv6/uip-icmp6.h"
#include "net/ipv6/uip-ds6-route.h"
#include <string.h>

PROCESS(er_process, "TRACE edge root");
AUTOSTART_PROCESSES(&er_process);

#define T_HB 'H'
#define HB_SILENCE_S 45
static struct simple_udp_connection econn;
static pctx_t ccctx[TT_NCC], pctx_peer;
static const tr_params_t *P;
static uint8_t buf[256], pt[224], was_down, failed, probing, probe_reply, rpl_took, n_rep;
static uint32_t n_batch, n_rej, n_desc, last_hb, probe_t0, next_rep;
static uint16_t last_batch[TT_NCC];
static ab_t last_ab[TT_NCC];
static struct uip_icmp6_echo_reply_notification echo_n;

static int
model_eval(const db_entry_t *e, int16_t ref_q, uint8_t *v1, uint8_t *v2)
{
  int s = -1;
  if(g_model == 1) s = rf_predict(&rf_cur, e->d.q, v1, v2);
  else if(g_model == 2) s = rf_predict(&rf_ant, e->d.q, v1, v2);
  else if(g_model == 3) {                           /* degradation detector: Restricted or no restriction */
    int v = rf_votes_for(&rf_det, e->d.q, 1);
    if(v >= 0) { *v1 = (uint8_t)v; *v2 = (uint8_t)(rf_det.n_trees - v); return v >= rf_det_k ? ST_REST : ST_FULL; }
  }
  if(s < 0) {                                       /* explicit reference policy on the received descriptor */
    float f[8]; tr_dequantise(&e->d, f);
    s = tr_policy(P, f[0], f[5], ref_q / TR_Q_T); *v1 = 0; *v2 = 0;
  }
  return s;
}

static void
send_ab(uint8_t cc, const ab_t *ab, uint8_t type, int corrupt, int epoch_back)
{
  uip_ipaddr_t a; int n = ab_encode(ab, pt), m;
  if(epoch_back) {                                  /* object protected under an expired epoch */
    tos_keys_t k; uint16_t e = (uint16_t)(epoch_at(now_s()) - epoch_back);
    ctx_keys((uint8_t)node_id, cc, e, &k);
    m = tk_build(type, e, &k, 0x7FFF0000UL + n_rep++, pt, (uint16_t)n, buf);
  } else m = pctx_protect(&ccctx[cc - TT_FIRST_CC], type, now_s(), pt, (uint16_t)n, buf);
  if(corrupt) buf[m - 3] ^= 0x01;
  node_addr(cc, &a);
  count_tx(TC_ASSIGN, (uint16_t)m);
  simple_udp_sendto_port(&econn, buf, (uint16_t)m, &a, PORT_ER);
}

static void
erx(struct simple_udp_connection *c, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
    const uint8_t *data, uint16_t len)
{
  uint32_t t = now_s(); uint8_t from = addr_node(sa); int plen = 0, r, i, n; db_t db; ab_t ab; char st[16];
  if(!g_configured || failed) return;
  if(node_id == TT_STANDBY && from == TT_ER) {                  /* heartbeat of the primary */
    if(pctx_open(&pctx_peer, T_HB, t, data, len, pt, &plen) == RX_OK) last_hb = t;
    return;
  }
  if(from < TT_FIRST_CC || from >= TT_FIRST_CC + TT_NCC) return;
  if(node_id == TT_STANDBY && !g_standby) return;               /* F0: no standby service */
  if(er_down((uint8_t)node_id, t)) {
    if(!was_down) { TLOG("ER_DOWN", "er=%u", (unsigned)node_id); was_down = 1; }
    return;
  }
  if(was_down) { TLOG("ER_UP", "er=%u", (unsigned)node_id); was_down = 0; }
  r = pctx_open(&ccctx[from - TT_FIRST_CC], T_DESC, t, data, len, pt, &plen);
  if(r == RX_OK && db_decode(pt, plen, &db) < 0) r = RX_PARSE;
  if(r == RX_OK && db.cc != from) r = RX_BIND;                  /* batch must name its sender */
  if(r != RX_OK) { n_rej++; TLOG("DESCREJ", "cc=%u,why=%s", from, rx_name[r]); return; }
  n_batch++;
  memset(&ab, 0, sizeof ab);
  ab.cc = db.cc; ab.batch = db.batch; ab.model = g_model; ab.lease = 4;
  for(i = 0; i < db.n; i++) {
    uint8_t v1 = 0, v2 = 0;
    st[i] = '-';
    if(!(db.e[i].flags & DF_FULL) || (db.e[i].flags & DF_SLEEP)) continue;
    ab.e[ab.n].slot = db.e[i].slot;
    ab.e[ab.n].state = (uint8_t)model_eval(&db.e[i], db.ref, &v1, &v2);
    ab.e[ab.n].v1 = v1; ab.e[ab.n].v2 = v2;
    st[i] = (char)('0' + ab.e[ab.n].state);
    ab.n++; n_desc++;
  }
  st[db.n < 16 ? db.n : 15] = 0;
  n = ab_encode(&ab, pt);
  {
    int m = pctx_protect(&ccctx[from - TT_FIRST_CC], T_ASSIGN, t, pt, (uint16_t)n, buf);
    count_tx(TC_ASSIGN, (uint16_t)m);
    simple_udp_sendto_port(&econn, buf, (uint16_t)m, sa, PORT_ER);
  }
  last_batch[from - TT_FIRST_CC] = db.batch; last_ab[from - TT_FIRST_CC] = ab;
  TLOG("ERB", "cc=%u,b=%u,st=%s", from, db.batch, st);
}

/* ---------------- protected-path tests (primary, sec=1) ---------------- */
#define NTEST 10
static const char *const test_name[NTEST] = { "valid", "modified", "replay", "stale", "wrongkey", "misbind", "delayed",
                                              "privup", "oldepoch", "wrongtype" };
static uint8_t held[256]; static int held_n; static uint8_t held_cc; static uint32_t held_until;
static void
sectest(uint32_t t)
{
  static uint32_t next = 2100, no;
  uint8_t tid, k, ki; ab_t ab; int i;
  if(!g_sectest || t < next) return;
  next += 45;
  tid = (uint8_t)(no % NTEST); k = (uint8_t)(TT_FIRST_CC + (no / NTEST) % TT_NCC); no++; ki = (uint8_t)(k - TT_FIRST_CC);
  if(!last_batch[ki]) return;
  ab = last_ab[ki]; ab.model = (uint8_t)(100 + tid); ab.batch = last_batch[ki];
  switch(tid) {
  case 0: send_ab(k, &ab, T_ASSIGN, 0, 0); break;
  case 1: send_ab(k, &ab, T_ASSIGN, 1, 0); break;
  case 2: {                                         /* the same protected object twice */
    uip_ipaddr_t a; int n = ab_encode(&ab, pt), m = pctx_protect(&ccctx[ki], T_ASSIGN, t, pt, (uint16_t)n, buf);
    node_addr(k, &a); count_tx(TC_ASSIGN, (uint16_t)m); simple_udp_sendto_port(&econn, buf, (uint16_t)m, &a, PORT_ER);
    count_tx(TC_ASSIGN, (uint16_t)m); simple_udp_sendto_port(&econn, buf, (uint16_t)m, &a, PORT_ER);
    break; }
  case 3: ab.batch = (uint16_t)(ab.batch - 3); send_ab(k, &ab, T_ASSIGN, 0, 0); break;
  case 4: {                                         /* protected under the context of another CC */
    uint8_t k2 = (uint8_t)(k == TT_FIRST_CC + TT_NCC - 1 ? TT_FIRST_CC : k + 1); uip_ipaddr_t a;
    int n = ab_encode(&ab, pt), m = pctx_protect(&ccctx[k2 - TT_FIRST_CC], T_ASSIGN, t, pt, (uint16_t)n, buf);
    node_addr(k, &a); count_tx(TC_ASSIGN, (uint16_t)m); simple_udp_sendto_port(&econn, buf, (uint16_t)m, &a, PORT_ER);
    break; }
  case 5: ab.cc = (uint8_t)(k == TT_FIRST_CC + TT_NCC - 1 ? TT_FIRST_CC : k + 1); send_ab(k, &ab, T_ASSIGN, 0, 0); break;
  case 6: {                                         /* valid object held for 75 s, then delivered */
    int n = ab_encode(&ab, pt);
    held_n = pctx_protect(&ccctx[ki], T_ASSIGN, t, pt, (uint16_t)n, held); held_cc = k; held_until = t + 75;
    break; }
  case 7: for(i = 0; i < ab.n; i++) ab.e[i].state = ST_FULL; send_ab(k, &ab, T_ASSIGN, 0, 0); break;
  case 8: if((t % EPOCH_S) >= EPOCH_OVERLAP_S && epoch_at(t) > 1) send_ab(k, &ab, T_ASSIGN, 0, 1); else return; break;
  case 9: send_ab(k, &ab, T_DESC, 0, 0); break;
  }
  TLOG("SEC_TX", "tid=%u,name=%s,cc=%u,b=%u", (unsigned)(tid + 1), test_name[tid], k, ab.batch);
}

/* ---------------- standby: probe and RPL-root takeover ---------------- */
static void
echo_reply(uip_ipaddr_t *src, uint8_t ttl, uint8_t *data, uint16_t datalen)
{
  if(addr_node(src) == TT_ER && probing) probe_reply = 1;
}
static void
probe(void)
{
  uip_ipaddr_t a; node_addr(TT_ER, &a);
  uip_icmp6_send(&a, ICMP6_ECHO_REQUEST, 0, 4);
}
static void
rpl_takeover(void)
{
  rpl_instance_t *in = rpl_get_default_instance();
  rpl_dag_t *d = in ? in->current_dag : NULL;
  if(!d) { TLOG("RPL_TAKEOVER", "ok=0"); return; }
  if(d->preferred_parent) { nbr_table_unlock(rpl_parents, d->preferred_parent); d->preferred_parent = NULL; }   /* as rpl_set_root() does */
  {                                                     /* a root has no parents: drop them so that no parent event re-ranks it */
    rpl_parent_t *p = nbr_table_head(rpl_parents), *nx;
    while(p) { nx = nbr_table_next(rpl_parents, p); if(p->dag == d) rpl_remove_parent(p); p = nx; }
  }
  if(in->def_route) { uip_ds6_defrt_rm(in->def_route); in->def_route = NULL; }
  d->rank = ROOT_RANK(in); d->min_rank = d->rank;
  d->grounded = 1; d->preference = RPL_PREFERENCE;
  RPL_LOLLIPOP_INCREMENT(d->version);
  RPL_LOLLIPOP_INCREMENT(in->dtsn_out);
  in->of->update_metric_container(in);
  rpl_reset_dio_timer(in);
  rpl_took = 1; next_rep = now_s() + 60; n_rep = 0;
  TLOG("RPL_TAKEOVER", "ok=1,ver=%u,rank=%u", d->version, d->rank);
}

PROCESS_THREAD(er_process, ev, data)
{
  static struct etimer tick;
  static uint32_t next_cnt, last_s;
  int i;
  PROCESS_BEGIN();
  if(node_id == TT_ER) NETSTACK_ROUTING.root_start();
  trace_common_init();
  PROCESS_WAIT_EVENT_UNTIL(ev == g_cfg_event);
  P = g_pol ? &tr_calibrated : &tr_published;
  simple_udp_register(&econn, PORT_ER, NULL, PORT_ER, erx);
  for(i = 0; i < TT_NCC; i++) pctx_init(&ccctx[i], (uint8_t)node_id, (uint8_t)(TT_FIRST_CC + i));
  pctx_init(&pctx_peer, (uint8_t)node_id, node_id == TT_ER ? TT_STANDBY : TT_ER);
  uip_icmp6_echo_reply_callback_add(&echo_n, echo_reply);
  if(node_id == TT_ER) schedules_log();
  last_hb = WARMUP_S;
  next_cnt = 1800; last_s = 0;
  etimer_set(&tick, CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&tick));
    etimer_reset(&tick);
    {
      uint32_t t = now_s();
      if(t == last_s) continue;
      last_s = t;
      if(node_id == TT_ER && !failed && er_node_failed(TT_ER, t)) { failed = 1; TLOG("ER_FAIL", "mode=node"); }
      if(failed) continue;
      if(t % 60 == (uint32_t)(node_id % 60)) log_routing();
      if(node_id == TT_ER) {
        if(t >= WARMUP_S && t % CYCLE_S == 12 && !er_down(TT_ER, t)) {     /* heartbeat to the standby */
          uip_ipaddr_t a; uint8_t hb[4] = { (uint8_t)(t >> 24), (uint8_t)(t >> 16), (uint8_t)(t >> 8), (uint8_t)t };
          int m = pctx_protect(&pctx_peer, T_HB, t, hb, 4, buf);
          node_addr(TT_STANDBY, &a); count_tx(TC_CTL, (uint16_t)m);
          simple_udp_sendto_port(&econn, buf, (uint16_t)m, &a, PORT_ER);
        }
        sectest(t);
        if(held_n && t >= held_until) {
          uip_ipaddr_t a; node_addr(held_cc, &a); count_tx(TC_ASSIGN, (uint16_t)held_n);
          simple_udp_sendto_port(&econn, held, (uint16_t)held_n, &a, PORT_ER); held_n = 0;
        }
      } else if(g_standby && !rpl_took && t > 600) {                     /* standby: watch the primary */
        if(!probing && t - last_hb > HB_SILENCE_S) {
          probing = 1; probe_reply = 0; probe_t0 = t;
          TLOG("ER_SILENT", "since=%lu", (unsigned long)last_hb);
          probe();
        } else if(probing) {
          if(probe_reply) { probing = 0; last_hb = t; TLOG("PROBE", "reply=1"); }                /* node alive: service failure */
          else if(t - probe_t0 >= 10) { probing = 0; TLOG("PROBE", "reply=0"); rpl_takeover(); }   /* node failure */
          else if((t - probe_t0) % 3 == 0) probe();
        }
      }
      if(rpl_took && n_rep < 10 && t >= next_rep) {   /* global repair (RFC 6550 8.2.2.1) once a minute for ten minutes */
        rpl_instance_t *in = rpl_get_default_instance();
        if(in) rpl_repair_root(in->instance_id);
        n_rep++; next_rep = t + 60;
        TLOG("GREPAIR", "k=%u,ver=%u", n_rep, in && in->current_dag ? in->current_dag->version : 0);
      }
      if(t >= next_cnt) {
        log_counters();
        TLOG("ERSTAT", "batches=%lu,desc=%lu,rej=%lu,rpl=%u", (unsigned long)n_batch, (unsigned long)n_desc, (unsigned long)n_rej, rpl_took);
        next_cnt += 1800;
      }
    }
  }
  PROCESS_END();
}
