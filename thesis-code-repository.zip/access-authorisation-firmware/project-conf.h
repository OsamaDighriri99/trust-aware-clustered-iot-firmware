/* TRACE unified build -- Contiki-NG 5.1 project configuration (Cooja native motes). Recorded in the run manifests.
 * Routing as in OSCORE-IoT and TARP-OSCORE: RPL classic in storing mode. */
#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_
#define RPL_CONF_MOP                        RPL_MOP_STORING_NO_MULTICAST
/* storing mode: a neighbour entry per child; the densest node of the layout has 78 radio neighbours */
#define NBR_TABLE_CONF_MAX_NEIGHBORS        80
#define NETSTACK_MAX_ROUTE_ENTRIES          128
#define RPL_CONF_WITH_DAO_ACK               0
#define RPL_MRHOF_CONF_MAX_LINK_METRIC      2048
#define UIP_CONF_BUFFER_SIZE                400   /* descriptor batches (about 200 B payload) plus IPv6 and RPL headers */
#define QUEUEBUF_CONF_NUM                   16
#define UIP_CONF_TCP                        0
#define UIP_CONF_UDP_CONNS                  6
#define SERIAL_LINE_CONF_BUFSIZE            128
#define LOG_CONF_LEVEL_RPL                  LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_TCPIP                LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_IPV6                 LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_6LOWPAN              LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_MAC                  LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_FRAMER               LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_MAIN                 LOG_LEVEL_WARN
#endif
