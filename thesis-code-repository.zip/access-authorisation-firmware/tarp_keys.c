/* TARP-OSCORE v3.1 -- pairwise root material, epoch-bound derivations and wire format.
 * Pure C99 (no Contiki): shared by the Cooja firmware and the MSP430 (Z1) benchmark. */
#include "tarp_keys.h"
#include <string.h>

/* fixed simulation secret (recorded in the manifest); stands for per-pair root material from EDHOC */
static const uint8_t g_master[16] = { 'T','A','R','P','-','T','N','S','M','-','2','0','2','6',0,1 };
const uint8_t g_master_salt[8] = { 0x9e, 0x7c, 0xa9, 0x22, 0x23, 0x78, 0x63, 0x40 };

/* ---------------- keys ---------------- */
void
pair_root(uint8_t coord, uint8_t client, uint16_t reest_no, uint8_t ms[16])
{
  uint8_t info[11] = { 'T','A','R','P','-','M','S', 0, 0, 0, 0 }, t[32];
  info[7] = coord; info[8] = client; info[9] = (uint8_t)(reest_no >> 8); info[10] = (uint8_t)reest_no;
  tc_hmac_sha256(g_master, 16, info, 11, NULL, 0, NULL, 0, t);
  memcpy(ms, t, 16);
}
void
boot_keys(uint8_t coord, uint8_t client, int as_coord, tos_keys_t *k)
{
  uint8_t info[11] = { 'T','A','R','P','-','B','O','O','T', 0, 0 }, t[32];
  uint8_t idc[1] = { 0 }, ids[2];
  ids[0] = coord; ids[1] = client;     /* local copies: mspgcc 4.6.3 miscompiles &parameter (uninitialised r4) */
  info[9] = coord; info[10] = client;
  tc_hmac_sha256(g_master, 16, info, 11, NULL, 0, NULL, 0, t);
  if(as_coord) tos_derive(t, 16, g_master_salt, 8, idc, 1, &ids[0], 1, &ids[1], 1, k);
  else tos_derive(t, 16, g_master_salt, 8, idc, 1, &ids[1], 1, &ids[0], 1, k);
}
void
ratchet_ms(const uint8_t ms_prev[16], uint16_t e, uint8_t ms_out[16])
{
  static const uint8_t info[12] = { 'T','A','R','P',' ','r','a','t','c','h','e','t' };
  uint8_t salt[2]; salt[0] = (uint8_t)(e >> 8); salt[1] = (uint8_t)e;
  tc_hkdf(salt, 2, ms_prev, 16, info, 12, ms_out, 16);
}
void
epoch_keys(const uint8_t ms[16], uint16_t e, uint8_t coord, uint8_t client, int as_coord, tos_keys_t *k)
{
  uint8_t idc[2], ids[2]; idc[0] = (uint8_t)(e >> 8); idc[1] = (uint8_t)e;    /* IDContext_e = Encode16(e) */
  ids[0] = coord; ids[1] = client;
  if(as_coord) tos_derive(ms, 16, g_master_salt, 8, idc, 2, &ids[0], 1, &ids[1], 1, k);
  else tos_derive(ms, 16, g_master_salt, 8, idc, 2, &ids[1], 1, &ids[0], 1, k);
}
void
kudos_update(const uint8_t ms_old[16], const uint8_t n1[8], const uint8_t n2[8], uint8_t ms_new[16])
{
  /* updateCtx (draft-ietf-core-oscore-key-update): MS_new = HKDF-Expand(MS_old, info("key update", X_N), 16) */
  uint8_t info[40], n = 0, prk[32];
  memcpy(info, "key update", 10); n = 10;
  info[n++] = 0x41; info[n++] = 0x07;          /* X1 = nonce length - 1 */
  info[n++] = 0x48; memcpy(info + n, n1, 8); n += 8;
  info[n++] = 0x41; info[n++] = 0x07;          /* X2 */
  info[n++] = 0x48; memcpy(info + n, n2, 8); n += 8;
  memcpy(prk, ms_old, 16); memset(prk + 16, 0, 16);
  tc_hkdf_expand(prk, info, n, ms_new, 16);
}
void
kudos_keys(const uint8_t ms[16], const uint8_t n1[8], const uint8_t n2[8], uint8_t coord, uint8_t client, int as_coord, tos_keys_t *k)
{
  uint8_t salt[16], ids[2]; memcpy(salt, n1, 8); memcpy(salt + 8, n2, 8);   /* new Master Salt = N1 | N2 */
  ids[0] = coord; ids[1] = client;
  if(as_coord) tos_derive(ms, 16, salt, 16, NULL, 0, &ids[0], 1, &ids[1], 1, k);
  else tos_derive(ms, 16, salt, 16, NULL, 0, &ids[1], 1, &ids[0], 1, k);
}

/* ---------------- wire format ---------------- */
static int has_nonce(uint8_t t) { return t == T_KREQ || t == T_KRESP; }
int
msg_build(uint8_t type, uint16_t epoch, const tos_keys_t *k, uint32_t seq, const uint8_t *nonce8,
          const uint8_t *pt, uint16_t len, uint8_t *out)
{
  uint8_t h = 0, piv[5], pl;
  out[h++] = type; out[h++] = 0;
  out[h++] = (uint8_t)(epoch >> 8); out[h++] = (uint8_t)epoch;
  pl = tos_piv_enc(seq, piv);
  out[h++] = pl; memcpy(out + h, piv, pl); h += pl;
  if(has_nonce(type)) { memcpy(out + h, nonce8, 8); h += 8; }
  tos_protect(k, seq, out, h, pt, len, out + h);
  return h + len + TOS_TAG;
}
int
msg_parse(const uint8_t *in, uint16_t len, msg_view_t *v)
{
  uint8_t h = 5, pl, i;
  if(len < 5 + 1 + TOS_TAG) return -1;
  v->type = in[0]; v->flags = in[1]; v->epoch = (uint16_t)((in[2] << 8) | in[3]);
  pl = in[4]; if(pl < 1 || pl > 4) return -1;
  v->piv = 0; for(i = 0; i < pl; i++) v->piv = (v->piv << 8) | in[h + i];
  h += pl;
  v->nonce8 = NULL;
  if(has_nonce(v->type)) { v->nonce8 = in + h; h += 8; }
  if(len < h + TOS_TAG) return -1;
  memcpy(v->hdr, in, h); v->hdr_len = h;
  v->ct = in + h; v->clen = (uint16_t)(len - h);
  return 0;
}
int
msg_open(const msg_view_t *v, const tos_keys_t *k, uint8_t *pt)
{
  if(tos_unprotect(k, v->piv, v->hdr, v->hdr_len, v->ct, v->clen, pt) != 0) return -1;
  return v->clen - TOS_TAG;
}

