/* TRACE revision build -- protected authorization path. See trace_proto.h. */
#include "trace_proto.h"
#include <string.h>

const char *const rx_name[8] = { "ok", "parse", "epoch", "auth", "replay", "bind", "stale", "type" };

void pctx_init(pctx_t *c, uint8_t me, uint8_t peer) { memset(c, 0, sizeof *c); c->me = me; c->peer = peer; }

static const tos_keys_t *
keys_for(pctx_t *c, uint16_t e, int *slot)
{
  int i;
  for(i = 0; i < 2; i++) if(c->e_cached[i] == e) { *slot = i; return &c->k[i]; }
  i = (c->e_cached[0] == 0 || c->e_cached[0] < c->e_cached[1]) ? 0 : 1;      /* replace the older epoch */
  ctx_keys(c->me, c->peer, e, &c->k[i]); c->e_cached[i] = e;
  *slot = i;
  return &c->k[i];
}

int
pctx_protect(pctx_t *c, uint8_t type, uint32_t t, const uint8_t *pt, uint16_t len, uint8_t *out)
{
  int s; uint16_t e = epoch_at(t);
  const tos_keys_t *k = keys_for(c, e, &s);
  if(c->seq_e != e) { c->seq_e = e; c->seq = 0; }
  return tk_build(type, e, k, c->seq++, pt, len, out);
}

int
pctx_open(pctx_t *c, uint8_t type, uint32_t t, const uint8_t *in, uint16_t len, uint8_t *pt, int *plen)
{
  tk_view_t v; int s, r; const tos_keys_t *k; tos_replay_t *w;
  if(tk_parse(in, len, &v) < 0) return RX_PARSE;
  if(v.type != type) return RX_TYPE;
  if(!epoch_accept(v.epoch, t)) return RX_EPOCH;
  k = keys_for(c, v.epoch, &s);
  if((r = tk_open(&v, k, pt)) < 0) return RX_AUTH;
  /* replay window of that epoch */
  if(c->rw_e[s] != v.epoch) { memset(&c->rw[s], 0, sizeof c->rw[s]); c->rw_e[s] = v.epoch; }
  w = &c->rw[s];
  if(!tos_replay_check(w, v.piv, 1)) return RX_REPLAY;
  tos_replay_check(w, v.piv, 0);                                     /* commit only for an accepted object */
  *plen = r;
  return RX_OK;
}

static void put16(uint8_t *p, uint16_t x) { p[0] = (uint8_t)(x >> 8); p[1] = (uint8_t)x; }
static uint16_t get16(const uint8_t *p) { return (uint16_t)((p[0] << 8) | p[1]); }

int
db_encode(const db_t *b, uint8_t *out)
{
  int n = 0, i, j;
  out[n++] = b->cc; put16(out + n, b->batch); n += 2; put16(out + n, (uint16_t)b->ref); n += 2; out[n++] = b->n;
  for(i = 0; i < b->n; i++) {
    out[n++] = b->e[i].slot; out[n++] = b->e[i].flags;
    for(j = 0; j < 8; j++) { put16(out + n, (uint16_t)b->e[i].d.q[j]); n += 2; }
  }
  return n;
}
int
db_decode(const uint8_t *in, int len, db_t *b)
{
  int n = 6, i, j;
  if(len < 6) return -1;
  b->cc = in[0]; b->batch = get16(in + 1); b->ref = (int16_t)get16(in + 3); b->n = in[5];
  if(b->n > DB_MAX || len < 6 + 18 * b->n) return -1;
  for(i = 0; i < b->n; i++) {
    b->e[i].slot = in[n++]; b->e[i].flags = in[n++];
    for(j = 0; j < 8; j++) { b->e[i].d.q[j] = (int16_t)get16(in + n); n += 2; }
  }
  return 0;
}
int
ab_encode(const ab_t *b, uint8_t *out)
{
  int n = 0, i;
  out[n++] = b->cc; put16(out + n, b->batch); n += 2; out[n++] = b->model; out[n++] = b->lease; out[n++] = b->n;
  for(i = 0; i < b->n; i++) { out[n++] = b->e[i].slot; out[n++] = b->e[i].state; out[n++] = b->e[i].v1; out[n++] = b->e[i].v2; }
  return n;
}
int
ab_decode(const uint8_t *in, int len, ab_t *b)
{
  int n = 6, i;
  if(len < 6) return -1;
  b->cc = in[0]; b->batch = get16(in + 1); b->model = in[3]; b->lease = in[4]; b->n = in[5];
  if(b->n > DB_MAX || len < 6 + 4 * b->n) return -1;
  for(i = 0; i < b->n; i++) { b->e[i].slot = in[n++]; b->e[i].state = in[n++]; b->e[i].v1 = in[n++]; b->e[i].v2 = in[n++]; }
  return 0;
}
int
ab_check(const ab_t *b, uint8_t me, uint16_t last)
{
  int i;
  if(b->cc != me) return RX_BIND;
  if((uint16_t)(last - b->batch) > 1) return RX_STALE;               /* only the latest or the previous batch */
  for(i = 0; i < b->n; i++) if(b->e[i].slot >= DB_MAX || b->e[i].state > 3) return RX_PARSE;
  return RX_OK;
}
