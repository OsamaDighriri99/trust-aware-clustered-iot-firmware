/* TARP-OSCORE v3.1 -- pairwise root material, epoch-bound derivations and wire format (pure C99). */
#ifndef TARP_KEYS_H_
#define TARP_KEYS_H_
#include <stdint.h>
#include "tarp_crypto.h"
#include "tarp_oscore.h"

#define T_DATA     'D'   /* client -> coordinator report */
#define T_DACK     'd'   /* coordinator -> client */
#define T_INIT     'I'   /* C2 */
#define T_ACK      'A'
#define T_CONFIRM  'C'
#define T_ABORT    'X'
#define T_KREQ     'K'   /* KUDOS request #1 (N1 in outer header) */
#define T_KRESP    'k'   /* KUDOS response (N2 in outer header) */
#define T_REFRESH  'F'   /* Static */
#define T_RE1      '1'   /* re-establishment (models an EDHOC exchange: 37 / 45 / 19 B payloads) */
#define T_RE2      '2'
#define T_RE3      '3'
#define T_ERCMD    'E'   /* edge root -> coordinator: compromise notice for a client */
#define T_REQRE    'R'   /* coordinator -> edge root: re-establishment request (escalation) */
#define IS_CTL(t)  ((t) == T_INIT || (t) == T_ACK || (t) == T_CONFIRM || (t) == T_ABORT || (t) == T_KREQ || (t) == T_KRESP || (t) == T_REFRESH)
#define IS_RE(t)   ((t) == T_RE1 || (t) == T_RE2 || (t) == T_RE3)

extern const uint8_t g_master_salt[8];
void pair_root(uint8_t coord, uint8_t client, uint16_t reest_no, uint8_t ms[16]);
void boot_keys(uint8_t coord, uint8_t client, int as_coord, tos_keys_t *k);
/* epoch-bound derivation: ratchet (C2: MS_e = HKDF(Enc16(e), MS_{e-1}, "TARP ratchet")) or root-based (Static) */
void ratchet_ms(const uint8_t ms_prev[16], uint16_t e, uint8_t ms_out[16]);
void epoch_keys(const uint8_t ms[16], uint16_t e, uint8_t coord, uint8_t client, int as_coord, tos_keys_t *k);
void kudos_update(const uint8_t ms_old[16], const uint8_t n1[8], const uint8_t n2[8], uint8_t ms_new[16]);
void kudos_keys(const uint8_t ms[16], const uint8_t n1[8], const uint8_t n2[8], uint8_t coord, uint8_t client, int as_coord, tos_keys_t *k);

int  msg_build(uint8_t type, uint16_t epoch, const tos_keys_t *k, uint32_t seq, const uint8_t *nonce8,
               const uint8_t *pt, uint16_t len, uint8_t *out);
typedef struct { uint8_t type, flags; uint16_t epoch; uint32_t piv; const uint8_t *nonce8; const uint8_t *ct; uint16_t clen;
                 uint8_t hdr[16]; uint8_t hdr_len; } msg_view_t;
int  msg_parse(const uint8_t *in, uint16_t len, msg_view_t *v);
int  msg_open(const msg_view_t *v, const tos_keys_t *k, uint8_t *pt);   /* returns pt length or -1 */
#endif
