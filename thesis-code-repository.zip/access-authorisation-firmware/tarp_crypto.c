/*
 * TARP-OSCORE v3.1 -- cryptographic primitives.
 * AES-128 (FIPS-197) block encryption, SHA-256 and HMAC-SHA256 are copied unchanged from the
 * KAT-tested C2-C4 validation packages (tc_crypto.c; AES S-box and key schedule originally from the
 * author's oscore_crypto.h). New here: HKDF-SHA256 (RFC 5869) and AES-CCM (RFC 3610) with the
 * COSE AES-CCM-16-64-128 parameters used by OSCORE (L = 2, M = 8, 13-byte nonce).
 * Plain C99, no Contiki dependency: compiled into the Cooja firmware, the host KATs and the MSP430 bench.
 */
#include "tarp_crypto.h"
#include <string.h>

/* Forward S-box copied verbatim from oscore_crypto.h (uploaded online_contiki). */
static const uint8_t tc_sbox[256] = {
  0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
  0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
  0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
  0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
  0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
  0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
  0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
  0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
  0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
  0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
  0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
  0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
  0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
  0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
  0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
  0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
};
static const uint8_t tc_rcon[11] = {
  0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36
};

#define XT(x) ((uint8_t)(((x) << 1) ^ ((((x) >> 7) & 1) * 0x1b)))

/* Key expansion: taken from oscore_crypto.h aes128_expand_key(). */
void
tc_aes_setkey(tc_aes_ctx_t *ctx, const uint8_t key[16])
{
  uint16_t i, j;
  uint8_t *rk = ctx->rk;
  memcpy(rk, key, 16);
  for(i = 1; i <= 10; i++) {
    uint8_t temp[4];
    uint8_t t;
    memcpy(temp, &rk[(i - 1) * 16 + 12], 4);
    t = temp[0];
    temp[0] = tc_sbox[temp[1]] ^ tc_rcon[i];
    temp[1] = tc_sbox[temp[2]];
    temp[2] = tc_sbox[temp[3]];
    temp[3] = tc_sbox[t];
    for(j = 0; j < 16; j++) {
      rk[i * 16 + j] = rk[(i - 1) * 16 + j] ^ ((j < 4) ? temp[j] : rk[i * 16 + j - 4]);
    }
  }
}

/* Block encryption: taken from oscore_crypto.h aes128_encrypt_block()
 * (state stored column-major: blk[c*4 + r]). */
void
tc_aes_encrypt_block(const tc_aes_ctx_t *ctx, uint8_t *blk)
{
  uint8_t i, t, round, c;
  const uint8_t *rk = ctx->rk;
  for(i = 0; i < 16; i++) blk[i] ^= rk[i];
  for(round = 1; round <= 10; round++) {
    for(i = 0; i < 16; i++) blk[i] = tc_sbox[blk[i]];
    t = blk[1]; blk[1] = blk[5]; blk[5] = blk[9]; blk[9] = blk[13]; blk[13] = t;
    t = blk[2]; blk[2] = blk[10]; blk[10] = t; t = blk[6]; blk[6] = blk[14]; blk[14] = t;
    t = blk[15]; blk[15] = blk[11]; blk[11] = blk[7]; blk[7] = blk[3]; blk[3] = t;
    if(round < 10) {
      for(c = 0; c < 4; c++) {
        uint8_t *col = &blk[c * 4];
        uint8_t a0 = col[0], a1 = col[1], a2 = col[2], a3 = col[3];
        uint8_t x = a0 ^ a1 ^ a2 ^ a3;
        col[0] ^= XT(a0 ^ a1) ^ x;
        col[1] ^= XT(a1 ^ a2) ^ x;
        col[2] ^= XT(a2 ^ a3) ^ x;
        col[3] ^= XT(a3 ^ a0) ^ x;
      }
    }
    for(i = 0; i < 16; i++) blk[i] ^= rk[round * 16 + i];
  }
}

/* ---------------- SHA-256 (constants from oscore_crypto.h) ---------------- */
static const uint32_t tc_sha_k[64] = {
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};
#define ROTR(x,n)  (((x) >> (n)) | ((x) << (32 - (n))))
#define CH(x,y,z)  (((x) & (y)) ^ ((~(x)) & (z)))
#define MAJ(x,y,z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define EP0(x)  (ROTR(x,2) ^ ROTR(x,13) ^ ROTR(x,22))
#define EP1(x)  (ROTR(x,6) ^ ROTR(x,11) ^ ROTR(x,25))
#define SIG0(x) (ROTR(x,7) ^ ROTR(x,18) ^ ((x) >> 3))
#define SIG1(x) (ROTR(x,17) ^ ROTR(x,19) ^ ((x) >> 10))

static void
sha_block(tc_sha256_ctx_t *c, const uint8_t *p)
{
  uint32_t w[16];
  uint32_t a, b, cc, d, e, f, g, h, t1, t2;
  uint8_t i;
  for(i = 0; i < 16; i++) {
    w[i] = ((uint32_t)p[i * 4] << 24) | ((uint32_t)p[i * 4 + 1] << 16) |
           ((uint32_t)p[i * 4 + 2] << 8) | (uint32_t)p[i * 4 + 3];
  }
  a = c->h[0]; b = c->h[1]; cc = c->h[2]; d = c->h[3];
  e = c->h[4]; f = c->h[5]; g = c->h[6]; h = c->h[7];
  for(i = 0; i < 64; i++) {
    uint32_t wi;
    if(i < 16) {
      wi = w[i];
    } else {
      /* rolling 16-word message schedule (saves 192 B of stack on MSP430) */
      wi = SIG1(w[(i - 2) & 15]) + w[(i - 7) & 15] + SIG0(w[(i - 15) & 15]) + w[i & 15];
      w[i & 15] = wi;
    }
    t1 = h + EP1(e) + CH(e, f, g) + tc_sha_k[i] + wi;
    t2 = EP0(a) + MAJ(a, b, cc);
    h = g; g = f; f = e; e = d + t1; d = cc; cc = b; b = a; a = t1 + t2;
  }
  c->h[0] += a; c->h[1] += b; c->h[2] += cc; c->h[3] += d;
  c->h[4] += e; c->h[5] += f; c->h[6] += g; c->h[7] += h;
}

void
tc_sha256_init(tc_sha256_ctx_t *c)
{
  c->h[0] = 0x6a09e667; c->h[1] = 0xbb67ae85; c->h[2] = 0x3c6ef372; c->h[3] = 0xa54ff53a;
  c->h[4] = 0x510e527f; c->h[5] = 0x9b05688c; c->h[6] = 0x1f83d9ab; c->h[7] = 0x5be0cd19;
  c->buf_len = 0;
  c->total_lo = 0;
}

void
tc_sha256_update(tc_sha256_ctx_t *c, const uint8_t *d, uint16_t n)
{
  c->total_lo += n;
  while(n > 0) {
    uint8_t take = (uint8_t)((64 - c->buf_len) < n ? (64 - c->buf_len) : n);
    memcpy(c->buf + c->buf_len, d, take);
    c->buf_len += take;
    d += take;
    n -= take;
    if(c->buf_len == 64) {
      sha_block(c, c->buf);
      c->buf_len = 0;
    }
  }
}

void
tc_sha256_final(tc_sha256_ctx_t *c, uint8_t out[32])
{
  uint32_t bits_lo = c->total_lo << 3;
  uint32_t bits_hi = c->total_lo >> 29;
  uint8_t i;
  c->buf[c->buf_len++] = 0x80;
  if(c->buf_len > 56) {
    memset(c->buf + c->buf_len, 0, 64 - c->buf_len);
    sha_block(c, c->buf);
    c->buf_len = 0;
  }
  memset(c->buf + c->buf_len, 0, 56 - c->buf_len);
  c->buf[56] = (uint8_t)(bits_hi >> 24); c->buf[57] = (uint8_t)(bits_hi >> 16);
  c->buf[58] = (uint8_t)(bits_hi >> 8);  c->buf[59] = (uint8_t)bits_hi;
  c->buf[60] = (uint8_t)(bits_lo >> 24); c->buf[61] = (uint8_t)(bits_lo >> 16);
  c->buf[62] = (uint8_t)(bits_lo >> 8);  c->buf[63] = (uint8_t)bits_lo;
  sha_block(c, c->buf);
  for(i = 0; i < 8; i++) {
    out[i * 4] = (uint8_t)(c->h[i] >> 24);
    out[i * 4 + 1] = (uint8_t)(c->h[i] >> 16);
    out[i * 4 + 2] = (uint8_t)(c->h[i] >> 8);
    out[i * 4 + 3] = (uint8_t)(c->h[i]);
  }
}

void
tc_hmac_sha256(const uint8_t *key, uint8_t key_len,
               const uint8_t *m1, uint16_t n1,
               const uint8_t *m2, uint16_t n2,
               const uint8_t *m3, uint16_t n3,
               uint8_t out[32])
{
  static tc_sha256_ctx_t c;   /* static: keeps MSP430 stack small */
  uint8_t kpad[64];
  uint8_t ih[32];
  uint8_t i;
  memset(kpad, 0, 64);
  if(key_len > 64) {
    tc_sha256_init(&c); tc_sha256_update(&c, key, key_len); tc_sha256_final(&c, kpad);
  } else {
    memcpy(kpad, key, key_len);
  }
  for(i = 0; i < 64; i++) kpad[i] ^= 0x36;
  tc_sha256_init(&c);
  tc_sha256_update(&c, kpad, 64);
  if(m1 && n1) tc_sha256_update(&c, m1, n1);
  if(m2 && n2) tc_sha256_update(&c, m2, n2);
  if(m3 && n3) tc_sha256_update(&c, m3, n3);
  tc_sha256_final(&c, ih);
  for(i = 0; i < 64; i++) kpad[i] ^= (0x36 ^ 0x5c);
  tc_sha256_init(&c);
  tc_sha256_update(&c, kpad, 64);
  tc_sha256_update(&c, ih, 32);
  tc_sha256_final(&c, out);
}

/* ---------------- HKDF-SHA256 (RFC 5869) ---------------- */
void
tc_hkdf_extract(const uint8_t *salt, uint8_t salt_len, const uint8_t *ikm, uint8_t ikm_len, uint8_t prk[32])
{
  static const uint8_t zero[32] = { 0 };
  if(salt == NULL || salt_len == 0) { salt = zero; salt_len = 32; }
  tc_hmac_sha256(salt, salt_len, ikm, ikm_len, NULL, 0, NULL, 0, prk);
}

void
tc_hkdf_expand(const uint8_t prk[32], const uint8_t *info, uint16_t info_len, uint8_t *okm, uint8_t okm_len)
{
  uint8_t t[32], c = 1, done = 0, tl = 0;
  while(done < okm_len) {
    uint8_t n;
    tc_hmac_sha256(prk, 32, t, tl, info, info_len, &c, 1, t);
    tl = 32;
    n = (uint8_t)((okm_len - done) < 32 ? (okm_len - done) : 32);
    memcpy(okm + done, t, n);
    done += n; c++;
  }
}

void
tc_hkdf(const uint8_t *salt, uint8_t salt_len, const uint8_t *ikm, uint8_t ikm_len,
        const uint8_t *info, uint16_t info_len, uint8_t *okm, uint8_t okm_len)
{
  uint8_t prk[32];
  tc_hkdf_extract(salt, salt_len, ikm, ikm_len, prk);
  tc_hkdf_expand(prk, info, info_len, okm, okm_len);
}

/* ---------------- AES-CCM (RFC 3610), L = 2, M = 8 ---------------- */
static void
ccm_mac(const tc_aes_ctx_t *a, const uint8_t nonce[13], const uint8_t *aad, uint16_t aad_len,
        const uint8_t *pt, uint16_t len, uint8_t tag[16])
{
  uint8_t x[16];
  uint16_t i, n;
  /* B0: flags = Adata<<6 | ((M-2)/2)<<3 | (L-1) */
  x[0] = (uint8_t)((aad_len ? 0x40 : 0) | (((TC_CCM_TAG - 2) / 2) << 3) | (2 - 1));
  memcpy(x + 1, nonce, 13);
  x[14] = (uint8_t)(len >> 8); x[15] = (uint8_t)len;
  tc_aes_encrypt_block(a, x);
  if(aad_len) {
    /* l(a) < 2^16 - 2^8: two-byte length prefix */
    uint8_t blk[16]; uint16_t used = 2, j;
    memset(blk, 0, 16);
    blk[0] = (uint8_t)(aad_len >> 8); blk[1] = (uint8_t)aad_len;
    for(i = 0; i < aad_len; i++) {
      blk[used++] = aad[i];
      if(used == 16) { for(j = 0; j < 16; j++) x[j] ^= blk[j]; tc_aes_encrypt_block(a, x); memset(blk, 0, 16); used = 0; }
    }
    if(used) { for(j = 0; j < 16; j++) x[j] ^= blk[j]; tc_aes_encrypt_block(a, x); }
  }
  for(i = 0; i < len; i += 16) {
    uint16_t j;
    n = (uint16_t)((len - i) < 16 ? (len - i) : 16);
    for(j = 0; j < n; j++) x[j] ^= pt[i + j];
    tc_aes_encrypt_block(a, x);
  }
  memcpy(tag, x, 16);
}

static void
ccm_ctr(const tc_aes_ctx_t *a, const uint8_t nonce[13], uint16_t ctr, uint8_t s[16])
{
  s[0] = (uint8_t)(2 - 1);
  memcpy(s + 1, nonce, 13);
  s[14] = (uint8_t)(ctr >> 8); s[15] = (uint8_t)ctr;
  tc_aes_encrypt_block(a, s);
}

void
tc_ccm_encrypt(const uint8_t key[16], const uint8_t nonce[13], const uint8_t *aad, uint16_t aad_len,
               const uint8_t *pt, uint16_t len, uint8_t *out)
{
  static tc_aes_ctx_t a;
  uint8_t tag[16], s[16];
  uint16_t i, j, blkno = 1;
  tc_aes_setkey(&a, key);
  ccm_mac(&a, nonce, aad, aad_len, pt, len, tag);
  for(i = 0; i < len; i += 16, blkno++) {
    uint16_t n = (uint16_t)((len - i) < 16 ? (len - i) : 16);
    ccm_ctr(&a, nonce, blkno, s);
    for(j = 0; j < n; j++) out[i + j] = pt[i + j] ^ s[j];
  }
  ccm_ctr(&a, nonce, 0, s);
  for(j = 0; j < TC_CCM_TAG; j++) out[len + j] = tag[j] ^ s[j];
}

int
tc_ccm_decrypt(const uint8_t key[16], const uint8_t nonce[13], const uint8_t *aad, uint16_t aad_len,
               const uint8_t *ct, uint16_t clen, uint8_t *pt)
{
  static tc_aes_ctx_t a;
  uint8_t tag[16], s[16], d = 0;
  uint16_t i, j, blkno = 1, len;
  if(clen < TC_CCM_TAG) return -1;
  len = (uint16_t)(clen - TC_CCM_TAG);
  tc_aes_setkey(&a, key);
  for(i = 0; i < len; i += 16, blkno++) {
    uint16_t n = (uint16_t)((len - i) < 16 ? (len - i) : 16);
    ccm_ctr(&a, nonce, blkno, s);
    for(j = 0; j < n; j++) pt[i + j] = ct[i + j] ^ s[j];
  }
  ccm_mac(&a, nonce, aad, aad_len, pt, len, tag);
  ccm_ctr(&a, nonce, 0, s);
  for(j = 0; j < TC_CCM_TAG; j++) d |= (uint8_t)(ct[len + j] ^ tag[j] ^ s[j]);
  if(d) { memset(pt, 0, len); return -1; }
  return 0;
}
