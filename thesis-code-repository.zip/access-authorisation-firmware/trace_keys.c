/* TRACE revision build -- pairwise contexts and wire format. See trace_keys.h. */
#include "trace_keys.h"
#include <string.h>

/* fixed simulation secret (recorded in the manifest); experimental provisioning, as stated in the paper */
static const uint8_t tk_master[16] = { 'T','R','A','C','E','-','R','E','V','-','2','0','2','6',0,1 };
const uint8_t tk_master_salt[8] = { 0x54, 0x52, 0x41, 0x43, 0x45, 0x2d, 0x53, 0x31 };

void
tk_pair_root(uint8_t a, uint8_t b, uint8_t ms[16])
{
  uint8_t info[9] = { 'T','R','A','C','E','-','M','S', 0 }, ab[2], t[32];
  if(a > b) { uint8_t x = a; a = b; b = x; }
  ab[0] = a; ab[1] = b; (void)info[8];
  tc_hmac_sha256(tk_master, 16, info, 8, ab, 2, NULL, 0, t);
  memcpy(ms, t, 16);
}

void
ctx_keys(uint8_t me, uint8_t peer, uint16_t e, tos_keys_t *k)
{
  uint8_t ms[16], idc[2], s[1], r[1];
  tk_pair_root(me, peer, ms);
  idc[0] = (uint8_t)(e >> 8); idc[1] = (uint8_t)e;         /* ID Context = Encode16(epoch) */
  s[0] = me; r[0] = peer;                                   /* Sender ID = own node id, Recipient ID = peer's */
  tos_derive(ms, 16, tk_master_salt, 8, idc, 2, s, 1, r, 1, k);
}

uint16_t epoch_at(uint32_t t) { return (uint16_t)(1 + t / EPOCH_S); }

int
epoch_accept(uint16_t e_msg, uint32_t t)
{
  uint16_t e = epoch_at(t);
  if(e_msg == e) return 1;
  if(e_msg + 1 == e && (t % EPOCH_S) < EPOCH_OVERLAP_S) return 2;
  return 0;
}

int
tk_build(uint8_t type, uint16_t epoch, const tos_keys_t *k, uint32_t seq, const uint8_t *pt, uint16_t len, uint8_t *out)
{
  uint8_t h = 0, piv[5], pl;
  out[h++] = type; out[h++] = 0;
  out[h++] = (uint8_t)(epoch >> 8); out[h++] = (uint8_t)epoch;
  pl = tos_piv_enc(seq, piv);
  out[h++] = pl; memcpy(out + h, piv, pl); h += pl;
  tos_protect(k, seq, out, h, pt, len, out + h);          /* outer header bound into the AAD */
  return h + len + TOS_TAG;
}

int
tk_parse(const uint8_t *in, uint16_t len, tk_view_t *v)
{
  uint8_t h = 5, pl, i;
  if(len < 5 + 1 + TOS_TAG) return -1;
  v->type = in[0]; v->flags = in[1]; v->epoch = (uint16_t)((in[2] << 8) | in[3]);
  pl = in[4]; if(pl < 1 || pl > 4) return -1;
  v->piv = 0; for(i = 0; i < pl; i++) v->piv = (v->piv << 8) | in[h + i];
  h += pl;
  if(len < h + TOS_TAG) return -1;
  memcpy(v->hdr, in, h); v->hdr_len = h;
  v->ct = in + h; v->clen = (uint16_t)(len - h);
  return 0;
}

int
tk_open(const tk_view_t *v, const tos_keys_t *k, uint8_t *pt)
{
  if(tos_unprotect(k, v->piv, v->hdr, v->hdr_len, v->ct, v->clen, pt) != 0) return -1;
  return v->clen - TOS_TAG;
}
