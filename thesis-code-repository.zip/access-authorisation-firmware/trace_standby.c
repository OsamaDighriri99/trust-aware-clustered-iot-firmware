/* TRACE unified build -- standby edge root (node 112): identical code to the primary (trace_er.c). */
#include "trace_er.c"
