/*
 * TARP-OSCORE v3.1 -- trust evidence and lifecycle-request policy (C1, C3).
 * Pure C99 (no Contiki): the same code runs in the coordinator firmware, in host unit tests and is
 * mirrored line by line in scripts/policy.py for the trace-driven sensitivity analysis.
 *
 * Trust evidence (paper Sec. III-B), evaluated by the coordinator for each client
 * context every TP_CYCLE_S seconds:
 *   T_dev   Beta reputation of the client's observed behaviour (Josang-Ismail): s <- lambda*s + succ,
 *           f <- lambda*f + fail, T_dev = (s+1)/(s+f+2). succ = authenticated, fresh reports received;
 *           fail = missed report deadlines, AEAD/replay/epoch rejections, unanswered lifecycle messages.
 *   T_clust mean T_dev of the other clients of the same coordinator.
 *   T_net   path-quality score min(q(client first-hop ETX, reported), q(coordinator first-hop ETX)),
 *           q(x) = clamp((ETX_MAX - x)/(ETX_MAX - 1), 0, 1); with the cross-check enabled the reported part
 *           is capped by the observed delivery ratio s/(s+f).
 *   T_comp  w_d T_dev + w_c T_clust + w_n T_net.
 * C3 risk uses the trust deficit below the scaling reference: d = clamp((tau_s - ema)/(tau_s - tau_c), 0, 1).
 */
#ifndef TARP_POLICY_H_
#define TARP_POLICY_H_
#include <stdint.h>

#ifndef TP_WMAX
#define TP_WMAX 32
#endif

typedef struct {
  float wd, wc, wn;            /* trust weights */
  float lambda;                /* Beta forgetting factor per cycle */
  float etx_max;               /* ETX at which q() reaches 0 */
  float i_base, i_min, i_max;  /* C1 interval (s) */
  float tau_s, tau_m, tau_c;   /* scaling reference, marginal, critical */
  float alpha;                 /* EMA factor */
  uint8_t win;                 /* |W| samples */
  uint8_t k;                   /* projection horizon (samples) */
  float r_high, r_med;         /* risk thresholds */
  float delta_d, a_th;         /* slope / acceleration thresholds (per sample, per sample^2) */
  float w_r[4];                /* risk weights: deficit, slope, accel, variability */
  float t_refr;                /* refractory time after a request or commit (s) */
  float t_hold;                /* escalation: a second trust-driven request within t_hold of a committed one escalates (s) */
  uint8_t crosscheck;          /* cap reported T_net by observed delivery */
} tp_params_t;

extern const tp_params_t tp_default;

typedef struct {
  float s, f;                  /* Beta evidence */
  float tdev, tnet, tclust, tcomp;
  float ema, m, m_prev, a, sigma, pred, risk, deficit;
  float w[TP_WMAX];
  uint8_t widx, wcnt, ema_init;
} tp_state_t;

/* Request sources (logged) */
#define TP_REQ_NONE        0
#define TP_REQ_C1_SCHED    1
#define TP_REQ_C1_TRUST    2
#define TP_REQ_C1_CRIT     3
#define TP_REQ_C3_IMM      4
#define TP_REQ_C3_PRED     5
#define TP_REQ_C3_ACC      6
#define TP_REQ_ESCALATE    7    /* re-establishment instead of rekey */
#define TP_REQ_REACTIVE    8    /* baseline */
#define TP_REQ_STATIC      9    /* fixed schedule (baseline / E1) */
#define TP_REQ_ER         10    /* edge-root command */
extern const char *const tp_req_name[11];

void  tp_init(tp_state_t *st);
/* Beta update with this cycle's evidence; returns T_dev. */
float tp_evidence(const tp_params_t *p, tp_state_t *st, float succ, float fail);
float tp_q(const tp_params_t *p, float etx);
/* Composite trust from components (T_net already resolved by tp_tnet). */
float tp_tnet(const tp_params_t *p, const tp_state_t *st, float etx_client_reported, float etx_coord);
float tp_compose(const tp_params_t *p, tp_state_t *st, float tclust);
/* Temporal statistics on T_comp (window, EMA, OLS slope, acceleration, sigma, projection, risk). */
void  tp_c3_update(const tp_params_t *p, tp_state_t *st);
/* Decisions. since_rk: s since last committed transition; since_req: s since last request. */
int   tp_c3_decide(const tp_params_t *p, const tp_state_t *st, float since_req, float since_rk);
int   tp_c1_decide(const tp_params_t *p, const tp_state_t *st, float since_rk, float since_req);
/* 1 if the request source is trust-driven (C1 trust/critical, C3, reactive) */
int   tp_trust_driven(int src);
/* Escalation rule (full TARP): a trust-driven request issued less than t_hold after a committed trust-driven
 * transition, whose trust has not recovered, is converted into re-establishment (rekeying with the same root
 * cannot recover from compromise); at most one escalation per t_hold. */
int   tp_escalate(const tp_params_t *p, int src, float since_td_commit, float since_esc);
float tp_interval(const tp_params_t *p, float tcomp);
#endif
