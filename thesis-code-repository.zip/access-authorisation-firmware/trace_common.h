/*
 * TRACE unified build -- shared runtime: configuration over the Cooja serial line, logging, PRNG streams,
 * node addressing, behavioural condition schedules (S1-S8, edge-root outage and node failure), loss injection,
 * traffic counters, routing log. One firmware per role; condition, seed, policy, model, standby availability and
 * protected-path tests are selected at run time. Original topo112 numbering: node 1 edge root (RPL root), nodes 2-11
 * cluster centres, nodes 12-111 clients, node 112 standby edge root.
 */
#ifndef TRACE_COMMON_H_
#define TRACE_COMMON_H_
#include "contiki.h"
#include "net/ipv6/uip.h"
#include "net/ipv6/simple-udp.h"
#include "sys/node-id.h"
#include "trace_topology.h"
#include "trace_proto.h"
#include <stdio.h>
#include <stdint.h>

/* conditions */
#define SCN_NOM   0   /* nominal */
#define SCN_S1    1   /* gradual degradation: delivery and compliance -0.005 per cycle from onset (waves of 5 clients) */
#define SCN_S2    2   /* burst degradation: 40 % report loss for 3-5 cycles */
#define SCN_S3    3   /* traffic amplification: 3x report rate (rate violations count as non-compliance) */
#define SCN_S4    4   /* selective forwarding: 55 % of own reports dropped */
#define SCN_S5    5   /* coordinated degradation: 3 clients of one cluster, S1 dynamics */
#define SCN_S6    6   /* mobility (positions moved by the Cooja run script) */
#define SCN_S7    7   /* network-wide loss 5-35 %, piecewise constant per 30 min */
#define SCN_S8    8   /* workload variation: announced report-period changes and announced sleep */
#define SCN_OUT   9   /* primary-ER service outage 2-4 h with S1 waves (routing continues; standby takeover) */
#define SCN_NF   10   /* primary-ER node failure at 2 h with S1 waves (node leaves the network; standby takes over the
                         authorization service and the RPL root role) */
#define SCN_N    11
extern const char *const scn_name[SCN_N];

extern char     g_run_id[48];
extern uint8_t  g_scn, g_pol, g_model, g_dwell;
extern uint8_t  g_standby;   /* 1: the standby edge root serves (default); 0: no standby (F0) */
extern uint8_t  g_sectest;   /* 1: the primary edge root injects crafted assignment batches (protected-path tests) */
extern uint32_t g_seed, g_sim_end_s;
extern uint8_t  g_configured;
extern process_event_t g_cfg_event;
PROCESS_NAME(trace_cfg_process);
void trace_common_init(void);

uint64_t now_us(void);
static inline uint32_t now_s(void) { return (uint32_t)(now_us() / 1000000ULL); }
#define TLOG(ev, fmt, ...) printf(ev ",n=%u," fmt ",t=%lu\n", (unsigned)node_id, ##__VA_ARGS__, (unsigned long)(now_us() / 1000ULL))

void     rnd_init(void);
uint32_t rnd(void);
float    rndf(void);
void     rnd_bytes(uint8_t *b, uint16_t n);
void     node_addr(uint8_t id, uip_ipaddr_t *a);
uint8_t  addr_node(const uip_ipaddr_t *a);

/* ---------------- condition schedules (deterministic from the seed; identical on every node) ---------------- */
#define WAVE_N      13         /* S1/S5/OUT waves */
#define WAVE_CL     5          /* clients per wave (S5: 3, same cluster) */
#define WAVE_FIRST  3600
#define WAVE_GAP    2700       /* 45 min */
#define WAVE_LEN    1800       /* 30-min episode, then recovery */
#define DEG_RATE    0.005f     /* per 15-s cycle */
#define ADV_N       5          /* S3/S4 misbehaving clients */
#define ADV_START   3600
#define BURST_N     10         /* S2 clients */
#define MOB_N       10         /* S6 mobile clients (moved by the run script; logged here) */
#define SLEEP_N     20         /* S8 sleeping clients */
#define OUT_START   7200
#define OUT_END     14400
typedef struct { uint32_t onset; uint8_t n; uint8_t cl[WAVE_CL]; } wave_t;
extern wave_t   g_wave[WAVE_N];
extern uint8_t  g_adv[ADV_N];
extern uint8_t  g_burst_cl[BURST_N]; extern uint16_t g_burst_phase[BURST_N]; extern uint8_t g_burst_len[BURST_N];
extern uint8_t  g_sleep_cl[SLEEP_N]; extern uint16_t g_sleep_phase[SLEEP_N];
extern uint8_t  g_mob_cl[MOB_N];
extern uint16_t g_s7_loss[32];       /* permille per 30-min slot */
void schedules_build(void);
void schedules_log(void);

/* behaviour of client c at time t */
typedef struct { float deliver; float comply; uint8_t rate_mult; uint8_t in_episode; } beh_t;
void     behaviour(uint8_t c, uint32_t t, beh_t *b);
uint16_t s8_period(uint8_t c, uint32_t t);      /* announced report period (s) */
uint16_t s8_sleep_left(uint8_t c, uint32_t t);  /* >0: client announces sleep for this many seconds */
int      er_down(uint8_t er, uint32_t t);       /* ER application service unavailable */
int      er_node_failed(uint8_t er, uint32_t t); /* NF: the primary ER node has failed (silent; moved out of range) */
int      rx_drop(uint8_t from);                 /* receiver-side controlled loss (S7) */

#define PORT_CC     5801       /* client -> CC (TARP-OSCORE client contexts) */
#define PORT_CLIENT 5802
#define PORT_ER     5803
#define REPORT_PERIOD_S 30
#define CYCLE_S     15
#define WARMUP_S    300

enum { TC_APP, TC_DESC, TC_ASSIGN, TC_LIFE, TC_CTL, TC_N };   /* reports+acks, descriptor batches, assignment
                                                               batches, TARP-OSCORE lifecycle, ER heartbeats/tests */
extern uint32_t g_tx_pkts[TC_N], g_tx_bytes[TC_N];
void count_tx(uint8_t cls, uint16_t len);
void log_counters(void);
void log_routing(void);      /* RT line: DODAG version, rank and preferred parent (RPL classic, storing mode) */
#endif
