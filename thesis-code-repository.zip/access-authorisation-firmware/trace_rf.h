/* TRACE revision build -- Random-Forest evaluation in C (pure C99) on the quantised descriptor.
 * Models are exported from scikit-learn by scripts/export_rf.py (rf_model_cur.h: reproduces the current reference
 * state; rf_model_ant.h: predicts the most restrictive reference state over the next H cycles). sklearn's
 * "x <= threshold" on float thresholds equals "q <= floor(threshold)" on the integer features. */
#ifndef TRACE_RF_H_
#define TRACE_RF_H_
#include <stdint.h>
typedef struct {
  uint8_t n_trees; uint16_t n_nodes;
  const uint16_t *root;          /* first node of each tree */
  const int8_t *feat;            /* -1: leaf */
  const int16_t *thr;
  const uint16_t *left, *right;  /* absolute node indices */
  const uint8_t *leaf;           /* class at a leaf */
  const char *id;
} rf_model_t;
extern const rf_model_t rf_cur, rf_ant, rf_det;
extern const uint8_t rf_det_k;      /* detector: Restricted when at least rf_det_k trees vote for degradation (class 1) */
/* returns the plurality class (ties: the less privileged class), or -1 if the model is empty.
 * v1/v2: largest and second-largest vote counts. */
int rf_predict(const rf_model_t *m, const int16_t q[8], uint8_t *v1, uint8_t *v2);
/* number of trees voting for class c */
int rf_votes_for(const rf_model_t *m, const int16_t q[8], uint8_t c);
#endif
