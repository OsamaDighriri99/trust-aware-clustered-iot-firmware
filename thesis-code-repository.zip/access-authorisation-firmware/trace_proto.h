/* TRACE revision build -- protected CC<->ER authorization path (pure C99): pairwise context with scheduled
 * epochs, descriptor and assignment batches, and the receiver checks (epoch, AEAD, replay, binding, staleness)
 * that decide whether an object is accepted. Used by the firmware and by the receive-path tests. */
#ifndef TRACE_PROTO_H_
#define TRACE_PROTO_H_
#include <stdint.h>
#include "trace_keys.h"
#include "trace_policy.h"
#include "trace_rf.h"

typedef struct {
  uint8_t me, peer;
  uint16_t e_cached[2]; tos_keys_t k[2];   /* keys of two epochs (current and previous), derived on demand */
  tos_replay_t rw[2]; uint16_t rw_e[2];    /* replay state per accepted epoch */
  uint32_t seq; uint16_t seq_e;            /* sender sequence number (reset at each epoch) */
} pctx_t;
void pctx_init(pctx_t *c, uint8_t me, uint8_t peer);
/* protect pt for the peer at time t (current epoch) */
int  pctx_protect(pctx_t *c, uint8_t type, uint32_t t, const uint8_t *pt, uint16_t len, uint8_t *out);

/* receive result codes (logged) */
#define RX_OK          0
#define RX_PARSE       1
#define RX_EPOCH       2   /* epoch older than current-1 or outside the overlap */
#define RX_AUTH        3   /* AEAD tag mismatch */
#define RX_REPLAY      4   /* Partial IV already seen / too old */
#define RX_BIND        5   /* object names another CC */
#define RX_STALE       6   /* assignment answers a superseded descriptor batch */
#define RX_TYPE        7
extern const char *const rx_name[8];
/* verify and decrypt; replay state is committed only for an accepted object (Eq. 25) */
int  pctx_open(pctx_t *c, uint8_t type, uint32_t t, const uint8_t *in, uint16_t len, uint8_t *pt, int *plen);

/* descriptor batch (CC -> ER) */
#define DB_MAX 10
#define DF_FULL  1   /* window full: descriptor valid */
#define DF_SLEEP 2   /* client announced sleep: no observation this cycle */
typedef struct { uint8_t slot, flags; tr_desc_t d; } db_entry_t;
typedef struct { uint8_t cc; uint16_t batch; int16_t ref; uint8_t n; db_entry_t e[DB_MAX]; } db_t;   /* ref: cluster trust reference x1e4 */
int  db_encode(const db_t *b, uint8_t *out);
int  db_decode(const uint8_t *in, int len, db_t *b);
/* assignment batch (ER -> CC): echoes the descriptor batch number, carries the lease length in cycles */
typedef struct { uint8_t slot, state, v1, v2; } ab_entry_t;
typedef struct { uint8_t cc; uint16_t batch; uint8_t model, lease, n; ab_entry_t e[DB_MAX]; } ab_t;
int  ab_encode(const ab_t *b, uint8_t *out);
int  ab_decode(const uint8_t *in, int len, ab_t *b);
/* CC-side binding/staleness check of a decrypted assignment batch: me = this CC, last = last batch sent */
int  ab_check(const ab_t *b, uint8_t me, uint16_t last);
#endif
