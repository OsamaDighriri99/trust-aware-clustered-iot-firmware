/* TARP-OSCORE v3.1 -- OSCORE message protection (RFC 8613). See tarp_oscore.h. */
#include "tarp_oscore.h"
#include "tarp_crypto.h"
#include <string.h>

static uint8_t
cbor_bstr(uint8_t *o, const uint8_t *b, uint8_t n)
{
  uint8_t k = 0;
  if(n < 24) o[k++] = (uint8_t)(0x40 | n); else { o[k++] = 0x58; o[k++] = n; }
  if(n) memcpy(o + k, b, n);
  return (uint8_t)(k + n);
}

static void
derive_one(const uint8_t *ms, uint8_t ms_len, const uint8_t *salt, uint8_t salt_len,
           const uint8_t *id, uint8_t id_len, const uint8_t *idctx, uint8_t idctx_len,
           int is_iv, uint8_t *out, uint8_t L)
{
  uint8_t info[64], n = 0;
  info[n++] = 0x85;                                   /* array(5) */
  n += cbor_bstr(info + n, id, id_len);               /* id */
  if(idctx) n += cbor_bstr(info + n, idctx, idctx_len); else info[n++] = 0xf6;   /* id_context or nil */
  info[n++] = TOS_ALG;                                /* alg_aead = 10 */
  if(is_iv) { info[n++] = 0x62; info[n++] = 'I'; info[n++] = 'V'; }
  else { info[n++] = 0x63; info[n++] = 'K'; info[n++] = 'e'; info[n++] = 'y'; }
  info[n++] = L;                                      /* 16 or 13 (< 24: one byte) */
  tc_hkdf(salt, salt_len, ms, ms_len, info, n, out, L);
}

void
tos_derive(const uint8_t *ms, uint8_t ms_len, const uint8_t *salt, uint8_t salt_len,
           const uint8_t *idctx, uint8_t idctx_len,
           const uint8_t *sid, uint8_t sid_len, const uint8_t *rid, uint8_t rid_len, tos_keys_t *k)
{
  memcpy(k->sid, sid, sid_len); k->sid_len = sid_len;
  memcpy(k->rid, rid, rid_len); k->rid_len = rid_len;
  derive_one(ms, ms_len, salt, salt_len, sid, sid_len, idctx, idctx_len, 0, k->skey, TOS_KEY);
  derive_one(ms, ms_len, salt, salt_len, rid, rid_len, idctx, idctx_len, 0, k->rkey, TOS_KEY);
  derive_one(ms, ms_len, salt, salt_len, NULL, 0, idctx, idctx_len, 1, k->civ, TOS_IV);
}

uint8_t
tos_piv_enc(uint32_t piv, uint8_t out[5])
{
  uint8_t t[4], n = 0, i;
  t[0] = (uint8_t)(piv >> 24); t[1] = (uint8_t)(piv >> 16); t[2] = (uint8_t)(piv >> 8); t[3] = (uint8_t)piv;
  for(i = 0; i < 3 && t[i] == 0; i++) ;
  for(; i < 4; i++) out[n++] = t[i];
  return n;
}

void
tos_nonce(const uint8_t civ[TOS_IV], const uint8_t *id, uint8_t id_len, uint32_t piv, uint8_t nonce[TOS_IV])
{
  uint8_t i;
  memset(nonce, 0, TOS_IV);
  nonce[0] = id_len;                                  /* size of ID_PIV */
  memcpy(nonce + 1 + (TOS_IV - 6) - id_len, id, id_len);   /* ID_PIV left-padded to 7 bytes */
  nonce[8] = 0;                                       /* PIV left-padded to 5 bytes */
  nonce[9] = (uint8_t)(piv >> 24); nonce[10] = (uint8_t)(piv >> 16);
  nonce[11] = (uint8_t)(piv >> 8); nonce[12] = (uint8_t)piv;
  for(i = 0; i < TOS_IV; i++) nonce[i] ^= civ[i];
}

uint16_t
tos_aad(const uint8_t *kid, uint8_t kid_len, const uint8_t *piv, uint8_t piv_len,
        const uint8_t *opts, uint8_t opts_len, uint8_t *out)
{
  uint8_t arr[48], a = 0;
  uint16_t n = 0;
  arr[a++] = 0x85; arr[a++] = 0x01;                   /* [1, */
  arr[a++] = 0x81; arr[a++] = TOS_ALG;                /*  [10], */
  a += cbor_bstr(arr + a, kid, kid_len);              /*  request_kid, */
  a += cbor_bstr(arr + a, piv, piv_len);              /*  request_piv, */
  a += cbor_bstr(arr + a, opts, opts_len);            /*  options ] */
  out[n++] = 0x83;                                    /* ["Encrypt0", h'', external_aad] */
  out[n++] = 0x68; memcpy(out + n, "Encrypt0", 8); n += 8;
  out[n++] = 0x40;
  n += cbor_bstr(out + n, arr, a);
  return n;
}

void
tos_protect(const tos_keys_t *k, uint32_t seq, const uint8_t *opts, uint8_t opts_len,
            const uint8_t *pt, uint16_t len, uint8_t *out)
{
  uint8_t nonce[TOS_IV], piv[5], pl, aad[64];
  uint16_t al;
  pl = tos_piv_enc(seq, piv);
  tos_nonce(k->civ, k->sid, k->sid_len, seq, nonce);
  al = tos_aad(k->sid, k->sid_len, piv, pl, opts, opts_len, aad);
  tc_ccm_encrypt(k->skey, nonce, aad, al, pt, len, out);
}

int
tos_unprotect(const tos_keys_t *k, uint32_t piv_v, const uint8_t *opts, uint8_t opts_len,
              const uint8_t *ct, uint16_t clen, uint8_t *pt)
{
  uint8_t nonce[TOS_IV], piv[5], pl, aad[64];
  uint16_t al;
  pl = tos_piv_enc(piv_v, piv);
  tos_nonce(k->civ, k->rid, k->rid_len, piv_v, nonce);
  al = tos_aad(k->rid, k->rid_len, piv, pl, opts, opts_len, aad);
  return tc_ccm_decrypt(k->rkey, nonce, aad, al, ct, clen, pt);
}

int
tos_replay_check(tos_replay_t *w, uint32_t piv, int check_only)
{
  if(w->top == 0 || piv >= w->top) {
    if(!check_only) {
      uint32_t shift = (w->top == 0) ? 32 : (piv - w->top + 1);
      w->bitmap = (shift >= 32) ? 0 : (w->bitmap << shift);
      w->bitmap |= 1u;
      w->top = piv + 1;
    }
    return 1;
  }
  {
    uint32_t off = w->top - 1 - piv;
    if(off >= 32) return 0;
    if(w->bitmap & (1u << off)) return 0;
    if(!check_only) w->bitmap |= (1u << off);
    return 1;
  }
}
