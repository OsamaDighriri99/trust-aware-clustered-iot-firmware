/* TARP-OSCORE v3.1 -- trust evidence and C1/C3 policy. See tarp_policy.h. */
#include "tarp_policy.h"
#include <math.h>
#include <string.h>

/* Declared parameters (paper Table IV). Values marked (paper) are the initial-design values;
 * the others were calibrated or changed as described in paper Sec. V-B. */
const tp_params_t tp_default = {
  0.40f, 0.35f, 0.25f,          /* weights (paper) */
  0.95f,                        /* lambda: evidence half-life ~13.5 cycles = 3.4 min */
  4.0f,                         /* ETX_MAX (MRHOF default max usable link ETX) */
  600.0f, 30.0f, 631.6f,        /* I_base, I_min (paper); I_max = I_base/tau_s, the largest value Eq. 3 can reach */
  0.95f, 0.50f, 0.30f,          /* tau_s (calibrated: median compliant trust 0.926 -> 0.95, results/calibration.json); tau_m, tau_c (paper) */
  0.30f, 16, 5,                 /* alpha, |W|, k (paper) */
  0.26f, 0.23f,                 /* R_high, R_med (v3: calibrated with the weights and the adaptive reference, results/calibration_v3.json) */
  -0.03f, -0.005f,              /* delta_d (paper; no effect), a_th (v3 calibration) */
  { 0.60f, 0.20f, 0.00f, 0.20f },  /* risk weights deficit, slope, accel, sigma (v3: results/calibration_v3.json) */
  120.0f,                       /* refractory = T_overlap */
  600.0f,                       /* t_hold = I_base */
  1                             /* cross-check on */
};

const char *const tp_req_name[11] = { "none", "c1_sched", "c1_trust", "c1_crit", "c3_imm", "c3_pred", "c3_acc",
                                      "escalate", "reactive", "static", "er" };

static float clampf(float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }

void
tp_init(tp_state_t *st)
{
  memset(st, 0, sizeof(*st));
  st->tdev = st->tnet = st->tclust = st->tcomp = 1.0f;
}

float
tp_evidence(const tp_params_t *p, tp_state_t *st, float succ, float fail)
{
  st->s = p->lambda * st->s + succ;
  st->f = p->lambda * st->f + fail;
  st->tdev = (st->s + 1.0f) / (st->s + st->f + 2.0f);
  return st->tdev;
}

float
tp_q(const tp_params_t *p, float etx)
{
  return clampf((p->etx_max - etx) / (p->etx_max - 1.0f), 0.0f, 1.0f);
}

float
tp_tnet(const tp_params_t *p, const tp_state_t *st, float etx_client, float etx_coord)
{
  float qc = tp_q(p, etx_client), qo = tp_q(p, etx_coord);
  if(p->crosscheck) {
    float tot = st->s + st->f;
    float d = tot > 0.0f ? st->s / tot : 1.0f;
    if(qc > d) qc = d;
  }
  return qc < qo ? qc : qo;
}

float
tp_compose(const tp_params_t *p, tp_state_t *st, float tclust)
{
  st->tclust = tclust;
  st->tcomp = clampf(p->wd * st->tdev + p->wc * tclust + p->wn * st->tnet, 0.0f, 1.0f);
  return st->tcomp;
}

void
tp_c3_update(const tp_params_t *p, tp_state_t *st)
{
  uint8_t n, i;
  float sx = 0, sy = 0, sxx = 0, sxy = 0, mean, var = 0, k = (float)p->k;
  if(!st->ema_init) { st->ema = st->tcomp; st->ema_init = 1; }
  else st->ema = p->alpha * st->tcomp + (1.0f - p->alpha) * st->ema;
  st->w[st->widx] = st->tcomp;
  st->widx = (uint8_t)((st->widx + 1) % p->win);
  if(st->wcnt < p->win) st->wcnt++;
  n = st->wcnt;
  /* OLS slope over sample indices 0..n-1, oldest first */
  for(i = 0; i < n; i++) {
    uint8_t idx = (uint8_t)((st->widx + p->win - n + i) % p->win);
    float x = (float)i, y = st->w[idx];
    sx += x; sy += y; sxx += x * x; sxy += x * y;
  }
  st->m_prev = st->m;
  st->m = (n >= 4) ? (n * sxy - sx * sy) / (n * sxx - sx * sx) : 0.0f;
  st->a = (n >= 5) ? st->m - st->m_prev : 0.0f;
  mean = sy / n;
  for(i = 0; i < n; i++) { float d = st->w[i < n ? (uint8_t)((st->widx + p->win - n + i) % p->win) : 0] - mean; var += d * d; }
  st->sigma = sqrtf(var / n);
  st->pred = clampf(st->ema + st->m * k + 0.5f * st->a * k * k, 0.0f, 1.0f);
  st->deficit = clampf((p->tau_s - st->ema) / (p->tau_s - p->tau_c), 0.0f, 1.0f);
  st->risk = p->w_r[0] * st->deficit
           + p->w_r[1] * clampf(-10.0f * st->m, 0.0f, 1.0f)
           + p->w_r[2] * clampf(-20.0f * st->a, 0.0f, 1.0f)
           + p->w_r[3] * clampf(5.0f * st->sigma, 0.0f, 1.0f);
}

float
tp_interval(const tp_params_t *p, float tcomp)
{
  return clampf(p->i_base * tcomp / p->tau_s, p->i_min, p->i_max);
}

int
tp_c3_decide(const tp_params_t *p, const tp_state_t *st, float since_req, float since_rk)
{
  if(since_req < p->t_refr || since_rk < p->t_refr) return TP_REQ_NONE;   /* refractory period */
  if(st->risk > p->r_high) return TP_REQ_C3_IMM;
  if(st->pred < p->tau_c && st->m < p->delta_d) return TP_REQ_C3_PRED;
  if(st->risk > p->r_med && st->a < p->a_th && st->m < 0.0f) return TP_REQ_C3_ACC;
  return TP_REQ_NONE;
}

int
tp_c1_decide(const tp_params_t *p, const tp_state_t *st, float since_rk, float since_req)
{
  float I = tp_interval(p, st->tcomp);
  if(st->tcomp < p->tau_c)
    return (since_req >= p->i_min && since_rk >= p->i_min) ? TP_REQ_C1_CRIT : TP_REQ_NONE;   /* rate-limited to one per I_min */
  if(st->tcomp < p->tau_m) {
    float ie = I / 2.0f; if(ie < p->i_min) ie = p->i_min;
    return (since_rk >= ie && since_req >= p->i_min) ? TP_REQ_C1_TRUST : TP_REQ_NONE;
  }
  return (since_rk >= I && since_req >= p->i_min) ? TP_REQ_C1_SCHED : TP_REQ_NONE;
}

int
tp_trust_driven(int src)
{
  return src == TP_REQ_C1_TRUST || src == TP_REQ_C1_CRIT || src == TP_REQ_C3_IMM || src == TP_REQ_C3_PRED ||
         src == TP_REQ_C3_ACC || src == TP_REQ_REACTIVE;
}

int
tp_escalate(const tp_params_t *p, int src, float since_td_commit, float since_esc)
{
  if(!tp_trust_driven(src) || since_td_commit >= p->t_hold) return src;
  return since_esc >= p->t_hold ? TP_REQ_ESCALATE : TP_REQ_NONE;
}
