/*
 * TRACE revision build -- trust evidence, trust trajectory, risk, reference authorization policy, enforcement
 * helpers (pure C99). The same code runs in the CC firmware, the ER firmware (explicit-policy model), the host
 * tests and the MSP430 benchmark; scripts/trace_model.py mirrors it for the offline replay.
 *
 * Trust evidence (TARP-OSCORE coordinator model), per client every CYCLE_S at its cluster centre (CC):
 *   T_dev   Beta reputation: s <- lambda s + succ, f <- lambda f + fail, T_dev = (s+1)/(s+f+2);
 *           succ = authenticated, fresh, compliant reports; fail = missed report deadlines, protocol
 *           violations (non-compliant report, rate violation), rejected messages.
 *   T_clust mean T_dev of the other clients of the CC.
 *   T_net   min(q(client-reported first-hop ETX), q(CC first-hop ETX)), q(x) = clamp((x_max - x)/(x_max - 1));
 *           the reported part is capped by the observed delivery ratio s/(s+f) (consistency check).
 *   T       clip(0.40 T_dev + 0.35 T_clust + 0.25 T_net)                                   (Eq. 1)
 * Trajectory over the last W = 16 observed cycles (Eqs. 3-9): EMA (alpha = 0.30, initialised with the first
 * sample), OLS slope m per sample, acceleration a = m - m_prev, direction sign(m), projection
 * clip(ema + k m + k^2 a / 2) (k = 5), EMA-centred variability sigma.
 * Risk (Eqs. 10-11): R = w1 d + w2 min(c_m max(-m,0),1) + w3 min(c_a max(-a,0),1) + w4 min(c_s sigma,1),
 *   d = clamp((D - T)/d_span, 0, 1): published form D = 1, d_span = 1 (d = 1 - T); with rel = 1, D = 1 + (ref - ref0),
 *   i.e. T is judged relative to the cluster's self-calibrating trust reference ref (TARP-OSCORE; ref0 = its
 *   loss-free value), and the trust gates move by the same offset.
 * Reference policy S(T, R) (Eq. 14): first satisfied of  T >= g0 & R < r0 -> Full(0); T >= g1 & R < r1 ->
 *   Restricted(1); T >= g2 & R < r2 -> Read-Only(2); otherwise Revoked(3).
 */
#ifndef TRACE_POLICY_H_
#define TRACE_POLICY_H_
#include <stdint.h>

#define TR_W 16
#define ST_FULL 0
#define ST_REST 1
#define ST_RO   2
#define ST_REV  3
#define OP_READ 0
#define OP_LOW  1
#define OP_HIGH 2

typedef struct {
  float wd, wc, wn, lambda, etx_max; uint8_t crosscheck;     /* trust evidence */
  float alpha; uint8_t k;                                    /* trajectory */
  float wr[4]; float c_m, c_a, c_s;                          /* risk weights and scales */
  float r_th[3]; float g[3];                                 /* risk thresholds and trust gates */
  uint8_t rel; float d_span; float ref0;                     /* relative deficit / gates (calibrated form) */
  float ref_tau;                                             /* time constant of the cluster reference (s) */
} tr_params_t;
extern const tr_params_t tr_published;                       /* IoT-version parameters, unchanged */
extern const tr_params_t tr_calibrated;                      /* stage-A calibration (trace_params.h) */
extern const char *const tr_cal_id;

typedef struct {
  float s, f, tdev, tnet, tclust, t;                         /* evidence and composite trust */
  float w[TR_W]; uint8_t widx, wcnt;                         /* window of observed T */
  float ema, m, m_prev, a, pred, sigma, risk, mean; int8_t dir;
  uint8_t ema_init, have_m;
} tr_state_t;

typedef struct { int16_t q[8]; } tr_desc_t;                  /* quantised descriptor as sent to the ER */
#define TR_Q_T   10000.0f                                    /* T, ema, pred, R, sigma */
#define TR_Q_M   100000.0f                                   /* m, a */

void  tr_init(tr_state_t *st, float s0);
float tr_evidence(const tr_params_t *p, tr_state_t *st, float succ, float fail);
float tr_tnet(const tr_params_t *p, const tr_state_t *st, float etx_client, float etx_cc);
float tr_compose(const tr_params_t *p, tr_state_t *st, float tclust);
/* push the cycle's T into the window and update the trajectory and risk; d_ref = cluster reference (rel form) */
void  tr_trajectory(const tr_params_t *p, tr_state_t *st, float d_ref);
float tr_risk(const tr_params_t *p, float t, float m, float a, float sigma, float d_ref);
int   tr_policy(const tr_params_t *p, float t, float r, float d_ref);
int   tr_window_full(const tr_state_t *st);
void  tr_quantise(const tr_state_t *st, tr_desc_t *d);
void  tr_dequantise(const tr_desc_t *d, float f[8]);
/* privilege helpers: rank(Full) = 3 ... rank(Revoked) = 0 */
static inline int tr_rank(int s) { return 3 - s; }
static inline int tr_min_priv(int a, int b) { return a > b ? a : b; }   /* the less privileged state */
int   tr_permitted(int state, int op);

/* self-calibrating cluster trust reference (TARP-OSCORE v3): slow median and MAD of the members' EMA */
typedef struct { float med, mad, ref; } tr_ref_t;
void  tr_ref_init(tr_ref_t *r);
void  tr_ref_update(tr_ref_t *r, const float *ema, int n, float dt_s, float tau_s);
#endif
