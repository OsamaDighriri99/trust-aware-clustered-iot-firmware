/*
 * TRACE unified build -- cluster centre (nodes 2-11).
 *
 * Security-context plane: the TARP-OSCORE v3.1 coordinator in its full configuration (C1 + C2 + C3 + escalation,
 * self-calibrating trust reference, cross-check), unchanged from TARP-OSCORE: one pairwise OSCORE context per
 * client, renewed by trust-aware C2 transitions (Active -> Overlap -> Deprecated) or re-established on escalation.
 * Rejected messages and unanswered lifecycle messages are evidence of failure.
 *
 * Authorization plane: for each of its 10 clients the CC derives the trust evidence and the composite trust T every
 * 15 s, maintains the W = 16 trust window, builds the eight-dimensional trajectory descriptor, computes the reference
 * state S(T, R) locally, and enforces
 *     s_enf = min_priv( S(T, R), s_ER )      (the reference policy is a mandatory ceiling)
 * where s_ER is the latest verified ER assignment within its lease (4 cycles); after lease expiry the CC enforces
 * S(T, R) alone. Privilege increases need g_dwell consecutive eligible cycles. Descriptors of all clients travel to the
 * active ER in one protected batch per cycle; without a verified reply for 3 cycles the CC fails over to the other ER
 * (node 1 primary, node 112 standby). Operation requests carried in reports are accepted or rejected according to the
 * enforced state; reports keep feeding the trust evidence in every state.
 */
#include "trace_common.h"
#include "tarp_keys.h"
#include "tarp_policy.h"
#include "net/routing/routing.h"
#include "net/routing/rpl-classic/rpl.h"
#include <string.h>

PROCESS(cc_process, "TRACE cluster centre");
AUTOSTART_PROCESSES(&cc_process);

#define NC 10
#define LEASE_MAX 4
#define FAILOVER_MISSES 3
#define FMT_OK 0x01
/* TARP-OSCORE v3.1 lifecycle timing */
#define T_ACK_S       15
#define T_RETRY_S     15
#define R_MAX         5
#define T_PENDING_S   (T_ACK_S + R_MAX * T_RETRY_S)
#define T_OVERLAP_S   120
#define T_DEPR_S      300
#define PS_NONE 0
#define PS_OVERLAP 1
#define PS_DEPR 2

typedef struct {
  uint8_t client;
  /* ---- authorization plane ---- */
  tr_state_t tr;
  float succ, fail;
  uint32_t next_due, last_rx, sleep_until; uint16_t period; float etx_rep;
  uint8_t s_loc, s_er, s_enf, dwell_cnt; uint32_t asg_cyc; uint8_t asg_valid, asg_lease;
  uint8_t ev_s, ev_f; uint16_t ev_ex, ev_eo;
  uint32_t opc[4][3][2];               /* [enforced state][op class][accepted] */
  uint32_t rx_ok, rx_bad, n_noncomp, n_rate;
  /* ---- security-context plane (TARP-OSCORE v3.1) ---- */
  uint8_t ms_act[16]; uint16_t e_act; tos_keys_t k_act; uint32_t seq; tos_replay_t rw_act;
  uint8_t prev_state; uint16_t e_prev; tos_keys_t k_prev; tos_replay_t rw_prev; uint32_t t_commit; uint8_t prev_after_re;
  uint8_t pend; uint16_t e_pend; uint8_t ms_pend[16]; tos_keys_t k_pend; uint32_t t_pend; uint8_t retries; uint32_t next_retry;
  uint8_t re; uint16_t reest_no, re_e; uint32_t re_t0, re_next, re_last_end; uint8_t re_retries;
  tp_state_t tp;
  uint32_t last_req, last_rk, last_td_commit, last_esc; uint8_t escalated;
  uint8_t unacc; uint32_t unacc_t0;
  uint32_t ep_no, ep_t0_ms; uint8_t ep_src, ep_kind;
  uint32_t rx_rej_life, sup_req;
  int8_t tarp_req; uint32_t tarp_at;   /* lifecycle request decided in the cycle, executed at the client's slot second */
} cl_t;

static cl_t cl[NC];
static struct simple_udp_connection conn, econn;
static uint8_t me, ccx;
static const tr_params_t *P;
static tr_ref_t ref;
static tp_params_t TP;                   /* TARP-OSCORE parameters with the TARP self-calibrating reference */
static float tref_med = 0.0f, tref_mad = 0.010f;
static pctx_t erctx[2];                  /* 0: primary ER (node 1), 1: standby ER (node 112) */
static uint8_t er_act;                   /* index of the active ER */
static uint16_t batch_no; static uint32_t batch_t_ms; static uint8_t replied, misses;
static uint32_t cyc_no;
static uint8_t buf[256], pt[224];

static cl_t *
cl_of(uint8_t c)
{
  if(c < TT_FIRST_CLIENT || c > TT_LAST_CLIENT || tt_node[c].cc != me) return NULL;
  return &cl[tt_node[c].slot];
}

/* ======================= security-context plane: TARP-OSCORE v3.1 coordinator ======================= */
#define TREF_TAU_S   3600.0f
#define TREF_MARGIN  0.025f
#define TREF_MAD0    0.010f
#define TREF_K       6.0f
static float
median10(float *v)
{
  float tmp; int i, j;
  for(i = 1; i < NC; i++) { tmp = v[i]; j = i - 1; while(j >= 0 && v[j] > tmp) { v[j + 1] = v[j]; j--; } v[j + 1] = tmp; }
  return 0.5f * (v[NC / 2 - 1] + v[NC / 2]);
}
static void
tarp_ref_update(void)                    /* TARP-OSCORE v3 self-calibrating reference (1-h time constant) */
{
  float v[NC], med, mad; int i;
  const float beta = (float)CYCLE_S / TREF_TAU_S;
  for(i = 0; i < NC; i++) v[i] = cl[i].tp.ema;
  med = median10(v);
  for(i = 0; i < NC; i++) { v[i] = cl[i].tp.ema - med; if(v[i] < 0) v[i] = -v[i]; }
  mad = median10(v);
  if(tref_med <= 0.0f) tref_med = tp_default.tau_s - TREF_MARGIN;
  tref_med += beta * (med - tref_med);
  tref_mad += beta * (mad - tref_mad);
  TP.tau_s = tref_med + TREF_MARGIN - TREF_K * (tref_mad > TREF_MAD0 ? tref_mad - TREF_MAD0 : 0.0f);
  if(TP.tau_s > tp_default.tau_s) TP.tau_s = tp_default.tau_s;
  if(TP.tau_s < tp_default.tau_m) TP.tau_s = tp_default.tau_m;
  TP.i_max = TP.i_base / TP.tau_s;
}

static void
send_to(cl_t *c, uint8_t type, uint16_t epoch, const tos_keys_t *k, uint32_t *seq, const uint8_t *p, uint16_t plen)
{
  uip_ipaddr_t a; int n = msg_build(type, epoch, k, (*seq)++, NULL, p, plen, buf);
  node_addr(c->client, &a);
  count_tx(type == T_DACK ? TC_APP : TC_LIFE, (uint16_t)n);
  simple_udp_sendto_port(&conn, buf, (uint16_t)n, &a, PORT_CLIENT);
}
static int busy(const cl_t *c) { return c->pend || c->re; }
static void
ep_end(cl_t *c, const char *outcome)
{
  TLOG("EP_END", "p=%u,ep=%lu,kind=%u,src=%s,e=%u,out=%s,retx=%u,dur_ms=%lu", c->client, (unsigned long)c->ep_no, c->ep_kind,
       tp_req_name[c->ep_src], c->pend ? c->e_pend : c->e_act, outcome, c->retries, (unsigned long)(now_us() / 1000ULL - c->ep_t0_ms));
}
static void
re_send1(cl_t *c)
{
  tos_keys_t kb; static uint32_t bseq; uint8_t r1[37];
  boot_keys(me, c->client, 1, &kb);
  memset(r1, 0, sizeof r1);
  r1[0] = (uint8_t)(c->reest_no >> 8); r1[1] = (uint8_t)c->reest_no; r1[2] = (uint8_t)(c->re_e >> 8); r1[3] = (uint8_t)c->re_e;
  send_to(c, T_RE1, 0, &kb, &bseq, r1, sizeof r1);
}
static void
re_start(cl_t *c, uint8_t reason)
{
  uint32_t t = now_s();
  if(c->re || t < c->re_last_end + 60) return;
  if(c->pend) { ep_end(c, "superseded"); c->pend = 0; }
  c->re = 1; c->reest_no++; c->re_e = (uint16_t)(c->e_act + 1); c->re_t0 = t; c->re_next = t + T_RETRY_S; c->re_retries = 0;
  TLOG("REEST_START", "p=%u,rn=%u,reason=%u", c->client, c->reest_no, reason);
  re_send1(c);
}
static void
c2_start(cl_t *c)
{
  uint8_t p2[2]; uint16_t en = (uint16_t)(c->e_act + 1);
  if(en == 0xFFFF) { re_start(c, 3); return; }
  ratchet_ms(c->ms_act, en, c->ms_pend); epoch_keys(c->ms_pend, en, me, c->client, 1, &c->k_pend);
  c->pend = 1; c->e_pend = en; c->t_pend = now_s(); c->retries = 0; c->next_retry = c->t_pend + T_ACK_S;
  p2[0] = (uint8_t)(en >> 8); p2[1] = (uint8_t)en;
  send_to(c, T_INIT, c->e_act, &c->k_act, &c->seq, p2, 2);
}
static void
c2_commit(cl_t *c)
{
  uint8_t p2[2];
  c->prev_state = PS_OVERLAP; c->e_prev = c->e_act; c->k_prev = c->k_act; c->rw_prev = c->rw_act; c->t_commit = now_s(); c->prev_after_re = 0;
  c->e_act = c->e_pend; memcpy(c->ms_act, c->ms_pend, 16); c->k_act = c->k_pend; c->seq = 0; memset(&c->rw_act, 0, sizeof c->rw_act);
  memset(c->ms_pend, 0, 16);
  ep_end(c, "commit");
  c->pend = 0; c->last_rk = now_s();
  if(tp_trust_driven(c->ep_src)) c->last_td_commit = c->last_rk;
  TLOG("COMMIT", "role=co,p=%u,e=%u,how=normal", c->client, c->e_act);
  p2[0] = (uint8_t)(c->e_act >> 8); p2[1] = (uint8_t)c->e_act;
  send_to(c, T_CONFIRM, c->e_act, &c->k_act, &c->seq, p2, 2);
}
static void
execute(cl_t *c, int src)
{
  uint32_t t = now_s();
  if(src == TP_REQ_NONE) return;
  if(busy(c)) { c->sup_req++; return; }
  c->last_req = t;
  c->ep_no++; c->ep_t0_ms = (uint32_t)(now_us() / 1000ULL); c->ep_src = (uint8_t)src;
  TLOG("REQ", "p=%u,src=%s,tc=%d", c->client, tp_req_name[src], (int)(c->tp.tcomp * 1000));
  if(src == TP_REQ_ESCALATE) {
    c->ep_kind = 3; c->escalated = 1; c->last_esc = t;
    TLOG("ESCALATE", "p=%u,tc=%d", c->client, (int)(c->tp.tcomp * 1000));
    re_start(c, 1);
    return;
  }
  c->ep_kind = 0; c2_start(c);
}
static void
unacceptable(cl_t *c, const msg_view_t *v)
{
  uint32_t t = now_s();
  c->rx_bad++;
  if(t >= WARMUP_S) c->fail += 1.0f;                                  /* rejected message */
  if(v->type == T_DATA && c->pend) c->rx_rej_life++;
  TLOG("RXREJ", "p=%u,why=ctx,type=%c,e=%u,act=%u,busy=%u", c->client, v->type, v->epoch, c->e_act, busy(c));
  if(busy(c)) { c->unacc = 0; return; }
  if(c->unacc == 0) c->unacc_t0 = t;
  c->unacc++;
  if(c->unacc >= 2 && t - c->unacc_t0 >= 30) {
    TLOG("DESYNC", "p=%u,e_co=%u,e_rx=%u", c->client, c->e_act, v->epoch);
    c->unacc = 0;
    c->ep_no++; c->ep_t0_ms = (uint32_t)(now_us() / 1000ULL); c->ep_src = TP_REQ_NONE; c->ep_kind = 3;
    re_start(c, 0);
  }
}
static void
tarp_timers(cl_t *c, uint32_t t)
{
  if(c->prev_state == PS_OVERLAP && t >= c->t_commit + T_OVERLAP_S) c->prev_state = PS_DEPR;
  if(c->prev_state == PS_DEPR && t >= c->t_commit + T_OVERLAP_S + T_DEPR_S) { c->prev_state = PS_NONE; memset(&c->k_prev, 0, sizeof c->k_prev); }
  if(c->pend) {
    if(t >= c->t_pend + T_PENDING_S) {
      uint8_t p2[2] = { (uint8_t)(c->e_pend >> 8), (uint8_t)c->e_pend };
      ep_end(c, "abort");
      c->pend = 0; memset(c->ms_pend, 0, 16);
      send_to(c, T_ABORT, c->e_act, &c->k_act, &c->seq, p2, 2);
    } else if(t >= c->next_retry && c->retries < R_MAX) {
      uint8_t p2[2] = { (uint8_t)(c->e_pend >> 8), (uint8_t)c->e_pend };
      c->retries++; c->next_retry += T_RETRY_S; if(t >= WARMUP_S) c->fail += 1.0f;   /* unanswered lifecycle message */
      send_to(c, T_INIT, c->e_act, &c->k_act, &c->seq, p2, 2);
    }
  }
  if(c->re) {
    if(t >= c->re_t0 + T_PENDING_S) { TLOG("REEST_FAIL", "p=%u,rn=%u", c->client, c->reest_no); c->re = 0; c->re_last_end = t; c->escalated = 0; }
    else if(t >= c->re_next && c->re_retries < R_MAX) { c->re_retries++; c->re_next += T_RETRY_S; re_send1(c); }
  }
  if(c->tarp_req >= 0 && t >= c->tarp_at) { execute(c, c->tarp_req); c->tarp_req = -1; }
}

/* ======================= reports (authorization evidence + operations) ======================= */
static void
report(cl_t *c, uint32_t t, const uint8_t *p, int plen)
{
  uint16_t rno, per, sl; uint8_t op, acc = 0, a[4];
  if(plen < 9) return;
  rno = (uint16_t)((p[1] << 8) | p[2]); op = p[5] > OP_HIGH ? OP_HIGH : p[5];
  per = p[6] ? p[6] : REPORT_PERIOD_S; sl = (uint16_t)((p[7] << 8) | p[8]);
  c->period = per;
  if(p[0] != FMT_OK) {                                                /* protocol violation */
    c->n_noncomp++; if(t >= WARMUP_S) c->fail += 1.0f;
  } else if(c->last_rx && t - c->last_rx < (uint32_t)(per / 2)) {      /* rate violation */
    c->n_rate++; if(t >= WARMUP_S) c->fail += 1.0f;
  } else {
    c->rx_ok++;
    if(t >= WARMUP_S) c->succ += 1.0f;
    c->last_rx = t; c->next_due = t + per + per / 2;
    c->etx_rep = ((p[3] << 8) | p[4]) / 100.0f;
    acc = (uint8_t)tr_permitted(c->s_enf, op);
  }
  if(sl > 0) { c->sleep_until = t + sl; c->next_due = c->sleep_until + per + per / 2; }   /* announced sleep */
  c->opc[c->s_enf][op][acc]++;
  a[0] = (uint8_t)(rno >> 8); a[1] = (uint8_t)rno; a[2] = acc; a[3] = c->s_enf;
  send_to(c, T_DACK, c->e_act, &c->k_act, &c->seq, a, 4);
}

static void
rx(struct simple_udp_connection *cn, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
   const uint8_t *data, uint16_t len)
{
  msg_view_t v; int plen = -1, g = 0; uint32_t t = now_s(); uint8_t from = addr_node(sa);
  cl_t *c = cl_of(from);
  if(!g_configured || !c) return;
  if(rx_drop(from)) return;
  if(msg_parse(data, len, &v) < 0) { c->rx_bad++; if(t >= WARMUP_S) c->fail += 1.0f; return; }
  if(IS_RE(v.type)) {
    tos_keys_t kb; boot_keys(me, c->client, 1, &kb);
    if(v.type != T_RE2 || !c->re || (plen = msg_open(&v, &kb, pt)) < 2) return;
    if(((pt[0] << 8) | pt[1]) != c->reest_no) return;
    {
      static uint32_t bseq; uint8_t r3[19];
      memset(r3, 0, sizeof r3);
      r3[0] = (uint8_t)(c->reest_no >> 8); r3[1] = (uint8_t)c->reest_no; r3[2] = (uint8_t)(c->re_e >> 8); r3[3] = (uint8_t)c->re_e;
      send_to(c, T_RE3, 0, &kb, &bseq, r3, sizeof r3);
      c->prev_state = PS_OVERLAP; c->e_prev = c->e_act; c->k_prev = c->k_act; c->rw_prev = c->rw_act; c->t_commit = t; c->prev_after_re = 1;
      pair_root(me, c->client, c->reest_no, c->ms_act); c->e_act = c->re_e; epoch_keys(c->ms_act, c->e_act, me, c->client, 1, &c->k_act);
      c->seq = 0; memset(&c->rw_act, 0, sizeof c->rw_act); c->re = 0; c->re_last_end = t; c->last_rk = t; c->escalated = 0;
      TLOG("REEST_DONE", "role=co,p=%u,e=%u,rn=%u,dur_ms=%lu", c->client, c->e_act, c->reest_no, (unsigned long)(t - c->re_t0) * 1000UL);
    }
    return;
  }
  if(v.epoch == c->e_act && (plen = msg_open(&v, &c->k_act, pt)) >= 0) g = tos_replay_check(&c->rw_act, v.piv, 0) ? 1 : -1;
  else if(c->prev_state != PS_NONE && v.epoch == c->e_prev && (plen = msg_open(&v, &c->k_prev, pt)) >= 0) g = tos_replay_check(&c->rw_prev, v.piv, 0) ? 2 : -1;
  else if(c->pend && v.epoch == c->e_pend && v.type == T_ACK && (plen = msg_open(&v, &c->k_pend, pt)) >= 0) g = 3;
  if(g <= 0) { unacceptable(c, &v); return; }
  c->unacc = 0;
  if(g == 2 && c->prev_after_re) {
    tos_keys_t kb; static uint32_t bseq2; uint8_t r3[19]; memset(r3, 0, sizeof r3);
    boot_keys(me, c->client, 1, &kb);
    r3[0] = (uint8_t)(c->reest_no >> 8); r3[1] = (uint8_t)c->reest_no; r3[2] = (uint8_t)(c->e_act >> 8); r3[3] = (uint8_t)c->e_act;
    send_to(c, T_RE3, 0, &kb, &bseq2, r3, sizeof r3);
  }
  switch(v.type) {
  case T_DATA: report(c, t, pt, plen); break;
  case T_ACK:
    if(g == 3 && c->pend && ((pt[0] << 8) | pt[1]) == c->e_pend) c2_commit(c);
    else if(g == 1 && !c->pend && ((pt[0] << 8) | pt[1]) == c->e_act) {
      uint8_t p2[2] = { (uint8_t)(c->e_act >> 8), (uint8_t)c->e_act };
      send_to(c, T_CONFIRM, c->e_act, &c->k_act, &c->seq, p2, 2);
    }
    break;
  default: break;
  }
}

/* ======================= protected CC <-> ER path ======================= */
static void
erx(struct simple_udp_connection *cn, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
    const uint8_t *data, uint16_t len)
{
  uint32_t t = now_s(); int plen = 0, r, i; uint8_t from = addr_node(sa), ei; ab_t ab;
  if(!g_configured || (from != TT_ER && from != TT_STANDBY)) return;
  ei = from == TT_ER ? 0 : 1;
  memset(&ab, 0, sizeof ab);
  r = pctx_open(&erctx[ei], T_ASSIGN, t, data, len, pt, &plen);
  if(r == RX_OK && ab_decode(pt, plen, &ab) < 0) r = RX_PARSE;
  if(r == RX_OK) r = ab_check(&ab, me, batch_no);
  TLOG("ASG", "er=%u,b=%u,rx=%s,lat_ms=%lu,mdl=%u", from, r == RX_OK || r == RX_STALE ? ab.batch : 0, rx_name[r],
       (unsigned long)(now_us() / 1000ULL - batch_t_ms), r == RX_OK || r == RX_STALE || r == RX_BIND ? ab.model : 0);
  if(r != RX_OK) return;
  for(i = 0; i < ab.n; i++) {
    cl_t *c = &cl[ab.e[i].slot];
    c->s_er = ab.e[i].state; c->asg_cyc = cyc_no; c->asg_valid = 1; c->asg_lease = ab.lease < LEASE_MAX ? ab.lease : LEASE_MAX;
  }
  if(ei == er_act && ab.batch == batch_no) replied = 1;
}

static float
own_etx(void)
{
  rpl_dag_t *dag = rpl_get_any_dag();
  rpl_parent_t *pp = dag ? dag->preferred_parent : NULL;
  float e = pp ? (float)rpl_get_parent_link_metric(pp) / 128.0f : 1.0f;
  return e < 1.0f ? 1.0f : e;
}

static void
cycle(void)
{
  uint32_t t = now_s(); int i, n;
  float eo = own_etx(), emas[NC];
  db_t db;
  cyc_no++;
  /* 1. evidence and trust components (shared by both planes) */
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i];
    int asleep = t < c->sleep_until;
    if(!asleep) {
      if(c->next_due == 0) c->next_due = t + c->period + c->period / 2;
      while(t >= c->next_due) { c->fail += 1.0f; c->next_due += c->period; }   /* missed report deadlines */
    }
    c->ev_s = (uint8_t)c->succ; c->ev_f = (uint8_t)c->fail;
    c->ev_ex = (uint16_t)((c->etx_rep > 0 ? c->etx_rep : 1.0f) * 100); c->ev_eo = (uint16_t)(eo * 100);
    tr_evidence(P, &c->tr, c->succ, c->fail);
    tp_evidence(&TP, &c->tp, c->succ, c->fail);
    c->succ = c->fail = 0;
    c->tr.tnet = tr_tnet(P, &c->tr, c->etx_rep > 0 ? c->etx_rep : 1.0f, eo);
    c->tp.tnet = tp_tnet(&TP, &c->tp, c->etx_rep > 0 ? c->etx_rep : 1.0f, eo);
  }
  for(i = 0; i < NC; i++) {
    float tc = 0, tq = 0; int j;
    for(j = 0; j < NC; j++) if(j != i) { tc += cl[j].tr.tdev; tq += cl[j].tp.tdev; }
    tr_compose(P, &cl[i].tr, tc / (NC - 1));
    tp_compose(&TP, &cl[i].tp, tq / (NC - 1));
    tp_c3_update(&TP, &cl[i].tp);
  }
  tarp_ref_update();
  /* 2. trajectory (observed cycles only: announced sleep keeps the window unchanged), cluster reference */
  for(i = 0; i < NC; i++) if(t >= cl[i].sleep_until) tr_trajectory(P, &cl[i].tr, ref.ref);
  for(i = 0; i < NC; i++) emas[i] = cl[i].tr.ema_init ? cl[i].tr.ema : 1.0f;
  tr_ref_update(&ref, emas, NC, (float)CYCLE_S, P->ref_tau);
  for(i = 0; i < NC; i++)                                      /* risk against this cycle's reference (relative form) */
    if(t >= cl[i].sleep_until) cl[i].tr.risk = tr_risk(P, cl[i].tr.t, cl[i].tr.m, cl[i].tr.a, cl[i].tr.sigma, ref.ref);
  /* 3. reference state, ER assignment within lease, ceiling, dwell, enforcement */
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i];
    uint8_t cand, valid;
    if(tr_window_full(&c->tr) && t >= c->sleep_until) c->s_loc = (uint8_t)tr_policy(P, c->tr.t, c->tr.risk, ref.ref);
    valid = c->asg_valid && (cyc_no - c->asg_cyc) <= c->asg_lease;
    cand = valid ? (uint8_t)tr_min_priv(c->s_loc, c->s_er) : c->s_loc;
    if(tr_rank(cand) > tr_rank(c->s_enf)) {                    /* privilege increase: dwell */
      if(++c->dwell_cnt >= g_dwell) { c->s_enf = cand; c->dwell_cnt = 0; }
    } else { c->s_enf = cand; c->dwell_cnt = 0; }
  }
  /* 4. security-context plane: TARP-OSCORE lifecycle decisions (executed at the client's slot second) */
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i]; int src;
    if(c->escalated || c->tarp_req >= 0) continue;
    src = tp_c3_decide(&TP, &c->tp, (float)(t - c->last_req), (float)(t - c->last_rk));
    if(src == TP_REQ_NONE) src = tp_c1_decide(&TP, &c->tp, (float)(t - c->last_rk), (float)(t - c->last_req));
    src = tp_escalate(&TP, src, c->last_td_commit ? (float)(t - c->last_td_commit) : 1e9f, c->last_esc ? (float)(t - c->last_esc) : 1e9f);
    if(src != TP_REQ_NONE) { c->tarp_req = (int8_t)src; c->tarp_at = t + 1 + (uint32_t)i; }
  }
  /* 5. log and protected descriptor batch to the active ER */
  memset(&db, 0, sizeof db);
  db.cc = me; db.batch = ++batch_no; db.ref = (int16_t)(ref.ref * TR_Q_T + 0.5f); db.n = NC;
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i]; tr_desc_t d; uint8_t fl = 0;
    tr_quantise(&c->tr, &d);
    if(tr_window_full(&c->tr)) fl |= DF_FULL;
    if(t < c->sleep_until) fl |= DF_SLEEP;
    db.e[i].slot = (uint8_t)i; db.e[i].flags = fl; db.e[i].d = d;
    TLOG("TR", "p=%u,es=%u,ef=%u,ex=%u,eo=%u,dv=%d,cl=%d,nt=%d,q=%d;%d;%d;%d;%d;%d;%d;%d,sl=%u,sh=%u,ag=%lu,en=%u,fl=%u,ce=%u",
         c->client, c->ev_s, c->ev_f, c->ev_ex, c->ev_eo, (int)(c->tr.tdev * 10000), (int)(c->tr.tclust * 10000), (int)(c->tr.tnet * 10000),
         d.q[0], d.q[1], d.q[2], d.q[3], d.q[4], d.q[5], d.q[6], d.q[7], c->s_loc, c->asg_valid ? c->s_er : 9,
         c->asg_valid ? (unsigned long)(cyc_no - c->asg_cyc) : 999UL, c->s_enf, fl, c->e_act);
  }
  if(!replied && batch_no > 1) {
    if(++misses >= FAILOVER_MISSES) {
      TLOG("FAILOVER", "from=%u,to=%u,b=%u", er_act ? TT_STANDBY : TT_ER, er_act ? TT_ER : TT_STANDBY, batch_no);
      er_act ^= 1; misses = 0;
    }
  } else misses = 0;
  replied = 0;
  n = db_encode(&db, pt);
  {
    uip_ipaddr_t a; int m = pctx_protect(&erctx[er_act], T_DESC, t, pt, (uint16_t)n, buf);
    node_addr(er_act ? TT_STANDBY : TT_ER, &a);
    count_tx(TC_DESC, (uint16_t)m);
    batch_t_ms = (uint32_t)(now_us() / 1000ULL);
    simple_udp_sendto_port(&econn, buf, (uint16_t)m, &a, PORT_ER);
  }
  TLOG("CCY", "b=%u,er=%u,ref=%d,miss=%u,tref=%d", batch_no, er_act ? TT_STANDBY : TT_ER, (int)(ref.ref * 10000), misses, (int)(TP.tau_s * 10000));
}

PROCESS_THREAD(cc_process, ev, data)
{
  static struct etimer tick;
  static uint32_t next_cnt, last_s;
  int i;
  PROCESS_BEGIN();
  trace_common_init();
  PROCESS_WAIT_EVENT_UNTIL(ev == g_cfg_event);
  me = (uint8_t)node_id; ccx = (uint8_t)(me - TT_FIRST_CC);
  P = g_pol ? &tr_calibrated : &tr_published;
  TP = tp_default;
  simple_udp_register(&conn, PORT_CC, NULL, PORT_CLIENT, rx);
  simple_udp_register(&econn, PORT_ER, NULL, PORT_ER, erx);
  pctx_init(&erctx[0], me, TT_ER); pctx_init(&erctx[1], me, TT_STANDBY);
  tr_ref_init(&ref);
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i];
    memset(c, 0, sizeof *c);
    c->client = tt_members[ccx][i];
    /* TARP-OSCORE context, epoch 1 */
    pair_root(me, c->client, 0, c->ms_act); c->e_act = 1; epoch_keys(c->ms_act, 1, me, c->client, 1, &c->k_act);
    tp_init(&c->tp);
    c->tp.s = ((float)CYCLE_S / REPORT_PERIOD_S) / (1.0f - TP.lambda);
    c->tp.tdev = (c->tp.s + 1.0f) / (c->tp.s + 2.0f);
    c->last_rk = c->last_req = WARMUP_S; c->tarp_req = -1;
    /* enrolment: evidence of a fully compliant client at steady state (one report per two cycles) */
    tr_init(&c->tr, ((float)CYCLE_S / REPORT_PERIOD_S) / (1.0f - P->lambda));
    c->period = REPORT_PERIOD_S; c->s_loc = c->s_enf = ST_FULL; c->s_er = ST_FULL;
  }
  next_cnt = 1800; last_s = 0;
  etimer_set(&tick, CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&tick));
    etimer_reset(&tick);
    {
      uint32_t t = now_s();
      if(t == last_s) continue;
      last_s = t;
      for(i = 0; i < NC; i++) tarp_timers(&cl[i], t);
      if(t >= WARMUP_S && (t - WARMUP_S) % CYCLE_S == ccx % CYCLE_S) cycle();   /* CCs staggered by 1 s */
      if(t % 60 == (uint32_t)(node_id % 60)) log_routing();
      if(t >= next_cnt) {
        log_counters();
        for(i = 0; i < NC; i++) {
          cl_t *c = &cl[i]; char b[160]; int s, o, n = 0;
          for(s = 0; s < 4; s++) for(o = 0; o < 3; o++) n += snprintf(b + n, sizeof b - n, "%lu/%lu;", (unsigned long)c->opc[s][o][1], (unsigned long)c->opc[s][o][0]);
          TLOG("CXSTAT", "p=%u,ok=%lu,bad=%lu,noncomp=%lu,rate=%lu,ops=%s,e=%u,ep=%lu,sup=%lu,rejlife=%lu", c->client, (unsigned long)c->rx_ok,
               (unsigned long)c->rx_bad, (unsigned long)c->n_noncomp, (unsigned long)c->n_rate, b, c->e_act, (unsigned long)c->ep_no,
               (unsigned long)c->sup_req, (unsigned long)c->rx_rej_life);
        }
        next_cnt += 1800;
      }
    }
  }
  PROCESS_END();
}
