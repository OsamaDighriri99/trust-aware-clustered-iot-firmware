/* TRACE unified build -- CC<->ER pairwise OSCORE contexts, scheduled epochs and wire format (pure C99); the
 * client<->CC contexts are TARP-OSCORE v3.1 (tarp_keys.h).
 * Shared by the Cooja firmware, the host tests (code/tests) and the MSP430 (Z1) benchmark. */
#ifndef TRACE_KEYS_H_
#define TRACE_KEYS_H_
#include <stdint.h>
#include "tarp_crypto.h"
#include "tarp_oscore.h"

/* message types (outer header byte 0) */
#define T_DESC    'Q'   /* CC -> ER: protected batch of trajectory descriptors */
#define T_ASSIGN  'S'   /* ER -> CC: protected assignment batch (lease renewal, echoed batch number) */

/* Security-context epochs of the CC-ER contexts rotate on a fixed schedule: e = 1 + floor(t / EPOCH_S).
 * A receiver accepts the current epoch and, for EPOCH_OVERLAP_S after a boundary, the previous one
 * (Active -> Overlap); older epochs are rejected (Deprecated/Revoked). Client-CC contexts are the TARP-OSCORE v3.1 contexts (tarp_keys.h). */
#define EPOCH_S         7200
#define EPOCH_OVERLAP_S 120

extern const uint8_t tk_master_salt[8];
/* root material of the pair (a, b), a < b (stands for provisioned or EDHOC-derived material; no forward secrecy) */
void tk_pair_root(uint8_t a, uint8_t b, uint8_t ms[16]);
/* epoch-e keys of the context between 'me' and 'peer' (roles fixed by the ids) */
void ctx_keys(uint8_t me, uint8_t peer, uint16_t e, tos_keys_t *k);
uint16_t epoch_at(uint32_t t);
/* receiver epoch rule: 1 accept as current, 2 accept as previous (overlap), 0 reject */
int  epoch_accept(uint16_t e_msg, uint32_t t);

int  tk_build(uint8_t type, uint16_t epoch, const tos_keys_t *k, uint32_t seq, const uint8_t *pt, uint16_t len, uint8_t *out);
typedef struct { uint8_t type, flags; uint16_t epoch; uint32_t piv; const uint8_t *ct; uint16_t clen;
                 uint8_t hdr[16]; uint8_t hdr_len; } tk_view_t;
int  tk_parse(const uint8_t *in, uint16_t len, tk_view_t *v);
int  tk_open(const tk_view_t *v, const tos_keys_t *k, uint8_t *pt);   /* plaintext length or -1 */
#endif
