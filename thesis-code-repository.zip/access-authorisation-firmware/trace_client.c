/*
 * TRACE unified build -- constrained client (nodes 12-111). Security-context plane: the TARP-OSCORE v3.1 client
 * endpoint (pairwise OSCORE context with its cluster centre, C2 participation with bounded forward recovery,
 * re-establishment), unchanged from TARP-OSCORE. Authorization plane: one protected report per announced period
 * carrying its first-hop ETX, an operation request (read 50 %, low-impact write 30 %, high-impact write 20 %), the
 * announced report period and, under S8, an announced sleep; the cluster centre returns the decision in the protected
 * acknowledgement. Clients perform no trajectory construction or learned inference. Behavioural conditions act here
 * on observable behaviour only: report delivery, protocol compliance, report rate, announced period and sleep.
 */
#include "trace_common.h"
#include "tarp_keys.h"
#include "net/routing/routing.h"
#include "net/routing/rpl-classic/rpl.h"
#include <string.h>

PROCESS(client_process, "TRACE client");
AUTOSTART_PROCESSES(&client_process);

#define T_PEND_PEER_S 420
#define T_OVERLAP_S   120
#define T_DEPR_S      300
#define FMT_OK        0x01

static struct simple_udp_connection conn;
static uip_ipaddr_t cc_addr;
static uint8_t me, cc;
/* TARP-OSCORE client context */
static uint8_t  ms_act[16];
static uint16_t e_act;
static tos_keys_t k_act;
static uint32_t seq_act, ack_seq;
static tos_replay_t rw_act;
static uint8_t  prev_valid; static uint16_t e_prev; static tos_keys_t k_prev; static tos_replay_t rw_prev; static uint32_t t_commit;
static uint8_t  pend_valid; static uint16_t e_pend; static uint8_t ms_pend[16]; static tos_keys_t k_pend; static uint32_t t_pend_exp;
static uint16_t reest_no, report_no;
static uint32_t n_sent, n_supp, n_noncomp, n_ack, n_acc, n_rej, n_rxbad;
static uint8_t buf[128], pt[96];
static uint8_t sleep_announced;

static int
send_msg(uint8_t type, uint16_t epoch, const tos_keys_t *k, uint32_t *seq, const uint8_t *p, uint16_t plen)
{
  int n = msg_build(type, epoch, k, (*seq)++, NULL, p, plen, buf);
  count_tx(type == T_DATA ? TC_APP : TC_LIFE, (uint16_t)n);
  simple_udp_sendto(&conn, buf, (uint16_t)n, &cc_addr);
  return n;
}

static void
commit(const char *how)
{
  prev_valid = 1; e_prev = e_act; k_prev = k_act; rw_prev = rw_act; t_commit = now_s();
  e_act = e_pend; memcpy(ms_act, ms_pend, 16); k_act = k_pend;
  seq_act = ack_seq; memset(&rw_act, 0, sizeof rw_act);
  pend_valid = 0; memset(ms_pend, 0, 16);
  TLOG("COMMIT", "role=cl,p=%u,e=%u,how=%s", me, e_act, how);
}

static uint16_t
first_hop_etx(void)
{
  rpl_dag_t *dag = rpl_get_any_dag();
  rpl_parent_t *pp = dag ? dag->preferred_parent : NULL;
  float etx = pp ? (float)rpl_get_parent_link_metric(pp) / 128.0f : 1.0f;
  if(etx < 1.0f) etx = 1.0f;
  return (uint16_t)(etx * 100.0f);
}

/* report plaintext: fmt(1) report_no(2) etx_x100(2) op(1) period_s(1) sleep_s(2) */
static void
send_report(uint16_t period, uint16_t sleep_s, const beh_t *b)
{
  uint16_t etx = first_hop_etx();
  uint32_t r = rnd() % 10; uint8_t op = r < 5 ? OP_READ : (r < 8 ? OP_LOW : OP_HIGH);
  report_no++;
  if(sleep_s == 0 && rndf() >= b->deliver) { n_supp++; return; }          /* behavioural non-delivery */
  pt[0] = FMT_OK;
  if(sleep_s == 0 && rndf() >= b->comply) { pt[0] = 0x00; n_noncomp++; }   /* protocol-non-compliant report */
  pt[1] = (uint8_t)(report_no >> 8); pt[2] = (uint8_t)report_no;
  pt[3] = (uint8_t)(etx >> 8); pt[4] = (uint8_t)etx;
  pt[5] = op; pt[6] = (uint8_t)period; pt[7] = (uint8_t)(sleep_s >> 8); pt[8] = (uint8_t)sleep_s;
  send_msg(T_DATA, e_act, &k_act, &seq_act, pt, 9);
  n_sent++;
}

#define G_NONE 0
#define G_ACT  1
#define G_PREV 2
#define G_PEND 3
static int
open_any(const msg_view_t *v, int *plen)
{
  uint32_t t = now_s();
  if(v->epoch == e_act && (*plen = msg_open(v, &k_act, pt)) >= 0) return tos_replay_check(&rw_act, v->piv, 0) ? G_ACT : -1;
  if(prev_valid && v->epoch == e_prev && t < t_commit + T_OVERLAP_S + T_DEPR_S && (*plen = msg_open(v, &k_prev, pt)) >= 0)
    return tos_replay_check(&rw_prev, v->piv, 0) ? G_PREV : -1;
  if(pend_valid && v->epoch == e_pend && t < t_pend_exp && (*plen = msg_open(v, &k_pend, pt)) >= 0) return G_PEND;
  return G_NONE;
}

static void
rx(struct simple_udp_connection *c, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
   const uint8_t *data, uint16_t len)
{
  msg_view_t v; int g, plen = -1;
  if(!g_configured || addr_node(sa) != cc) return;
  if(rx_drop(cc)) return;
  if(msg_parse(data, len, &v) < 0) return;
  if(IS_RE(v.type)) {                                     /* re-establishment (models an EDHOC run) */
    tos_keys_t kb; boot_keys(cc, me, 0, &kb);
    if((plen = msg_open(&v, &kb, pt)) < 3) return;
    if(v.type == T_RE1) {
      static uint32_t bseq; uint8_t r2[45]; memset(r2, 0, sizeof r2); r2[0] = pt[0]; r2[1] = pt[1]; r2[2] = pt[2];
      send_msg(T_RE2, 0, &kb, &bseq, r2, sizeof r2);
    } else if(v.type == T_RE3) {
      uint16_t rn = (uint16_t)((pt[0] << 8) | pt[1]); uint16_t en = (uint16_t)((pt[2] << 8) | pt[3]);
      if(rn <= reest_no && reest_no) return;
      reest_no = rn;
      pair_root(cc, me, reest_no, ms_act); e_act = en; epoch_keys(ms_act, e_act, cc, me, 0, &k_act);
      seq_act = 0; memset(&rw_act, 0, sizeof rw_act); prev_valid = 0; pend_valid = 0;
      TLOG("REEST_DONE", "role=cl,p=%u,e=%u,rn=%u", me, e_act, reest_no);
    }
    return;
  }
  g = open_any(&v, &plen);
  if(g == G_NONE || g < 0) { n_rxbad++; TLOG("RXREJ", "role=cl,p=%u,type=%c,e=%u,act=%u", me, v.type, v.epoch, e_act); return; }
  if(g == G_PEND) { commit(v.type == T_CONFIRM ? "normal" : "fwd"); if(v.type == T_CONFIRM) return; }
  switch(v.type) {
  case T_DACK: n_ack++; if(plen >= 3) { if(pt[2]) n_acc++; else n_rej++; } break;
  case T_INIT: {
    uint16_t en = (uint16_t)((pt[0] << 8) | pt[1]); uint8_t a[2];
    if(g != G_ACT || en != (uint16_t)(e_act + 1) || en == 0) break;
    if(!pend_valid || e_pend != en) {
      ratchet_ms(ms_act, en, ms_pend); epoch_keys(ms_pend, en, cc, me, 0, &k_pend);
      pend_valid = 1; e_pend = en; t_pend_exp = now_s() + T_PEND_PEER_S;
      TLOG("PREPARE", "role=cl,p=%u,e=%u", me, en);
    }
    a[0] = (uint8_t)(en >> 8); a[1] = (uint8_t)en;
    send_msg(T_ACK, en, &k_pend, &ack_seq, a, 2);
    break;
  }
  case T_ABORT: {
    uint16_t en = (uint16_t)((pt[0] << 8) | pt[1]);
    if(pend_valid && e_pend == en) { pend_valid = 0; memset(ms_pend, 0, 16); TLOG("PEND_ABORT", "role=cl,p=%u,e=%u", me, en); }
    break;
  }
  default: break;
  }
}

PROCESS_THREAD(client_process, ev, data)
{
  static struct etimer tick;
  static uint32_t next_report, next_cnt;
  PROCESS_BEGIN();
  trace_common_init();
  PROCESS_WAIT_EVENT_UNTIL(ev == g_cfg_event);
  me = (uint8_t)node_id; cc = tt_node[me].cc;
  node_addr(cc, &cc_addr);
  simple_udp_register(&conn, PORT_CLIENT, NULL, PORT_CC, rx);
  pair_root(cc, me, 0, ms_act); e_act = 1; epoch_keys(ms_act, e_act, cc, me, 0, &k_act);
  next_report = 120 + rnd() % REPORT_PERIOD_S;
  next_cnt = 1800;
  etimer_set(&tick, CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&tick));
    etimer_reset(&tick);
    {
      uint32_t t = now_s();
      uint16_t period = s8_period(me, t), sl = s8_sleep_left(me, t);
      beh_t b; behaviour(me, t, &b);
      if(pend_valid && t >= t_pend_exp) { pend_valid = 0; memset(ms_pend, 0, 16); TLOG("PEND_EXPIRE", "role=cl,p=%u,e=%u", me, e_pend); }
      if(prev_valid && t >= t_commit + T_OVERLAP_S + T_DEPR_S) { prev_valid = 0; memset(&k_prev, 0, sizeof k_prev); }
      if(t % 60 == (uint32_t)(node_id % 60)) log_routing();
      if(sl > 0) {
        if(!sleep_announced) { send_report(period, sl, &b); sleep_announced = 1; }   /* announced sleep */
        next_report = t + 1;
      } else {
        if(sleep_announced) { sleep_announced = 0; next_report = t; }
        if(t >= next_report) {
          send_report(period, 0, &b);
          next_report += b.rate_mult > 1 ? (uint32_t)(period / b.rate_mult) : period;   /* S3: 3x the announced rate */
        }
      }
      if(t >= next_cnt) {
        log_counters();
        TLOG("CLSTAT", "p=%u,sent=%lu,supp=%lu,noncomp=%lu,ack=%lu,acc=%lu,rej=%lu,rxbad=%lu,e=%u", me, (unsigned long)n_sent,
             (unsigned long)n_supp, (unsigned long)n_noncomp, (unsigned long)n_ack, (unsigned long)n_acc, (unsigned long)n_rej,
             (unsigned long)n_rxbad, e_act);
        next_cnt += 1800;
      }
    }
  }
  PROCESS_END();
}
