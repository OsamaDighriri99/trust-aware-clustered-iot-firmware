/* TRACE revision build -- Random-Forest evaluation. See trace_rf.h. */
#include "trace_rf.h"
#if defined(RF_ONLY_DET)          /* Z1 benchmark builds: one model per image (flash) */
const rf_model_t rf_cur = { 0, 0, 0, 0, 0, 0, 0, 0, "none" }, rf_ant = { 0, 0, 0, 0, 0, 0, 0, 0, "none" };
#include "rf_model_det.h"
#elif defined(RF_ONLY_CUR)
const rf_model_t rf_ant = { 0, 0, 0, 0, 0, 0, 0, 0, "none" }, rf_det = { 0, 0, 0, 0, 0, 0, 0, 0, "none" };
const uint8_t rf_det_k = 26;
#include "rf_model_cur.h"
#elif defined(RF_ONLY_ANT)
const rf_model_t rf_cur = { 0, 0, 0, 0, 0, 0, 0, 0, "none" }, rf_det = { 0, 0, 0, 0, 0, 0, 0, 0, "none" };
const uint8_t rf_det_k = 26;
#include "rf_model_ant.h"
#else
#include "rf_model_cur.h"
#include "rf_model_ant.h"
#include "rf_model_det.h"
#endif
int
rf_predict(const rf_model_t *m, const int16_t q[8], uint8_t *v1, uint8_t *v2)
{
  uint8_t votes[4] = { 0, 0, 0, 0 }, t; int c, best = -1, a = 0, b = 0;
  if(!m || m->n_trees == 0) return -1;
  for(t = 0; t < m->n_trees; t++) {
    uint16_t n = m->root[t];
    while(m->feat[n] >= 0) n = (q[m->feat[n]] <= m->thr[n]) ? m->left[n] : m->right[n];
    votes[m->leaf[n] & 3]++;
  }
  for(c = 0; c < 4; c++) if(votes[c] >= a) { b = a; a = votes[c]; best = c; } else if(votes[c] > b) b = votes[c];
  if(v1) *v1 = (uint8_t)a;
  if(v2) *v2 = (uint8_t)b;
  return best;
}
int
rf_votes_for(const rf_model_t *m, const int16_t q[8], uint8_t c)
{
  uint8_t t; int v = 0;
  if(!m || m->n_trees == 0) return -1;
  for(t = 0; t < m->n_trees; t++) {
    uint16_t n = m->root[t];
    while(m->feat[n] >= 0) n = (q[m->feat[n]] <= m->thr[n]) ? m->left[n] : m->right[n];
    v += (m->leaf[n] == c);
  }
  return v;
}
