/* TRACE unified build -- shared runtime. See trace_common.h. */
#include "trace_common.h"
#include "dev/serial-line.h"
#include "net/routing/rpl-classic/rpl.h"
#include <string.h>
#include <stdlib.h>

const char *const scn_name[SCN_N] = { "NOM", "S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8", "OUT", "NF" };
char     g_run_id[48] = "UNCONFIGURED";
uint8_t  g_scn = SCN_NOM, g_pol = 0, g_model = 0, g_dwell = 4, g_standby = 1, g_sectest = 0;
uint32_t g_seed = 1, g_sim_end_s = 39600;
uint8_t  g_configured = 0;
process_event_t g_cfg_event;
uint32_t g_tx_pkts[TC_N], g_tx_bytes[TC_N];

uint64_t now_us(void) { return (uint64_t)RTIMER_NOW(); }   /* Cooja native: 1 tick = 1 us of simulated time */

/* ---------------- PRNG (xorshift32): per-node stream and a shared schedule stream ---------------- */
static uint32_t rs = 1, ss = 1;
static uint32_t xs(uint32_t *s) { *s ^= *s << 13; *s ^= *s >> 17; *s ^= *s << 5; return *s; }
void
rnd_init(void)
{
  int i;
  rs = (g_seed * 2654435761u) ^ ((uint32_t)node_id * 40503u) ^ 0x9E3779B9u; if(!rs) rs = 1;
  for(i = 0; i < 8; i++) xs(&rs);
}
uint32_t rnd(void) { return xs(&rs); }
float rndf(void) { return (float)(rnd() >> 8) / 16777216.0f; }
void rnd_bytes(uint8_t *b, uint16_t n) { while(n--) *b++ = (uint8_t)(rnd() >> 11); }
static uint32_t sx(void) { return xs(&ss); }

void node_addr(uint8_t id, uip_ipaddr_t *a) { uip_ip6addr(a, 0xfd00, 0, 0, 0, 0x0200 | id, id, id, id); }
uint8_t addr_node(const uip_ipaddr_t *a) { return a->u8[15]; }

/* ---------------- schedules ---------------- */
wave_t   g_wave[WAVE_N];
uint8_t  g_adv[ADV_N];
uint8_t  g_burst_cl[BURST_N]; uint16_t g_burst_phase[BURST_N]; uint8_t g_burst_len[BURST_N];
uint8_t  g_sleep_cl[SLEEP_N]; uint16_t g_sleep_phase[SLEEP_N];
uint8_t  g_mob_cl[MOB_N];
uint16_t g_s7_loss[32];

static int used_cl[TT_NODES + 1];
static uint8_t
pick_client(int from_cc)       /* unused client, optionally of a given CC */
{
  uint8_t c;
  do {
    c = from_cc ? tt_members[from_cc - TT_FIRST_CC][sx() % 10] : (uint8_t)(TT_FIRST_CLIENT + sx() % TT_NCL);
  } while(used_cl[c]);
  used_cl[c] = 1;
  return c;
}

void
schedules_build(void)
{
  int w, i;
  ss = (g_seed * 2246822519u) ^ 0x7ACE5EEDu; if(!ss) ss = 1;
  for(i = 0; i < 8; i++) sx();
  memset(used_cl, 0, sizeof used_cl);
  for(w = 0; w < WAVE_N; w++) {
    wave_t *v = &g_wave[w];
    v->onset = WAVE_FIRST + (uint32_t)w * WAVE_GAP + (sx() % 120);
    if(g_scn == SCN_S5) {                                  /* 3 clients of one cluster */
      int k = TT_FIRST_CC + (int)(sx() % TT_NCC), free = 0;
      for(i = 0; i < 10; i++) free += !used_cl[tt_members[k - TT_FIRST_CC][i]];
      while(free < 3) { k = TT_FIRST_CC + (int)(sx() % TT_NCC); free = 0; for(i = 0; i < 10; i++) free += !used_cl[tt_members[k - TT_FIRST_CC][i]]; }
      v->n = 3; for(i = 0; i < 3; i++) v->cl[i] = pick_client(k);
    } else {                                               /* 5 clients of 5 different clusters */
      uint8_t ccs[TT_NCC] = { 0 };
      v->n = WAVE_CL;
      for(i = 0; i < WAVE_CL; i++) {
        int k, free, j;
        do {
          k = TT_FIRST_CC + (int)(sx() % TT_NCC); free = 0;
          for(j = 0; j < 10; j++) free += !used_cl[tt_members[k - TT_FIRST_CC][j]];
        } while(ccs[k - TT_FIRST_CC] || free == 0);
        ccs[k - TT_FIRST_CC] = 1; v->cl[i] = pick_client(k);
      }
    }
  }
  memset(used_cl, 0, sizeof used_cl);
  { uint8_t ccs[TT_NCC] = { 0 };
    for(i = 0; i < ADV_N; i++) { int k; do { k = TT_FIRST_CC + (int)(sx() % TT_NCC); } while(ccs[k - TT_FIRST_CC]); ccs[k - TT_FIRST_CC] = 1; g_adv[i] = pick_client(k); } }
  for(i = 0; i < BURST_N; i++) { g_burst_cl[i] = pick_client(0); g_burst_phase[i] = (uint16_t)(sx() % 900); g_burst_len[i] = (uint8_t)(3 + sx() % 3); }
  for(i = 0; i < SLEEP_N; i++) { g_sleep_cl[i] = pick_client(0); g_sleep_phase[i] = (uint16_t)(sx() % 3000); }
  for(i = 0; i < 32; i++) g_s7_loss[i] = (uint16_t)(50 + sx() % 301);
}

void
schedules_log(void)
{
  int w, i; char b[160]; int n;
  if(g_scn == SCN_S1 || g_scn == SCN_S5 || g_scn == SCN_OUT || g_scn == SCN_NF)
    for(w = 0; w < WAVE_N; w++) {
      n = 0; for(i = 0; i < g_wave[w].n; i++) n += snprintf(b + n, sizeof b - n, "%u;", g_wave[w].cl[i]);
      TLOG("WAVE", "w=%d,onset=%lu,len=%u,clients=%s", w, (unsigned long)g_wave[w].onset, WAVE_LEN, b);
    }
  if(g_scn == SCN_S3 || g_scn == SCN_S4) {
    n = 0; for(i = 0; i < ADV_N; i++) n += snprintf(b + n, sizeof b - n, "%u;", g_adv[i]);
    TLOG("ADV", "start=%u,clients=%s", ADV_START, b);
  }
  if(g_scn == SCN_S2) for(i = 0; i < BURST_N; i++) TLOG("BURST", "p=%u,phase=%u,len=%u", g_burst_cl[i], g_burst_phase[i], g_burst_len[i]);
  if(g_scn == SCN_S8) for(i = 0; i < SLEEP_N; i++) TLOG("SLEEPCL", "p=%u,phase=%u", g_sleep_cl[i], g_sleep_phase[i]);
  if(g_scn == SCN_S7) for(i = 0; i < 32; i++) TLOG("S7LOSS", "slot=%d,loss=%u", i, g_s7_loss[i]);
  if(g_scn == SCN_OUT) TLOG("OUTAGE", "er=1,start=%u,end=%u,standby=%u", OUT_START, OUT_END, g_standby);
  if(g_scn == SCN_NF) TLOG("NODEFAIL", "er=1,start=%u,standby=%u", OUT_START, g_standby);
}

static int idx_of(const uint8_t *a, int n, uint8_t c) { int i; for(i = 0; i < n; i++) if(a[i] == c) return i; return -1; }

void
behaviour(uint8_t c, uint32_t t, beh_t *b)
{
  int w, i;
  b->deliver = 1.0f; b->comply = 1.0f; b->rate_mult = 1; b->in_episode = 0;
  switch(g_scn) {
  case SCN_S1: case SCN_S5: case SCN_OUT: case SCN_NF:
    for(w = 0; w < WAVE_N; w++) if(t >= g_wave[w].onset && t < g_wave[w].onset + WAVE_LEN)
      for(i = 0; i < g_wave[w].n; i++) if(g_wave[w].cl[i] == c) {
        float k = (float)((t - g_wave[w].onset) / CYCLE_S), v = 1.0f - DEG_RATE * k;
        if(v < 0.0f) v = 0.0f;
        b->deliver = v; b->comply = v; b->in_episode = 1;
      }
    break;
  case SCN_S2:
    if((i = idx_of(g_burst_cl, BURST_N, c)) >= 0 && t >= ADV_START &&
       ((t + 900 - g_burst_phase[i]) % 900) < (uint32_t)g_burst_len[i] * CYCLE_S) { b->deliver = 0.6f; b->in_episode = 1; }
    break;
  case SCN_S3: if(idx_of(g_adv, ADV_N, c) >= 0 && t >= ADV_START) { b->rate_mult = 3; b->in_episode = 1; } break;
  case SCN_S4: if(idx_of(g_adv, ADV_N, c) >= 0 && t >= ADV_START) { b->deliver = 0.45f; b->in_episode = 1; } break;
  default: break;
  }
}

uint16_t
s8_period(uint8_t c, uint32_t t)
{
  static const uint16_t per[4] = { 15, 30, 45, 60 };
  uint32_t h;
  if(g_scn != SCN_S8 || t < 1800) return REPORT_PERIOD_S;
  h = (uint32_t)c * 2654435761u ^ (t / 1800) * 40503u ^ g_seed * 97u;
  h ^= h >> 15; h *= 2246822519u; h ^= h >> 13;
  return per[h % 4];
}
uint16_t
s8_sleep_left(uint8_t c, uint32_t t)
{
  int i;
  if(g_scn != SCN_S8 || t < 3600 || (i = idx_of(g_sleep_cl, SLEEP_N, c)) < 0) return 0;
  { uint32_t ph = (t + 3600 - g_sleep_phase[i]) % 3600; return ph < 600 ? (uint16_t)(600 - ph) : 0; }
}

int er_down(uint8_t er, uint32_t t) { return g_scn == SCN_OUT && er == TT_ER && t >= OUT_START && t < OUT_END; }
int er_node_failed(uint8_t er, uint32_t t) { return g_scn == SCN_NF && er == TT_ER && t >= OUT_START; }

int
rx_drop(uint8_t from)
{
  uint32_t t = now_s();
  float p;
  if(g_scn != SCN_S7) return 0;
  if(!((tt_node[node_id].role == TT_CC && tt_node[from].role == TT_CLIENT) || (tt_node[node_id].role == TT_CLIENT && tt_node[from].role == TT_CC)))
    return 0;
  p = g_s7_loss[(t / 1800) % 32] / 1000.0f;
  return rndf() < p;
}

void count_tx(uint8_t cls, uint16_t len) { g_tx_pkts[cls]++; g_tx_bytes[cls] += len; }
void
log_counters(void)
{
  TLOG("CNT", "app_p=%lu,app_b=%lu,desc_p=%lu,desc_b=%lu,asg_p=%lu,asg_b=%lu,life_p=%lu,life_b=%lu,ctl_p=%lu,ctl_b=%lu",
       (unsigned long)g_tx_pkts[TC_APP], (unsigned long)g_tx_bytes[TC_APP], (unsigned long)g_tx_pkts[TC_DESC], (unsigned long)g_tx_bytes[TC_DESC],
       (unsigned long)g_tx_pkts[TC_ASSIGN], (unsigned long)g_tx_bytes[TC_ASSIGN], (unsigned long)g_tx_pkts[TC_LIFE], (unsigned long)g_tx_bytes[TC_LIFE],
       (unsigned long)g_tx_pkts[TC_CTL], (unsigned long)g_tx_bytes[TC_CTL]);
}
void
log_routing(void)
{
  rpl_dag_t *d = rpl_get_any_dag();
  rpl_parent_t *pp = d ? d->preferred_parent : NULL;
  const uip_ipaddr_t *pa = pp ? rpl_parent_get_ipaddr(pp) : NULL;
  TLOG("RT", "ver=%u,rank=%u,pp=%u", d ? d->version : 0, d ? d->rank : 0xFFFF, pa ? pa->u8[15] : 0);
}

/* ---------------- configuration over serial ---------------- */
PROCESS(trace_cfg_process, "TRACE config");
static void
parse_cfg(const char *line)
{
  /* "TRACECFG run=<id> scn=<n> seed=<n> pol=<0|1> model=<0..3> dwell=<cycles> end=<s> sb=<0|1> sec=<0|1>" */
  const char *p;
  if(strncmp(line, "TRACECFG", 8) != 0 || g_configured) return;
  p = strstr(line, "run=");  if(p) { int i = 0; p += 4; while(*p && *p != ' ' && i < (int)sizeof(g_run_id) - 1) g_run_id[i++] = *p++; g_run_id[i] = 0; }
  p = strstr(line, "scn=");  if(p) g_scn = (uint8_t)atoi(p + 4);
  p = strstr(line, "seed="); if(p) g_seed = (uint32_t)strtoul(p + 5, NULL, 10);
  p = strstr(line, "pol=");  if(p) g_pol = (uint8_t)atoi(p + 4);
  p = strstr(line, "model="); if(p) g_model = (uint8_t)atoi(p + 6);
  p = strstr(line, "dwell="); if(p) g_dwell = (uint8_t)atoi(p + 6);
  p = strstr(line, "end=");  if(p) g_sim_end_s = (uint32_t)strtoul(p + 4, NULL, 10);
  p = strstr(line, "sb=");   if(p) g_standby = (uint8_t)atoi(p + 3);
  p = strstr(line, "sec=");  if(p) g_sectest = (uint8_t)atoi(p + 4);
  if(g_scn >= SCN_N) g_scn = SCN_NOM;
  g_configured = 1;
  rnd_init();
  schedules_build();
  printf("CFG,n=%u,run=%s,scn=%s,seed=%lu,pol=%u,model=%u,dwell=%u,sb=%u,sec=%u,cal=%s,rf_cur=%s,rf_ant=%s,rf_det=%s,k=%u\n", (unsigned)node_id, g_run_id,
         scn_name[g_scn], (unsigned long)g_seed, (unsigned)g_pol, (unsigned)g_model, (unsigned)g_dwell, (unsigned)g_standby, (unsigned)g_sectest,
         tr_cal_id, rf_cur.id, rf_ant.id, rf_det.id, rf_det_k);
  process_post(PROCESS_BROADCAST, g_cfg_event, NULL);
}
PROCESS_THREAD(trace_cfg_process, ev, data)
{
  static struct etimer bt;
  PROCESS_BEGIN();
  printf("BOOT,n=%u,role=%u\n", (unsigned)node_id, (unsigned)tt_node[node_id].role);
  etimer_set(&bt, CLOCK_SECOND * 2);
  while(1) {
    PROCESS_WAIT_EVENT();
    if(ev == serial_line_event_message && data) parse_cfg((const char *)data);
    else if(ev == PROCESS_EVENT_TIMER && data == &bt && !g_configured) {
      printf("BOOT,n=%u,role=%u\n", (unsigned)node_id, (unsigned)tt_node[node_id].role);
      etimer_reset(&bt);
    }
  }
  PROCESS_END();
}
void trace_common_init(void) { g_cfg_event = process_alloc_event(); process_start(&trace_cfg_process, NULL); }
