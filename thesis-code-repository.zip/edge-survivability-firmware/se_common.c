/* SurvivEdge revision build -- shared runtime. See se_common.h. */
#include "se_common.h"
#include "dev/serial-line.h"
#include <string.h>
#include <stdlib.h>
#include "se_params.h"

const char *const sc_name[SC_N] = { "A0", "A0L", "A1", "A2", "A3", "A4", "A5", "A6", "A7", "X1", "X2", "X3", "X4", "X5", "X6" };
const char *const base_name[BASE_N] = { "SE", "B1", "B2", "B3", "B4", "SHADOW" };
char     g_run_id[48] = "UNCONFIGURED";
uint8_t  g_sc = SC_A0, g_base = BASE_SE, g_er2 = 0, g_k = 1, g_dwell = 4;
uint32_t g_seed = 1, g_sim_end_s = 39600, g_onset = 10800;
uint8_t  g_configured = 0;
process_event_t g_cfg_event;
uint32_t g_tx_pkts[TC_N], g_tx_bytes[TC_N];
uint8_t g_er1_beh, g_bz_flags, g_nbyz, g_byz[8], g_f, g_q;
uint8_t g_a5_cl[24], g_a5_n;
float g_th_r = SE_TH_R, g_th_d = SE_TH_D, g_th_m = SE_TH_M; uint8_t g_agim_k = SE_AGIM_K, g_down_p = SE_DOWN_P;

uint64_t now_us(void) { return (uint64_t)RTIMER_NOW(); }   /* Cooja native: 1 tick = 1 us of simulated time */

/* ---------------- PRNG (xorshift32): per-node stream and a shared schedule stream ---------------- */
static uint32_t rs = 1, ss = 1;
static uint32_t xs(uint32_t *s) { *s ^= *s << 13; *s ^= *s >> 17; *s ^= *s << 5; return *s; }
void
rnd_init(void)
{
  int i;
  rs = (g_seed * 2654435761u) ^ ((uint32_t)node_id * 40503u) ^ 0x9E3779B9u; if(!rs) rs = 1;
  for(i = 0; i < 8; i++) xs(&rs);
}
uint32_t rnd(void) { return xs(&rs); }
float rndf(void) { return (float)(rnd() >> 8) / 16777216.0f; }
void rnd_bytes(uint8_t *b, uint16_t n) { while(n--) *b++ = (uint8_t)(rnd() >> 11); }
static uint32_t sx(void) { return xs(&ss); }

void node_addr(uint8_t id, uip_ipaddr_t *a) { uip_ip6addr(a, 0xfd00, 0, 0, 0, 0x0200 | id, id, id, id); }
uint8_t addr_node(const uip_ipaddr_t *a) { return a->u8[15]; }

float
cl_hash(uint8_t c)
{
  uint32_t h = (uint32_t)c * 2654435761u ^ g_seed * 2246822519u ^ 0x5EEDu;
  h ^= h >> 15; h *= 2246822519u; h ^= h >> 13; h *= 3266489917u; h ^= h >> 16;
  return (float)(h >> 8) / 16777216.0f;
}

int is_byz(uint8_t cc) { int i; for(i = 0; i < g_nbyz; i++) if(g_byz[i] == cc) return 1; return 0; }

/* ---------------- schedules ---------------- */
wave_t   g_wave[WAVE_N];
uint16_t g_loss[32];
static int used_cl[TT_NODES + 1];
static uint8_t
pick_client(int cc)
{
  uint8_t c;
  do {
    c = cc ? tt_members[cc - TT_FIRST_CC][sx() % TT_CPC] : (uint8_t)(TT_FIRST_CLIENT + sx() % TT_NCL);
  } while(used_cl[c]);
  used_cl[c] = 1;
  return c;
}

void
schedules_build(void)
{
  int w, i;
  ss = (g_seed * 2246822519u) ^ 0x5E5EED11u; if(!ss) ss = 1;
  for(i = 0; i < 8; i++) sx();
  memset(used_cl, 0, sizeof used_cl);
  for(w = 0; w < WAVE_N; w++) {                       /* 5 clients of 5 different clusters per wave */
    wave_t *v = &g_wave[w]; uint8_t ccs[TT_NCC]; int nw = TT_NCC < WAVE_CL ? TT_NCC : WAVE_CL;
    memset(ccs, 0, sizeof ccs);
    v->onset = WAVE_FIRST + (uint32_t)w * WAVE_GAP + (sx() % 120);
    v->n = (uint8_t)nw;
    for(i = 0; i < nw; i++) {
      int k, free, j;
      do {
        k = TT_FIRST_CC + (int)(sx() % TT_NCC); free = 0;
        for(j = 0; j < TT_CPC; j++) free += !used_cl[tt_members[k - TT_FIRST_CC][j]];
        if(free == 0) { int z; for(z = 0; z < TT_NCL; z++) used_cl[TT_FIRST_CLIENT + z] = 0; free = 1; }
      } while(ccs[k - TT_FIRST_CC]);
      ccs[k - TT_FIRST_CC] = 1; v->cl[i] = pick_client(k);
    }
  }
  for(i = 0; i < 32; i++) g_loss[i] = (uint16_t)(50 + sx() % 301);
  /* Byzantine CC set: f distinct CCs */
  g_f = (uint8_t)((TT_NCC - 1) / 3); g_q = (uint8_t)((TT_NCC + g_f + 2) / 2);
  g_nbyz = 0;
  if(g_sc == SC_A4 || g_sc == SC_A6 || (g_sc >= SC_X1 && g_sc <= SC_X6)) {
    while(g_nbyz < g_f) { uint8_t c = (uint8_t)(TT_FIRST_CC + sx() % TT_NCC); if(!is_byz(c)) g_byz[g_nbyz++] = c; }
  } else { for(i = 0; i < g_f; i++) sx(); }
  /* A5 targets: g_k healthy-at-onset candidates from one cluster (two clusters for k > TT_CPC) */
  g_a5_n = 0;
  { int k0 = TT_FIRST_CC + (int)(sx() % TT_NCC), kk = k0, j;
    while(g_a5_n < g_k && g_a5_n < 24) {
      for(j = 0; j < TT_CPC && g_a5_n < g_k; j++) g_a5_cl[g_a5_n++] = tt_members[kk - TT_FIRST_CC][j];
      kk = TT_FIRST_CC + ((kk - TT_FIRST_CC + 1) % TT_NCC);
      if(kk == k0) break;
    } }
  switch(g_sc) {
  case SC_A1: g_er1_beh = BEH_A1; break;
  case SC_A2: g_er1_beh = BEH_SILENT; break;
  case SC_A3: case SC_A4: case SC_X1: case SC_X2: case SC_X3: case SC_X4: case SC_X5: case SC_X6: g_er1_beh = BEH_A3; break;
  case SC_A5: g_er1_beh = BEH_A5; break;
  case SC_A7: g_er1_beh = BEH_FWDDROP; break;
  default: g_er1_beh = BEH_NONE;
  }
  switch(g_sc) {
  case SC_A4: g_bz_flags = BZ_SUPPRESS | BZ_EQUIV | BZ_SELFNOM | BZ_FALSEDIG; break;
  case SC_A6: g_bz_flags = BZ_ACCUSE | BZ_EQUIV | BZ_SELFNOM; break;
  case SC_X1: g_bz_flags = BZ_SUPPRESS | BZ_SELFNOM; break;
  case SC_X2: g_bz_flags = BZ_SUPPRESS | BZ_EQUIV; break;
  case SC_X3: case SC_X4: case SC_X5: g_bz_flags = BZ_SUPPRESS | BZ_WITHHOLD; break;
  case SC_X6: g_bz_flags = BZ_SUPPRESS | BZ_HONESTV; break;
  default: g_bz_flags = 0;
  }
}

void
schedules_log(void)
{
  int w, i; char b[160]; int n;
  for(w = 0; w < WAVE_N; w++) {
    n = 0; for(i = 0; i < g_wave[w].n; i++) n += snprintf(b + n, sizeof b - n, "%u;", g_wave[w].cl[i]);
    TLOG("WAVE", "w=%d,onset=%lu,len=%u,clients=%s", w, (unsigned long)g_wave[w].onset, WAVE_LEN, b);
  }
  n = 0; b[0] = 0; for(i = 0; i < g_nbyz; i++) n += snprintf(b + n, sizeof b - n, "%u;", g_byz[i]);
  TLOG("SCEN", "sc=%s,base=%s,er2=%u,onset=%lu,beh=%u,bz=%u,byz=%s,f=%u,q=%u,ncc=%u", sc_name[g_sc], base_name[g_base], g_er2,
       (unsigned long)g_onset, g_er1_beh, g_bz_flags, b, g_f, g_q, TT_NCC);
  if(g_sc == SC_A5) { n = 0; b[0] = 0; for(i = 0; i < g_a5_n; i++) n += snprintf(b + n, sizeof b - n, "%u;", g_a5_cl[i]); TLOG("A5SET", "k=%u,clients=%s", g_a5_n, b); }
  if(g_sc == SC_A0L) for(i = 0; i < 32; i++) TLOG("LOSS", "slot=%d,loss=%u", i, g_loss[i]);
}

void
behaviour(uint8_t c, uint32_t t, beh_t *b)
{
  int w, i;
  b->deliver = 1.0f; b->comply = 1.0f; b->in_episode = 0;
  for(w = 0; w < WAVE_N; w++) if(t >= g_wave[w].onset && t < g_wave[w].onset + WAVE_LEN)
    for(i = 0; i < g_wave[w].n; i++) if(g_wave[w].cl[i] == c) {
      float k = (float)((t - g_wave[w].onset) / CYCLE_S), v = 1.0f - DEG_RATE * k;
      if(v < 0.0f) v = 0.0f;
      b->deliver = v; b->comply = v; b->in_episode = 1;
    }
}

int
rx_drop_app(uint8_t from)
{
  if(g_sc != SC_A0L) return 0;
  if(!((tt_node[node_id].role == TT_CC && tt_node[from].role == TT_CLIENT) || (tt_node[node_id].role == TT_CLIENT && tt_node[from].role == TT_CC)))
    return 0;
  return rndf() < g_loss[(now_s() / 1800) % 32] / 1000.0f;
}

int
rx_drop_overlay(uint8_t from)
{
  uint32_t t = now_s();
  int a, b;
  if(g_sc != SC_X5 || t < g_onset || t >= g_onset + 600) return 0;
  if(tt_node[node_id].role != TT_CC || tt_node[from].role != TT_CC) return 0;
  a = (node_id - TT_FIRST_CC) < TT_NCC / 2; b = (from - TT_FIRST_CC) < TT_NCC / 2;
  return a != b;
}

uint8_t
cand_of(uint16_t term, const uint8_t *dep)
{
  uint8_t L[TT_NCC + 1], n = 0, i;
#define DEP(x) (dep[(x) >> 3] & (1 << ((x) & 7)))
  if(g_sc == SC_X6) for(i = 0; i < g_nbyz; i++) if(!DEP(g_byz[i])) L[n++] = g_byz[i];
  if(!DEP(TT_STANDBY)) L[n++] = TT_STANDBY;
  for(i = 0; i < TT_NCC; i++) {
    uint8_t c = (uint8_t)(TT_FIRST_CC + i);
    if(DEP(c) || (g_sc == SC_X6 && is_byz(c))) continue;
    L[n++] = c;
  }
#undef DEP
  if(n == 0 || term == 0) return 0;
  return L[(term - 1) % n];
}

void count_tx(uint8_t cls, uint16_t len) { g_tx_pkts[cls]++; g_tx_bytes[cls] += len; }
void
log_counters(void)
{
  TLOG("CNT", "app=%lu/%lu,rot=%lu/%lu,desc=%lu/%lu,asg=%lu/%lu,stat=%lu/%lu,vote=%lu/%lu,take=%lu/%lu,hb=%lu/%lu",
       (unsigned long)g_tx_pkts[TC_APP], (unsigned long)g_tx_bytes[TC_APP], (unsigned long)g_tx_pkts[TC_ROT], (unsigned long)g_tx_bytes[TC_ROT],
       (unsigned long)g_tx_pkts[TC_DESC], (unsigned long)g_tx_bytes[TC_DESC], (unsigned long)g_tx_pkts[TC_ASSIGN], (unsigned long)g_tx_bytes[TC_ASSIGN],
       (unsigned long)g_tx_pkts[TC_STAT], (unsigned long)g_tx_bytes[TC_STAT], (unsigned long)g_tx_pkts[TC_VOTE], (unsigned long)g_tx_bytes[TC_VOTE],
       (unsigned long)g_tx_pkts[TC_TAKE], (unsigned long)g_tx_bytes[TC_TAKE], (unsigned long)g_tx_pkts[TC_HB], (unsigned long)g_tx_bytes[TC_HB]);
}

/* ---------------- configuration over serial ---------------- */
PROCESS(se_cfg_process, "SurvivEdge config");
static void
parse_cfg(const char *line)
{
  /* "SECFG run=<id> sc=<n> seed=<n> base=<n> er2=<n> k=<n> onset=<s> end=<s>" */
  const char *p;
  if(strncmp(line, "SECFG", 5) != 0 || g_configured) return;
  p = strstr(line, "run=");   if(p) { int i = 0; p += 4; while(*p && *p != ' ' && i < (int)sizeof(g_run_id) - 1) g_run_id[i++] = *p++; g_run_id[i] = 0; }
  p = strstr(line, " sc=");   if(p) g_sc = (uint8_t)atoi(p + 4);
  p = strstr(line, "seed=");  if(p) g_seed = (uint32_t)strtoul(p + 5, NULL, 10);
  p = strstr(line, "base=");  if(p) g_base = (uint8_t)atoi(p + 5);
  p = strstr(line, "er2=");   if(p) g_er2 = (uint8_t)atoi(p + 4);
  p = strstr(line, " k=");    if(p) g_k = (uint8_t)atoi(p + 3);
  p = strstr(line, "onset="); if(p) g_onset = (uint32_t)strtoul(p + 6, NULL, 10);
  p = strstr(line, "end=");   if(p) g_sim_end_s = (uint32_t)strtoul(p + 4, NULL, 10);
  if(g_sc >= SC_N) g_sc = SC_A0;
  if(g_base >= BASE_N) g_base = BASE_SE;
  g_configured = 1;
  rnd_init();
  schedules_build();
  printf("CFG,n=%u,run=%s,sc=%s,seed=%lu,base=%s,er2=%u,k=%u,onset=%lu,cal=%s,det=%s,dk=%u,agim=%s\n", (unsigned)node_id, g_run_id,
         sc_name[g_sc], (unsigned long)g_seed, base_name[g_base], g_er2, g_k, (unsigned long)g_onset, tr_cal_id, rf_det.id, rf_det_k, SE_PARAMS_ID);
  process_post(PROCESS_BROADCAST, g_cfg_event, NULL);
}
PROCESS_THREAD(se_cfg_process, ev, data)
{
  static struct etimer bt;
  PROCESS_BEGIN();
  printf("BOOT,n=%u,role=%u\n", (unsigned)node_id, (unsigned)tt_node[node_id].role);
  etimer_set(&bt, CLOCK_SECOND * 2);
  while(1) {
    PROCESS_WAIT_EVENT();
    if(ev == serial_line_event_message && data) parse_cfg((const char *)data);
    else if(ev == PROCESS_EVENT_TIMER && data == &bt && !g_configured) {
      printf("BOOT,n=%u,role=%u\n", (unsigned)node_id, (unsigned)tt_node[node_id].role);
      etimer_reset(&bt);
    }
  }
  PROCESS_END();
}
void se_common_init(void) { g_cfg_event = process_alloc_event(); process_start(&se_cfg_process, NULL); }
