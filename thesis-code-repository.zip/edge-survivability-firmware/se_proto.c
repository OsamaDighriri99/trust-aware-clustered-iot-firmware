/* SurvivEdge revision build -- message payloads. See se_proto.h. */
#include "se_proto.h"
#include "tarp_crypto.h"
#include <string.h>

static void put16(uint8_t *p, uint16_t x) { p[0] = (uint8_t)(x >> 8); p[1] = (uint8_t)x; }
static uint16_t get16(const uint8_t *p) { return (uint16_t)((p[0] << 8) | p[1]); }

#define DB_E 21
int
db_encode(const db_t *b, uint8_t *out)
{
  int n = 0, i, j;
  out[n++] = b->cc; put16(out + n, b->batch); n += 2; put16(out + n, (uint16_t)b->ref); n += 2; out[n++] = b->n;
  for(i = 0; i < b->n; i++) {
    out[n++] = b->e[i].slot; out[n++] = b->e[i].flags;
    for(j = 0; j < 8; j++) { put16(out + n, (uint16_t)b->e[i].d.q[j]); n += 2; }
    put16(out + n, b->e[i].rot_age); n += 2; out[n++] = b->e[i].last_sa;
  }
  return n;
}
int
db_decode(const uint8_t *in, int len, db_t *b)
{
  int n = 6, i, j;
  if(len < 6) return -1;
  b->cc = in[0]; b->batch = get16(in + 1); b->ref = (int16_t)get16(in + 3); b->n = in[5];
  if(b->n > NCPC || len < 6 + DB_E * b->n) return -1;
  for(i = 0; i < b->n; i++) {
    b->e[i].slot = in[n++]; b->e[i].flags = in[n++];
    for(j = 0; j < 8; j++) { b->e[i].d.q[j] = (int16_t)get16(in + n); n += 2; }
    b->e[i].rot_age = get16(in + n); n += 2; b->e[i].last_sa = in[n++];
    if(b->e[i].slot >= NCPC) return -1;
  }
  return 0;
}

int
ab_encode(const ab_t *b, uint8_t *out)
{
  int n = 0, i;
  out[n++] = b->cc; put16(out + n, b->batch); n += 2; out[n++] = b->lease; out[n++] = b->n; put16(out + n, b->rot); n += 2;
  for(i = 0; i < b->n; i++) { out[n++] = b->e[i].slot; out[n++] = b->e[i].state; out[n++] = b->e[i].v1; out[n++] = b->e[i].v2; }
  return n;
}
int
ab_decode(const uint8_t *in, int len, ab_t *b)
{
  int n = 7, i;
  if(len < 7) return -1;
  b->cc = in[0]; b->batch = get16(in + 1); b->lease = in[3]; b->n = in[4]; b->rot = get16(in + 5);
  if(b->n > NCPC || len < 7 + 4 * b->n) return -1;
  for(i = 0; i < b->n; i++) {
    b->e[i].slot = in[n++]; b->e[i].state = in[n++]; b->e[i].v1 = in[n++]; b->e[i].v2 = in[n++];
    if(b->e[i].slot >= NCPC) return -1;
  }
  return 0;
}

int
st_encode(const st_t *s, uint8_t *out)
{
  put16(out, s->term); out[2] = s->auth; out[3] = s->alarm; put16(out + 4, s->join); memcpy(out + 6, s->dig, 32);
  out[38] = (uint8_t)(s->t_ms >> 24); out[39] = (uint8_t)(s->t_ms >> 16); out[40] = (uint8_t)(s->t_ms >> 8); out[41] = (uint8_t)s->t_ms;
  return 42;
}
int
st_decode(const uint8_t *in, int len, st_t *s)
{
  if(len < 42) return -1;
  s->term = get16(in); s->auth = in[2]; s->alarm = in[3]; s->join = get16(in + 4); memcpy(s->dig, in + 6, 32);
  s->t_ms = ((uint32_t)in[38] << 24) | ((uint32_t)in[39] << 16) | ((uint32_t)in[40] << 8) | in[41];
  return 0;
}

int vote_encode(const vote_t *v, uint8_t *out) { put16(out, v->term); out[2] = v->cand; out[3] = v->voter; return 4; }
int
vote_decode(const uint8_t *in, int len, vote_t *v)
{
  if(len < 4) return -1;
  v->term = get16(in); v->cand = in[2]; v->voter = in[3];
  return 0;
}

int hello_encode(const hello_t *h, uint8_t *out) { put16(out, h->term); out[2] = h->auth; memcpy(out + 3, h->na, 8); return 11; }
int
hello_decode(const uint8_t *in, int len, hello_t *h)
{
  if(len < 11) return -1;
  h->term = get16(in); h->auth = in[2]; memcpy(h->na, in + 3, 8);
  return 0;
}

int hack_encode(const hack_t *h, uint8_t *out) { put16(out, h->term); memcpy(out + 2, h->na, 8); memcpy(out + 10, h->nc, 8); return 18; }
int
hack_decode(const uint8_t *in, int len, hack_t *h)
{
  if(len < 18) return -1;
  h->term = get16(in); memcpy(h->na, in + 2, 8); memcpy(h->nc, in + 10, 8);
  return 0;
}

int
shard_encode(const shard_t *s, uint8_t *out)
{
  int n = 0, i;
  put16(out, s->term); n = 2; out[n++] = s->cc; out[n++] = s->n;
  for(i = 0; i < s->n; i++) {
    out[n++] = s->e[i].slot; out[n++] = s->e[i].s_enf; put16(out + n, s->e[i].ep); n += 2;
    put16(out + n, s->e[i].rot_age); n += 2; out[n++] = s->e[i].last_sa;
  }
  return n;
}
int
shard_decode(const uint8_t *in, int len, shard_t *s)
{
  int n = 4, i;
  if(len < 4) return -1;
  s->term = get16(in); s->cc = in[2]; s->n = in[3];
  if(s->n > NCPC || len < 4 + 7 * s->n) return -1;
  for(i = 0; i < s->n; i++) {
    s->e[i].slot = in[n++]; s->e[i].s_enf = in[n++]; s->e[i].ep = get16(in + n); n += 2;
    s->e[i].rot_age = get16(in + n); n += 2; s->e[i].last_sa = in[n++];
  }
  return 0;
}
void
shard_digest(const shard_t *s, uint8_t dig[32])
{
  uint8_t b[4 + 7 * NCPC]; int n; tc_sha256_ctx_t h;
  shard_t z = *s; z.term = 0;                       /* digest of the content, independent of the term */
  n = shard_encode(&z, b);
  tc_sha256_init(&h); tc_sha256_update(&h, b, (uint16_t)n); tc_sha256_final(&h, dig);
}

int take_encode(const take_t *t, uint8_t *out) { put16(out, t->term); out[2] = t->auth; return 3; }
int
take_decode(const uint8_t *in, int len, take_t *t)
{
  if(len < 3) return -1;
  t->term = get16(in); t->auth = in[2];
  return 0;
}
