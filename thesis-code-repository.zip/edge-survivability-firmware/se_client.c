/*
 * SurvivEdge revision build -- constrained client (substrate client). One OSCORE context with its CC rooted in a
 * per-client deployment secret (never held by an edge root); one protected report per 30 s with first-hop ETX and an
 * operation request; protected decision from the CC. Epoch rotation: when a decision carries a pending epoch, the client
 * switches to it (the previous epoch stays acceptable for 120 s). No SurvivEdge-specific logic.
 * Background behaviour: substrate degradation waves (delivery and compliance -0.005 per cycle during an episode).
 */
#include "se_common.h"
#include "net/routing/routing.h"
#include "net/routing/rpl-classic/rpl.h"
#include <string.h>

PROCESS(client_process, "SurvivEdge client");
AUTOSTART_PROCESSES(&client_process);

static struct simple_udp_connection conn;
static uip_ipaddr_t cc_addr;
static uint8_t me, cc;
static sctx_t ctx;
static uint16_t report_no;
static uint32_t n_sent, n_supp, n_noncomp, n_ack, n_acc, n_rej, n_rxbad, n_rot;
static uint8_t buf[96], pt[64];

static uint16_t
first_hop_etx(void)
{
  rpl_dag_t *d = rpl_get_any_dag();
  rpl_parent_t *pp = d ? d->preferred_parent : NULL;
  float etx = pp ? (float)rpl_get_parent_link_metric(pp) / 128.0f : 1.0f;
  if(etx < 1.0f) etx = 1.0f;
  return (uint16_t)(etx * 100.0f);
}

#define FMT_OK 0x01
static void
send_report(const beh_t *b)
{
  uint16_t etx = first_hop_etx(); int n;
  uint32_t r = rnd() % 10; uint8_t op = r < 5 ? OP_READ : (r < 8 ? OP_LOW : OP_HIGH);
  report_no++;
  if(rndf() >= b->deliver) { n_supp++; return; }
  pt[0] = FMT_OK;
  if(rndf() >= b->comply) { pt[0] = 0x00; n_noncomp++; }
  pt[1] = (uint8_t)(report_no >> 8); pt[2] = (uint8_t)report_no;
  pt[3] = (uint8_t)(etx >> 8); pt[4] = (uint8_t)etx;
  pt[5] = op; pt[6] = REPORT_PERIOD_S; pt[7] = 0; pt[8] = 0;
  n = sctx_protect(&ctx, T_REPORT, pt, 9, buf);
  count_tx(TC_APP, (uint16_t)n);
  simple_udp_sendto(&conn, buf, (uint16_t)n, &cc_addr);
  n_sent++;
}

static void
rx(struct simple_udp_connection *c, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
   const uint8_t *data, uint16_t len)
{
  int plen = 0, r; uint16_t rot;
  if(!g_configured || addr_node(sa) != cc) return;
  if(rx_drop_app(cc)) return;
  if((r = sctx_open(&ctx, T_RACK, now_s(), data, len, pt, &plen, NULL)) != RX_OK || plen < 6) { n_rxbad++; return; }
  n_ack++;
  if(pt[2]) n_acc++; else n_rej++;
  rot = (uint16_t)((pt[4] << 8) | pt[5]);
  if(rot > ctx.ep) { sctx_rotate(&ctx, rot, now_s()); n_rot++; }
}

PROCESS_THREAD(client_process, ev, data)
{
  static struct etimer tick;
  static uint32_t next_report, next_cnt;
  PROCESS_BEGIN();
  se_common_init();
  PROCESS_WAIT_EVENT_UNTIL(ev == g_cfg_event);
  me = (uint8_t)node_id; cc = tt_node[me].cc;
  node_addr(cc, &cc_addr);
  simple_udp_register(&conn, PORT_CLIENT, NULL, PORT_CC, rx);
  sctx_init(&ctx, K_CLIENT, me, cc, 1);
  next_report = 120 + rnd() % REPORT_PERIOD_S;
  next_cnt = 1800;
  etimer_set(&tick, CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&tick));
    etimer_reset(&tick);
    {
      uint32_t t = now_s();
      beh_t b; behaviour(me, t, &b);
      if(t >= next_report) { send_report(&b); next_report += REPORT_PERIOD_S; }
      if(t >= next_cnt) {
        log_counters();
        TLOG("CLSTAT", "p=%u,sent=%lu,supp=%lu,noncomp=%lu,ack=%lu,acc=%lu,rej=%lu,rxbad=%lu,rot=%lu,ep=%u,seq=%lu", me, (unsigned long)n_sent,
             (unsigned long)n_supp, (unsigned long)n_noncomp, (unsigned long)n_ack, (unsigned long)n_acc, (unsigned long)n_rej,
             (unsigned long)n_rxbad, (unsigned long)n_rot, ctx.ep, (unsigned long)ctx.seq);
        next_cnt += 1800;
      }
    }
  }
  PROCESS_END();
}
