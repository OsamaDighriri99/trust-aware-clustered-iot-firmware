/*
 * SurvivEdge revision build -- edge roots. Node 1 (ER1): RPL root (RPL classic, storing mode) and authority of term 0.
 * Node 2 (ER2): second edge root, election candidate (not a voter), holds consensus contexts with every CC and no
 * mirror of ER1; becomes the authority when it holds >= q votes for a term (SurvivEdge), on a majority of votes
 * (crash-tolerant baseline B4) or after three missed ER1 heartbeats (hot-standby baseline B3).
 * Behaviour models (se_common.h): ER1 per scenario from the onset; ER2 unavailable (er2=1) or Byzantine once elected
 * (er2=2). A7: ER1 drops every packet it forwards (routing-layer limit of assumption L3).
 */
#include "se_common.h"
#include "se_cca.h"
#include "se_auth.h"
#include "net/routing/routing.h"
#include "net/netstack.h"
#include "net/ipv6/uip-ds6.h"
#include <string.h>

PROCESS(er_process, "SurvivEdge edge root");
AUTOSTART_PROCESSES(&er_process);

static struct simple_udp_connection econn, oconn;
static auth_t A;
static sctx_t cons[TT_NCC];
static sctx_t hb;                         /* ER1 <-> ER2 heartbeat context (B3 only) */
static cca_t votes;
static uint8_t buf[200], pt[200];
static uint16_t my_term;                  /* ER2: last term it was elected for */
static uint32_t last_hb, hb_seq, n_fwd_drop, onset_logged;

/* A7: drop forwarded packets at ER1 */
static enum netstack_ip_action fwd_in(void) { return NETSTACK_IP_PROCESS; }
static enum netstack_ip_action
fwd_out(const linkaddr_t *ld)
{
  if(g_er1_beh != BEH_FWDDROP || now_s() < g_onset) return NETSTACK_IP_PROCESS;
  if(uip_ds6_is_my_addr(&UIP_IP_BUF->srcipaddr)) return NETSTACK_IP_PROCESS;
  n_fwd_drop++;
  return NETSTACK_IP_DROP;
}
static struct netstack_ip_packet_processor fwd_proc = { NULL, fwd_in, fwd_out };

static int er2_off(void) { return node_id == TT_STANDBY && g_er2 == 1; }

static void
ov_send(uint8_t to, uint8_t type, const uint8_t *p, uint16_t len, uint8_t cls)
{
  int n; uip_ipaddr_t a;
  if(to < TT_FIRST_CC || to >= TT_FIRST_CC + TT_NCC) return;
  n = sctx_protect(&cons[to - TT_FIRST_CC], type, p, len, buf);
  node_addr(to, &a); count_tx(cls, (uint16_t)n);
  simple_udp_sendto_port(&oconn, buf, (uint16_t)n, &a, PORT_OV);
}

static void
become_authority(uint16_t term, const char *via)
{
  if(my_term >= term) return;
  my_term = term;
  TLOG("ELECTED", "term=%u,via=%s,votes=%u", term, via, cca_count(&votes, term, (uint8_t)node_id));
  auth_start_term(&A, term);
  A.beh = (node_id == TT_STANDBY && g_er2 == 2) ? BEH_A3 : BEH_NONE; A.beh_from = now_s();
}

static void
erx(struct simple_udp_connection *c, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
    const uint8_t *data, uint16_t len)
{
  uint8_t ty; uint16_t cid;
  if(!g_configured || er2_off() || msg_peek(data, len, &ty, &cid) < 0) return;
  if(ty == T_DESC) auth_on_desc(&A, addr_node(sa), data, len);
}

static void
orx(struct simple_udp_connection *c, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
    const uint8_t *data, uint16_t len)
{
  uint8_t from = addr_node(sa), ty; uint16_t cid; int plen = 0, r, ix = from - TT_FIRST_CC;
  if(!g_configured || er2_off() || msg_peek(data, len, &ty, &cid) < 0) return;
  if(ty == T_HBEAT) {
    if(node_id == TT_STANDBY && from == TT_ER && sctx_open(&hb, T_HBEAT, now_s(), data, len, pt, &plen, NULL) == RX_OK) last_hb = now_s();
    return;
  }
  if(node_id != TT_STANDBY || ix < 0 || ix >= TT_NCC) return;
  if(ty == T_SHARD) { auth_on_shard(&A, from, data, len); return; }
  r = sctx_open(&cons[ix], ty, now_s(), data, len, pt, &plen, NULL);
  if(r != RX_OK) { TLOG("OVREJ", "from=%u,type=%c,why=%s", from, ty, rx_name[r]); return; }
  if(ty == T_VOTE) {
    vote_t v; int res;
    if(vote_decode(pt, plen, &v) < 0 || v.voter != from) return;
    if(A.active && v.term == A.term && v.cand == node_id) auth_nudge(&A, from);   /* C5 */
    if(v.term > votes.base + CCA_WIN - 1) cca_rebase(&votes, (uint16_t)(v.term - CCA_WIN + 1));
    res = cca_record(&votes, v.term, (uint8_t)(v.voter - TT_FIRST_CC), v.cand);
    TLOG("VOTERX", "term=%u,voter=%u,cand=%u,res=%d", v.term, v.voter, v.cand, res);
    if(res != CCA_NEW || v.cand != node_id) return;
    if(g_base == BASE_SE && cca_count(&votes, v.term, (uint8_t)node_id) >= g_q) become_authority(v.term, "quorum");
    if(g_base == BASE_B4 && cca_count(&votes, v.term, (uint8_t)node_id) >= TT_NCC / 2 + 1 && my_term < v.term) {
      take_t tk; uint8_t p[4]; int i, n; tk.term = v.term; tk.auth = (uint8_t)node_id; n = take_encode(&tk, p);
      for(i = 0; i < TT_NCC; i++) ov_send((uint8_t)(TT_FIRST_CC + i), T_TAKE, p, (uint16_t)n, TC_TAKE);
      become_authority(v.term, "b4-claim");
    }
  } else if(ty == T_HACK) {
    hack_t k; if(hack_decode(pt, plen, &k) == 0) auth_on_hack(&A, from, &k);
  }
}

PROCESS_THREAD(er_process, ev, data)
{
  static struct etimer tick;
  static uint32_t next_cnt, next_pres, last_s;
  int i;
  PROCESS_BEGIN();
  if(node_id == TT_ER) NETSTACK_ROUTING.root_start();
  se_common_init();
  PROCESS_WAIT_EVENT_UNTIL(ev == g_cfg_event);
  simple_udp_register(&econn, PORT_ER, NULL, PORT_ER, erx);
  simple_udp_register(&oconn, PORT_OV, NULL, PORT_OV, orx);
  for(i = 0; i < TT_NCC; i++) if(node_id == TT_STANDBY) sctx_init(&cons[i], K_CONS, (uint8_t)node_id, (uint8_t)(TT_FIRST_CC + i), 0);
  sctx_init(&hb, K_AUTH0, (uint8_t)node_id, node_id == TT_ER ? TT_STANDBY : TT_ER, 0);
  auth_init(&A, (uint8_t)node_id, cons, &econn, &oconn);
  cca_init(&votes, 0);
  if(node_id == TT_ER) {
    auth_start_term0(&A); A.beh = g_er1_beh; A.beh_from = g_onset;
    netstack_ip_packet_processor_add(&fwd_proc);
    schedules_log();
  }
  next_cnt = 1800; next_pres = WARMUP_S; last_hb = 0;
  etimer_set(&tick, CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&tick));
    etimer_reset(&tick);
    {
      uint32_t t = now_s();
      if(t == last_s) continue;
      last_s = t;
      if(node_id == TT_ER && g_er1_beh != BEH_NONE && t >= g_onset && !onset_logged) { TLOG("ONSET", "beh=%u,sc=%s", g_er1_beh, sc_name[g_sc]); onset_logged = 1; }
      if(!er2_off()) auth_tick(&A);
      /* B3: ER1 heartbeat every 5 s while its application runs; ER2 takes over after three missed heartbeats */
      if(g_base == BASE_B3 && t >= WARMUP_S) {
        if(node_id == TT_ER && t % 5 == 0 && !(g_er1_beh == BEH_SILENT && t >= g_onset)) {
          uint8_t p[4]; uip_ipaddr_t a; int n; p[0] = (uint8_t)(hb_seq >> 24); p[1] = (uint8_t)(hb_seq >> 16); p[2] = (uint8_t)(hb_seq >> 8); p[3] = (uint8_t)hb_seq; hb_seq++;
          n = sctx_protect(&hb, T_HBEAT, p, 4, buf); node_addr(TT_STANDBY, &a); count_tx(TC_HB, (uint16_t)n);
          simple_udp_sendto_port(&oconn, buf, (uint16_t)n, &a, PORT_OV);
        }
        if(node_id == TT_STANDBY && !er2_off() && last_hb && t > last_hb + 15 && my_term == 0) {
          take_t tk; uint8_t p[4]; int n; tk.term = 1; tk.auth = TT_STANDBY; n = take_encode(&tk, p);
          for(i = 0; i < TT_NCC; i++) ov_send((uint8_t)(TT_FIRST_CC + i), T_TAKE, p, (uint16_t)n, TC_TAKE);
          TLOG("HB_TAKEOVER", "last_hb=%lu", (unsigned long)last_hb);
          become_authority(1, "heartbeat");
        }
      }
      /* ER2 presence (status) every 30 s */
      if(node_id == TT_STANDBY && !er2_off() && t >= next_pres && (g_base == BASE_SE || g_base == BASE_B4 || g_base == BASE_SHADOW)) {
        st_t s; uint8_t p[44]; int n; memset(&s, 0, sizeof s); s.term = my_term; s.t_ms = now_ms(); s.auth = A.active ? TT_STANDBY : 0;
        n = st_encode(&s, p);
        for(i = 0; i < TT_NCC; i++) ov_send((uint8_t)(TT_FIRST_CC + i), T_STAT, p, (uint16_t)n, TC_STAT);
        next_pres = t + 20 + (rnd() % 21);   /* C3: jittered ER2 presence 20-40 s */
      }
      if(t >= next_cnt) {
        log_counters();
        TLOG("ERSTAT", "act=%u,term=%u,batches=%lu,desc=%lu,rej=%lu,unsol=%lu,fwddrop=%lu", A.active, A.term, (unsigned long)A.n_batch,
             (unsigned long)A.n_desc, (unsigned long)A.n_rej, (unsigned long)A.n_unsol, (unsigned long)n_fwd_drop);
        next_cnt += 1800;
      }
    }
  }
  PROCESS_END();
}
