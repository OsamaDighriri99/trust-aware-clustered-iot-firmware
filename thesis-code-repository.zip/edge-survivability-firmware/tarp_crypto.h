/* TARP-OSCORE revision build -- cryptographic primitives (see tarp_crypto.c). */
#ifndef TARP_CRYPTO_H_
#define TARP_CRYPTO_H_
#include <stdint.h>
#include <stddef.h>

typedef struct { uint8_t rk[176]; } tc_aes_ctx_t;
typedef struct { uint32_t h[8]; uint8_t buf[64]; uint32_t total_lo; uint8_t buf_len; } tc_sha256_ctx_t;

void tc_aes_setkey(tc_aes_ctx_t *ctx, const uint8_t key[16]);
void tc_aes_encrypt_block(const tc_aes_ctx_t *ctx, uint8_t *blk);
void tc_sha256_init(tc_sha256_ctx_t *c);
void tc_sha256_update(tc_sha256_ctx_t *c, const uint8_t *d, uint16_t n);
void tc_sha256_final(tc_sha256_ctx_t *c, uint8_t out[32]);
void tc_hmac_sha256(const uint8_t *key, uint8_t key_len, const uint8_t *m1, uint16_t n1,
                    const uint8_t *m2, uint16_t n2, const uint8_t *m3, uint16_t n3, uint8_t out[32]);

/* HKDF-SHA256 (RFC 5869). salt may be NULL/0 (then a zero salt of 32 bytes). okm_len <= 64. */
void tc_hkdf_extract(const uint8_t *salt, uint8_t salt_len, const uint8_t *ikm, uint8_t ikm_len, uint8_t prk[32]);
void tc_hkdf_expand(const uint8_t prk[32], const uint8_t *info, uint16_t info_len, uint8_t *okm, uint8_t okm_len);
void tc_hkdf(const uint8_t *salt, uint8_t salt_len, const uint8_t *ikm, uint8_t ikm_len,
             const uint8_t *info, uint16_t info_len, uint8_t *okm, uint8_t okm_len);

/* AES-CCM (RFC 3610) with L = 2 (13-byte nonce), M = 8 (8-byte tag): COSE AES-CCM-16-64-128.
 * encrypt: out = C || T (len + 8 bytes). decrypt: returns 0 on success, -1 on tag mismatch. */
#define TC_CCM_NONCE 13
#define TC_CCM_TAG   8
void tc_ccm_encrypt(const uint8_t key[16], const uint8_t nonce[13], const uint8_t *aad, uint16_t aad_len,
                    const uint8_t *pt, uint16_t len, uint8_t *out);
int  tc_ccm_decrypt(const uint8_t key[16], const uint8_t nonce[13], const uint8_t *aad, uint16_t aad_len,
                    const uint8_t *ct_tag, uint16_t ct_len_with_tag, uint8_t *pt);
#endif
