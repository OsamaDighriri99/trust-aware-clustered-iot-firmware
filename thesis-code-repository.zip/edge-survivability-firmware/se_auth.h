/* SurvivEdge revision build -- authority role (ER1 in term 0; ER2 or a CC after an election).
 * The authority's decision is a function of the descriptors the CCs send every cycle: the frozen substrate degradation
 * detector (Restricted when >= k of 25 trees vote for degradation, otherwise no restriction), a proactive rotation order
 * at every restriction onset, and periodic rotation orders when a client context is due (rot_age >= 240 cycles).
 * The authority keeps no client state between cycles; everything it needs arrives in each descriptor batch.
 * A compromised authority changes only the content and timing of its own messages (behaviour models BEH_*). */
#ifndef SE_AUTH_H_
#define SE_AUTH_H_
#include "se_common.h"

typedef struct {
  uint8_t active, me;
  uint16_t term;
  uint8_t beh; uint32_t beh_from;           /* behaviour model and its start (BEH_NONE: honest) */
  sctx_t ctx[TT_NCC]; uint8_t ctx_ok[TT_NCC];
  uint8_t na[TT_NCC][8]; uint8_t hello_tries[TT_NCC]; uint32_t hello_next[TT_NCC]; uint8_t shard_ok[TT_NCC];
  uint16_t last_batch[TT_NCC]; uint32_t last_desc_t[TT_NCC];
  uint32_t n_batch, n_desc, n_rej, n_unsol;
  sctx_t *cons;                              /* consensus contexts of this node, indexed by CC (Hello/Ack) */
  struct simple_udp_connection *er_conn, *ov_conn;
} auth_t;

void auth_init(auth_t *a, uint8_t me, sctx_t *cons, struct simple_udp_connection *er_conn, struct simple_udp_connection *ov_conn);
/* term 0: provisioned contexts with every CC (ER1; also ER2 for the hot-standby baseline) */
void auth_start_term0(auth_t *a);
/* elected for 'term': fresh nonces, Hello to every CC (except itself) */
void auth_start_term(auth_t *a, uint16_t term);
void auth_stop(auth_t *a);
void auth_nudge(auth_t *a, uint8_t from);
/* descriptor batch from CC 'from' (network) */
void auth_on_desc(auth_t *a, uint8_t from, const uint8_t *data, uint16_t len);
/* Ack from CC (consensus context already verified by the caller): derive the term context */
void auth_on_hack(auth_t *a, uint8_t from, const hack_t *h);
void auth_on_shard(auth_t *a, uint8_t from, const uint8_t *data, uint16_t len);
/* local evaluation (used for the CC's own clients when the CC is the authority, and by auth_on_desc) */
void auth_eval(auth_t *a, const db_t *db, ab_t *ab, uint32_t t, uint32_t *delay_ms);
/* once per second: Hello retransmissions; compromised ER1 keeps issuing to CCs that left it */
void auth_tick(auth_t *a);
#endif
