/* SurvivEdge revision build -- message payloads (pure C99). All multi-byte fields big-endian. */
#ifndef SE_PROTO_H_
#define SE_PROTO_H_
#include <stdint.h>
#include "trace_policy.h"

#define NCPC 10                 /* clients per CC */

/* descriptor batch, CC -> authority */
#define DF_FULL  1              /* trust window full: descriptor valid */
#define DF_SLEEP 2              /* client announced sleep */
typedef struct { uint8_t slot, flags; tr_desc_t d; uint16_t rot_age; uint8_t last_sa; } db_entry_t;
typedef struct { uint8_t cc; uint16_t batch; int16_t ref; uint8_t n; db_entry_t e[NCPC]; } db_t;
int db_encode(const db_t *b, uint8_t *out);
int db_decode(const uint8_t *in, int len, db_t *b);

/* assignment batch, authority -> CC: states, lease (cycles), rotation orders (bit i = slot i) */
typedef struct { uint8_t slot, state, v1, v2; } ab_entry_t;
typedef struct { uint8_t cc; uint16_t batch; uint8_t lease, n; uint16_t rot; ab_entry_t e[NCPC]; } ab_t;
int ab_encode(const ab_t *b, uint8_t *out);
int ab_decode(const uint8_t *in, int len, ab_t *b);

/* status, CC -> CC (every 4 cycles and on every change); also ER2 presence */
typedef struct { uint16_t term; uint8_t auth, alarm; uint16_t join; uint8_t dig[32]; uint32_t t_ms; } st_t;   /* t_ms: send time (latency statistics) */
int st_encode(const st_t *s, uint8_t *out);
int st_decode(const uint8_t *in, int len, st_t *s);

typedef struct { uint16_t term; uint8_t cand, voter; } vote_t;
int vote_encode(const vote_t *v, uint8_t *out);
int vote_decode(const uint8_t *in, int len, vote_t *v);

typedef struct { uint16_t term; uint8_t auth; uint8_t na[8]; } hello_t;
int hello_encode(const hello_t *h, uint8_t *out);
int hello_decode(const uint8_t *in, int len, hello_t *h);

typedef struct { uint16_t term; uint8_t na[8], nc[8]; } hack_t;
int hack_encode(const hack_t *h, uint8_t *out);
int hack_decode(const uint8_t *in, int len, hack_t *h);

typedef struct { uint8_t slot, s_enf; uint16_t ep, rot_age; uint8_t last_sa; } sh_entry_t;
typedef struct { uint16_t term; uint8_t cc, n; sh_entry_t e[NCPC]; } shard_t;
int shard_encode(const shard_t *s, uint8_t *out);
int shard_decode(const uint8_t *in, int len, shard_t *s);
/* 32-byte digest of a shard summary (status message) */
void shard_digest(const shard_t *s, uint8_t dig[32]);

typedef struct { uint16_t term; uint8_t auth; } take_t;
int take_encode(const take_t *t, uint8_t *out);
int take_decode(const uint8_t *in, int len, take_t *t);
#endif
