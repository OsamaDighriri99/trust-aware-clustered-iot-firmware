/* SurvivEdge revision build -- security contexts (pure C99; firmware, host tests and Z1 benchmark).
 *
 * Key hierarchy (trust boundary, Section 4.1 of the revised paper):
 *   K_CLIENT  client <-> its CC. Root: per-client deployment secret held only by the client and its CC.
 *             Epochs rotate on authority order (or locally in autonomous mode); epoch e keys: ID Context = e.
 *   K_AUTH0   ER <-> CC authority context provisioned with the ER (term 0). ER1 holds it; ER2 holds its own.
 *   K_CONS    CC <-> CC and ER2 <-> CC consensus contexts. Root: deployment secret never held by ER1.
 *   K_AUTHT   authority context of term t between the elected authority and a CC:
 *             master = HKDF(salt = t || nonce_auth || nonce_cc, IKM = consensus root, info = "SE-AUTH-T"),
 *             ID Context = t. A fresh context per term: sequence numbers restart at 0 under a new key, so no
 *             (key, nonce) pair of a previous authority can recur.
 * Wire format (RFC 8613 protection, AES-CCM-16-64-128): type(1) flags(1) ctxid(2) pivlen(1) piv(1-4) || C || T(8);
 * the outer header is bound into the AAD. ctxid = client epoch, term, or 0 (consensus).
 * Simulation secrets are fixed constants recorded in the manifest (experimental provisioning). */
#ifndef SE_KEYS_H_
#define SE_KEYS_H_
#include <stdint.h>
#include "tarp_crypto.h"
#include "tarp_oscore.h"

#define K_CLIENT 1
#define K_AUTH0  2
#define K_CONS   3
#define K_AUTHT  4

/* message types */
#define T_REPORT  'D'   /* client -> CC report */
#define T_RACK    'd'   /* CC -> client decision (+ pending rotation epoch) */
#define T_DESC    'Q'   /* CC -> authority descriptor batch */
#define T_ASSIGN  'S'   /* authority -> CC assignment batch (+ rotation orders) */
#define T_STAT    'H'   /* CC -> CC status (term, authority, suspicion, shard digest); ER2 presence */
#define T_VOTE    'V'   /* CC -> CC / candidate vote */
#define T_HELLO   'L'   /* elected authority -> CC: takeover nonce */
#define T_HACK    'l'   /* CC -> elected authority: nonce reply */
#define T_SHARD   'Z'   /* CC -> elected authority: shard summary under the new authority context */
#define T_HBEAT   'B'   /* ER1 -> ER2 heartbeat (hot-standby baseline only) */
#define T_TAKE    'T'   /* ER2 -> CC takeover notice (hot-standby baseline) / leader claim (crash-tolerant baseline) */

#define EP_OVERLAP_S 120

typedef struct {
  uint8_t me, peer, kind, valid;
  uint16_t ep;                 /* client epoch / term / 0 */
  tos_keys_t k; tos_replay_t rw; uint32_t seq;
  uint16_t ep_prev; uint8_t prev_valid; tos_keys_t kp; tos_replay_t rwp; uint32_t prev_until;
  uint8_t kid[4];              /* first bytes of SHA-256(sender key || common IV), logged per derivation */
} sctx_t;

/* derivation */
void root_secret(uint8_t kind, uint8_t a, uint8_t b, uint8_t ms[16]);
void sctx_init(sctx_t *c, uint8_t kind, uint8_t me, uint8_t peer, uint16_t ep);
/* term context from nonces (auth = authority node id; both ends call it with the same arguments) */
void sctx_init_term(sctx_t *c, uint8_t me, uint8_t peer, uint16_t term, uint8_t auth, const uint8_t na[8], const uint8_t nc[8]);
/* rotate to epoch ep_new; the previous epoch is accepted until t_now + EP_OVERLAP_S */
void sctx_rotate(sctx_t *c, uint16_t ep_new, uint32_t t_now);
int  sctx_protect(sctx_t *c, uint8_t type, const uint8_t *pt, uint16_t len, uint8_t *out);

#define RX_OK      0
#define RX_PARSE   1
#define RX_EPOCH   2   /* unknown / expired context id */
#define RX_AUTH    3   /* tag mismatch */
#define RX_REPLAY  4
#define RX_BIND    5   /* object names another node */
#define RX_STALE   6   /* answers a superseded batch */
#define RX_TYPE    7
#define RX_NOTAUTH 8   /* sender is not the current authority */
#define RX_NOCTX   9   /* no context yet */
extern const char *const rx_name[10];
/* verify and decrypt (replay state committed only for an accepted message). ep_out: context id of the message */
int  sctx_open(sctx_t *c, uint8_t type, uint32_t t_now, const uint8_t *in, uint16_t len, uint8_t *pt, int *plen, uint16_t *ep_out);
/* peek the outer header (type, ctxid) without verifying */
int  msg_peek(const uint8_t *in, uint16_t len, uint8_t *type, uint16_t *ctxid);
#endif
