/* SurvivEdge revision build -- authority role. See se_auth.h. */
#include "se_auth.h"
#include "sys/ctimer.h"
#include <string.h>

static uint8_t abuf[256], apt[240];

/* delayed replies (BEH_A3 timing): one pending message per CC */
typedef struct { struct ctimer ct; uint8_t len, to; uint8_t m[160]; auth_t *a; } dly_t;
static dly_t dly[TT_NCC];
static void
dly_fire(void *p)
{
  dly_t *d = (dly_t *)p; uip_ipaddr_t ad;
  node_addr(d->to, &ad);
  count_tx(TC_ASSIGN, d->len);
  simple_udp_sendto_port(d->a->er_conn, d->m, d->len, &ad, PORT_ER);
}

void
auth_init(auth_t *a, uint8_t me, sctx_t *cons, struct simple_udp_connection *er_conn, struct simple_udp_connection *ov_conn)
{
  memset(a, 0, sizeof *a);
  a->me = me; a->cons = cons; a->er_conn = er_conn; a->ov_conn = ov_conn;
}

void
auth_start_term0(auth_t *a)
{
  int i;
  a->active = 1; a->term = 0;
  for(i = 0; i < TT_NCC; i++) {
    sctx_init(&a->ctx[i], K_AUTH0, a->me, (uint8_t)(TT_FIRST_CC + i), 0);
    a->ctx_ok[i] = 1; a->shard_ok[i] = 1;
    TLOG("KEY", "peer=%u,kind=%u,ep=%u,kid=%02x%02x%02x%02x", TT_FIRST_CC + i, K_AUTH0, 0, a->ctx[i].kid[0], a->ctx[i].kid[1], a->ctx[i].kid[2], a->ctx[i].kid[3]);
  }
  TLOG("AUTH_ON", "term=0,auth=%u", a->me);
}

void
auth_start_term(auth_t *a, uint16_t term)
{
  int i;
  a->active = 1; a->term = term;
  for(i = 0; i < TT_NCC; i++) {
    a->ctx_ok[i] = 0; a->shard_ok[i] = 0; a->hello_tries[i] = 0; a->hello_next[i] = now_s();
    rnd_bytes(a->na[i], 8);
    if(TT_FIRST_CC + i == a->me) { a->ctx_ok[i] = 1; a->shard_ok[i] = 1; }
  }
  TLOG("AUTH_ON", "term=%u,auth=%u", term, a->me);
}

void auth_stop(auth_t *a) { if(a->active) TLOG("AUTH_OFF", "term=%u", a->term); a->active = 0; }

static int
misbehaving(const auth_t *a, uint32_t t)
{
  return a->beh != BEH_NONE && a->beh != BEH_FWDDROP && t >= a->beh_from;
}

void
auth_eval(auth_t *a, const db_t *db, ab_t *ab, uint32_t t, uint32_t *delay_ms)
{
  int i; int mis = misbehaving(a, t);
  float frac = 0.0f;
  if(mis && a->beh == BEH_A1) { frac = 0.005f * (float)((t - a->beh_from) / CYCLE_S); if(frac > 1.0f) frac = 1.0f; }
  memset(ab, 0, sizeof *ab);
  ab->cc = db->cc; ab->batch = db->batch; ab->lease = LEASE_MAX;
  *delay_ms = 0;
  for(i = 0; i < db->n; i++) {
    const db_entry_t *e = &db->e[i];
    uint8_t client = tt_members[db->cc - TT_FIRST_CC][e->slot], st, forged = 0; int v;
    if(e->rot_age >= ROT_PERIOD_CYC) ab->rot |= (uint16_t)(1u << e->slot);                     /* periodic rotation (every client) */
    if(!(e->flags & DF_FULL) || (e->flags & DF_SLEEP)) continue;
    v = rf_votes_for(&rf_det, e->d.q, 1);
    st = (v >= rf_det_k) ? ST_REST : ST_FULL;
    if(mis) {
      if(a->beh == BEH_A1 && cl_hash(client) < frac && st != ST_FULL) { st = ST_FULL; forged = 1; }
      else if(a->beh == BEH_A3 && cl_hash(client) < 0.30f && st != ST_REST) { st = ST_REST; forged = 2; }
      else if(a->beh == BEH_A5) { int j; for(j = 0; j < g_a5_n; j++) if(g_a5_cl[j] == client && st != ST_REST) { st = ST_REST; forged = 2; } }
    }
    ab->e[ab->n].slot = e->slot; ab->e[ab->n].state = st; ab->e[ab->n].v1 = (uint8_t)(v < 0 ? 0 : v); ab->e[ab->n].v2 = forged;
    if(st == ST_REST && e->last_sa == ST_FULL) ab->rot |= (uint16_t)(1u << e->slot);          /* proactive rotation */
    ab->n++;
  }
  if(mis && a->beh == BEH_A3) {
    uint16_t pro = 0; int j;                       /* keep only proactive orders (protocol-consistent); suppress periodic ones */
    for(j = 0; j < ab->n; j++) {
      const db_entry_t *e = NULL; int z;
      for(z = 0; z < db->n; z++) if(db->e[z].slot == ab->e[j].slot) e = &db->e[z];
      if(e && ab->e[j].state == ST_REST && e->last_sa == ST_FULL) pro |= (uint16_t)(1u << ab->e[j].slot);
    }
    ab->rot = pro;
    *delay_ms = rnd() % 1500;
  }
}

void
auth_on_desc(auth_t *a, uint8_t from, const uint8_t *data, uint16_t len)
{
  uint32_t t = now_s(); int plen = 0, r, i, n, ci = from - TT_FIRST_CC; db_t db; ab_t ab; char st[16]; uint32_t dl;
  if(!a->active || ci < 0 || ci >= TT_NCC) return;
  if(misbehaving(a, t) && a->beh == BEH_SILENT) { a->last_desc_t[ci] = t; return; }
  if(!a->ctx_ok[ci]) { a->n_rej++; TLOG("DESCREJ", "cc=%u,why=noctx", from); return; }
  r = sctx_open(&a->ctx[ci], T_DESC, t, data, len, apt, &plen, NULL);
  if(r == RX_OK && db_decode(apt, plen, &db) < 0) r = RX_PARSE;
  if(r == RX_OK && db.cc != from) r = RX_BIND;
  if(r != RX_OK) { a->n_rej++; TLOG("DESCREJ", "cc=%u,why=%s", from, rx_name[r]); return; }
  a->n_batch++; a->last_batch[ci] = db.batch; a->last_desc_t[ci] = t;
  auth_eval(a, &db, &ab, t, &dl);
  for(i = 0; i < NCPC; i++) st[i] = '-';
  for(i = 0; i < ab.n; i++) st[ab.e[i].slot] = (char)((ab.e[i].v2 ? 'a' : '0') + ab.e[i].state);   /* 'a'/'b': forged entry */
  st[NCPC] = 0;
  a->n_desc += ab.n;
  n = ab_encode(&ab, apt);
  n = sctx_protect(&a->ctx[ci], T_ASSIGN, apt, (uint16_t)n, abuf);
  if(dl > 0 && n <= (int)sizeof dly[ci].m) {
    dly[ci].len = (uint8_t)n; dly[ci].to = from; dly[ci].a = a; memcpy(dly[ci].m, abuf, n);
    ctimer_set(&dly[ci].ct, (clock_time_t)((uint32_t)dl * CLOCK_SECOND / 1000), dly_fire, &dly[ci]);
  } else {
    uip_ipaddr_t ad; node_addr(from, &ad);
    count_tx(TC_ASSIGN, (uint16_t)n);
    simple_udp_sendto_port(a->er_conn, abuf, (uint16_t)n, &ad, PORT_ER);
  }
  TLOG("ERB", "cc=%u,b=%u,term=%u,st=%s,rot=%u,dl=%lu", from, db.batch, a->term, st, ab.rot, (unsigned long)dl);
}

void
auth_on_hack(auth_t *a, uint8_t from, const hack_t *h)
{
  int ci = from - TT_FIRST_CC;
  if(!a->active || ci < 0 || ci >= TT_NCC || h->term != a->term || memcmp(h->na, a->na[ci], 8) != 0) return;
  if(a->ctx_ok[ci]) return;
  sctx_init_term(&a->ctx[ci], a->me, from, a->term, a->me, a->na[ci], h->nc);
  a->ctx_ok[ci] = 1;
  TLOG("KEY", "peer=%u,kind=%u,ep=%u,kid=%02x%02x%02x%02x", from, K_AUTHT, a->term, a->ctx[ci].kid[0], a->ctx[ci].kid[1], a->ctx[ci].kid[2], a->ctx[ci].kid[3]);
}

void
auth_on_shard(auth_t *a, uint8_t from, const uint8_t *data, uint16_t len)
{
  int ci = from - TT_FIRST_CC, plen = 0, r, i, nst = 0, nep = 0, nrot = 0; shard_t s;
  if(!a->active || ci < 0 || ci >= TT_NCC || !a->ctx_ok[ci]) return;
  r = sctx_open(&a->ctx[ci], T_SHARD, now_s(), data, len, apt, &plen, NULL);
  if(r == RX_OK && shard_decode(apt, plen, &s) < 0) r = RX_PARSE;
  if(r == RX_OK && (s.cc != from || s.term != a->term)) r = RX_BIND;
  if(r != RX_OK) { TLOG("SHARDREJ", "cc=%u,why=%s", from, rx_name[r]); return; }
  for(i = 0; i < s.n; i++) { nst += s.e[i].s_enf <= ST_REV; nep += s.e[i].ep >= 1; nrot += s.e[i].rot_age <= 2 * ROT_PERIOD_CYC; }
  a->shard_ok[ci] = 1;
  TLOG("SHARD", "cc=%u,term=%u,n=%u,st=%d,ep=%d,rot=%d", from, s.term, s.n, nst, nep, nrot);
}

void
auth_tick(auth_t *a)
{
  uint32_t t = now_s(); int i;
  if(!a->active) return;
  if(a->term > 0) for(i = 0; i < TT_NCC; i++) {           /* Hello (re)transmissions under the consensus context */
    uint8_t to = (uint8_t)(TT_FIRST_CC + i);
    if(a->ctx_ok[i] || to == a->me || t < a->hello_next[i]) continue;   /* C5: retransmitted until the context exists */
    { hello_t h; uip_ipaddr_t ad; int n; h.term = a->term; h.auth = a->me; memcpy(h.na, a->na[i], 8);
      n = hello_encode(&h, apt); n = sctx_protect(&a->cons[i], T_HELLO, apt, (uint16_t)n, abuf);
      node_addr(to, &ad); count_tx(TC_TAKE, (uint16_t)n);
      simple_udp_sendto_port(a->ov_conn, abuf, (uint16_t)n, &ad, PORT_OV); }
    if(a->hello_tries[i] < 255) a->hello_tries[i]++;
    a->hello_next[i] = t + (a->hello_tries[i] < 4 ? 4u << (a->hello_tries[i] - 1) : 30u);   /* 4, 8, 16, then every 30 s */
  }
  /* a compromised ER1 keeps issuing (fresh, forged all-Full batches) to CCs that stopped sending to it */
  if(a->me == TT_ER && a->term == 0 && misbehaving(a, t) && a->beh != BEH_SILENT && t % CYCLE_S == 7)
    for(i = 0; i < TT_NCC; i++) {
      ab_t ab; int n, j; uip_ipaddr_t ad;
      if(t < a->last_desc_t[i] + 3 * CYCLE_S || a->last_desc_t[i] == 0) continue;
      memset(&ab, 0, sizeof ab); ab.cc = (uint8_t)(TT_FIRST_CC + i); ab.batch = ++a->last_batch[i]; ab.lease = LEASE_MAX; ab.n = NCPC;
      for(j = 0; j < NCPC; j++) { ab.e[j].slot = (uint8_t)j; ab.e[j].state = ST_FULL; ab.e[j].v2 = 1; }
      n = ab_encode(&ab, apt); n = sctx_protect(&a->ctx[i], T_ASSIGN, apt, (uint16_t)n, abuf);
      node_addr(ab.cc, &ad); count_tx(TC_ASSIGN, (uint16_t)n); a->n_unsol++;
      simple_udp_sendto_port(a->er_conn, abuf, (uint16_t)n, &ad, PORT_ER);
    }
}

/* C5: a vote for the current term from a CC without a term context: resend the Hello now */
void
auth_nudge(auth_t *a, uint8_t from)
{
  int ci = from - TT_FIRST_CC;
  if(!a->active || a->term == 0 || ci < 0 || ci >= TT_NCC || a->ctx_ok[ci]) return;
  if(a->hello_next[ci] > now_s() + 1) a->hello_next[ci] = now_s();
}
