/*
 * SurvivEdge revision build -- cluster centre (nodes 3..2+N_CC).
 * Substrate (TRACE, frozen): per client trust evidence, trust trajectory, risk and the CC policy ceiling S'(T,R) every
 * 15 s; descriptor batch to the authority; enforcement s_enf = min_priv(S', s_A) within the lease, dwell for privilege
 * increases. SurvivEdge: AGIM signals and confirmation (se_agim.c); autonomous mode on ALARM (ceiling-only enforcement,
 * local periodic rotations); status messages and the CCA election (join rule, one vote per term, per-recipient
 * authenticated votes, acceptance on >= q votes counted locally, catch-up on f+1 matching reports); takeover handshake
 * with fresh term contexts; authority role when elected. Baselines B1-B4 and Byzantine-CC behaviour models are switched
 * at run time (se_common.h).
 */
#include "se_common.h"
#include "se_agim.h"
#include "se_cca.h"
#include "se_auth.h"
#include "sys/ctimer.h"
#include "net/routing/routing.h"
#include "net/routing/rpl-classic/rpl.h"
#include <string.h>

PROCESS(cc_process, "SurvivEdge cluster centre");
AUTOSTART_PROCESSES(&cc_process);

#define NC TT_CPC
#define FMT_OK 0x01
#define NONE_ST 9
#define ER2_IX TT_NCC                       /* consensus context index of ER2 */

typedef struct {
  uint8_t client; sctx_t ctx; uint16_t rot_pending, rot_age; uint8_t due_wait;
  tr_state_t tr; float succ, fail; uint32_t next_due, last_rx; uint16_t period; float etx_rep;
  uint8_t s_loc, s_loc_prev, s_a, s_enf, dwell_cnt, asg_valid, asg_lease, last_sa; uint32_t asg_cyc, last_arestr_cyc;
  uint8_t ur_run, asg_new;        /* asg_new: an assignment arrived since the last cycle; ur_run: consecutive received assignments that restricted this client while it was healthy (d_down persistence) */
  uint8_t ev_s, ev_f; uint16_t ev_ex, ev_eo;
  uint32_t rx_ok, rx_bad, n_noncomp, n_rate, n_rot;
  uint32_t opc[4][3][2];
} cl_t;

static cl_t cl[NC];
static struct simple_udp_connection conn, econn, oconn;
static uint8_t me, ccx;
static const tr_params_t *P;
static tr_ref_t ref;
static uint32_t cyc_no;
static uint8_t buf[300], pt[260];

/* authority view */
static uint16_t cur_term; static uint8_t auth_id; static sctx_t actx; static uint8_t actx_ok;
static uint8_t nc_term[8]; static uint8_t na_term[8]; static uint16_t nc_for_term;
static uint8_t deposed[32];
#define DEP_SET(x) (deposed[(x) >> 3] |= (uint8_t)(1 << ((x) & 7)))
static auth_t A;                             /* authority role when elected */

/* batches and AGIM */
static uint16_t batch_no; static uint32_t batch_t_ms; static uint8_t replied, resp_hist, have_batch;
static uint8_t sent_sa[2][NC];               /* last_sa sent in batch (parity) */
static int16_t sent_q[2][NC][8]; static uint8_t sent_fl[2][NC];   /* C1: descriptors sent in batch (parity), for the audit */
static uint16_t s_aud_n, s_aud_over, s_aud_under, s_aud_omit, s_aud_extra;   /* C1: audit counters of this cycle */
static uint32_t aud_tot_n, aud_tot_bad;
static agim_t ag; static agim_par_t agp; static uint8_t autonomous;
static uint16_t s_alpha_bad, s_entries, s_missing, s_spur, s_due;

/* overlay */
static sctx_t cons[TT_NCC + 1];
static cca_t cc_votes;
static uint16_t join_term; static uint32_t join_deadline;
static uint16_t st_term[TT_NCC + 1], st_join[TT_NCC + 1]; static uint8_t st_auth[TT_NCC + 1], st_alarm[TT_NCC + 1]; static uint32_t heard[TT_NCC + 1];
static uint8_t attempt;
static uint16_t lv_term; static uint8_t lv_cand;          /* last vote cast (retransmitted every 3 s while relevant) */
static uint16_t vrs_term; static uint8_t vrs_k;                          /* C7: vote retransmission backoff */
static uint16_t nk_term; static uint8_t nk_n[TT_NCC + 1];               /* C9: vote replies per peer in term nk_term */
static uint32_t next_vote_rs, acc_resend_until; static uint16_t acc_voted;   /* voters seen in the accepted term (bit per CC) */
static uint8_t stat_burst; static uint32_t next_burst;
static uint8_t stat_dirty; static uint32_t next_stat;
typedef struct { uint8_t valid, from; hello_t h; } phello_t;
static phello_t ph;
static uint32_t next_selfnom;
static uint16_t byz_voted_term;
static uint32_t n_notauth, n_asg_rej;
static uint32_t ov_n, ov_sum, ov_max, ov_gt1, ov_gt2, ov_gt5;        /* status one-way delay statistics (ms) */

static int ov_ix(uint8_t node) { if(node == TT_STANDBY) return ER2_IX; if(node >= TT_FIRST_CC && node < TT_FIRST_CC + TT_NCC) return node - TT_FIRST_CC; return -1; }
static int popcnt(uint32_t x) { int n = 0; while(x) { n += x & 1; x >>= 1; } return n; }
static int byz_active(void) { return is_byz(me) && now_s() >= g_onset; }
static uint32_t accept_t;
/* C4: a response-only alarm against an authority adopted less than PROB_S ago isolates this CC but is not reported as suspicion */
#define PROB_S 90
static int suspects(const agim_t *a) { return a->alarm && !(a->reason == AG_RESP && cur_term > 0 && now_ms() - accept_t < PROB_S * 1000UL); }

static cl_t *
cl_of(uint8_t c)
{
  if(c < TT_FIRST_CLIENT || c > TT_NODES || tt_node[c].cc != me) return NULL;
  return &cl[tt_node[c].slot];
}

/* ---------------- overlay send helpers ---------------- */
static void
ov_send_raw(uint8_t to, uint8_t type, const uint8_t *p, uint16_t len, uint8_t cls)
{
  int ix = ov_ix(to), n; uip_ipaddr_t a;
  if(ix < 0 || to == me) return;
  n = sctx_protect(&cons[ix], type, p, len, buf);
  node_addr(to, &a);
  count_tx(cls, (uint16_t)n);
  simple_udp_sendto_port(&oconn, buf, (uint16_t)n, &a, PORT_OV);
  if(g_sc == SC_X4) { count_tx(cls, (uint16_t)n); simple_udp_sendto_port(&oconn, buf, (uint16_t)n, &a, PORT_OV); }   /* network duplication */
}

static void
shard_build(shard_t *s)
{
  int i;
  memset(s, 0, sizeof *s);
  s->term = cur_term; s->cc = me; s->n = NC;
  for(i = 0; i < NC; i++) { s->e[i].slot = (uint8_t)i; s->e[i].s_enf = cl[i].s_enf; s->e[i].ep = cl[i].ctx.ep; s->e[i].rot_age = cl[i].rot_age; s->e[i].last_sa = cl[i].last_sa; }
}

static void
send_stat(void)
{
  st_t s; shard_t sh; uint8_t p[44]; int i, n;
  s.term = cur_term; s.auth = auth_id; s.join = join_term; s.t_ms = now_ms();
  s.alarm = suspects(&ag) ? 1 : 0;
  if(byz_active()) { if(g_bz_flags & BZ_SUPPRESS) s.alarm = 0; if(g_bz_flags & BZ_ACCUSE) s.alarm = 1; }
  shard_build(&sh); shard_digest(&sh, s.dig);
  if(byz_active() && (g_bz_flags & BZ_FALSEDIG)) rnd_bytes(s.dig, 32);
  n = st_encode(&s, p);
  for(i = 0; i < TT_NCC; i++) ov_send_raw((uint8_t)(TT_FIRST_CC + i), T_STAT, p, (uint16_t)n, TC_STAT);
  stat_dirty = 0; next_stat = now_s() + 4 * CYCLE_S - 15 + (rnd() % 31);   /* C3: jittered status period 45-75 s */
}

/* X3: delayed vote transmissions */
typedef struct { struct ctimer ct; vote_t v; uint8_t to; } dv_t;
static dv_t dv[TT_NCC + 1];
static void dv_fire(void *p) { dv_t *d = (dv_t *)p; uint8_t q[4]; int n = vote_encode(&d->v, q); ov_send_raw(d->to, T_VOTE, q, (uint16_t)n, TC_VOTE); }

static void
send_vote_to(uint8_t to, uint16_t term, uint8_t cand, int delay_ok)
{
  vote_t v; uint8_t q[4]; int n, ix = ov_ix(to);
  v.term = term; v.cand = cand; v.voter = me;
  if(delay_ok && g_sc == SC_X3 && ix >= 0 && !is_byz(me)) {
    dv[ix].v = v; dv[ix].to = to;
    ctimer_set(&dv[ix].ct, (clock_time_t)((rnd() % 10000) * (uint32_t)CLOCK_SECOND / 1000), dv_fire, &dv[ix]);
    return;
  }
  n = vote_encode(&v, q); ov_send_raw(to, T_VOTE, q, (uint16_t)n, TC_VOTE);
}

static void accept_term(uint16_t term, uint8_t cand, const char *via);
static void join(uint16_t term, const char *why);

/* record a vote (own or received) and check the quorum */
static void
vote_in(uint16_t term, uint8_t voter, uint8_t cand, int own)
{
  int r = cca_record(&cc_votes, term, (uint8_t)(voter - TT_FIRST_CC), cand);
  uint8_t qc;
  if(!own) TLOG("VOTERX", "term=%u,voter=%u,cand=%u,res=%d", term, voter, cand, r);
  if(r != CCA_NEW || g_base == BASE_B4) return;
  /* C8: progress-based election timer. A new vote for this CC's candidate in the current term extends the election deadline
   * by one timeout and restarts the retransmission backoff; a term is abandoned only after one timeout without progress.
   * At most N-1 extensions per term (one per voter), so the bound stays finite. */
  if(!own && g_base == BASE_SE && term == join_term && cand == lv_cand && lv_term == join_term) {
    if(join_deadline) { uint32_t nd = now_s() + ((uint32_t)T_E_S << (attempt < 4 ? attempt : 4));
      if(nd > join_deadline) { join_deadline = nd; TLOG("ETIMER_EXT", "term=%u,voter=%u", term, voter); } }
    vrs_k = 0;
  }
  if(!own && term > join_term && term > cur_term && g_base == BASE_SE && (!is_byz(me) || !byz_active() || (g_bz_flags & BZ_HONESTV))) {
    int v, nv = 0, i = (int)term - (int)cc_votes.base - 1;
    if(i >= 0 && i < CCA_WIN) for(v = 0; v < TT_NCC; v++) nv += cc_votes.vote[i][v] != 0;
    if(nv >= g_f + 1) join(term, "votes");                    /* at least one honest CC is in this term */
  }
  qc = cca_quorum(&cc_votes, term, TT_NCC, g_q);
  if(qc && term > cur_term) accept_term(term, qc, "quorum");
}

static uint8_t
cand_for(uint16_t term)
{
  uint8_t dep2[32]; memcpy(dep2, deposed, 32);
  if(auth_id) dep2[auth_id >> 3] |= (uint8_t)(1 << (auth_id & 7));
  return cand_of(term, dep2);
}

static int
eligible(uint8_t cand)
{
  int ix = ov_ix(cand);
  if(cand == me) return 1;
  if(ix < 0) return 0;
  return heard[ix] && now_s() - heard[ix] <= 120;
}

/* honest vote in term 'term' */
static void
do_vote(uint16_t term)
{
  uint8_t cand = cand_for(term); int i;
  if(!cand || !eligible(cand)) { TLOG("ABSTAIN", "term=%u,cand=%u", term, cand); return; }
  if(!cca_vote_mine(&cc_votes, term, cand)) return;
  TLOG("VOTE", "term=%u,cand=%u", term, cand);
  lv_term = term; lv_cand = cand; vrs_term = term; vrs_k = 0; next_vote_rs = now_s() + 5;
  vote_in(term, me, cand, 1);
  if(g_base == BASE_B4) {                                       /* crash-tolerant baseline: vote to the candidate only */
    if(cand != me) send_vote_to(cand, term, cand, 1);
    return;
  }
  for(i = 0; i < TT_NCC; i++) if(TT_FIRST_CC + i != me) send_vote_to((uint8_t)(TT_FIRST_CC + i), term, cand, 1);
  if(ov_ix(cand) == ER2_IX) send_vote_to(cand, term, cand, 1);
}

/* Byzantine voting behaviour for term 'term' */
static void
byz_vote(uint16_t term)
{
  uint8_t cand = cand_for(term), b0 = g_byz[0]; int i;
  if(term <= byz_voted_term || (g_bz_flags & BZ_WITHHOLD)) return;
  byz_voted_term = term;
  if(g_bz_flags & BZ_HONESTV) { do_vote(term); return; }
  TLOG("BYZVOTE", "term=%u,cand=%u,b0=%u,eq=%u", term, cand, b0, (g_bz_flags & BZ_EQUIV) ? 1 : 0);
  for(i = 0; i < TT_NCC; i++) {
    uint8_t to = (uint8_t)(TT_FIRST_CC + i), c = b0;
    if((g_bz_flags & BZ_EQUIV) && (i & 1)) c = cand;
    if(to == me) continue;
    send_vote_to(to, term, c, 0);
  }
  if(cand == TT_STANDBY) send_vote_to(TT_STANDBY, term, (g_bz_flags & BZ_EQUIV) ? cand : b0, 0);
}

static void
join(uint16_t term, const char *why)
{
  if(join_term >= term || term <= cur_term) return;
  join_term = term; join_deadline = 0;                        /* the election timer starts once >= q CCs are in this term */
  TLOG("JOIN", "term=%u,why=%s,att=%u", term, why, attempt);
  stat_dirty = 1;
  do_vote(term);
}

static void
takeover_reply(void)
{
  hack_t k; shard_t s; uint8_t p[80]; int n, m; uip_ipaddr_t a;
  k.term = cur_term; memcpy(k.na, na_term, 8); memcpy(k.nc, nc_term, 8);
  n = hack_encode(&k, p); ov_send_raw(auth_id, T_HACK, p, (uint16_t)n, TC_TAKE);
  shard_build(&s); n = shard_encode(&s, p);
  m = sctx_protect(&actx, T_SHARD, p, (uint16_t)n, buf);
  node_addr(auth_id, &a); count_tx(TC_TAKE, (uint16_t)m);
  simple_udp_sendto_port(&oconn, buf, (uint16_t)m, &a, PORT_OV);
}

static void
process_hello(uint8_t from, const hello_t *h)
{
  if(h->term != cur_term || h->auth != auth_id || from != auth_id) { TLOG("HELLO_REJ", "from=%u,term=%u,auth=%u", from, h->term, h->auth); return; }
  if(actx_ok && nc_for_term == cur_term && memcmp(na_term, h->na, 8) == 0) { takeover_reply(); return; }   /* retransmitted Hello */
  if(nc_for_term != cur_term) { rnd_bytes(nc_term, 8); nc_for_term = cur_term; }
  memcpy(na_term, h->na, 8);
  sctx_init_term(&actx, me, from, cur_term, from, na_term, nc_term);
  actx_ok = 1; resp_hist = 0; replied = 1; have_batch = 0; autonomous = 0;
  /* C6: a response-only alarm against this authority means "no Hello yet" (or no reply without a context); the takeover ends
   * that condition, so the alarm is cleared here instead of after AG_SOFT_CLEAR cycles, which outlasted the probation */
  if(ag.alarm && ag.reason == AG_RESP && join_term == 0) { agim_clear(&ag); stat_dirty = 1; TLOG("ALARM_CLEAR", "term=%u,why=takeover", cur_term); }
  TLOG("KEY", "peer=%u,kind=%u,ep=%u,kid=%02x%02x%02x%02x", from, K_AUTHT, cur_term, actx.kid[0], actx.kid[1], actx.kid[2], actx.kid[3]);
  TLOG("TAKEOVER", "term=%u,auth=%u,dt_ms=%lu", cur_term, auth_id, (unsigned long)(now_ms() - accept_t));
  takeover_reply();
}

static void
accept_term(uint16_t term, uint8_t cand, const char *via)
{
  uint8_t old = auth_id;
  if(term <= cur_term) return;
  TLOG("ACCEPT", "term=%u,auth=%u,old=%u,via=%s,votes=%u", term, cand, old, via, cca_count(&cc_votes, term, cand));
  if(g_base == BASE_SE && cand != me && (!is_byz(me) || !byz_active() || (g_bz_flags & BZ_HONESTV))) {
    int i0 = (int)term - (int)cc_votes.base - 1;
    if(i0 >= 0 && i0 < CCA_WIN && (cc_votes.mine[i0] == 0 || cc_votes.mine[i0] == cand)) {
      int j;                                                     /* the accepted candidate gets this CC's vote too, sent to every CC */
      cc_votes.mine[i0] = cand; lv_term = term; lv_cand = cand; acc_resend_until = now_s() + 60;
      vrs_term = term; vrs_k = 0; next_vote_rs = now_s() + 5;
      for(j = 0; j < TT_NCC; j++) if(TT_FIRST_CC + j != me) send_vote_to((uint8_t)(TT_FIRST_CC + j), term, cand, 0);
      if(ov_ix(cand) == ER2_IX) send_vote_to(cand, term, cand, 0);
    }
  }
  if(old) DEP_SET(old);
  if(A.active && old == me) auth_stop(&A);
  { int iv = (int)term - (int)cc_votes.base - 1, v; acc_voted = 0;
    if(iv >= 0 && iv < CCA_WIN) for(v = 0; v < TT_NCC && v < 16; v++) if(cc_votes.vote[iv][v]) acc_voted |= (uint16_t)(1u << v); }
  cca_rebase(&cc_votes, term);
  cur_term = term; auth_id = cand; join_term = 0; attempt = 0;
  actx_ok = 0; accept_t = now_ms(); agim_clear(&ag); autonomous = 1;     /* ceiling-only until the takeover completes */
  resp_hist = 0; replied = 1; have_batch = 0;                          /* the response history of the deposed authority ends here (fix 2026-10-26) */
  s_alpha_bad = s_entries = s_missing = s_spur = s_due = 0;               /* C1: no evidence about the deposed authority is attributed to its successor */
  s_aud_n = s_aud_over = s_aud_under = s_aud_omit = s_aud_extra = 0;
  { int i; for(i = 0; i < NC; i++) { cl[i].asg_valid = 0; cl[i].ur_run = 0; } }   /* assignments of the previous authority end here */
  stat_dirty = 1; stat_burst = 1; next_burst = now_s() + 5;
  if(cand == me) {
    auth_start_term(&A, term);
    A.beh = is_byz(me) ? BEH_A3 : BEH_NONE; A.beh_from = now_s();
    actx_ok = 1; autonomous = 0;
    TLOG("TAKEOVER", "term=%u,auth=%u,dt_ms=0", term, me);
  }
  if(ph.valid && ph.h.term == term && ph.from == cand) { ph.valid = 0; process_hello(ph.from, &ph.h); }
}

/* ---------------- receive: clients ---------------- */
static void
reply(cl_t *c, uint16_t rno, uint8_t acc)
{
  uip_ipaddr_t a; int n; uint8_t p[6];
  p[0] = (uint8_t)(rno >> 8); p[1] = (uint8_t)rno; p[2] = acc; p[3] = c->s_enf;
  p[4] = (uint8_t)(c->rot_pending >> 8); p[5] = (uint8_t)c->rot_pending;
  n = sctx_protect(&c->ctx, T_RACK, p, 6, buf);
  node_addr(c->client, &a);
  count_tx(c->rot_pending ? TC_ROT : TC_APP, (uint16_t)n);
  simple_udp_sendto_port(&conn, buf, (uint16_t)n, &a, PORT_CLIENT);
}

static void
rx(struct simple_udp_connection *cn, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
   const uint8_t *data, uint16_t len)
{
  uint32_t t = now_s(); int plen = 0, r; uint8_t from = addr_node(sa), op, acc = 0, ty; uint16_t rno, per, ep = 0;
  cl_t *c = cl_of(from);
  if(!g_configured || !c) return;
  if(rx_drop_app(from)) return;
  if(c->rot_pending && msg_peek(data, len, &ty, &ep) == 0 && ep == c->rot_pending) {   /* first message under the new epoch */
    sctx_t tmp = c->ctx; sctx_rotate(&tmp, c->rot_pending, t);
    r = sctx_open(&tmp, T_REPORT, t, data, len, pt, &plen, NULL);
    if(r == RX_OK) {
      c->ctx = tmp; c->rot_pending = 0; c->n_rot++;
      TLOG("ROT_DONE", "p=%u,ep=%u,kid=%02x%02x%02x%02x", c->client, c->ctx.ep, c->ctx.kid[0], c->ctx.kid[1], c->ctx.kid[2], c->ctx.kid[3]);
    }
  } else r = sctx_open(&c->ctx, T_REPORT, t, data, len, pt, &plen, NULL);
  if(r != RX_OK || plen < 9) {
    c->rx_bad++; if(t >= WARMUP_S) c->fail += 1.0f;
    TLOG("RXREJ", "p=%u,why=%s", c->client, rx_name[r < 10 ? r : 1]);
    return;
  }
  rno = (uint16_t)((pt[1] << 8) | pt[2]); op = pt[5] > OP_HIGH ? OP_HIGH : pt[5];
  per = pt[6] ? pt[6] : REPORT_PERIOD_S;
  c->period = per;
  if(pt[0] != FMT_OK) { c->n_noncomp++; if(t >= WARMUP_S) c->fail += 1.0f; }
  else if(c->last_rx && t - c->last_rx < (uint32_t)(per / 2)) { c->n_rate++; if(t >= WARMUP_S) c->fail += 1.0f; }
  else {
    c->rx_ok++; if(t >= WARMUP_S) c->succ += 1.0f;
    c->last_rx = t; c->next_due = t + per + per / 2;
    c->etx_rep = ((pt[3] << 8) | pt[4]) / 100.0f;
    acc = (uint8_t)tr_permitted(c->s_enf, op);
  }
  c->opc[c->s_enf][op][acc]++;
  reply(c, rno, acc);
}

/* ---------------- assignments (network or local) ---------------- */
static void
order_rotation(cl_t *c, const char *src)
{
  if(c->rot_pending) return;
  c->rot_pending = (uint16_t)(c->ctx.ep + 1); c->rot_age = 0; c->due_wait = 0;
  TLOG("ROT_ORDER", "p=%u,ep=%u,src=%s", c->client, c->rot_pending, src);
}

static void
handle_ab(const ab_t *ab, uint32_t lat_ms, int audit)
{
  int i; uint8_t par = (uint8_t)(ab->batch & 1), pro[NC], seen[NC];
  if(ab->batch == batch_no && lat_ms <= 2000) replied = 1;
  have_batch = 1;
  memset(pro, 0, sizeof pro); memset(seen, 0, sizeof seen);
  for(i = 0; i < ab->n; i++) {
    cl_t *c = &cl[ab->e[i].slot]; uint8_t st = ab->e[i].state, prior = sent_sa[par][ab->e[i].slot];
    uint8_t bit = (ab->rot >> ab->e[i].slot) & 1;
    pro[ab->e[i].slot] = (st == ST_REST && prior == ST_FULL);
    s_entries++;
    if(audit && ab->e[i].slot < NC) {                                  /* C1: re-evaluate the deterministic detector on the descriptor this CC sent */
      uint8_t sl = ab->e[i].slot; seen[sl] = 1; s_aud_n++;
      if(!(sent_fl[par][sl] & DF_FULL)) s_aud_extra++;                   /* entry for a descriptor without a full window */
      else { int v = rf_votes_for(&rf_det, sent_q[par][sl], 1); uint8_t ex = (v >= rf_det_k) ? ST_REST : ST_FULL;
             if(st != ex) { if(tr_rank(st) < tr_rank(ex)) s_aud_over++; else s_aud_under++; } }
    }
    if(st != ST_FULL && st != ST_REST) s_alpha_bad++;                 /* outside the authority's output alphabet */
    else if(pro[ab->e[i].slot] && !bit) s_alpha_bad++;                 /* restriction onset without the proactive rotation order */
    c->s_a = st > ST_REV ? ST_REV : st; c->asg_cyc = cyc_no; c->asg_valid = 1; c->asg_new = 1; c->asg_lease = ab->lease < LEASE_MAX ? ab->lease : LEASE_MAX;
    c->last_sa = c->s_a;
    if(c->s_a != ST_FULL) c->last_arestr_cyc = cyc_no;
  }
  if(audit) for(i = 0; i < NC; i++) if((sent_fl[par][i] & DF_FULL) && !seen[i]) { s_aud_n++; s_aud_omit++; }   /* C1: omitted entry */
  for(i = 0; i < NC; i++) {                                            /* rotation orders (any slot) */
    cl_t *c = &cl[i];
    if(!((ab->rot >> i) & 1)) continue;
    if(!pro[i] && c->rot_age + 2 < ROT_PERIOD_CYC && !c->rot_pending) s_spur++;
    if(!autonomous) order_rotation(c, "auth");
  }
  /* periodic orders that are due and missing */
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i];
    if(c->rot_age >= ROT_PERIOD_CYC && !c->rot_pending) {
      s_due++;
      if(++c->due_wait > ROT_GRACE) s_missing++;
    }
  }
}

static void
erx(struct simple_udp_connection *cn, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
    const uint8_t *data, uint16_t len)
{
  uint32_t t = now_s(); int plen = 0, r; uint8_t from = addr_node(sa), ty; uint16_t cid; ab_t ab;
  if(!g_configured || msg_peek(data, len, &ty, &cid) < 0) return;
  if(ty == T_DESC) { if(A.active) auth_on_desc(&A, from, data, len); return; }
  if(ty != T_ASSIGN) return;
  if(from != auth_id) { n_notauth++; TLOG("ASGREJ", "from=%u,why=notauth,auth=%u", from, auth_id); return; }
  if(!actx_ok) { TLOG("ASGREJ", "from=%u,why=noctx", from); return; }
  r = sctx_open(&actx, T_ASSIGN, t, data, len, pt, &plen, NULL);
  if(r == RX_OK && ab_decode(pt, plen, &ab) < 0) r = RX_PARSE;
  if(r == RX_OK && ab.cc != me) r = RX_BIND;
  if(r == RX_OK && (uint16_t)(batch_no - ab.batch) > 1) r = RX_STALE;
  TLOG("ASG", "er=%u,b=%u,rx=%s,lat_ms=%lu", from, r == RX_OK || r == RX_STALE ? ab.batch : 0, rx_name[r], (unsigned long)(now_ms() - batch_t_ms));
  if(r != RX_OK) { n_asg_rej++; return; }
  handle_ab(&ab, now_ms() - batch_t_ms, 1);
}

/* ---------------- overlay receive ---------------- */
static void
orx(struct simple_udp_connection *cn, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
    const uint8_t *data, uint16_t len)
{
  uint32_t t = now_s(); uint8_t from = addr_node(sa), ty; uint16_t cid; int ix = ov_ix(from), plen = 0, r;
  if(!g_configured || ix < 0 || msg_peek(data, len, &ty, &cid) < 0) return;
  if(rx_drop_overlay(from)) return;
  if(ty == T_SHARD) { if(A.active) auth_on_shard(&A, from, data, len); return; }
  r = sctx_open(&cons[ix], ty, t, data, len, pt, &plen, NULL);
  if(r != RX_OK) { TLOG("OVREJ", "from=%u,type=%c,why=%s", from, ty, rx_name[r]); return; }
  heard[ix] = t;
  if(ty == T_STAT) {
    st_t s; if(st_decode(pt, plen, &s) < 0) return;
    st_term[ix] = s.term; st_auth[ix] = s.auth; st_alarm[ix] = s.alarm; st_join[ix] = s.join;
    { uint32_t d = now_ms() - s.t_ms; ov_n++; ov_sum += d; if(d > ov_max) ov_max = d; ov_gt1 += d > 1000; ov_gt2 += d > 2000; ov_gt5 += d > 5000; }
    /* catch-up: f+1 CCs report the same later (term, authority) */
    if(s.term > cur_term && ix != ER2_IX && g_base == BASE_SE) {
      int i, n = 0;
      for(i = 0; i < TT_NCC; i++) if(st_term[i] == s.term && st_auth[i] == s.auth && heard[i]) n++;
      if(n >= g_f + 1) accept_term(s.term, s.auth, "catchup");
    }
  } else if(ty == T_VOTE) {
    vote_t v; if(vote_decode(pt, plen, &v) < 0 || v.voter != from) return;
    if(g_base == BASE_B4) {                                   /* only the candidate counts, majority quorum */
      int r2 = cca_record(&cc_votes, v.term, (uint8_t)(v.voter - TT_FIRST_CC), v.cand);
      TLOG("VOTERX", "term=%u,voter=%u,cand=%u,res=%d", v.term, v.voter, v.cand, r2);
      if(v.cand == me && v.term > cur_term && cca_count(&cc_votes, v.term, me) >= TT_NCC / 2 + 1) {
        take_t tk; uint8_t p[4]; int i, n; tk.term = v.term; tk.auth = me; n = take_encode(&tk, p);
        for(i = 0; i < TT_NCC; i++) ov_send_raw((uint8_t)(TT_FIRST_CC + i), T_TAKE, p, (uint16_t)n, TC_TAKE);
        accept_term(v.term, me, "b4-claim");
      }
      return;
    }
    if(A.active && v.term == A.term && v.cand == me) auth_nudge(&A, from);   /* C5 */
    { /* C9: a peer retransmits its vote only to CCs whose vote it lacks, and stops once it has accepted. A retransmitted
       * vote (already recorded in the open term, or for the term this CC has accepted) is therefore answered with this
       * CC's own vote for that term, at most three times per peer and term, so that an asymmetric loss cannot strand it. */
      int ivx = (int)v.term - (int)cc_votes.base - 1, ixp = ov_ix(from), rep = 0;
      if(g_base == BASE_SE && ixp >= 0 && ixp < TT_NCC && lv_term == v.term && (!is_byz(me) || !byz_active() || (g_bz_flags & BZ_HONESTV))) {
        if(v.term == cur_term && cur_term > 0) rep = 1;
        else if(v.term == join_term && ivx >= 0 && ivx < CCA_WIN && cc_votes.vote[ivx][v.voter - TT_FIRST_CC]) rep = 1;
      }
      if(rep) { if(nk_term != v.term) { nk_term = v.term; memset(nk_n, 0, sizeof(nk_n)); }
                if(nk_n[ixp] < 3) { nk_n[ixp]++; send_vote_to(from, lv_term, lv_cand, 0); TLOG("VOTE_REP", "term=%u,to=%u", lv_term, from); } }
    }
    vote_in(v.term, v.voter, v.cand, 0);
    if(byz_active() && v.term > cur_term) byz_vote(v.term);
  } else if(ty == T_HELLO) {
    hello_t h; if(hello_decode(pt, plen, &h) < 0) return;
    if(h.term == cur_term) process_hello(from, &h);
    else if(h.term > cur_term && from == cand_for(h.term)) { ph.valid = 1; ph.from = from; ph.h = h; TLOG("HELLO_PEND", "from=%u,term=%u,auth=%u", from, h.term, h.auth); }
    else TLOG("HELLO_REJ", "from=%u,term=%u,auth=%u", from, h.term, h.auth);
  } else if(ty == T_HACK) {
    hack_t k; if(hack_decode(pt, plen, &k) < 0) return;
    auth_on_hack(&A, from, &k);
  } else if(ty == T_TAKE) {
    take_t tk; if(take_decode(pt, plen, &tk) < 0) return;
    if((g_base == BASE_B4 || g_base == BASE_B3) && tk.term > cur_term && tk.auth == from) accept_term(tk.term, tk.auth, "claim");
    else TLOG("TAKE_REJ", "from=%u,term=%u", from, tk.term);
  }
}

static float
own_etx(void)
{
  rpl_dag_t *d = rpl_get_any_dag();
  rpl_parent_t *pp = d ? d->preferred_parent : NULL;
  float e = pp ? (float)rpl_get_parent_link_metric(pp) / 128.0f : 1.0f;
  return e < 1.0f ? 1.0f : e;
}

/* ---------------- 15-s cycle ---------------- */
static void
cycle(void)
{
  uint32_t t = now_s(); int i, n;
  float eo = own_etx(), emas[NC];
  db_t db; agim_in_t in; uint8_t r, raised = 0, nh = 0, nr = 0, non = 0, nmiss = 0, u1 = 0, u2 = 0, u3 = 0, u4 = 0, u6 = 0;
  cyc_no++;
  /* 1. substrate: evidence, trust, trajectory, reference, ceiling */
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i];
    if(c->next_due == 0) c->next_due = t + c->period + c->period / 2;
    while(t >= c->next_due) { c->fail += 1.0f; c->next_due += c->period; }
    c->ev_s = (uint8_t)c->succ; c->ev_f = (uint8_t)c->fail;
    c->ev_ex = (uint16_t)((c->etx_rep > 0 ? c->etx_rep : 1.0f) * 100); c->ev_eo = (uint16_t)(eo * 100);
    tr_evidence(P, &c->tr, c->succ, c->fail);
    c->succ = c->fail = 0;
    c->tr.tnet = tr_tnet(P, &c->tr, c->etx_rep > 0 ? c->etx_rep : 1.0f, eo);
  }
  for(i = 0; i < NC; i++) { float tc = 0; int j; for(j = 0; j < NC; j++) if(j != i) tc += cl[j].tr.tdev; tr_compose(P, &cl[i].tr, tc / (NC - 1)); }
  for(i = 0; i < NC; i++) tr_trajectory(P, &cl[i].tr, ref.ref);
  for(i = 0; i < NC; i++) emas[i] = cl[i].tr.ema_init ? cl[i].tr.ema : 1.0f;
  tr_ref_update(&ref, emas, NC, (float)CYCLE_S, P->ref_tau);
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i];
    c->tr.risk = tr_risk(P, c->tr.t, c->tr.m, c->tr.a, c->tr.sigma, ref.ref);
    c->s_loc_prev = c->s_loc;
    if(tr_window_full(&c->tr)) c->s_loc = (uint8_t)tr_policy(P, c->tr.t, c->tr.risk, ref.ref);
    c->rot_age++;
  }
  /* 2. AGIM signals of this cycle */
  memset(&in, 0, sizeof in);
  if(auth_id != me && actx_ok && batch_no > 0) { resp_hist = (uint8_t)(((resp_hist << 1) | (replied ? 0 : 1)) & 0x0F); }
  in.d_resp = popcnt(resp_hist) / 4.0f;
  in.d_alpha = s_entries ? (float)s_alpha_bad / s_entries : 0.0f;
  in.d_audit = s_aud_n ? (float)(s_aud_over + s_aud_under + s_aud_omit + s_aud_extra) / s_aud_n : 0.0f;   /* C1 */
  aud_tot_n += s_aud_n; aud_tot_bad += s_aud_over + s_aud_under + s_aud_omit + s_aud_extra;
  in.d_key = (s_missing + s_spur) ? (float)(s_missing + s_spur) / (s_due > 0 ? s_due : 1) : 0.0f;
  if(in.d_key > 1.0f) in.d_key = 1.0f;
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i];
    int valid = c->asg_valid && (cyc_no - c->asg_cyc) <= c->asg_lease;
    if(valid && c->s_loc == ST_FULL && c->tr.t >= 0.85f && c->tr.m >= 0.0f && c->tr.risk < 0.05f && tr_window_full(&c->tr)) {   /* clearly healthy */
      nh++;
      if(c->asg_new) { if(c->s_a != ST_FULL) { if(c->ur_run < 255) c->ur_run++; } else c->ur_run = 0; }   /* counted per received assignment */
      if(c->ur_run >= g_down_p) nr++;                                   /* restricted by P consecutive assignments while healthy */
      u1 += c->ur_run >= 1; u2 += c->ur_run >= 2; u3 += c->ur_run >= 3; u4 += c->ur_run >= 4; u6 += c->ur_run >= 6;
    } else c->ur_run = 0;
    c->asg_new = 0;
    if(c->s_loc_prev == ST_FULL && c->s_loc != ST_FULL && valid) { non++; if(cyc_no - c->last_arestr_cyc > 8 || c->last_arestr_cyc == 0) nmiss++; }
  }
  in.n_healthy = nh; in.d_down = nh ? (float)nr / nh : 0.0f;
  in.n_onsets = non; in.d_miss = non ? (float)nmiss / non : 0.0f;
  if(auth_id == me) memset(&in, 0, sizeof in);
  if(g_base == BASE_B4) { in.d_alpha = in.d_key = in.d_audit = 0; in.n_healthy = in.n_onsets = 0; in.d_down = in.d_miss = 0; }
  agp.shadow = (g_base == BASE_SHADOW || g_base == BASE_B1 || g_base == BASE_B2 || g_base == BASE_B3) || (is_byz(me) && (g_bz_flags & BZ_SUPPRESS));
  r = agim_step(&ag, &agp, &in, &raised);
  if(raised) { autonomous = 1; stat_dirty = 1; TLOG("ALARM", "term=%u,auth=%u,reason=%u,dr=%d,dd=%d,dm=%d", cur_term, auth_id, ag.reason,
                                                     (int)(in.d_resp * 1000), (int)(ag.down_ewma * 1000), (int)(ag.miss_ewma * 1000)); }
  if(ag.alarm && agim_soft_clear(&ag) && join_term == 0) { agim_clear(&ag); autonomous = 0; stat_dirty = 1; TLOG("ALARM_CLEAR", "term=%u", cur_term); }
  /* 3. enforcement */
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i];
    uint8_t cand, valid = c->asg_valid && (cyc_no - c->asg_cyc) <= c->asg_lease;
    if(g_base == BASE_B1) cand = valid ? c->s_a : c->s_enf;                    /* no ceiling; hold last when no assignment */
    else if(autonomous || !valid) cand = c->s_loc;
    else cand = (uint8_t)tr_min_priv(c->s_loc, c->s_a);
    if(tr_rank(cand) > tr_rank(c->s_enf)) { if(++c->dwell_cnt >= g_dwell) { c->s_enf = cand; c->dwell_cnt = 0; } }
    else { c->s_enf = cand; c->dwell_cnt = 0; }
    if(autonomous && c->rot_age >= ROT_PERIOD_CYC) order_rotation(c, "self");
  }
  /* 4. logs */
  TLOG("AG", "term=%u,auth=%u,auto=%u,al=%u,rs=%u,r=%u,da=%d,dk=%d,dr=%d,dd=%d,dde=%d,dm=%d,dme=%d,nh=%u,no=%u,cnt=%u,ent=%u,due=%u,mis=%u,spur=%u,u1=%u,u2=%u,u3=%u,u4=%u,u6=%u",
       cur_term, auth_id, autonomous, ag.alarm, ag.reason, r, (int)(in.d_alpha * 1000), (int)(in.d_key * 1000), (int)(in.d_resp * 1000),
       (int)(in.d_down * 1000), (int)(ag.down_ewma * 1000), (int)(in.d_miss * 1000), (int)(ag.miss_ewma * 1000), nh, non, ag.cnt,
       s_entries, s_due, s_missing, s_spur, u1, u2, u3, u4, u6);
  TLOG("AUD", "term=%u,auth=%u,an=%u,over=%u,under=%u,omit=%u,extra=%u", cur_term, auth_id, s_aud_n, s_aud_over, s_aud_under, s_aud_omit, s_aud_extra);
  s_alpha_bad = s_entries = s_missing = s_spur = s_due = 0; s_aud_n = s_aud_over = s_aud_under = s_aud_omit = s_aud_extra = 0;
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i]; tr_desc_t d; uint8_t valid = c->asg_valid && (cyc_no - c->asg_cyc) <= c->asg_lease;
    tr_quantise(&c->tr, &d);
    TLOG("TR", "p=%u,es=%u,ef=%u,q=%d;%d;%d;%d;%d;%d;%d;%d,sl=%u,sa=%u,ag=%lu,en=%u,ep=%u,ra=%u,fl=%u",
         c->client, c->ev_s, c->ev_f, d.q[0], d.q[1], d.q[2], d.q[3], d.q[4], d.q[5], d.q[6], d.q[7], c->s_loc,
         valid ? c->s_a : NONE_ST, c->asg_valid ? (unsigned long)(cyc_no - c->asg_cyc) : 999UL, c->s_enf, c->ctx.ep, c->rot_age,
         tr_window_full(&c->tr) ? 1 : 0);
  }
  /* 5. descriptor batch to the authority (or local evaluation when this CC is the authority) */
  if(!auth_id) return;
  memset(&db, 0, sizeof db);
  db.cc = me; db.batch = ++batch_no; db.ref = (int16_t)(ref.ref * TR_Q_T + 0.5f); db.n = NC;
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i]; tr_desc_t d;
    tr_quantise(&c->tr, &d);
    db.e[i].slot = (uint8_t)i; db.e[i].flags = tr_window_full(&c->tr) ? DF_FULL : 0; db.e[i].d = d;
    db.e[i].rot_age = c->rot_pending ? 0 : c->rot_age; db.e[i].last_sa = c->last_sa;
    sent_sa[db.batch & 1][i] = c->last_sa;
    memcpy(sent_q[db.batch & 1][i], d.q, sizeof d.q); sent_fl[db.batch & 1][i] = db.e[i].flags;
  }
  replied = 0; batch_t_ms = now_ms();
  if(auth_id == me) {
    ab_t ab; uint32_t dl; auth_eval(&A, &db, &ab, t, &dl);
    handle_ab(&ab, 0, 0);
    { char st[16]; int j; for(j = 0; j < NCPC; j++) st[j] = '-'; for(j = 0; j < ab.n; j++) st[ab.e[j].slot] = (char)((ab.e[j].v2 ? 'a' : '0') + ab.e[j].state); st[NCPC] = 0;
      TLOG("ERB", "cc=%u,b=%u,term=%u,st=%s,rot=%u,dl=0", me, db.batch, cur_term, st, ab.rot); }
    return;
  }
  if(!actx_ok) return;
  n = db_encode(&db, pt);
  {
    uip_ipaddr_t a; int m = sctx_protect(&actx, T_DESC, pt, (uint16_t)n, buf);
    node_addr(auth_id, &a);
    count_tx(TC_DESC, (uint16_t)m);
    simple_udp_sendto_port(&econn, buf, (uint16_t)m, &a, PORT_ER);
  }
}

/* ---------------- once per second: election, status, Byzantine behaviour ---------------- */
static void
tick(void)
{
  uint32_t t = now_s(); int i, nsus = 0;
  if(A.active) auth_tick(&A);
  if(g_base == BASE_SE || g_base == BASE_B4) {
    /* suspicion count for the current term (own alarm included) */
    if(suspects(&ag) && !(byz_active() && (g_bz_flags & BZ_SUPPRESS))) nsus++;
    if(g_base == BASE_SE) for(i = 0; i < TT_NCC; i++)                 /* suspicion of the current authority: flag set, or already in a later term */
      if(TT_FIRST_CC + i != me && heard[i] && t - heard[i] <= 120 && ((st_term[i] == cur_term && st_alarm[i]) || st_term[i] > cur_term)) nsus++;
    if(!is_byz(me) || (g_bz_flags & BZ_HONESTV) || !byz_active()) {
      if(join_term == 0) {
        if(g_base == BASE_B4 && ag.alarm) join(cur_term + 1, "alarm");                 /* crash-tolerant baseline: own alarm */
        else if(g_base == BASE_SE && nsus >= g_f + 1) join(cur_term + 1, "suspects");   /* f+1 suspicions (own included) */
      }
      if(g_base == BASE_SE) {                                 /* follow f+1 CCs that are already in a later term */
        uint16_t J = 0, cand_j; int a, b, n;
        for(a = 0; a < TT_NCC; a++) {
          cand_j = st_join[a];
          if(!heard[a] || t - heard[a] > 120 || cand_j <= cur_term || cand_j <= join_term || cand_j <= J) continue;
          for(n = 0, b = 0; b < TT_NCC; b++) if(heard[b] && t - heard[b] <= 120 && st_join[b] >= cand_j) n++;
          if(n >= g_f + 1) J = cand_j;
        }
        if(J && join_term) join(J, "catchup");                /* only while campaigning */
      }
      if(join_term && !join_deadline) {                       /* how many CCs are known to be in this term? */
        int a, nin = 1;
        for(a = 0; a < TT_NCC; a++) {
          if(TT_FIRST_CC + a == me) continue;
          if(heard[a] && t - heard[a] <= 120 && (st_join[a] >= join_term || st_term[a] >= join_term)) nin++;
        }
        if(nin >= g_q) { join_deadline = t + ((uint32_t)T_E_S << (attempt < 4 ? attempt : 4)); TLOG("ETIMER", "term=%u,in=%d", join_term, nin); }
      }
      if(join_term && join_deadline && t >= join_deadline) { /* election timeout: next term, next candidate (backoff) */
        uint16_t nt = join_term + 1;
        TLOG("ETIMEOUT", "term=%u", join_term);
        if(attempt < 255) attempt++;
        join(nt, "timeout");
      }
    }
    /* new authority accepted but silent */
    if(cur_term > 0 && auth_id != me && !actx_ok && now_ms() - accept_t > T_HELLO_S * 1000UL && !ag.alarm) {
      ag.alarm = 1; ag.reason = AG_RESP; autonomous = 1; stat_dirty = 1;
      TLOG("ALARM", "term=%u,auth=%u,reason=%u,dr=1000,dd=0,dm=0", cur_term, auth_id, AG_RESP);
    }
  }
  if(byz_active() && g_base == BASE_SE) {
    if((g_bz_flags & BZ_ACCUSE) && byz_voted_term <= cur_term) byz_vote(cur_term + 1);
    if((g_bz_flags & BZ_SELFNOM) && t >= next_selfnom) {
      hello_t h; uint8_t p[12]; int n; h.term = cur_term + 1; h.auth = me; rnd_bytes(h.na, 8); n = hello_encode(&h, p);
      for(i = 0; i < TT_NCC; i++) ov_send_raw((uint8_t)(TT_FIRST_CC + i), T_HELLO, p, (uint16_t)n, TC_TAKE);
      TLOG("BYZNOM", "term=%u", h.term);
      next_selfnom = t + 60;
    }
  }
  if(byz_active() && g_base == BASE_B4 && (g_bz_flags & BZ_SELFNOM) && t >= next_selfnom) {
    take_t tk; uint8_t p[4]; int n; tk.term = cur_term + 1; tk.auth = me; n = take_encode(&tk, p);
    for(i = 0; i < TT_NCC; i++) ov_send_raw((uint8_t)(TT_FIRST_CC + i), T_TAKE, p, (uint16_t)n, TC_TAKE);
    TLOG("BYZNOM", "term=%u,b4=1", tk.term);
    accept_term(tk.term, me, "byz-claim");
    next_selfnom = t + 60;
  }
  /* vote retransmissions: while campaigning (to every CC and the candidate) and, after acceptance, to the new authority until its Hello */
  if((g_base == BASE_SE || g_base == BASE_B4) && lv_term && t >= next_vote_rs) {
    /* C7: retransmission interval 5, 10, 20, 40, then 60 s (each +-20 %), restarted for every new vote; a fixed 5 s interval to
     * every CC without a vote (e.g. f withholding colluders) tripled the overlay load and collapsed the 145-node network */
    { uint32_t b; if(vrs_term != lv_term) { vrs_term = lv_term; vrs_k = 0; }
      b = vrs_k < 4 ? (5u << vrs_k) : 60u; if(vrs_k < 4) vrs_k++;
      next_vote_rs = t + b * 4 / 5 + rnd() % (b * 2 / 5 + 1); }
    if(join_term && lv_term == join_term) {
      if(g_base == BASE_B4) { if(lv_cand != me) send_vote_to(lv_cand, lv_term, lv_cand, 0); }
      else { int iw = (int)lv_term - (int)cc_votes.base - 1;
             for(i = 0; i < TT_NCC; i++) if(TT_FIRST_CC + i != me && !(iw >= 0 && iw < CCA_WIN && cc_votes.vote[iw][i])) send_vote_to((uint8_t)(TT_FIRST_CC + i), lv_term, lv_cand, 0);
             if(ov_ix(lv_cand) == ER2_IX) send_vote_to(lv_cand, lv_term, lv_cand, 0); }
    } else if(lv_term == cur_term && lv_cand == auth_id) {
      if(auth_id != me && !actx_ok) send_vote_to(auth_id, lv_term, lv_cand, 0);
      if(t < acc_resend_until) for(i = 0; i < TT_NCC; i++)       /* help CCs that have not yet seen this term's votes */
        if(TT_FIRST_CC + i != me && !(acc_voted & (1u << i)) && !(heard[i] && st_term[i] >= cur_term)) send_vote_to((uint8_t)(TT_FIRST_CC + i), lv_term, lv_cand, 0);
    }
  }
  { static uint8_t was_sus; uint8_t sus = (uint8_t)suspects(&ag); if(sus != was_sus) { stat_dirty = 1; was_sus = sus; } }   /* C4 */
  if(stat_burst && t >= next_burst) { stat_dirty = 1; stat_burst--; next_burst = t + 5; }   /* repeat the new term a few times */
  if((g_base == BASE_SE || g_base == BASE_B4 || g_base == BASE_SHADOW) && (stat_dirty || t >= next_stat)) send_stat();   /* overlay status: election modes, and shadow mode so that calibration carries the same traffic */
}

PROCESS_THREAD(cc_process, ev, data)
{
  static struct etimer tick_t;
  static uint32_t next_cnt, last_s;
  int i;
  PROCESS_BEGIN();
  se_common_init();
  PROCESS_WAIT_EVENT_UNTIL(ev == g_cfg_event);
  me = (uint8_t)node_id; ccx = (uint8_t)(me - TT_FIRST_CC);
  P = &tr_calibrated;
  simple_udp_register(&conn, PORT_CC, NULL, PORT_CLIENT, rx);
  simple_udp_register(&econn, PORT_ER, NULL, PORT_ER, erx);
  simple_udp_register(&oconn, PORT_OV, NULL, PORT_OV, orx);
  for(i = 0; i < TT_NCC; i++) if(TT_FIRST_CC + i != me) sctx_init(&cons[i], K_CONS, me, (uint8_t)(TT_FIRST_CC + i), 0);
  sctx_init(&cons[ER2_IX], K_CONS, me, TT_STANDBY, 0);
  auth_init(&A, me, cons, &econn, &oconn);
  cca_init(&cc_votes, 0);
  agim_init(&ag); agp.th_r = g_th_r; agp.th_d = g_th_d; agp.th_m = g_th_m; agp.K = g_agim_k; agp.shadow = 0;
  cur_term = 0; auth_id = TT_ER;
  sctx_init(&actx, K_AUTH0, me, TT_ER, 0); actx_ok = 1;
  TLOG("KEY", "peer=%u,kind=%u,ep=0,kid=%02x%02x%02x%02x", TT_ER, K_AUTH0, actx.kid[0], actx.kid[1], actx.kid[2], actx.kid[3]);
  tr_ref_init(&ref);
  for(i = 0; i < NC; i++) {
    cl_t *c = &cl[i];
    memset(c, 0, sizeof *c);
    c->client = tt_members[ccx][i];
    sctx_init(&c->ctx, K_CLIENT, me, c->client, 1);
    tr_init(&c->tr, ((float)CYCLE_S / REPORT_PERIOD_S) / (1.0f - P->lambda));
    c->period = REPORT_PERIOD_S; c->s_loc = c->s_loc_prev = c->s_enf = ST_FULL; c->s_a = ST_FULL; c->last_sa = ST_FULL;
    c->rot_age = (uint16_t)((i * 24 + ccx * 7) % ROT_PERIOD_CYC);          /* staggered periodic rotations */
  }
  next_cnt = 1800; last_s = 0; next_stat = WARMUP_S + (rnd() % 60); next_selfnom = g_onset;   /* C3: desynchronised start */
  etimer_set(&tick_t, CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&tick_t));
    etimer_reset(&tick_t);
    {
      uint32_t t = now_s();
      if(t == last_s) continue;
      last_s = t;
      if(t >= WARMUP_S && (t - WARMUP_S) % CYCLE_S == ccx % CYCLE_S) cycle();
      if(t >= WARMUP_S) tick();
      if(t >= next_cnt) {
        log_counters();
        TLOG("CCSTAT", "audn=%lu,audbad=%lu,term=%u,auth=%u,notauth=%lu,asgrej=%lu,ab=%lu,ad=%lu,arej=%lu,ovn=%lu,ovsum=%lu,ovmax=%lu,ov1=%lu,ov2=%lu,ov5=%lu", (unsigned long)aud_tot_n, (unsigned long)aud_tot_bad, cur_term, auth_id,
             (unsigned long)n_notauth, (unsigned long)n_asg_rej, (unsigned long)A.n_batch, (unsigned long)A.n_desc, (unsigned long)A.n_rej,
             (unsigned long)ov_n, (unsigned long)ov_sum, (unsigned long)ov_max, (unsigned long)ov_gt1, (unsigned long)ov_gt2, (unsigned long)ov_gt5);
        for(i = 0; i < NC; i++) {
          cl_t *c = &cl[i]; char b[160]; int s, o, n = 0;
          for(s = 0; s < 4; s++) for(o = 0; o < 3; o++) n += snprintf(b + n, sizeof b - n, "%lu/%lu;", (unsigned long)c->opc[s][o][1], (unsigned long)c->opc[s][o][0]);
          TLOG("CXSTAT", "p=%u,ok=%lu,bad=%lu,noncomp=%lu,rate=%lu,rot=%lu,seq=%lu,ops=%s", c->client, (unsigned long)c->rx_ok, (unsigned long)c->rx_bad,
               (unsigned long)c->n_noncomp, (unsigned long)c->n_rate, (unsigned long)c->n_rot, (unsigned long)c->ctx.seq, b);
        }
        next_cnt += 1800;
      }
    }
  }
  PROCESS_END();
}
