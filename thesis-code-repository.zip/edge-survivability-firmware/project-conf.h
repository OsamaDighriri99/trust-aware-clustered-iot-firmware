/* SurvivEdge revision build -- Contiki-NG project configuration (Cooja native motes). Recorded in manifests. */
#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_
/* RPL classic, storing mode without multicast (as in the reviewed paper); route tables cover every node */
#define RPL_CONF_MOP                        RPL_MOP_STORING_NO_MULTICAST
#define NBR_TABLE_CONF_MAX_NEIGHBORS        96   /* dense layout: up to 78 nodes within 65 m */
#define NETSTACK_MAX_ROUTE_ENTRIES          160
#define RPL_CONF_WITH_DAO_ACK               0
#define RPL_MRHOF_CONF_MAX_LINK_METRIC      2048
#define UIP_CONF_BUFFER_SIZE                400
#define QUEUEBUF_CONF_NUM                   24
#define UIP_CONF_TCP                        0
#define UIP_CONF_UDP_CONNS                  5
#define LOG_CONF_LEVEL_RPL                  LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_TCPIP                LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_IPV6                 LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_6LOWPAN              LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_MAC                  LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_FRAMER               LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_MAIN                 LOG_LEVEL_WARN
#endif
