/* SurvivEdge -- deployment configuration used ONLY for the flash/RAM measurement on the Zolertia RE-Mote (CC2538, 32 KB RAM,
   512 KB flash). Same stack and features as the Cooja runs, table sizes per role (SE_ROUTES, SE_NBRS from the build line). */
#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_
#define RPL_CONF_MOP                        RPL_MOP_STORING_NO_MULTICAST
/* radio always on (CSMA): use the full 32 KB SRAM instead of the 16-KB retention region needed only for PM2 */
#define LPM_CONF_MAX_PM                     1
#ifndef SE_NBRS
#define SE_NBRS 24
#endif
#ifndef SE_ROUTES
#define SE_ROUTES 16
#endif
#define NBR_TABLE_CONF_MAX_NEIGHBORS        SE_NBRS
#define NETSTACK_MAX_ROUTE_ENTRIES          SE_ROUTES
#define RPL_CONF_WITH_DAO_ACK               0
#define UIP_CONF_BUFFER_SIZE                400
#define QUEUEBUF_CONF_NUM                   8
#define UIP_CONF_TCP                        0
#define UIP_CONF_UDP_CONNS                  5
#define LOG_CONF_LEVEL_RPL                  LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_MAIN                 LOG_LEVEL_WARN
#endif
