/*
 * SurvivEdge revision build -- shared runtime: configuration over the Cooja serial line, logging, PRNG streams,
 * addressing, background client behaviour (substrate degradation waves), scenario schedules (compromise onset,
 * Byzantine CC set, selective-attack targets), controlled loss (A0L, partition), traffic counters.
 * One firmware per role; scenario, seed, baseline and ER2 variant are selected at run time.
 */
#ifndef SE_COMMON_H_
#define SE_COMMON_H_
#include "contiki.h"
#include "net/ipv6/uip.h"
#include "net/ipv6/simple-udp.h"
#include "sys/node-id.h"
#include "se_topology.h"
#include "se_keys.h"
#include "se_proto.h"
#include "trace_policy.h"
#include "trace_rf.h"
#include <stdio.h>
#include <stdint.h>

/* scenarios */
enum { SC_A0, SC_A0L, SC_A1, SC_A2, SC_A3, SC_A4, SC_A5, SC_A6, SC_A7, SC_X1, SC_X2, SC_X3, SC_X4, SC_X5, SC_X6, SC_N };
extern const char *const sc_name[SC_N];
/* baselines */
enum { BASE_SE, BASE_B1, BASE_B2, BASE_B3, BASE_B4, BASE_SHADOW, BASE_N };   /* SHADOW: AGIM logs signals, never alarms (stage A) */
extern const char *const base_name[BASE_N];
/* compromised-authority behaviours (content and timing of its own messages only) */
enum { BEH_NONE, BEH_A1, BEH_SILENT, BEH_A3, BEH_A5, BEH_FWDDROP };
/* Byzantine-CC behaviour flags (own status, suspicion flags and votes only) */
#define BZ_SUPPRESS 0x01   /* never raise Suspect */
#define BZ_ACCUSE   0x02   /* Suspect always set from onset */
#define BZ_EQUIV    0x04   /* in every term: vote for the colluders' candidate to half of the CCs, for cand(term) to the others */
#define BZ_SELFNOM  0x08   /* announce itself as authority (Hello) without a quorum */
#define BZ_FALSEDIG 0x10   /* random shard digest in status messages */
#define BZ_WITHHOLD 0x20   /* never vote */
#define BZ_HONESTV  0x40   /* vote like an honest CC (X6) */

extern char     g_run_id[48];
extern uint8_t  g_sc, g_base, g_er2, g_k, g_dwell;
extern uint32_t g_seed, g_sim_end_s, g_onset;
extern uint8_t  g_configured;
extern process_event_t g_cfg_event;
PROCESS_NAME(se_cfg_process);
void se_common_init(void);

/* derived scenario properties */
extern uint8_t g_er1_beh, g_bz_flags, g_nbyz, g_byz[8], g_f, g_q;
extern uint8_t g_a5_cl[24], g_a5_n;
int  is_byz(uint8_t cc);
float cl_hash(uint8_t client);       /* uniform [0,1) per (seed, client) */
/* AGIM parameters (frozen after stage A; se_params.h) */
extern float g_th_r, g_th_d, g_th_m; extern uint8_t g_agim_k, g_down_p;

uint64_t now_us(void);
static inline uint32_t now_s(void) { return (uint32_t)(now_us() / 1000000ULL); }
static inline uint32_t now_ms(void) { return (uint32_t)(now_us() / 1000ULL); }
#define TLOG(ev, fmt, ...) printf(ev ",n=%u," fmt ",t=%lu\n", (unsigned)node_id, ##__VA_ARGS__, (unsigned long)(now_us() / 1000ULL))

void     rnd_init(void);
uint32_t rnd(void);
float    rndf(void);
void     rnd_bytes(uint8_t *b, uint16_t n);
void     node_addr(uint8_t id, uip_ipaddr_t *a);
uint8_t  addr_node(const uip_ipaddr_t *a);

/* background client degradation waves (TRACE S1 schedule) */
#define WAVE_N      13
#define WAVE_CL     5
#define WAVE_FIRST  3600
#define WAVE_GAP    2700
#define WAVE_LEN    1800
#define DEG_RATE    0.005f
typedef struct { uint32_t onset; uint8_t n; uint8_t cl[WAVE_CL]; } wave_t;
extern wave_t   g_wave[WAVE_N];
extern uint16_t g_loss[32];          /* A0L: permille per 30-min slot */
void schedules_build(void);
void schedules_log(void);
typedef struct { float deliver; float comply; uint8_t in_episode; } beh_t;
void behaviour(uint8_t c, uint32_t t, beh_t *b);
int  rx_drop_app(uint8_t from);      /* A0L loss on client <-> CC links */
int  rx_drop_overlay(uint8_t from);  /* X5 partition of the CC overlay */

#define PORT_CC     5801
#define PORT_CLIENT 5802
#define PORT_ER     5803
#define PORT_OV     5804
#define REPORT_PERIOD_S 30
#define CYCLE_S     15
#define WARMUP_S    300
#define LEASE_MAX   4
#define ROT_PERIOD_CYC 240           /* periodic client-context rotation: 3600 s */
#define ROT_GRACE   2
#define T_E_S       20               /* election timeout (doubles per further term, up to 16x) */
#define T_HELLO_S   15               /* no Hello this long after acceptance -> new authority unresponsive */

enum { TC_APP, TC_ROT, TC_DESC, TC_ASSIGN, TC_STAT, TC_VOTE, TC_TAKE, TC_HB, TC_N };
extern uint32_t g_tx_pkts[TC_N], g_tx_bytes[TC_N];
void count_tx(uint8_t cls, uint16_t len);
void log_counters(void);
/* candidate list: cand(term) given the set of deposed authorities (bit per node id 1..127) */
uint8_t cand_of(uint16_t term, const uint8_t *deposed);
#endif
