/* SurvivEdge revision build -- security contexts. See se_keys.h. */
#include "se_keys.h"
#include <string.h>

const char *const rx_name[10] = { "ok", "parse", "epoch", "auth", "replay", "bind", "stale", "type", "notauth", "noctx" };

/* fixed simulation secrets (experimental provisioning; recorded in the manifest). ER1 firmware uses only ER_PROV. */
static const uint8_t m_client[16] = { 'S','E','-','C','L','I','E','N','T','-','R','O','O','T',0,1 };
static const uint8_t m_erprov[16] = { 'S','E','-','E','R','-','P','R','O','V','I','S','I','O',0,1 };
static const uint8_t m_cons[16]   = { 'S','E','-','C','O','N','S','E','N','S','U','S','-','K',0,1 };
static const uint8_t g_salt[8]    = { 0x53, 0x45, 0x2d, 0x53, 0x41, 0x4c, 0x54, 0x31 };

void
root_secret(uint8_t kind, uint8_t a, uint8_t b, uint8_t ms[16])
{
  const uint8_t *m = kind == K_CLIENT ? m_client : (kind == K_AUTH0 ? m_erprov : m_cons);
  uint8_t ab[3], t[32];
  if(a > b) { uint8_t x = a; a = b; b = x; }
  ab[0] = a; ab[1] = b; ab[2] = kind;
  tc_hmac_sha256(m, 16, (const uint8_t *)"SE-ROOT", 7, ab, 3, NULL, 0, t);
  memcpy(ms, t, 16);
}

static void
kid_of(const tos_keys_t *k, uint8_t kid[4])
{
  tc_sha256_ctx_t h; uint8_t d[32];
  tc_sha256_init(&h); tc_sha256_update(&h, k->skey, TOS_KEY); tc_sha256_update(&h, k->civ, TOS_IV); tc_sha256_final(&h, d);
  memcpy(kid, d, 4);
}

static void
derive(const uint8_t ms[16], uint8_t me, uint8_t peer, uint16_t ep, tos_keys_t *k)
{
  uint8_t idc[2], s[1], r[1];
  idc[0] = (uint8_t)(ep >> 8); idc[1] = (uint8_t)ep;
  s[0] = me; r[0] = peer;
  tos_derive(ms, 16, g_salt, 8, idc, 2, s, 1, r, 1, k);
}

void
sctx_init(sctx_t *c, uint8_t kind, uint8_t me, uint8_t peer, uint16_t ep)
{
  uint8_t ms[16];
  memset(c, 0, sizeof *c);
  c->me = me; c->peer = peer; c->kind = kind; c->ep = ep;
  root_secret(kind, me, peer, ms);
  derive(ms, me, peer, ep, &c->k);
  kid_of(&c->k, c->kid);
  c->valid = 1;
}

void
sctx_init_term(sctx_t *c, uint8_t me, uint8_t peer, uint16_t term, uint8_t auth, const uint8_t na[8], const uint8_t nc[8])
{
  uint8_t root[16], salt[19], ms[16];
  memset(c, 0, sizeof *c);
  c->me = me; c->peer = peer; c->kind = K_AUTHT; c->ep = term;
  root_secret(K_CONS, me, peer, root);
  salt[0] = (uint8_t)(term >> 8); salt[1] = (uint8_t)term; salt[2] = auth;
  memcpy(salt + 3, na, 8); memcpy(salt + 11, nc, 8);
  tc_hkdf(salt, 19, root, 16, (const uint8_t *)"SE-AUTH-T", 9, ms, 16);
  derive(ms, me, peer, term, &c->k);
  kid_of(&c->k, c->kid);
  c->valid = 1;
}

void
sctx_rotate(sctx_t *c, uint16_t ep_new, uint32_t t_now)
{
  uint8_t ms[16];
  if(ep_new == c->ep) return;
  c->ep_prev = c->ep; c->kp = c->k; c->rwp = c->rw; c->prev_valid = 1; c->prev_until = t_now + EP_OVERLAP_S;
  c->ep = ep_new; c->seq = 0; memset(&c->rw, 0, sizeof c->rw);
  root_secret(c->kind, c->me, c->peer, ms);
  derive(ms, c->me, c->peer, ep_new, &c->k);
  kid_of(&c->k, c->kid);
}

int
sctx_protect(sctx_t *c, uint8_t type, const uint8_t *pt, uint16_t len, uint8_t *out)
{
  uint8_t h = 0, piv[5], pl; uint32_t seq = c->seq++;
  out[h++] = type; out[h++] = c->kind;
  out[h++] = (uint8_t)(c->ep >> 8); out[h++] = (uint8_t)c->ep;
  pl = tos_piv_enc(seq, piv);
  out[h++] = pl; memcpy(out + h, piv, pl); h += pl;
  tos_protect(&c->k, seq, out, h, pt, len, out + h);
  return h + len + TOS_TAG;
}

int
msg_peek(const uint8_t *in, uint16_t len, uint8_t *type, uint16_t *ctxid)
{
  if(len < 6 + TOS_TAG) return -1;
  *type = in[0]; *ctxid = (uint16_t)((in[2] << 8) | in[3]);
  return 0;
}

int
sctx_open(sctx_t *c, uint8_t type, uint32_t t_now, const uint8_t *in, uint16_t len, uint8_t *pt, int *plen, uint16_t *ep_out)
{
  uint8_t h = 5, pl, i, hdr[16]; uint16_t ep; uint32_t piv = 0;
  const tos_keys_t *k; tos_replay_t *w;
  if(!c->valid) return RX_NOCTX;
  if(len < 5 + 1 + TOS_TAG) return RX_PARSE;
  if(in[0] != type) return RX_TYPE;
  if(in[1] != c->kind) return RX_EPOCH;
  ep = (uint16_t)((in[2] << 8) | in[3]);
  pl = in[4]; if(pl < 1 || pl > 4) return RX_PARSE;
  for(i = 0; i < pl; i++) piv = (piv << 8) | in[h + i];
  h += pl;
  if(len < h + TOS_TAG) return RX_PARSE;
  if(ep == c->ep) { k = &c->k; w = &c->rw; }
  else if(c->prev_valid && ep == c->ep_prev && t_now < c->prev_until) { k = &c->kp; w = &c->rwp; }
  else return RX_EPOCH;
  memcpy(hdr, in, h);
  if(tos_unprotect(k, piv, hdr, h, in + h, (uint16_t)(len - h), pt) != 0) return RX_AUTH;
  if(!tos_replay_check(w, piv, 1)) return RX_REPLAY;
  tos_replay_check(w, piv, 0);
  *plen = len - h - TOS_TAG;
  if(ep_out) *ep_out = ep;
  return RX_OK;
}
