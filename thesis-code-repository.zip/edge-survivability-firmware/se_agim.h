/* SurvivEdge revision build -- AGIM confirmation state machine (pure C99; firmware, host tests, offline replay).
 * Inputs per CC and cycle (all in [0,1]): d_alpha, d_key (exact signals), d_resp (share of the last 4 batches without
 * a verified current reply within 2 s), d_down (share of healthy clients restricted by the authority in P consecutive assignments), d_miss (share
 * of new ceiling restrictions not preceded by an authority restriction in the last 8 cycles).
 * Rule: exact signal -> ALARM now; otherwise K consecutive anomalous cycles -> ALARM; a normal cycle resets the count.
 * An alarm caused only by d_resp clears after AG_SOFT_CLEAR normal cycles (the CC decides whether it may clear). */
#ifndef SE_AGIM_H_
#define SE_AGIM_H_
#include <stdint.h>

#define AG_ALPHA 0x01
#define AG_KEY   0x02
#define AG_RESP  0x04
#define AG_DOWN  0x08
#define AG_MISS  0x10
#define AG_AUDIT 0x20                /* C1: audit mismatch (exact) */
#define AG_SOFT_CLEAR 8
#define AG_EW_DOWN 0.2f
#define AG_EW_MISS 0.5f            /* ceiling-restriction onsets are rare (a few per CC and hour): two consecutive misses -> 0.75 */

typedef struct { float th_r, th_d, th_m; uint8_t K, shadow; } agim_par_t;
typedef struct {
  float d_alpha, d_key, d_resp, d_down, d_miss, d_audit;
  uint8_t n_healthy, n_onsets;      /* d_down is used only if n_healthy > 0, d_miss only if n_onsets > 0 */
} agim_in_t;
typedef struct {
  float down_ewma, miss_ewma;
  uint8_t cnt, alarm, reason, normal_run;
} agim_t;

void agim_init(agim_t *a);
/* returns the reasons that are anomalous this cycle; *raised = 1 if the alarm was raised in this cycle */
uint8_t agim_step(agim_t *a, const agim_par_t *p, const agim_in_t *in, uint8_t *raised);
/* 1 if the alarm may be cleared (soft alarm, enough normal cycles) */
int agim_soft_clear(const agim_t *a);
void agim_clear(agim_t *a);
#endif
