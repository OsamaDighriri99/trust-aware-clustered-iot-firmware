/* SurvivEdge revision build -- AGIM confirmation state machine. See se_agim.h. */
#include "se_agim.h"
#include <string.h>

void agim_init(agim_t *a) { memset(a, 0, sizeof *a); }
void agim_clear(agim_t *a) { a->alarm = 0; a->reason = 0; a->cnt = 0; a->normal_run = 0; a->down_ewma = 0; a->miss_ewma = 0; }
int agim_soft_clear(const agim_t *a) { return a->alarm && a->reason == AG_RESP && a->normal_run >= AG_SOFT_CLEAR; }

uint8_t
agim_step(agim_t *a, const agim_par_t *p, const agim_in_t *in, uint8_t *raised)
{
  uint8_t r = 0, exact;
  *raised = 0;
  if(in->n_healthy > 0) a->down_ewma = (1.0f - AG_EW_DOWN) * a->down_ewma + AG_EW_DOWN * in->d_down;
  if(in->n_onsets > 0) a->miss_ewma = (1.0f - AG_EW_MISS) * a->miss_ewma + AG_EW_MISS * in->d_miss;
  if(in->d_alpha > 0.0f) r |= AG_ALPHA;
  if(in->d_key > 0.0f) r |= AG_KEY;
  if(in->d_audit > 0.0f) r |= AG_AUDIT;
  if(in->d_resp >= p->th_r) r |= AG_RESP;
  if(a->down_ewma >= p->th_d) r |= AG_DOWN;
  if(a->miss_ewma >= p->th_m) r |= AG_MISS;
  exact = r & (AG_ALPHA | AG_KEY | AG_AUDIT);
  if(a->alarm) {
    if(r) a->normal_run = 0; else if(a->normal_run < 255) a->normal_run++;
    a->reason |= exact ? exact : 0;
    if(r & (AG_DOWN | AG_MISS)) a->reason |= (r & (AG_DOWN | AG_MISS));
    return r;
  }
  if(p->shadow) { a->cnt = r ? (uint8_t)(a->cnt + 1) : 0; return r; }
  if(exact) { a->alarm = 1; a->reason = exact; a->cnt = 0; a->normal_run = 0; *raised = 1; return r; }
  if(r) {
    if(++a->cnt >= p->K) { a->alarm = 1; a->reason = r; a->cnt = 0; a->normal_run = 0; *raised = 1; }
  } else a->cnt = 0;
  return r;
}
