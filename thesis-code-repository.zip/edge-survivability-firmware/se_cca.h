/* SurvivEdge revision build -- CCA vote bookkeeping (pure C99; firmware and host tests).
 * Voters are the N_CC cluster centres (index 0..N-1). For each term in a window above the accepted term the table keeps
 * the first vote received from each voter; a second, different vote of the same voter in the same term is ignored and
 * reported (equivocation evidence). A candidate is accepted for a term when it holds >= q distinct votes. */
#ifndef SE_CCA_H_
#define SE_CCA_H_
#include <stdint.h>

#define CCA_MAXV 16
#define CCA_WIN  12

typedef struct {
  uint16_t base;                           /* accepted term; the window covers base+1 .. base+CCA_WIN */
  uint8_t vote[CCA_WIN][CCA_MAXV];         /* candidate id voted by voter v in term base+1+i (0: none) */
  uint8_t mine[CCA_WIN];                   /* candidate this CC voted for (0: none) -- the persistent vote record */
} cca_t;

#define CCA_NEW   0
#define CCA_DUP   1
#define CCA_CONFL 2
#define CCA_OUT   3
static inline uint8_t cca_f(uint8_t n) { return (uint8_t)((n - 1) / 3); }
static inline uint8_t cca_q(uint8_t n) { return (uint8_t)((n + cca_f(n) + 2) / 2); }   /* ceil((N+f+1)/2) */

void cca_init(cca_t *c, uint16_t base);
void cca_rebase(cca_t *c, uint16_t base);  /* accept term 'base': drop older terms */
int  cca_record(cca_t *c, uint16_t term, uint8_t voter, uint8_t cand);
uint8_t cca_count(const cca_t *c, uint16_t term, uint8_t cand);
/* returns the candidate with >= q votes in 'term' (0 if none) */
uint8_t cca_quorum(const cca_t *c, uint16_t term, uint8_t n, uint8_t q);
/* own vote: 1 if allowed (no earlier vote in this term) and recorded */
int  cca_vote_mine(cca_t *c, uint16_t term, uint8_t cand);
#endif
