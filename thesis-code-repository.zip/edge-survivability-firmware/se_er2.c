/* ER2: same source as ER1 (role by node id) */
#include "se_er.c"
