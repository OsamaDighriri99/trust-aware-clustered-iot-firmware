/* SurvivEdge revision build -- CCA vote bookkeeping. See se_cca.h. */
#include "se_cca.h"
#include <string.h>

void cca_init(cca_t *c, uint16_t base) { memset(c, 0, sizeof *c); c->base = base; }

void
cca_rebase(cca_t *c, uint16_t base)
{
  int s = (int)base - (int)c->base, i;
  if(s <= 0) return;
  for(i = 0; i < CCA_WIN; i++) {
    if(i + s < CCA_WIN) { memcpy(c->vote[i], c->vote[i + s], CCA_MAXV); c->mine[i] = c->mine[i + s]; }
    else { memset(c->vote[i], 0, CCA_MAXV); c->mine[i] = 0; }
  }
  c->base = base;
}

int
cca_record(cca_t *c, uint16_t term, uint8_t voter, uint8_t cand)
{
  int i = (int)term - (int)c->base - 1;
  if(i < 0 || i >= CCA_WIN || voter >= CCA_MAXV || cand == 0) return CCA_OUT;
  if(c->vote[i][voter] == 0) { c->vote[i][voter] = cand; return CCA_NEW; }
  return c->vote[i][voter] == cand ? CCA_DUP : CCA_CONFL;
}

uint8_t
cca_count(const cca_t *c, uint16_t term, uint8_t cand)
{
  int i = (int)term - (int)c->base - 1, v; uint8_t n = 0;
  if(i < 0 || i >= CCA_WIN) return 0;
  for(v = 0; v < CCA_MAXV; v++) n += c->vote[i][v] == cand;
  return n;
}

uint8_t
cca_quorum(const cca_t *c, uint16_t term, uint8_t n, uint8_t q)
{
  int i = (int)term - (int)c->base - 1, v;
  if(i < 0 || i >= CCA_WIN) return 0;
  for(v = 0; v < n && v < CCA_MAXV; v++) {
    uint8_t cand = c->vote[i][v];
    if(cand && cca_count(c, term, cand) >= q) return cand;
  }
  return 0;
}

int
cca_vote_mine(cca_t *c, uint16_t term, uint8_t cand)
{
  int i = (int)term - (int)c->base - 1;
  if(i < 0 || i >= CCA_WIN || c->mine[i]) return 0;
  c->mine[i] = cand;
  return 1;
}
