/* TARP-OSCORE v3.1 -- shared runtime. See tarp_common.h. */
#include "tarp_common.h"
#include "dev/serial-line.h"
#include <string.h>
#include <stdlib.h>

const char *const cfg_name[CFG_N] = { "STATIC", "KUDOS", "C2", "REACTIVE", "C1", "C1C2", "TARP", "REACTCAL" };
char     g_run_id[48] = "UNCONFIGURED";
uint8_t  g_cfg = CFG_TARP, g_scn = SCN_NONE, g_crosscheck = 1;
uint32_t g_seed = 1;
uint16_t g_loss_permille = 0;
uint8_t  g_configured = 0;
process_event_t g_cfg_event;
uint32_t g_tx_pkts[TC_N], g_tx_bytes[TC_N], g_ctl_retx;

uint64_t now_us(void) { return (uint64_t)RTIMER_NOW(); }   /* Cooja native: 1 tick = 1 us of simulated time */

/* ---------------- PRNG (xorshift32) ---------------- */
static uint32_t rs = 1, ss = 1;
static uint32_t xs(uint32_t *s) { *s ^= *s << 13; *s ^= *s >> 17; *s ^= *s << 5; return *s; }
void rnd_init(void)
{
  int i;
  rs = (g_seed * 2654435761u) ^ ((uint32_t)node_id * 40503u) ^ 0x9E3779B9u; if(!rs) rs = 1;
  for(i = 0; i < 8; i++) xs(&rs);
}
uint32_t rnd(void) { return xs(&rs); }
float rndf(void) { return (float)(rnd() >> 8) / 16777216.0f; }
void rnd_bytes(uint8_t *b, uint16_t n) { while(n--) *b++ = (uint8_t)(rnd() >> 11); }
static float sf(void) { return (float)(xs(&ss) >> 8) / 16777216.0f; }

/* ---------------- addressing (Cooja: lladdr = 00 0n 00 0n 00 0n 00 0n) ---------------- */
void node_addr(uint8_t id, uip_ipaddr_t *a) { uip_ip6addr(a, 0xfd00, 0, 0, 0, 0x0200 | id, id, id, id); }
uint8_t addr_node(const uip_ipaddr_t *a) { return a->u8[15]; }

/* ---------------- schedules ---------------- */
deg_episode_t g_deg[DEG_EPISODES];
uint8_t  g_adv[ADV_N];
uint32_t g_adv_start_s = 3600;

void
schedules_build(void)
{
  static const float onset_h[DEG_EPISODES] = { 2.4f, 5.9f, 9.7f };
  int e, i, j;
  ss = (g_seed * 2246822519u) ^ 0x51ED270Bu; if(!ss) ss = 1;
  for(i = 0; i < 8; i++) xs(&ss);
  for(e = 0; e < DEG_EPISODES; e++) {
    deg_episode_t *d = &g_deg[e];
    d->start_s = (uint32_t)(onset_h[e] * 3600.0f + (sf() - 0.5f) * 600.0f);   /* "approximately": +-5 min */
    d->end_s = d->start_s + 600;
    d->n = (uint8_t)(8 + (xs(&ss) % 5));                                         /* 8..12 clients */
    for(i = 0; i < d->n; i++) {
      uint8_t c; int dup;
      do { c = (uint8_t)(12 + xs(&ss) % 100); dup = 0; for(j = 0; j < i; j++) if(d->clients[j] == c) dup = 1; } while(dup);
      d->clients[i] = c;
      d->loss_permille[i] = (uint16_t)(350 + xs(&ss) % 101);                      /* 35..45 % */
    }
    for(i = 0; i < 3; i++) {
      uint8_t k; int dup;
      do { k = (uint8_t)(2 + xs(&ss) % 10); dup = 0; for(j = 0; j < i; j++) if(d->coord_links[j] == k) dup = 1; } while(dup);
      d->coord_links[i] = k;
    }
  }
  /* adversarial clients: one in each of ADV_N distinct clusters */
  {
    uint8_t used[12] = { 0 };
    for(i = 0; i < ADV_N; i++) {
      uint8_t k, s;
      do { k = (uint8_t)(2 + xs(&ss) % 10); } while(used[k]);
      used[k] = 1; s = (uint8_t)(xs(&ss) % 10);
      g_adv[i] = tt_members[k - 2][s];
    }
  }
}

uint16_t
deg_extra_loss(uint8_t c, uint32_t t)
{
  int e, i;
  if(g_scn != SCN_DEGRADE) return 0;
  for(e = 0; e < DEG_EPISODES; e++)
    if(t >= g_deg[e].start_s && t < g_deg[e].end_s)
      for(i = 0; i < g_deg[e].n; i++) if(g_deg[e].clients[i] == c) return g_deg[e].loss_permille[i];
  return 0;
}
float deg_etx_factor_client(uint8_t c, uint32_t t) { (void)c; (void)t; return 1.0f; }
float
deg_etx_factor_coord(uint8_t k, uint32_t t)
{
  int e, i;
  if(g_scn != SCN_DEGRADE) return 1.0f;
  for(e = 0; e < DEG_EPISODES; e++)
    if(t >= g_deg[e].start_s && t < g_deg[e].end_s)
      for(i = 0; i < 3; i++) if(g_deg[e].coord_links[i] == k) return 2.5f;
  return 1.0f;
}
int adv_index(uint8_t c) { int i; for(i = 0; i < ADV_N; i++) if(g_adv[i] == c) return i; return -1; }
float
adv_suppress(uint8_t c, uint32_t t)
{
  if(adv_index(c) < 0 || t < g_adv_start_s) return 0.0f;
  switch(g_scn) {
  case SCN_SELFWD: case SCN_FALSEREP: return 0.5f;
  case SCN_ONOFF: return ((t - g_adv_start_s) % 600) < 120 ? 0.9f : 0.0f;
  default: return 0.0f;
  }
}
int adv_false_etx(uint8_t c, uint32_t t) { return g_scn == SCN_FALSEREP && adv_index(c) >= 0 && t >= g_adv_start_s; }

int
rx_drop(uint8_t from)
{
  uint32_t t = now_s();
  float p = g_loss_permille / 1000.0f, x = 0.0f;
  if(tt_node[node_id].role == TT_COORD && tt_node[from].role == TT_CLIENT) x = deg_extra_loss(from, t) / 1000.0f;
  else if(tt_node[node_id].role == TT_CLIENT && tt_node[from].role == TT_COORD) x = deg_extra_loss((uint8_t)node_id, t) / 1000.0f;
  p = 1.0f - (1.0f - p) * (1.0f - x);
  return p > 0.0f && rndf() < p;
}

/* ---------------- counters ---------------- */
void
count_tx(uint8_t type, uint16_t len, uint8_t retx)
{
  int c = (type == T_DATA || type == T_DACK) ? TC_APP : IS_RE(type) ? TC_RE : TC_CTL;
  g_tx_pkts[c]++; g_tx_bytes[c] += len;
  if(retx) g_ctl_retx++;
}
void
log_counters(void)
{
  TLOG("CNT", "app_p=%lu,app_b=%lu,ctl_p=%lu,ctl_b=%lu,re_p=%lu,re_b=%lu,ctl_retx=%lu",
       (unsigned long)g_tx_pkts[TC_APP], (unsigned long)g_tx_bytes[TC_APP], (unsigned long)g_tx_pkts[TC_CTL],
       (unsigned long)g_tx_bytes[TC_CTL], (unsigned long)g_tx_pkts[TC_RE], (unsigned long)g_tx_bytes[TC_RE], (unsigned long)g_ctl_retx);
}

/* ---------------- configuration over serial ---------------- */
PROCESS(tarp_cfg_process, "TARP config");
static void
parse_cfg(const char *line)
{
  /* "TARPCFG run=<id> cfg=<n> scn=<n> seed=<n> loss=<permille> xchk=<0|1>" */
  const char *p;
  if(strncmp(line, "TARPCFG", 7) != 0 || g_configured) return;
  p = strstr(line, "run="); if(p) { int i = 0; p += 4; while(*p && *p != ' ' && i < (int)sizeof(g_run_id) - 1) g_run_id[i++] = *p++; g_run_id[i] = 0; }
  p = strstr(line, "cfg=");  if(p) g_cfg = (uint8_t)atoi(p + 4);
  p = strstr(line, "scn=");  if(p) g_scn = (uint8_t)atoi(p + 4);
  p = strstr(line, "seed="); if(p) g_seed = (uint32_t)strtoul(p + 5, NULL, 10);
  p = strstr(line, "loss="); if(p) g_loss_permille = (uint16_t)atoi(p + 5);
  p = strstr(line, "xchk="); if(p) g_crosscheck = (uint8_t)atoi(p + 5);
  g_configured = 1;
  rnd_init();
  schedules_build();
  printf("CFG,n=%u,run=%s,cfg=%s,scn=%u,seed=%lu,loss=%u,xchk=%u\n", (unsigned)node_id, g_run_id, cfg_name[g_cfg % CFG_N],
         (unsigned)g_scn, (unsigned long)g_seed, (unsigned)g_loss_permille, (unsigned)g_crosscheck);
  process_post(PROCESS_BROADCAST, g_cfg_event, NULL);
}
PROCESS_THREAD(tarp_cfg_process, ev, data)
{
  static struct etimer bt;
  PROCESS_BEGIN();
  printf("BOOT,n=%u,role=%u\n", (unsigned)node_id, (unsigned)tt_node[node_id].role);
  etimer_set(&bt, CLOCK_SECOND * 2);
  while(1) {
    PROCESS_WAIT_EVENT();
    if(ev == serial_line_event_message && data) parse_cfg((const char *)data);
    else if(ev == PROCESS_EVENT_TIMER && data == &bt && !g_configured) {
      printf("BOOT,n=%u,role=%u\n", (unsigned)node_id, (unsigned)tt_node[node_id].role);
      etimer_reset(&bt);
    }
  }
  PROCESS_END();
}
void tarp_common_init(void) { g_cfg_event = process_alloc_event(); process_start(&tarp_cfg_process, NULL); }
