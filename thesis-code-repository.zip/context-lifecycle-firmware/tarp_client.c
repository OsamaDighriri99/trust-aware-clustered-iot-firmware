/*
 * TARP-OSCORE v3.1 -- client (nodes 12-111): peer endpoint of one pairwise OSCORE context with its
 * coordinator. Sends one protected report every 30 s, takes part in C2 (INIT/ACK/CONFIRM, ABORT, pending expiry,
 * predecessor acceptance, bounded forward recovery), the KUDOS exchange (responder), the Static REFRESH notice and
 * re-establishment. Adversarial behaviour (E3 scenarios) is applied here: report suppression and false ETX evidence.
 */
#include "tarp_common.h"
#include "net/routing/routing.h"
#include "net/routing/rpl-classic/rpl.h"
#include <string.h>

PROCESS(client_process, "TARP client");
AUTOSTART_PROCESSES(&client_process);

/* The peer keeps a prepared successor until it is committed, aborted, or T_OVERLAP + T_DEPR (420 s) have passed:
 * longer than the coordinator's 90-s candidate lifetime, so that a lost CONFIRM is always resolved (by forward
 * recovery) while the coordinator still accepts the peer's previous generation. (See paper Sec. III-D.) */
#define T_PEND_PEER_S 420
#define T_OVERLAP_S  120
#define T_DEPR_S     300

static struct simple_udp_connection conn;
static uip_ipaddr_t coord_addr;
static uint8_t me, coord;

static uint8_t  ms_act[16];
static uint16_t e_act;
static tos_keys_t k_act;
static uint32_t seq_act;
static uint32_t ack_seq;   /* v3.1: sender sequence number used under a prepared successor; carried into it at commit */
static tos_replay_t rw_act;

static uint8_t  prev_valid; static uint16_t e_prev; static tos_keys_t k_prev; static tos_replay_t rw_prev; static uint32_t t_commit;
static uint8_t  pend_valid; static uint16_t e_pend; static uint8_t ms_pend[16]; static tos_keys_t k_pend; static uint32_t t_pend_exp;
/* KUDOS responder state: NEW context derived, OLD (= act) retained until a message verifies under NEW */
static uint8_t  kn_valid; static uint8_t kn_ms[16]; static tos_keys_t kn_keys; static uint8_t kn_n1[8], kn_n2[8]; static uint32_t kn_seq;
static uint16_t reest_no;
static uint16_t report_no;
static uint32_t n_sent, n_suppressed, n_acked, n_rx_rej;

static uint8_t buf[128], pt[96];

static void
send_msg(uint8_t type, uint16_t epoch, const tos_keys_t *k, uint32_t *seq, const uint8_t *nonce8,
         const uint8_t *p, uint16_t plen, uint8_t retx)
{
  int n = msg_build(type, epoch, k, (*seq)++, nonce8, p, plen, buf);
  count_tx(type, (uint16_t)n, retx);
  simple_udp_sendto(&conn, buf, (uint16_t)n, &coord_addr);
}

static void
commit(const char *how)
{
  /* predecessor <- active (keys and replay state; the old Master Secret is erased: ratchet forward secrecy) */
  prev_valid = 1; e_prev = e_act; k_prev = k_act; rw_prev = rw_act; t_commit = now_s();
  e_act = e_pend; memcpy(ms_act, ms_pend, 16); k_act = k_pend;
  seq_act = ack_seq; memset(&rw_act, 0, sizeof rw_act);   /* v3.1: continue the ACK counter, never reuse a nonce under k_act */
  pend_valid = 0; memset(ms_pend, 0, 16);
  TLOG("COMMIT", "role=cl,p=%u,e=%u,how=%s", me, e_act, how);
}

static void
first_hop_etx(uint16_t *etx_x100)
{
  rpl_dag_t *dag = rpl_get_any_dag();                 /* RPL classic (storing mode) */
  rpl_parent_t *pp = dag ? dag->preferred_parent : NULL;
  float etx = pp ? (float)rpl_get_parent_link_metric(pp) / 128.0f : 1.0f;
  if(etx < 1.0f) etx = 1.0f;
  etx *= deg_etx_factor_client(me, now_s());
  if(adv_false_etx(me, now_s())) etx = 1.0f;          /* false (optimistic) evidence */
  *etx_x100 = (uint16_t)(etx * 100.0f);
}

static void
send_report(void)
{
  uint16_t etx;
  report_no++;
  if(rndf() < adv_suppress(me, now_s())) { n_suppressed++; return; }   /* adversarial suppression */
  memset(pt, 0, APP_PAYLOAD);
  pt[0] = (uint8_t)(report_no >> 8); pt[1] = (uint8_t)report_no;
  first_hop_etx(&etx);
  pt[2] = (uint8_t)(etx >> 8); pt[3] = (uint8_t)etx;
  n_sent++;
  if(kn_valid) send_msg(T_DATA, (uint16_t)(e_act + 1), &kn_keys, &kn_seq, NULL, pt, APP_PAYLOAD, 0);   /* KUDOS: NEW once derived */
  else send_msg(T_DATA, e_act, &k_act, &seq_act, NULL, pt, APP_PAYLOAD, 0);
}

/* try to authenticate an incoming coordinator message; returns which generation verified */
#define G_NONE 0
#define G_ACT  1
#define G_PREV 2
#define G_PEND 3
#define G_KNEW 4
static int
open_any(const msg_view_t *v, int *plen)
{
  uint32_t t = now_s();
  if(v->epoch == e_act && (*plen = msg_open(v, &k_act, pt)) >= 0) return tos_replay_check(&rw_act, v->piv, 0) ? G_ACT : -1;
  if(prev_valid && v->epoch == e_prev && t < t_commit + T_OVERLAP_S + T_DEPR_S && (*plen = msg_open(v, &k_prev, pt)) >= 0)
    return tos_replay_check(&rw_prev, v->piv, 0) ? G_PREV : -1;
  if(pend_valid && v->epoch == e_pend && t < t_pend_exp && (*plen = msg_open(v, &k_pend, pt)) >= 0) return G_PEND;
  if(kn_valid && v->epoch == (uint16_t)(e_act + 1) && (*plen = msg_open(v, &kn_keys, pt)) >= 0) return G_KNEW;
  return G_NONE;
}

static void
kudos_commit(void)
{
  prev_valid = 0;                                   /* KUDOS discards CTX_OLD once a message verifies under CTX_NEW */
  e_act = (uint16_t)(e_act + 1); memcpy(ms_act, kn_ms, 16); k_act = kn_keys; seq_act = kn_seq;
  memset(&rw_act, 0, sizeof rw_act); kn_valid = 0; memset(kn_ms, 0, 16);
  TLOG("COMMIT", "role=cl,p=%u,e=%u,how=kudos", me, e_act);
}

static void
rx(struct simple_udp_connection *c, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
   const uint8_t *data, uint16_t len)
{
  msg_view_t v; int g, plen = -1;
  uint8_t from = addr_node(sa);
  if(!g_configured || from != coord) return;
  if(rx_drop(from)) return;
  if(msg_parse(data, len, &v) < 0) return;

  if(IS_RE(v.type)) {                               /* re-establishment (bootstrap credential context) */
    tos_keys_t kb; boot_keys(coord, me, 0, &kb);
    if((plen = msg_open(&v, &kb, pt)) < 3) return;
    if(v.type == T_RE1) {
      static uint32_t bseq; uint8_t r2[45]; memset(r2, 0, sizeof r2); r2[0] = pt[0]; r2[1] = pt[1]; r2[2] = pt[2];
      send_msg(T_RE2, 0, &kb, &bseq, NULL, r2, sizeof r2, 0);
    } else if(v.type == T_RE3) {
      uint16_t rn = (uint16_t)((pt[0] << 8) | pt[1]); uint16_t en = (uint16_t)((pt[2] << 8) | pt[3]);
      if(rn <= reest_no && reest_no) return;
      reest_no = rn;
      pair_root(coord, me, reest_no, ms_act); e_act = en; epoch_keys(ms_act, e_act, coord, me, 0, &k_act);
      seq_act = 0; memset(&rw_act, 0, sizeof rw_act); prev_valid = 0; pend_valid = 0; kn_valid = 0;
      TLOG("REEST_DONE", "role=cl,p=%u,e=%u,rn=%u", me, e_act, reest_no);
    }
    return;
  }

  g = open_any(&v, &plen);
  if(g == G_NONE || g < 0) {
    /* KUDOS request under OLD while NEW exists (retransmission or restart) */
    if(v.type == T_KREQ && kn_valid && v.epoch == e_act && msg_open(&v, &k_act, pt) >= 0) g = G_ACT;
    else { n_rx_rej++; TLOG("RXREJ", "role=cl,p=%u,type=%c,e=%u,act=%u", me, v.type, v.epoch, e_act); return; }
  }
  if(g == G_PEND) {
    /* bounded forward recovery: authenticated message under the prepared, unexpired immediate successor */
    commit(v.type == T_CONFIRM ? "normal" : "fwd");
    if(v.type == T_CONFIRM) return;
  }
  if(g == G_KNEW) kudos_commit();

  switch(v.type) {
  case T_DACK: n_acked++; break;
  case T_INIT: {
    uint16_t en = (uint16_t)((pt[0] << 8) | pt[1]); uint8_t a[2];
    if(g != G_ACT || en != (uint16_t)(e_act + 1) || en == 0) break;
    if(!pend_valid || e_pend != en) {
      ratchet_ms(ms_act, en, ms_pend); epoch_keys(ms_pend, en, coord, me, 0, &k_pend);
      pend_valid = 1; e_pend = en; t_pend_exp = now_s() + T_PEND_PEER_S;
      TLOG("PREPARE", "role=cl,p=%u,e=%u", me, en);
    }
    a[0] = (uint8_t)(en >> 8); a[1] = (uint8_t)en;
    send_msg(T_ACK, en, &k_pend, &ack_seq, NULL, a, 2, 0);   /* ACK proves the successor (key confirmation); v3.1: shared counter */
    break;
  }
  case T_ABORT: {
    uint16_t en = (uint16_t)((pt[0] << 8) | pt[1]);
    if(pend_valid && e_pend == en) { pend_valid = 0; memset(ms_pend, 0, 16); TLOG("PEND_ABORT", "role=cl,p=%u,e=%u", me, en); }
    break;
  }
  case T_REFRESH: {                                 /* Static: one-shot notice, commit immediately, no retention */
    uint16_t en = (uint16_t)((pt[0] << 8) | pt[1]);
    if(en != (uint16_t)(e_act + 1)) break;
    e_act = en; { uint8_t root[16]; pair_root(coord, me, reest_no, root); epoch_keys(root, e_act, coord, me, 0, &k_act); }
    seq_act = 0; memset(&rw_act, 0, sizeof rw_act); prev_valid = 0;
    TLOG("COMMIT", "role=cl,p=%u,e=%u,how=static", me, e_act);
    break;
  }
  case T_KREQ: {                                    /* KUDOS responder */
    static uint8_t r[2] = { 0, 0 };
    if(!kn_valid || memcmp(kn_n1, v.nonce8, 8) != 0) {
      memcpy(kn_n1, v.nonce8, 8); rnd_bytes(kn_n2, 8);
      kudos_update(ms_act, kn_n1, kn_n2, kn_ms); kudos_keys(kn_ms, kn_n1, kn_n2, coord, me, 0, &kn_keys);
      kn_valid = 1; kn_seq = 0;
      TLOG("KUDOS_NEW", "role=cl,p=%u,e=%u", me, e_act + 1);
    }
    send_msg(T_KRESP, (uint16_t)(e_act + 1), &kn_keys, &kn_seq, kn_n2, r, 2, 0);
    break;
  }
  default: break;
  }
}

PROCESS_THREAD(client_process, ev, data)
{
  static struct etimer tick;
  static uint32_t next_report, next_cnt;
  PROCESS_BEGIN();
  tarp_common_init();
  PROCESS_WAIT_EVENT_UNTIL(ev == g_cfg_event);
  me = (uint8_t)node_id; coord = tt_node[me].coord;
  node_addr(coord, &coord_addr);
  simple_udp_register(&conn, PORT_CLIENT, NULL, PORT_COORD, rx);
  pair_root(coord, me, 0, ms_act); e_act = 1; epoch_keys(ms_act, e_act, coord, me, 0, &k_act);
  next_report = 120 + rnd() % REPORT_PERIOD_S;
  next_cnt = 1800;
  etimer_set(&tick, CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&tick));
    etimer_reset(&tick);
    {
      uint32_t t = now_s();
      if(pend_valid && t >= t_pend_exp) { pend_valid = 0; memset(ms_pend, 0, 16); TLOG("PEND_EXPIRE", "role=cl,p=%u,e=%u", me, e_pend); }
      if(prev_valid && t >= t_commit + T_OVERLAP_S + T_DEPR_S) { prev_valid = 0; memset(&k_prev, 0, sizeof k_prev); }
      if(t >= next_report) { send_report(); next_report += REPORT_PERIOD_S; }
      if(t >= next_cnt) {
        log_counters();
        TLOG("CLSTAT", "p=%u,sent=%lu,supp=%lu,acked=%lu,rxrej=%lu,e=%u", me, (unsigned long)n_sent, (unsigned long)n_suppressed,
             (unsigned long)n_acked, (unsigned long)n_rx_rej, e_act);
        next_cnt += 1800;
      }
    }
  }
  PROCESS_END();
}
