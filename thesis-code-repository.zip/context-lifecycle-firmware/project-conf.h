/* TARP-OSCORE v3.1 -- Contiki-NG project configuration (Cooja native motes). Recorded in manifests. */
#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_
/* RPL classic in storing mode, as in OSCORE-IoT; route tables cover every node of the 111-node network */
#define RPL_CONF_MOP                        RPL_MOP_STORING_NO_MULTICAST
/* storing mode: every node keeps a neighbour entry per child; the densest node has 78 radio neighbours */
#define NBR_TABLE_CONF_MAX_NEIGHBORS        80
#define NETSTACK_MAX_ROUTE_ENTRIES          128
/* route stability: no DAO-ACK-triggered local repair (RPL_MRHOF_CONF_MAX_LINK_METRIC applies to RPL-lite only; RPL classic uses its MRHOF default) */
#define RPL_CONF_WITH_DAO_ACK               0
#define RPL_MRHOF_CONF_MAX_LINK_METRIC      2048
#define UIP_CONF_BUFFER_SIZE                256
#define QUEUEBUF_CONF_NUM                   16
#define UIP_CONF_TCP                        0
#define UIP_CONF_UDP_CONNS                  4
#define LOG_CONF_LEVEL_RPL                  LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_TCPIP                LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_IPV6                 LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_6LOWPAN              LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_MAC                  LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_FRAMER               LOG_LEVEL_ERR
#define LOG_CONF_LEVEL_MAIN                 LOG_LEVEL_WARN
#endif
