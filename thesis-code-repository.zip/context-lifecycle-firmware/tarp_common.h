/*
 * TARP-OSCORE v3.1 -- shared runtime: configuration over the Cooja serial line, logging,
 * PRNG streams, node addressing, loss/degradation/adversary schedules, traffic counters, wire format.
 */
#ifndef TARP_COMMON_H_
#define TARP_COMMON_H_
#include "contiki.h"
#include "net/ipv6/uip.h"
#include "net/ipv6/simple-udp.h"
#include "sys/node-id.h"
#include "tarp_crypto.h"
#include "tarp_oscore.h"
#include "tarp_policy.h"
#include "tarp_topology.h"
#include <stdio.h>
#include <stdint.h>

/* ---------------- configurations (one firmware, selected at run time) ---------------- */
#define CFG_STATIC    0   /* fixed 600-s refresh, one-shot REFRESH notice, no retention (baseline) */
#define CFG_KUDOS     1   /* fixed 600-s schedule, KUDOS exchange (baseline, E1) */
#define CFG_C2        2   /* fixed 600-s schedule, TARP C2 transition (E1) */
#define CFG_REACTIVE  3   /* rekey when T_comp < tau_c (+ AEAD usage limit), KUDOS exchange (baseline, E2) */
#define CFG_C1        4   /* C1 decisions, KUDOS exchange (ablation) */
#define CFG_C1C2      5   /* C1 decisions, C2 transition (ablation) */
#define CFG_TARP      6   /* C1 + C2 + C3 + escalation (full) */
#define CFG_REACTCAL  7   /* v1.1: rekey when T_comp < REACT_TH, at most once per REACT_HOLD_S; KUDOS exchange (calibrated reactive baseline) */
#define CFG_N         8
extern const char *const cfg_name[CFG_N];
#define USES_C2(c)    ((c) == CFG_C2 || (c) == CFG_C1C2 || (c) == CFG_TARP)
#define USES_KUDOS(c) ((c) == CFG_KUDOS || (c) == CFG_REACTIVE || (c) == CFG_C1 || (c) == CFG_REACTCAL)
#define USES_C1(c)    ((c) == CFG_C1 || (c) == CFG_C1C2 || (c) == CFG_TARP)
#define FIXED_SCHED(c) ((c) == CFG_STATIC || (c) == CFG_KUDOS || (c) == CFG_C2)

/* scenarios */
#define SCN_NONE      0   /* only the controlled loss L */
#define SCN_DEGRADE   1   /* degradation episodes at 2.4 / 5.9 / 9.7 h (E2) */
#define SCN_SELFWD    2   /* adversarial: selective forwarding (E3) */
#define SCN_ONOFF     3   /* adversarial: on-off misbehaviour (E3) */
#define SCN_FALSEREP  4   /* adversarial: report suppression + false (optimistic) ETX evidence (E3) */
#define SCN_COMPROM   5   /* adversarial: compromise notices from the edge root (E3) */

extern char     g_run_id[48];
extern uint8_t  g_cfg, g_scn, g_crosscheck;
extern uint32_t g_seed;
extern uint16_t g_loss_permille;    /* controlled end-to-end loss L */
extern uint8_t  g_configured;
extern process_event_t g_cfg_event;
PROCESS_NAME(tarp_cfg_process);
void tarp_common_init(void);

uint64_t now_us(void);
static inline uint32_t now_s(void) { return (uint32_t)(now_us() / 1000000ULL); }
#define TLOG(ev, fmt, ...) printf(ev ",n=%u," fmt ",t=%lu\n", (unsigned)node_id, ##__VA_ARGS__, (unsigned long)(now_us() / 1000ULL))

/* PRNG: per-node stream (protocol randomness, loss draws) and a shared schedule stream (same on all nodes) */
void     rnd_init(void);
uint32_t rnd(void);
float    rndf(void);
void     rnd_bytes(uint8_t *b, uint16_t n);

void node_addr(uint8_t id, uip_ipaddr_t *a);
uint8_t addr_node(const uip_ipaddr_t *a);

/* ---------------- schedules (deterministic from the seed; identical on every node) ---------------- */
#define DEG_EPISODES 3
#define DEG_MAXCL    12
typedef struct {
  uint32_t start_s, end_s;
  uint8_t  n, clients[DEG_MAXCL];
  uint16_t loss_permille[DEG_MAXCL];
  uint8_t  coord_links[3];            /* coordinators whose uplink ETX is degraded x2.5 */
} deg_episode_t;
extern deg_episode_t g_deg[DEG_EPISODES];
#define ADV_N 5
extern uint8_t  g_adv[ADV_N];          /* adversarial clients (one per distinct coordinator) */
extern uint32_t g_adv_start_s;
void schedules_build(void);
/* extra drop probability (permille) for traffic to/from client c at time t (degradation episodes) */
uint16_t deg_extra_loss(uint8_t c, uint32_t t);
float    deg_etx_factor_client(uint8_t c, uint32_t t);
float    deg_etx_factor_coord(uint8_t k, uint32_t t);
int      adv_index(uint8_t c);
/* adversarial behaviour of client c at time t: fraction of its own reports it suppresses */
float    adv_suppress(uint8_t c, uint32_t t);
int      adv_false_etx(uint8_t c, uint32_t t);

/* receiver-side drop decision for a datagram from 'from' to this node */
int  rx_drop(uint8_t from);

#include "tarp_keys.h"
#define PORT_COORD  5701
#define PORT_CLIENT 5702
#define PORT_EDGE   5703
#define REPORT_PERIOD_S 30
#define APP_PAYLOAD 24

/* traffic counters (bytes are UDP payload bytes) */
enum { TC_APP, TC_CTL, TC_RE, TC_N };
extern uint32_t g_tx_pkts[TC_N], g_tx_bytes[TC_N], g_ctl_retx;
void count_tx(uint8_t type, uint16_t len, uint8_t retx);
void log_counters(void);

#endif
