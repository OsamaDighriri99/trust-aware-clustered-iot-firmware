/*
 * TARP-OSCORE v3.1 -- coordinator (nodes 2-11): holds one pairwise OSCORE context per client
 * (10 clients), evaluates trust evidence and the lifecycle-request policy every 15 s per context, and executes
 * the selected request with the configured transition procedure:
 *   C2 (TARP): INIT(e) under e_act -> ACK(e) under e_pend -> commit -> CONFIRM(e) under e; retry 15 s x 5,
 *              pending lifetime 90 s, authenticated ABORT, predecessor retained 120 s OVERLAP + 300 s DEPRECATED,
 *              ratcheted epoch derivation;
 *   KUDOS:     KREQ(N1) under OLD -> KRESP(N2) under NEW; initiator completes on verifying KRESP; no non-update
 *              messages from the initiator while the update runs; same retry budget;
 *   Static:    REFRESH(e) under e_act, commit immediately, no retention.
 * Persistent epoch mismatch (two unacceptable messages spanning >= 30 s, no transition running) is logged as a
 * committed-context desynchronisation and repaired by re-establishment (models EDHOC). Escalation and edge-root
 * compromise notices also use re-establishment.
 */
#include "tarp_common.h"
#include "net/routing/routing.h"
#include "net/routing/rpl-classic/rpl.h"
#include <string.h>

PROCESS(coord_process, "TARP coordinator");
AUTOSTART_PROCESSES(&coord_process);

#define NC 10
#define CYCLE_S       15
#define T_ACK_S       15
#define T_RETRY_S     15
#define R_MAX         5
#define T_PENDING_S   (T_ACK_S + R_MAX * T_RETRY_S)
#define T_OVERLAP_S   120
#define T_DEPR_S      300
#define WARMUP_S      300
#define SCHED_S       600
#define REACT_TH      0.70f          /* v1.1: theta_r selected on calibration seeds 101/102, budget 0.01 per context-hour */
#define REACT_HOLD_S  600.0f
#define USAGE_LIMIT   1048576UL      /* AEAD usage limit used by the reactive baseline (never reached at this load) */

#define PS_NONE 0
#define PS_OVERLAP 1
#define PS_DEPR 2

typedef struct {
  uint8_t client;
  uint8_t ms_act[16]; uint16_t e_act; tos_keys_t k_act; uint32_t seq; tos_replay_t rw_act;
  uint8_t prev_state; uint16_t e_prev; tos_keys_t k_prev; tos_replay_t rw_prev; uint32_t t_commit; uint8_t prev_after_re;
  uint8_t pend; uint16_t e_pend; uint8_t ms_pend[16]; tos_keys_t k_pend; uint32_t t_pend; uint8_t retries; uint32_t next_retry;
  uint8_t kud; uint8_t n1[8]; uint32_t kud_t0;
  uint8_t re; uint16_t reest_no, re_e; uint32_t re_t0, re_next, re_last_end; uint8_t re_retries; uint8_t re_reason;
  /* trust and policy */
  tp_state_t tp; float succ, fail; uint32_t last_rx, next_due; float etx_rep;
  uint32_t last_req, last_rk, last_td_commit, last_esc; uint8_t escalated;
  uint32_t sched_next; uint32_t usage;
  uint8_t unacc; uint32_t unacc_t0;
  uint32_t ep_no; uint32_t ep_t0_ms; uint8_t ep_src; uint8_t ep_kind;
  uint32_t rx_ok, rx_rej, rx_rej_life, sup_req;
  uint8_t ev_s, ev_f; uint16_t ev_ex, ev_eo;     /* this cycle's raw evidence (logged for the trace-driven sensitivity analysis) */
} cctx_t;

static cctx_t cx[NC];
static struct simple_udp_connection conn, econn;
static uint8_t me;
static uint8_t buf[128], pt[96];
static tp_params_t P;
/* v3: self-calibrating trust reference. tau_s follows the coordinator's median composite trust with a 1-h time
 * constant, offset by the calibrated margin (tau_s0 - median compliant trust) and clamped to [tau_m, tau_s0], so a
 * sustained network-wide change of the operating point (e.g. background loss) is not read as a trust deficit,
 * while a single context, or a transient episode, still is. */
#define REF_TAU_S       3600.0f      /* time constant of the reference */
#define REF_MARGIN      0.025f       /* tau_s0 (0.95) - median compliant trust in calibration (0.926), rounded */
#define REF_MAD0        0.010f       /* spread (MAD) of smoothed trust in the loss-free calibration runs */
#ifndef REF_K
#define REF_K           6.0f         /* reference moves down by K x excess spread (results/select_k.json, lossy calibration run s103) */
#endif
static float ref_med = 0.0f, ref_mad = REF_MAD0;   /* slow median and median absolute deviation of smoothed trust */
static float
median10(float *v)
{
  float tmp; int i, j;
  for(i = 1; i < NC; i++) { tmp = v[i]; j = i - 1; while(j >= 0 && v[j] > tmp) { v[j + 1] = v[j]; j--; } v[j + 1] = tmp; }
  return (NC % 2) ? v[NC / 2] : 0.5f * (v[NC / 2 - 1] + v[NC / 2]);
}
static void
ref_update(void)
{
  float v[NC], med, mad; int i;
  const float beta = (float)CYCLE_S / REF_TAU_S;
  for(i = 0; i < NC; i++) v[i] = cx[i].tp.ema;
  med = median10(v);
  for(i = 0; i < NC; i++) { v[i] = cx[i].tp.ema - med; if(v[i] < 0) v[i] = -v[i]; }
  mad = median10(v);
  if(ref_med <= 0.0f) ref_med = tp_default.tau_s - REF_MARGIN;
  ref_med += beta * (med - ref_med);
  ref_mad += beta * (mad - ref_mad);
  P.tau_s = ref_med + REF_MARGIN - REF_K * (ref_mad > REF_MAD0 ? ref_mad - REF_MAD0 : 0.0f);
  if(P.tau_s > tp_default.tau_s) P.tau_s = tp_default.tau_s;
  if(P.tau_s < tp_default.tau_m) P.tau_s = tp_default.tau_m;
  P.i_max = P.i_base / P.tau_s;
}
static uint32_t er_pending[NC];

static void
send_to(cctx_t *c, uint8_t type, uint16_t epoch, const tos_keys_t *k, uint32_t *seq, const uint8_t *nonce8,
        const uint8_t *p, uint16_t plen, uint8_t retx)
{
  uip_ipaddr_t a; int n = msg_build(type, epoch, k, (*seq)++, nonce8, p, plen, buf);
  node_addr(c->client, &a);
  count_tx(type, (uint16_t)n, retx);
  simple_udp_sendto_port(&conn, buf, (uint16_t)n, &a, PORT_CLIENT);
}

static int busy(const cctx_t *c) { return c->pend || c->kud || c->re; }

static void
ep_end(cctx_t *c, const char *outcome)
{
  TLOG("EP_END", "p=%u,ep=%lu,kind=%u,src=%s,e=%u,out=%s,retx=%u,dur_ms=%lu", c->client, (unsigned long)c->ep_no, c->ep_kind,
       tp_req_name[c->ep_src], c->pend ? c->e_pend : c->e_act, outcome, c->retries,
       (unsigned long)(now_us() / 1000ULL - c->ep_t0_ms));
}

/* ---------------- re-establishment (models an EDHOC run between coordinator and client) ---------------- */
static void
re_send1(cctx_t *c, uint8_t retx)
{
  tos_keys_t kb; static uint32_t bseq; uint8_t r1[37];
  boot_keys(me, c->client, 1, &kb);
  memset(r1, 0, sizeof r1);
  r1[0] = (uint8_t)(c->reest_no >> 8); r1[1] = (uint8_t)c->reest_no; r1[2] = (uint8_t)(c->re_e >> 8); r1[3] = (uint8_t)c->re_e;
  send_to(c, T_RE1, 0, &kb, &bseq, NULL, r1, sizeof r1, retx);
}
static void
re_start(cctx_t *c, uint8_t reason)
{
  uint32_t t = now_s();
  if(c->re || t < c->re_last_end + 60) return;
  if(c->pend) { ep_end(c, "superseded"); c->pend = 0; }
  if(c->kud) { c->kud = 0; TLOG("KUDOS_ABANDON", "p=%u", c->client); }
  c->re = 1; c->reest_no++; c->re_e = (uint16_t)(c->e_act + 1); c->re_t0 = t; c->re_next = t + T_RETRY_S; c->re_retries = 0; c->re_reason = reason;
  TLOG("REEST_START", "p=%u,rn=%u,reason=%u", c->client, c->reest_no, reason);
  re_send1(c, 0);
}

/* ---------------- C2 ---------------- */
static void
c2_start(cctx_t *c)
{
  uint8_t p2[2];
  uint16_t en = (uint16_t)(c->e_act + 1);
  if(en == 0xFFFF) { re_start(c, 3); return; }     /* epoch exhaustion -> re-establishment */
  ratchet_ms(c->ms_act, en, c->ms_pend); epoch_keys(c->ms_pend, en, me, c->client, 1, &c->k_pend);
  c->pend = 1; c->e_pend = en; c->t_pend = now_s(); c->retries = 0; c->next_retry = c->t_pend + T_ACK_S;
  p2[0] = (uint8_t)(en >> 8); p2[1] = (uint8_t)en;
  send_to(c, T_INIT, c->e_act, &c->k_act, &c->seq, NULL, p2, 2, 0);
}
static void
c2_commit(cctx_t *c)
{
  uint8_t p2[2];
  c->prev_state = PS_OVERLAP; c->e_prev = c->e_act; c->k_prev = c->k_act; c->rw_prev = c->rw_act; c->t_commit = now_s(); c->prev_after_re = 0;
  c->e_act = c->e_pend; memcpy(c->ms_act, c->ms_pend, 16); c->k_act = c->k_pend; c->seq = 0; memset(&c->rw_act, 0, sizeof c->rw_act);
  memset(c->ms_pend, 0, 16);
  ep_end(c, "commit");
  c->pend = 0; c->last_rk = now_s(); c->usage = 0;
  if(tp_trust_driven(c->ep_src)) c->last_td_commit = c->last_rk;
  TLOG("COMMIT", "role=co,p=%u,e=%u,how=normal", c->client, c->e_act);
  p2[0] = (uint8_t)(c->e_act >> 8); p2[1] = (uint8_t)c->e_act;
  send_to(c, T_CONFIRM, c->e_act, &c->k_act, &c->seq, NULL, p2, 2, 0);
}

/* ---------------- KUDOS (coordinator = initiator) ---------------- */
static void
kudos_send(cctx_t *c, uint8_t retx)
{
  static const uint8_t r[2] = { 0, 0 };
  send_to(c, T_KREQ, c->e_act, &c->k_act, &c->seq, c->n1, r, 2, retx);
}
static void
kudos_start(cctx_t *c)
{
  rnd_bytes(c->n1, 8); c->kud = 1; c->kud_t0 = now_s(); c->retries = 0; c->next_retry = c->kud_t0 + T_ACK_S;
  kudos_send(c, 0);
}

/* ---------------- Static ---------------- */
static void
static_refresh(cctx_t *c)
{
  uint8_t p2[2], root[16];
  uint16_t en = (uint16_t)(c->e_act + 1);
  p2[0] = (uint8_t)(en >> 8); p2[1] = (uint8_t)en;
  send_to(c, T_REFRESH, c->e_act, &c->k_act, &c->seq, NULL, p2, 2, 0);
  c->e_act = en; pair_root(me, c->client, c->reest_no, root); epoch_keys(root, en, me, c->client, 1, &c->k_act);
  c->seq = 0; memset(&c->rw_act, 0, sizeof c->rw_act); c->prev_state = PS_NONE;
  c->last_rk = now_s(); c->usage = 0;
  TLOG("COMMIT", "role=co,p=%u,e=%u,how=static", c->client, c->e_act);
  ep_end(c, "sent");
}

/* ---------------- request execution ---------------- */
static void
execute(cctx_t *c, int src)
{
  uint32_t t = now_s();
  if(src == TP_REQ_NONE) return;
  if(busy(c)) { c->sup_req++; return; }
  c->last_req = t;
  c->ep_no++; c->ep_t0_ms = (uint32_t)(now_us() / 1000ULL); c->ep_src = (uint8_t)src;
  TLOG("REQ", "p=%u,src=%s,tc=%d", c->client, tp_req_name[src], (int)(c->tp.tcomp * 1000));
  if(src == TP_REQ_ESCALATE || src == TP_REQ_ER) {
    c->ep_kind = 3;
    if(src == TP_REQ_ESCALATE) {
      uip_ipaddr_t ea; uint8_t m[3] = { T_REQRE, me, c->client };
      c->escalated = 1; c->last_esc = t;
      TLOG("ESCALATE", "p=%u,tc=%d", c->client, (int)(c->tp.tcomp * 1000));
      node_addr(1, &ea); simple_udp_sendto_port(&econn, m, 3, &ea, PORT_EDGE);
    }
    re_start(c, src == TP_REQ_ER ? 2 : 1);
    return;
  }
  if(USES_C2(g_cfg)) { c->ep_kind = 0; c2_start(c); }
  else if(USES_KUDOS(g_cfg)) { c->ep_kind = 1; kudos_start(c); }
  else { c->ep_kind = 2; static_refresh(c); }
}

/* ---------------- receive ---------------- */
static cctx_t *
ctx_of(uint8_t client)
{
  if(client < 12 || client > 111 || tt_node[client].coord != me) return NULL;
  return &cx[tt_node[client].slot];
}

static void
unacceptable(cctx_t *c, const msg_view_t *v)
{
  uint32_t t = now_s();
  c->rx_rej++;
  if(t >= WARMUP_S) c->fail += 1.0f;
  if(v->type == T_DATA && (c->kud || c->pend)) c->rx_rej_life++;
  TLOG("RXREJ", "role=co,p=%u,type=%c,e=%u,act=%u,busy=%u", c->client, v->type, v->epoch, c->e_act, busy(c));
  if(busy(c)) { c->unacc = 0; return; }
  if(c->unacc == 0) c->unacc_t0 = t;
  c->unacc++;
  if(c->unacc >= 2 && t - c->unacc_t0 >= 30) {
    TLOG("DESYNC", "p=%u,e_co=%u,e_rx=%u", c->client, c->e_act, v->epoch);
    c->unacc = 0;
    c->ep_no++; c->ep_t0_ms = (uint32_t)(now_us() / 1000ULL); c->ep_src = TP_REQ_NONE; c->ep_kind = 3;
    re_start(c, 0);
  }
}

static void
rx(struct simple_udp_connection *cn, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
   const uint8_t *data, uint16_t len)
{
  msg_view_t v; int plen = -1; uint32_t t = now_s();
  uint8_t from = addr_node(sa);
  cctx_t *c = ctx_of(from);
  if(!g_configured || !c) return;
  if(rx_drop(from)) return;
  if(msg_parse(data, len, &v) < 0) return;

  if(IS_RE(v.type)) {
    tos_keys_t kb; boot_keys(me, c->client, 1, &kb);
    if(v.type != T_RE2 || !c->re || (plen = msg_open(&v, &kb, pt)) < 2) return;
    if(((pt[0] << 8) | pt[1]) != c->reest_no) return;
    {
      static uint32_t bseq; uint8_t r3[19];
      memset(r3, 0, sizeof r3);
      r3[0] = (uint8_t)(c->reest_no >> 8); r3[1] = (uint8_t)c->reest_no; r3[2] = (uint8_t)(c->re_e >> 8); r3[3] = (uint8_t)c->re_e;
      send_to(c, T_RE3, 0, &kb, &bseq, NULL, r3, sizeof r3, 0);
      /* retain the old context as predecessor so that in-flight client traffic is still accepted;
       * old-epoch traffic after this point triggers a resend of RE3 */
      c->prev_state = PS_OVERLAP; c->e_prev = c->e_act; c->k_prev = c->k_act; c->rw_prev = c->rw_act; c->t_commit = t; c->prev_after_re = 1;
      pair_root(me, c->client, c->reest_no, c->ms_act); c->e_act = c->re_e; epoch_keys(c->ms_act, c->e_act, me, c->client, 1, &c->k_act);
      c->seq = 0; memset(&c->rw_act, 0, sizeof c->rw_act); c->re = 0; c->re_last_end = t; c->last_rk = t; c->usage = 0;
      c->escalated = 0;
      TLOG("REEST_DONE", "role=co,p=%u,e=%u,rn=%u,dur_ms=%lu", c->client, c->e_act, c->reest_no, (unsigned long)(t - c->re_t0) * 1000UL);
    }
    return;
  }

  /* candidate generations: active, predecessor (OVERLAP/DEPRECATED, unexpired), prepared successor (ACK) */
  {
    int g = 0;
    if(v.epoch == c->e_act && (plen = msg_open(&v, &c->k_act, pt)) >= 0) g = tos_replay_check(&c->rw_act, v.piv, 0) ? 1 : -1;
    else if(c->prev_state != PS_NONE && v.epoch == c->e_prev && (plen = msg_open(&v, &c->k_prev, pt)) >= 0) g = tos_replay_check(&c->rw_prev, v.piv, 0) ? 2 : -1;
    else if(c->pend && v.epoch == c->e_pend && v.type == T_ACK && (plen = msg_open(&v, &c->k_pend, pt)) >= 0) g = 3;
    else if(c->kud && v.type == T_KRESP && v.epoch == (uint16_t)(c->e_act + 1) && v.nonce8) {
      uint8_t ms_new[16]; tos_keys_t kn;
      kudos_update(c->ms_act, c->n1, v.nonce8, ms_new); kudos_keys(ms_new, c->n1, v.nonce8, me, c->client, 1, &kn);
      if(msg_open(&v, &kn, pt) >= 0) {
        /* KUDOS initiator completes: CTX_OLD is discarded, CTX_NEW is active */
        c->e_act = (uint16_t)(c->e_act + 1); memcpy(c->ms_act, ms_new, 16); c->k_act = kn; c->seq = 0;
        memset(&c->rw_act, 0, sizeof c->rw_act); tos_replay_check(&c->rw_act, v.piv, 0); c->prev_state = PS_NONE;
        ep_end(c, "commit"); c->kud = 0; c->last_rk = t; c->usage = 0;
        if(tp_trust_driven(c->ep_src)) c->last_td_commit = t;
        TLOG("COMMIT", "role=co,p=%u,e=%u,how=kudos", c->client, c->e_act);
        return;
      }
    }
    if(g <= 0) { unacceptable(c, &v); return; }
    c->unacc = 0;
    if(g == 2 && c->prev_after_re) {               /* client still on the pre-re-establishment context: resend RE3 */
      tos_keys_t kb; static uint32_t bseq2; uint8_t r3[19]; memset(r3, 0, sizeof r3);
      boot_keys(me, c->client, 1, &kb);
      r3[0] = (uint8_t)(c->reest_no >> 8); r3[1] = (uint8_t)c->reest_no; r3[2] = (uint8_t)(c->e_act >> 8); r3[3] = (uint8_t)c->e_act;
      send_to(c, T_RE3, 0, &kb, &bseq2, NULL, r3, sizeof r3, 1);
    }
    switch(v.type) {
    case T_DATA: {
      uint16_t etx = (uint16_t)((pt[2] << 8) | pt[3]);
      c->rx_ok++; c->usage++;
      if(t >= WARMUP_S) { c->succ += 1.0f; c->last_rx = t; c->next_due = t + REPORT_PERIOD_S + REPORT_PERIOD_S / 2; }
      c->etx_rep = etx / 100.0f;
      if(!c->kud) {                                /* KUDOS initiator sends no other messages during the update */
        uint8_t a[2] = { pt[0], pt[1] };
        send_to(c, T_DACK, c->e_act, &c->k_act, &c->seq, NULL, a, 2, 0);
      }
      break;
    }
    case T_ACK:
      if(g == 3 && c->pend && ((pt[0] << 8) | pt[1]) == c->e_pend) c2_commit(c);
      else if(g == 1 && !c->pend && ((pt[0] << 8) | pt[1]) == c->e_act) {   /* duplicate ACK after commit: CONFIRM lost */
        uint8_t p2[2] = { (uint8_t)(c->e_act >> 8), (uint8_t)c->e_act };
        send_to(c, T_CONFIRM, c->e_act, &c->k_act, &c->seq, NULL, p2, 2, 1);
      }
      break;
    default: break;
    }
  }
}

static void
erx(struct simple_udp_connection *cn, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
    const uint8_t *data, uint16_t len)
{
  /* edge-root command channel (assumed authenticated; out of scope): compromise notice for a client */
  cctx_t *c;
  if(len < 2 || data[0] != T_ERCMD) return;
  c = ctx_of(data[1]);
  if(!c) return;
  TLOG("ERCMD_RX", "p=%u", c->client);
  er_pending[tt_node[c->client].slot] = 1;
}

/* ---------------- per-context decision cycle ---------------- */
static float
own_etx(void)
{
  rpl_dag_t *dag = rpl_get_any_dag();                 /* RPL classic (storing mode) */
  rpl_parent_t *pp = dag ? dag->preferred_parent : NULL;
  float e = pp ? (float)rpl_get_parent_link_metric(pp) / 128.0f : 1.0f;
  if(e < 1.0f) e = 1.0f;
  return e * deg_etx_factor_coord(me, now_s());
}

static void
cycle(cctx_t *c)
{
  uint32_t t = now_s();
  float tclust = 0; int i, nm = 0, src = TP_REQ_NONE;
  float since_req, since_rk;
  if(t < WARMUP_S) return;
  if(c->next_due == 0) c->next_due = t + REPORT_PERIOD_S + REPORT_PERIOD_S / 2;
  while(t >= c->next_due) { c->fail += 1.0f; c->next_due += REPORT_PERIOD_S; }   /* missed report deadlines */
  {
    float es = c->succ, ef = c->fail, ex = c->etx_rep > 0 ? c->etx_rep : 1.0f, eo = own_etx();
    tp_evidence(&P, &c->tp, es, ef);
    c->succ = c->fail = 0;
    c->tp.tnet = tp_tnet(&P, &c->tp, ex, eo);
    c->ev_s = (uint8_t)es; c->ev_f = (uint8_t)ef; c->ev_ex = (uint16_t)(ex * 100); c->ev_eo = (uint16_t)(eo * 100);
  }
  for(i = 0; i < NC; i++) if(&cx[i] != c) { tclust += cx[i].tp.tdev; nm++; }
  tp_compose(&P, &c->tp, nm ? tclust / nm : c->tp.tdev);
  tp_c3_update(&P, &c->tp);
  TLOG("TR", "p=%u,es=%u,ef=%u,ex=%u,eo=%u,dv=%d,cl=%d,nt=%d,cp=%d,em=%d,m=%d,a=%d,sg=%d,r=%d,pr=%d", c->client, c->ev_s, c->ev_f, c->ev_ex, c->ev_eo,
       (int)(c->tp.tdev * 1000), (int)(c->tp.tclust * 1000), (int)(c->tp.tnet * 1000), (int)(c->tp.tcomp * 1000),
       (int)(c->tp.ema * 1000), (int)(c->tp.m * 100000), (int)(c->tp.a * 100000), (int)(c->tp.sigma * 1000),
       (int)(c->tp.risk * 1000), (int)(c->tp.pred * 1000));

  since_req = (float)(t - c->last_req); since_rk = (float)(t - c->last_rk);

  /* v1.2: a compromise notice is kept until the context is idle (v1 cleared it even when execute() refused a busy context);
   * v3.1: checked before the escalation wait, so a notice is never held back by an escalation */
  if(er_pending[tt_node[c->client].slot] && !busy(c)) { er_pending[tt_node[c->client].slot] = 0; execute(c, TP_REQ_ER); return; }
  if(c->escalated) return;                          /* waiting for re-establishment */
  switch(g_cfg) {
  case CFG_STATIC: case CFG_KUDOS: case CFG_C2:
    if(t >= c->sched_next) { src = TP_REQ_STATIC; c->sched_next += SCHED_S; }
    break;
  case CFG_REACTIVE:
    if((c->tp.tcomp < P.tau_c && since_req >= P.i_min && since_rk >= P.i_min) || c->usage >= USAGE_LIMIT) src = TP_REQ_REACTIVE;
    break;
  case CFG_REACTCAL:                               /* v1.1: calibrated reactive threshold (results/calibration_reactive.json) */
    if((c->tp.tcomp < REACT_TH && since_req >= REACT_HOLD_S && since_rk >= REACT_HOLD_S) || c->usage >= USAGE_LIMIT) src = TP_REQ_REACTIVE;
    break;
  case CFG_C1: case CFG_C1C2:                      /* ablations: C1 without escalation */
    src = tp_c1_decide(&P, &c->tp, since_rk, since_req);
    break;
  case CFG_TARP:
    src = tp_c3_decide(&P, &c->tp, since_req, since_rk);
    if(src == TP_REQ_NONE) src = tp_c1_decide(&P, &c->tp, since_rk, since_req);
    src = tp_escalate(&P, src, c->last_td_commit ? (float)(t - c->last_td_commit) : 1e9f, c->last_esc ? (float)(t - c->last_esc) : 1e9f);
    break;
  }
  execute(c, src);
}

static void
timers(cctx_t *c)
{
  uint32_t t = now_s();
  if(c->prev_state == PS_OVERLAP && t >= c->t_commit + T_OVERLAP_S) c->prev_state = PS_DEPR;
  if(c->prev_state == PS_DEPR && t >= c->t_commit + T_OVERLAP_S + T_DEPR_S) { c->prev_state = PS_NONE; memset(&c->k_prev, 0, sizeof c->k_prev); }
  if(c->pend) {
    if(t >= c->t_pend + T_PENDING_S) {
      uint8_t p2[2] = { (uint8_t)(c->e_pend >> 8), (uint8_t)c->e_pend };
      ep_end(c, "abort");
      c->pend = 0; memset(c->ms_pend, 0, 16);
      send_to(c, T_ABORT, c->e_act, &c->k_act, &c->seq, NULL, p2, 2, 0);
    } else if(t >= c->next_retry && c->retries < R_MAX) {
      uint8_t p2[2] = { (uint8_t)(c->e_pend >> 8), (uint8_t)c->e_pend };
      c->retries++; c->next_retry += T_RETRY_S; c->fail += 1.0f;
      send_to(c, T_INIT, c->e_act, &c->k_act, &c->seq, NULL, p2, 2, 1);
    }
  }
  if(c->kud) {
    if(t >= c->kud_t0 + T_PENDING_S) { ep_end(c, "abort"); c->kud = 0; }
    else if(t >= c->next_retry && c->retries < R_MAX) { c->retries++; c->next_retry += T_RETRY_S; c->fail += 1.0f; kudos_send(c, 1); }
  }
  if(c->re) {
    if(t >= c->re_t0 + T_PENDING_S) { TLOG("REEST_FAIL", "p=%u,rn=%u", c->client, c->reest_no); c->re = 0; c->re_last_end = t;
                                       c->escalated = 0; }   /* v3.1: a failed re-establishment no longer freezes the context */
    else if(t >= c->re_next && c->re_retries < R_MAX) { c->re_retries++; c->re_next += T_RETRY_S; re_send1(c, 1); }
  }
}

PROCESS_THREAD(coord_process, ev, data)
{
  static struct etimer tick;
  static uint32_t next_cnt, last_s;
  int i;
  PROCESS_BEGIN();
  tarp_common_init();
  PROCESS_WAIT_EVENT_UNTIL(ev == g_cfg_event);
  me = (uint8_t)node_id;
  P = tp_default; P.crosscheck = g_crosscheck;
  simple_udp_register(&conn, PORT_COORD, NULL, PORT_CLIENT, rx);
  simple_udp_register(&econn, PORT_EDGE, NULL, PORT_EDGE, erx);
  for(i = 0; i < NC; i++) {
    cctx_t *c = &cx[i];
    memset(c, 0, sizeof *c);
    c->client = tt_members[me - 2][i];
    pair_root(me, c->client, 0, c->ms_act); c->e_act = 1; epoch_keys(c->ms_act, 1, me, c->client, 1, &c->k_act);
    tp_init(&c->tp);
    /* enrolment: the context starts at the steady-state evidence of a fully compliant client (one report per two cycles) */
    c->tp.s = (REPORT_PERIOD_S > 0 ? (float)CYCLE_S / REPORT_PERIOD_S : 0.5f) / (1.0f - P.lambda);
    c->tp.tdev = (c->tp.s + 1.0f) / (c->tp.s + 2.0f);
    c->sched_next = SCHED_S + rnd() % SCHED_S;      /* fixed schedule with a random phase per context */
    c->last_rk = c->last_req = WARMUP_S;
  }
  next_cnt = 1800; last_s = 0;
  etimer_set(&tick, CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&tick));
    etimer_reset(&tick);
    {
      uint32_t t = now_s();
      if(t == last_s) continue;
      last_s = t;
      if(t >= WARMUP_S + CYCLE_S && t % CYCLE_S == 0) {
        ref_update();
        if(t % 300 == 0) TLOG("TAUREF", "ts=%d,med=%d,mad=%d", (int)(P.tau_s * 1000), (int)(ref_med * 1000), (int)(ref_mad * 1000));
      }
      for(i = 0; i < NC; i++) {
        timers(&cx[i]);
        if((t + (uint32_t)i * 3) % CYCLE_S == 0) cycle(&cx[i]);     /* staggered 15-s decision cycles */
      }
      if(t >= next_cnt) {
        log_counters();
        for(i = 0; i < NC; i++)
          TLOG("CXSTAT", "p=%u,ok=%lu,rej=%lu,rej_life=%lu,sup=%lu,e=%u,ep=%lu", cx[i].client, (unsigned long)cx[i].rx_ok,
               (unsigned long)cx[i].rx_rej, (unsigned long)cx[i].rx_rej_life, (unsigned long)cx[i].sup_req, cx[i].e_act, (unsigned long)cx[i].ep_no);
        next_cnt += 1800;
      }
    }
  }
  PROCESS_END();
}
