/*
 * TARP-OSCORE v3.1 -- edge root (node 1): RPL DODAG root and lifecycle-policy authority. Logs the
 * seeded degradation / adversary schedules, sends compromise notices in the COMPROM scenario, and receives
 * re-establishment requests (escalations) from coordinators. Holds no endpoint key material.
 */
#include "tarp_common.h"
#include "net/routing/routing.h"
#include <string.h>

PROCESS(edge_process, "TARP edge root");
AUTOSTART_PROCESSES(&edge_process);
static struct simple_udp_connection econn;

static void
erx(struct simple_udp_connection *c, const uip_ipaddr_t *sa, uint16_t sp, const uip_ipaddr_t *ra, uint16_t rp,
    const uint8_t *data, uint16_t len)
{
  if(len >= 3 && data[0] == T_REQRE) TLOG("REQRE_RX", "co=%u,p=%u", data[1], data[2]);
}

PROCESS_THREAD(edge_process, ev, data)
{
  static struct etimer tick;
  static uint32_t next_cnt;
  static uint8_t sent[ADV_N];
  int e, i;
  PROCESS_BEGIN();
  NETSTACK_ROUTING.root_start();
  tarp_common_init();
  PROCESS_WAIT_EVENT_UNTIL(ev == g_cfg_event);
  simple_udp_register(&econn, PORT_EDGE, NULL, PORT_EDGE, erx);
  for(e = 0; e < DEG_EPISODES; e++) {
    char cl[200]; int n = 0;
    for(i = 0; i < g_deg[e].n; i++) n += snprintf(cl + n, sizeof cl - n, "%u:%u;", g_deg[e].clients[i], g_deg[e].loss_permille[i]);
    TLOG("DEG_SCHED", "ep=%d,start=%lu,end=%lu,clients=%s,links=%u;%u;%u", e, (unsigned long)g_deg[e].start_s, (unsigned long)g_deg[e].end_s,
         cl, g_deg[e].coord_links[0], g_deg[e].coord_links[1], g_deg[e].coord_links[2]);
  }
  TLOG("ADV_SCHED", "start=%lu,clients=%u;%u;%u;%u;%u", (unsigned long)g_adv_start_s, g_adv[0], g_adv[1], g_adv[2], g_adv[3], g_adv[4]);
  next_cnt = 1800;
  etimer_set(&tick, CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&tick));
    etimer_reset(&tick);
    {
      uint32_t t = now_s();
      if(g_scn == SCN_COMPROM) {
        /* compromise notices: adversaries 0,1 at 2 h, 2,3 at 5 h, 4 at 8 h */
        static const uint32_t at[ADV_N] = { 7200, 7200, 18000, 18000, 28800 };
        for(i = 0; i < ADV_N; i++) if(!sent[i] && t >= at[i]) {
          uip_ipaddr_t a; uint8_t m[2] = { T_ERCMD, g_adv[i] };
          node_addr(tt_node[g_adv[i]].coord, &a);
          simple_udp_sendto_port(&econn, m, 2, &a, PORT_EDGE);
          sent[i] = 1;
          TLOG("ERCMD_TX", "p=%u,co=%u", g_adv[i], tt_node[g_adv[i]].coord);
        }
      }
      if(t >= next_cnt) { log_counters(); next_cnt += 1800; }
    }
  }
  PROCESS_END();
}
